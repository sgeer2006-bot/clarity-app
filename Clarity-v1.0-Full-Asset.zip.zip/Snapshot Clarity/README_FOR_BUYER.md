# README for Buyer — `clarity-for-sale`

Welcome, and thanks for purchasing this codebase. This file is a short, practical setup guide to get the app running on your own infrastructure. For a deeper look at the architecture, components, and data model, see the main `README.md` in this project root.

---

## 1. What you're getting

- The full application source code (`src/`, `public/`)
- The Supabase project scaffolding, including edge functions and migrations (`supabase/`)
- All build configuration (`vite.config.ts`, `tsconfig.*`, `tailwind.config.ts`, `components.json`, `package.json`)
- Project documentation (`docs/`, `README.md`)
- This buyer guide and a separate `MIGRATION_GUIDE.md`

What is **not** included (by design):
- No `.env` files or secrets of any kind
- No database dumps
- No `node_modules`, build outputs, or local caches

You will need to create your own Supabase project and supply your own environment values.

---

## 2. Prerequisites

Install one of the following package managers:

- [Bun](https://bun.sh) (recommended — this project ships a `bun.lock`/`bun.lockb`)
- Or Node.js 18+ with npm

You will also want:

- A free [Supabase](https://supabase.com) account (for the database and edge functions)
- The [Supabase CLI](https://supabase.com/docs/guides/cli) if you plan to use `supabase db push` or deploy edge functions from the command line

---

## 3. Install dependencies

From the project root:

```bash
bun install
```

Or, if you prefer npm:

```bash
npm install
```

---

## 4. Configure environment variables

This repo ships an `.env.example` file. Copy it to a real `.env` file and fill in your own Supabase project values:

```bash
cp .env.example .env
```

Then edit `.env` and set:

```
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-anon-key
VITE_SUPABASE_PROJECT_ID=your-project-ref
```

You can find these values in your Supabase project's **Project Settings → API** page.

---

## 5. Create a new Supabase project

1. Sign in at [supabase.com](https://supabase.com) and click **New project**.
2. Pick a name, a strong database password, and a region close to your users.
3. Once the project is provisioned, copy the **Project URL**, **anon/public key**, and **Project ref** into your `.env` file (see step 4).
4. Set up your database schema. See `MIGRATION_GUIDE.md` for the two supported options (Supabase CLI `db push` from the included `supabase/` folder, or manual recreation from the schema described in `README.md`).

---

## 6. Deploy the edge functions

The `supabase/functions/` folder contains the project's serverless edge functions. To deploy them to your new Supabase project:

```bash
# Sign in once
supabase login

# Link this repo to your new project
supabase link --project-ref your-project-ref

# Deploy all functions in the folder
supabase functions deploy
```

Refer to the [Supabase edge functions docs](https://supabase.com/docs/guides/functions) for per-function deployment, secrets, and logs.

---

## 7. Run the app

Local development:

```bash
bun run dev
```

Production build:

```bash
bun run build
```

(If you're using npm, swap `bun run` for `npm run`.)

The dev server URL will appear in the terminal. Open it in your browser to verify the app boots and connects to your Supabase project.

---

## 8. Next steps

- Read the main `README.md` in this folder for full architecture details, the Supabase schema reference, and any project-specific notes.
- Read `MIGRATION_GUIDE.md` for the two supported approaches to recreating the database.
- Browse `docs/` for any additional design notes shipped with the project.

Happy shipping.
