#!/usr/bin/env bash
# Phase 2 demo walkthrough: lists URLs to manually inspect the premium flow.
set -e
PORT="${PORT:-8080}"
BASE="http://localhost:${PORT}"
echo "Premium demo walkthrough — visit these in the preview:"
echo "  1. ${BASE}/         — FTUE (multi-step) appears once per browser"
echo "  2. ${BASE}/demo/premium       — Premium onboarding demo"
echo "  3. ${BASE}/insights           — Insights (premium variant if entitled)"
echo "  4. ${BASE}/analytics/premium  — Premium analytics dashboard"
echo "  5. ${BASE}/settings/visual    — Premium calm layer toggle / preview"
echo "  6. ${BASE}/dev/features       — Experiment flag toggles (DEV only)"
