#!/usr/bin/env bash
# Phase 2 verification: tsc clean + presence of new files/routes.
set -e
cd "$(dirname "$0")/.."

echo "→ tsc --noEmit"
npx tsc --noEmit

echo "→ checking required files"
for f in \
  src/components/premium/PremiumOnboarding.tsx \
  src/pages/DemoPremiumPage.tsx \
  src/components/ui/CalmLayer/PremiumCalmLayer.tsx \
  src/components/ui/CalmLayer/index.ts \
  src/components/habit/SuccessChip.tsx \
  src/components/habit/ContinuationBadge.tsx \
  src/components/habit/DailyMicroDigestTile.tsx \
  src/pages/InsightsPage.premium.tsx \
  src/pages/AnalyticsPremium.tsx \
  src/lib/flags.ts \
  scripts/demo_premium.sh ; do
  if [ ! -f "$f" ]; then
    echo "MISSING: $f"; exit 1
  fi
done

echo "→ checking routes wired in App.tsx"
for route in '"/demo/premium"' '"/analytics/premium"' '"/insights"' ; do
  grep -q "path=$route" src/App.tsx || { echo "MISSING route $route"; exit 1; }
done

echo "→ Phase 2 verification passed."
