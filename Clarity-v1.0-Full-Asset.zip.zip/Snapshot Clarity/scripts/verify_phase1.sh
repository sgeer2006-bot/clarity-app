#!/usr/bin/env bash
# Phase 1 verification — Clarity restructure.
#
# Reachability sweep (Commit 8). Source-only checks; no dev server.
#
# Structural truth after Phase 1:
#   - "/"        → Insights flow (InsightsFlowPage)
#   - "/reflect" → Conversations (NewSession)
#   - Primary nav: Insights · Reflect · Analytics · More
#   - More menu items live in src/components/nav/MoreMenu.tsx
#   - Settings root at /settings (SettingsIndexPage)
#   - /welcome and /home are NOT routed; /onboarding is the single FTUE
#   - Legacy /patterns/* redirect to anchors on "/"
#
# Exits non-zero on first failure.

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { echo "✗ $1"; exit 1; }
ok()   { echo "✓ $1"; }

echo "› Running tsc --noEmit"
if command -v npx >/dev/null 2>&1; then
  npx --yes tsc --noEmit
elif command -v bunx >/dev/null 2>&1; then
  bunx tsc --noEmit
else
  fail "neither npx nor bunx available"
fi
ok "tsc clean"

APP="src/App.tsx"
MOREMENU="src/components/nav/MoreMenu.tsx"
PRIMARYNAV="src/components/nav/PrimaryNav.tsx"

# --- Home & Reflect ---------------------------------------------------------
grep -q 'path="/" element={<InsightsFlowPage' "$APP" \
  || fail "/ does not render InsightsFlowPage"
ok "/ renders Insights flow"

grep -q 'path="/reflect" element={<NewSession' "$APP" \
  || fail "/reflect does not render NewSession"
ok "/reflect renders Conversations (NewSession)"

# --- FTUE consolidation -----------------------------------------------------
if grep -qE 'path="/(welcome|home)"' "$APP"; then
  fail "/welcome or /home is still routed (should be removed)"
fi
ok "/welcome and /home are not routed"

grep -q 'path="/onboarding"' "$APP" || fail "/onboarding route missing"
ok "/onboarding route mounted"

# --- Settings root ----------------------------------------------------------
grep -q 'path="/settings" element={<SettingsIndexPage' "$APP" \
  || fail "/settings root missing"
ok "/settings root mounted"

# --- Insights & analytics ---------------------------------------------------
grep -q 'path="/insights"' "$APP" || fail "/insights route missing"
ok "/insights route mounted"

grep -q 'path="/dashboard"' "$APP" || fail "/dashboard route missing"
ok "/dashboard (Analytics) route mounted"

# --- Legacy patterns redirects ---------------------------------------------
for p in dashboard timeline heatmap clusters profile; do
  grep -q "path=\"/patterns/${p}\" element={<Navigate" "$APP" \
    || fail "/patterns/${p} not redirecting"
done
ok "/patterns/* legacy paths redirect to anchors on /"

# --- Dev features -----------------------------------------------------------
grep -q 'path="/dev/features"' "$APP" || fail "/dev/features route missing"
ok "/dev/features route mounted"

# --- Primary nav contents ---------------------------------------------------
grep -q 'to: "/", label: "Insights"'      "$PRIMARYNAV" || fail "PrimaryNav missing Insights"
grep -q 'to: "/reflect", label: "Reflect"' "$PRIMARYNAV" || fail "PrimaryNav missing Reflect"
grep -q 'to: "/dashboard", label: "Analytics"' "$PRIMARYNAV" || fail "PrimaryNav missing Analytics"
grep -q '<MoreMenu' "$PRIMARYNAV" || fail "PrimaryNav not rendering <MoreMenu />"
ok "PrimaryNav exposes Insights · Reflect · Analytics · More"

# --- More menu reachability -------------------------------------------------
grep -q 'Two'         "$MOREMENU" || fail "MoreMenu missing Two‑Person"
grep -q 'to="/folders"'      "$MOREMENU" || fail "MoreMenu missing Folders"
grep -q 'to="/history"'      "$MOREMENU" || fail "MoreMenu missing History"
grep -q 'to="/settings/visual"'  "$MOREMENU" || fail "MoreMenu missing Visual Calm"
grep -q 'to="/premium"'      "$MOREMENU" || fail "MoreMenu missing Premium"
grep -q 'to="/settings/billing"' "$MOREMENU" || fail "MoreMenu missing Billing"
grep -q 'to="/safety/resources"' "$MOREMENU" || fail "MoreMenu missing Safety"
grep -q 'to="/settings"'     "$MOREMENU" || fail "MoreMenu missing Settings root"
grep -q 'Sign Out'           "$MOREMENU" || fail "MoreMenu missing Sign Out"
ok "MoreMenu exposes all nine items (incl. Two‑Person, Settings root, Sign Out)"

# --- Stale references -------------------------------------------------------
if rg -n 'to="/welcome"|to="/home"|navigate\("/welcome|navigate\("/home' src/ >/dev/null 2>&1; then
  fail "stale links to /welcome or /home found in src/"
fi
ok "no stale links to /welcome or /home"

echo
echo "Phase 1 verification: PASSED"
