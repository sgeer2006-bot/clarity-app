/**
 * Hybrid Onboarding — client-side user profile store.
 *
 * Mirrors the identity model's persistence approach (localStorage, single
 * cached instance, custom-event broadcast). Additive only — does not touch
 * the identity model's structure or fields.
 */

export type Gender = "male" | "female" | "nonbinary" | "prefer_not_to_say";
export type PersonalityStyle =
  | "reflective"
  | "expressive"
  | "steady"
  | "driven"
  | "curious";
export type StressLevel = 1 | 2 | 3 | 4 | 5;

export interface LightOnboarding {
  age: number | null;
  gender: Gender | null;
  interests: string[];
  goals: string[];
  intentToday: string | null;
  completedAt: string | null;
}

export interface DeepOnboarding {
  personalityStyle: PersonalityStyle | null;
  emotionalTendencies: string[];
  relationshipPatterns: string[];
  stressLevel: StressLevel | null;
  currentChallenges: string[];
  desiredChange: string | null;
  completedAt: string | null;
  skipped: boolean;
}

export interface OnboardingStatus {
  lightCompleted: boolean;
  deepCompleted: boolean;
  deepSkipped: boolean;
  version: 1;
}

export interface UserProfile {
  lightOnboarding: LightOnboarding;
  deepOnboarding: DeepOnboarding;
  onboardingStatus: OnboardingStatus;
}

const STORAGE_KEY = "clarity.userProfile.v1";
const EVENT = "clarity:user-profile-updated";

function freshProfile(): UserProfile {
  return {
    lightOnboarding: {
      age: null,
      gender: null,
      interests: [],
      goals: [],
      intentToday: null,
      completedAt: null,
    },
    deepOnboarding: {
      personalityStyle: null,
      emotionalTendencies: [],
      relationshipPatterns: [],
      stressLevel: null,
      currentChallenges: [],
      desiredChange: null,
      completedAt: null,
      skipped: false,
    },
    onboardingStatus: {
      lightCompleted: false,
      deepCompleted: false,
      deepSkipped: false,
      version: 1,
    },
  };
}

function load(): UserProfile {
  if (typeof window === "undefined") return freshProfile();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return freshProfile();
    const parsed = JSON.parse(raw) as UserProfile;
    if (parsed?.onboardingStatus?.version !== 1) return freshProfile();
    // Defensive merge to tolerate older partial profiles.
    const base = freshProfile();
    return {
      lightOnboarding: { ...base.lightOnboarding, ...parsed.lightOnboarding },
      deepOnboarding: { ...base.deepOnboarding, ...parsed.deepOnboarding },
      onboardingStatus: { ...base.onboardingStatus, ...parsed.onboardingStatus },
    };
  } catch {
    return freshProfile();
  }
}

function save(p: UserProfile): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(p));
    window.dispatchEvent(new CustomEvent(EVENT));
  } catch {
    /* ignore quota */
  }
}

let cached: UserProfile | null = null;
function get(): UserProfile {
  if (!cached) cached = load();
  return cached;
}

/** Public accessor. Returns merged onboarding profile. */
export function getUserProfile(): UserProfile {
  return get();
}

export function updateLightOnboarding(patch: Partial<LightOnboarding>): UserProfile {
  const cur = get();
  const next: UserProfile = {
    ...cur,
    lightOnboarding: { ...cur.lightOnboarding, ...patch },
  };
  cached = next;
  save(next);
  return next;
}

export function updateDeepOnboarding(patch: Partial<DeepOnboarding>): UserProfile {
  const cur = get();
  const next: UserProfile = {
    ...cur,
    deepOnboarding: { ...cur.deepOnboarding, ...patch },
  };
  cached = next;
  save(next);
  return next;
}

export function setOnboardingStatus(patch: Partial<OnboardingStatus>): UserProfile {
  const cur = get();
  const next: UserProfile = {
    ...cur,
    onboardingStatus: { ...cur.onboardingStatus, ...patch, version: 1 },
  };
  cached = next;
  save(next);
  return next;
}

export function completeLightOnboarding(answers: Omit<LightOnboarding, "completedAt">): UserProfile {
  const now = new Date().toISOString();
  const cur = get();
  const next: UserProfile = {
    ...cur,
    lightOnboarding: { ...answers, completedAt: now },
    onboardingStatus: { ...cur.onboardingStatus, lightCompleted: true, version: 1 },
  };
  cached = next;
  save(next);
  return next;
}

export function completeDeepOnboarding(
  answers: Omit<DeepOnboarding, "completedAt" | "skipped">,
): UserProfile {
  const now = new Date().toISOString();
  const cur = get();
  const next: UserProfile = {
    ...cur,
    deepOnboarding: { ...answers, completedAt: now, skipped: false },
    onboardingStatus: { ...cur.onboardingStatus, deepCompleted: true, deepSkipped: false, version: 1 },
  };
  cached = next;
  save(next);
  return next;
}

export function _resetUserProfileForTests(): void {
  cached = null;
  if (typeof window !== "undefined") localStorage.removeItem(STORAGE_KEY);
}

/** Default landing route after onboarding (mirrors existing post-auth landing). */
export const DEFAULT_LANDING_ROUTE = "/home";
