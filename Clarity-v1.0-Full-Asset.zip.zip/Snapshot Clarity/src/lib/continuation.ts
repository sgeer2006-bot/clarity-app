import { supabase } from "@/integrations/supabase/client";
import { FriendlyError } from "@/lib/api";
import { trackEvent } from "@/lib/engineV2";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

export type ContinuationMode = "explore" | "angle" | "context";

export const MODE_LABELS: Record<ContinuationMode, string> = {
  explore: "Explore Deeper",
  angle: "Try Another Angle",
  context: "Add New Context",
};

export const MODE_DESCRIPTIONS: Record<ContinuationMode, string> = {
  explore: "Drill into the most charged thread of what you shared.",
  angle: "Imagine what the other person might be feeling or intending.",
  context: "Add new information and update your snapshot in place.",
};

export const MAX_CONTINUATION_QUESTIONS = 5;

export interface ContinuationStartResponse {
  continuationId: string;
  question: string;
  questionsAsked: number;
  max: number;
  done: boolean;
}

export interface ContinuationNextResponse {
  question?: string;
  questionsAsked: number;
  max: number;
  done: boolean;
  exitReason?: "max_questions_reached" | "no_new_ground" | "fields_saturated";
}

export interface MiniSnapshot {
  title: string;
  summary: string;
  insights: string[];
  changed_sections: Record<string, unknown>;
}

export interface ContinuationFinalizeResponse {
  miniSnapshot: MiniSnapshot;
  snapshotPatched: boolean;
  updatedSnapshot: unknown;
}

async function call<T>(action: string, body: Record<string, unknown>): Promise<T> {
  const { data: sess } = await supabase.auth.getSession();
  const token = sess.session?.access_token;
  if (!token) throw new FriendlyError("auth", "Your session expired. Please sign in again.");

  let resp: Response;
  try {
    resp = await fetch(`${SUPABASE_URL}/functions/v1/continuation-engine`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: ANON_KEY,
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ action, ...body }),
    });
  } catch {
    throw new FriendlyError("network", "We couldn't reach the server. Please try again.");
  }

  let payload: any = null;
  try { payload = await resp.json(); } catch { /* ignore */ }
  if (resp.status === 401) throw new FriendlyError("auth", "Your session expired.");
  if (!resp.ok) throw new FriendlyError("ai", payload?.error || "Continuation engine failed.");
  return payload as T;
}

export async function startContinuation(
  sessionId: string,
  mode: ContinuationMode,
): Promise<ContinuationStartResponse> {
  trackEvent("continuation_started", { sessionId, mode });
  return await call<ContinuationStartResponse>("start", { sessionId, mode });
}

export async function nextContinuation(
  continuationId: string,
  userAnswer: string,
): Promise<ContinuationNextResponse> {
  const r = await call<ContinuationNextResponse>("next", { continuationId, userAnswer });
  if (r.done && r.exitReason) {
    trackEvent("continuation_exited_by_guard", { continuationId, exitReason: r.exitReason });
  }
  return r;
}

export async function finalizeContinuation(
  continuationId: string,
): Promise<ContinuationFinalizeResponse> {
  const r = await call<ContinuationFinalizeResponse>("finalize", { continuationId });
  trackEvent("continuation_completed", { continuationId, snapshotPatched: r.snapshotPatched });
  return r;
}
