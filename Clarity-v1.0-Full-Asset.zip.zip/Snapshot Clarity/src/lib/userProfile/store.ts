/**
 * Server-backed user_profiles store with localStorage cache fallback.
 *
 * Used by the FTUE controller (Parts 1, 2, 3, 4 of clarity_global_pass_v1).
 * Persists onboarding flags & identity_seed per account, with an optimistic
 * local cache so reads are synchronous from the UI's perspective.
 */

import { supabase } from "@/integrations/supabase/client";

export interface UserProfileFlags {
  ftue_a_completed: boolean;
  ftue_a_completed_at: string | null;
  ftue_b_last_shown_at: string | null;
  ftue_enabled: boolean;
  tour_completed: boolean;
  tour_completed_at: string | null;
  identity_seed: string | null;
  identity_seed_at: string | null;
  clarity_plus_intro_dismissed: boolean;
}

const DEFAULTS: UserProfileFlags = {
  ftue_a_completed: false,
  ftue_a_completed_at: null,
  ftue_b_last_shown_at: null,
  ftue_enabled: true,
  tour_completed: false,
  tour_completed_at: null,
  identity_seed: null,
  identity_seed_at: null,
  clarity_plus_intro_dismissed: false,
};

const CACHE_KEY = "clarity.userProfile.server.v1";
const EVENT = "clarity:user-profile-server";

let cache: UserProfileFlags | null = null;

function readCache(): UserProfileFlags {
  if (typeof window === "undefined") return { ...DEFAULTS };
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return { ...DEFAULTS };
    const parsed = JSON.parse(raw) as Partial<UserProfileFlags>;
    return { ...DEFAULTS, ...parsed };
  } catch {
    return { ...DEFAULTS };
  }
}

function writeCache(p: UserProfileFlags) {
  cache = p;
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(p));
    window.dispatchEvent(new CustomEvent(EVENT));
  } catch {
    /* ignore */
  }
}

export function getProfileSync(): UserProfileFlags {
  if (cache) return cache;
  cache = readCache();
  return cache;
}

export async function fetchProfile(): Promise<UserProfileFlags> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) {
    const c = readCache();
    writeCache(c);
    return c;
  }
  const { data, error } = await supabase
    .from("user_profiles")
    .select("*")
    .eq("user_id", auth.user.id)
    .maybeSingle();
  if (error || !data) {
    // Trigger should have created the row; tolerate transient read failure.
    const c = readCache();
    writeCache(c);
    return c;
  }
  const merged: UserProfileFlags = {
    ftue_a_completed: !!data.ftue_a_completed,
    ftue_a_completed_at: data.ftue_a_completed_at,
    ftue_b_last_shown_at: data.ftue_b_last_shown_at,
    ftue_enabled: data.ftue_enabled !== false,
    tour_completed: !!data.tour_completed,
    tour_completed_at: data.tour_completed_at,
    identity_seed: data.identity_seed,
    identity_seed_at: data.identity_seed_at,
    clarity_plus_intro_dismissed: !!data.clarity_plus_intro_dismissed,
  };
  writeCache(merged);
  return merged;
}

export async function patchProfile(
  patch: Partial<UserProfileFlags>,
): Promise<UserProfileFlags> {
  const next: UserProfileFlags = { ...getProfileSync(), ...patch };
  writeCache(next); // optimistic
  const { data: auth } = await supabase.auth.getUser();
  if (auth.user) {
    await supabase
      .from("user_profiles")
      .upsert({ user_id: auth.user.id, ...patch }, { onConflict: "user_id" });
  }
  return next;
}

export function subscribeProfile(cb: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  const handler = () => cb();
  window.addEventListener(EVENT, handler);
  return () => window.removeEventListener(EVENT, handler);
}

export const FTUE_DEFAULTS = DEFAULTS;
