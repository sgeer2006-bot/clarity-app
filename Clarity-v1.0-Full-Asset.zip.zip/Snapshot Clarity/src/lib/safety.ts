// Lightweight client-side crisis detection.
// This is intentionally conservative: it surfaces help, never blocks the user.

export type SafetyCategory =
  | "suicide"
  | "domestic_violence"
  | "substance_use"
  | "gambling"
  | "veterans"
  | "disaster"
  | "general";

export type SafetySeverity = "low" | "medium" | "high";

export interface SafetyMatch {
  category: SafetyCategory;
  severity: SafetySeverity;
  matchedTerms: string[];
}

interface Pattern {
  category: SafetyCategory;
  severity: SafetySeverity;
  // Each term is matched as a whole-word/phrase, case-insensitive.
  terms: string[];
}

const PATTERNS: Pattern[] = [
  {
    category: "suicide",
    severity: "high",
    terms: [
      "kill myself", "suicide", "suicidal", "end my life", "want to die",
      "don't want to live", "do not want to live", "take my own life",
      "better off dead", "no reason to live",
    ],
  },
  {
    category: "suicide",
    severity: "medium",
    terms: [
      "self harm", "self-harm", "self-harming", "self harming",
      "hurt myself", "hurting myself", "harm myself", "harming myself",
      "cutting myself", "cut myself",
    ],
  },
  {
    category: "domestic_violence",
    severity: "high",
    terms: [
      "he hits me", "she hits me", "they hit me", "hits me", "beats me",
      "abuses me", "abusing me", "afraid of my partner", "afraid of him",
      "afraid of her", "threatens me", "chokes me", "strangles me",
    ],
  },
  {
    category: "domestic_violence",
    severity: "medium",
    terms: ["domestic violence", "abusive relationship", "controlling partner"],
  },
  {
    category: "substance_use",
    severity: "medium",
    terms: [
      "drinking too much", "can't stop drinking", "cannot stop drinking",
      "addicted to", "using again", "relapsed", "overdose", "withdrawal",
    ],
  },
  {
    category: "gambling",
    severity: "medium",
    terms: ["gambling problem", "can't stop gambling", "lost everything gambling"],
  },
  {
    category: "veterans",
    severity: "medium",
    terms: ["since i got back from deployment", "after my deployment", "ptsd from combat"],
  },
  {
    category: "disaster",
    severity: "medium",
    terms: ["lost my home in", "after the hurricane", "after the wildfire", "after the flood", "after the earthquake"],
  },
];

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function detectSafety(text: string): SafetyMatch | null {
  if (!text) return null;
  const lower = text.toLowerCase();

  let best: SafetyMatch | null = null;
  const sevRank: Record<SafetySeverity, number> = { low: 0, medium: 1, high: 2 };

  for (const p of PATTERNS) {
    const matched: string[] = [];
    for (const term of p.terms) {
      const re = new RegExp(`(^|[^a-z])${escapeRegex(term)}([^a-z]|$)`, "i");
      if (re.test(lower)) matched.push(term);
    }
    if (matched.length === 0) continue;

    if (!best || sevRank[p.severity] > sevRank[best.severity]) {
      best = { category: p.category, severity: p.severity, matchedTerms: matched };
    }
  }
  return best;
}

export interface Hotline {
  name: string;
  contact: string;
  detail?: string;
  href?: string;
}

export function hotlinesFor(category: SafetyCategory): Hotline[] {
  const universal: Hotline[] = [
    {
      name: "988 Suicide & Crisis Lifeline",
      contact: "Call or text 988",
      detail: "24/7, free, confidential support (US).",
      href: "tel:988",
    },
    {
      name: "Crisis Text Line",
      contact: "Text HOME to 741741",
      detail: "24/7 text support.",
      href: "sms:741741",
    },
  ];

  switch (category) {
    case "domestic_violence":
      return [
        {
          name: "National Domestic Violence Hotline",
          contact: "Call 1-800-799-7233 · Text START to 88788",
          detail: "24/7, confidential, free.",
          href: "tel:18007997233",
        },
        ...universal,
      ];
    case "substance_use":
      return [
        {
          name: "SAMHSA National Helpline",
          contact: "Call 1-800-662-4357",
          detail: "24/7 treatment referral and information (US).",
          href: "tel:18006624357",
        },
        ...universal,
      ];
    case "gambling":
      return [
        {
          name: "National Problem Gambling Helpline",
          contact: "Call or text 1-800-GAMBLER",
          detail: "24/7 confidential support.",
          href: "tel:18004262537",
        },
        ...universal,
      ];
    case "veterans":
      return [
        {
          name: "Veterans Crisis Line",
          contact: "Dial 988 then press 1 · Text 838255",
          detail: "Confidential support for Veterans and their families.",
          href: "tel:988",
        },
        ...universal,
      ];
    case "disaster":
      return [
        {
          name: "SAMHSA Disaster Distress Helpline",
          contact: "Call or text 1-800-985-5990",
          detail: "24/7 crisis counseling for disaster-related distress.",
          href: "tel:18009855990",
        },
        ...universal,
      ];
    case "suicide":
    case "general":
    default:
      return universal;
  }
}

export function categoryLabel(category: SafetyCategory): string {
  switch (category) {
    case "suicide": return "If you're thinking about hurting yourself";
    case "domestic_violence": return "If you feel unsafe with someone close to you";
    case "substance_use": return "If substances are part of what's hard right now";
    case "gambling": return "If gambling is causing harm right now";
    case "veterans": return "Support for Veterans";
    case "disaster": return "Support after a disaster";
    case "general": return "If you need someone to talk to";
  }
}
