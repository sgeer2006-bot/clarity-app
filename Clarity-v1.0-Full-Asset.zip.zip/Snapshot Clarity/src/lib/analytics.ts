import { supabase } from "@/integrations/supabase/client";

export interface UserSummaryStats {
  total_sessions: number;
  completed_sessions: number;
  total_shared: number;
  total_patterns_matched: number;
  unique_patterns: number;
  current_streak_days: number;
}

export interface UserPatternCount {
  pattern_id: string;
  slug: string;
  name: string;
  short_description: string;
  match_count: number;
  last_matched_at: string;
}

export interface ActivityPoint {
  day: string; // YYYY-MM-DD
  session_count: number;
}

export interface RecentSnapshot {
  id: string;
  title: string;
  completed_at: string;
  folder_id: string | null;
}

export interface SharedSnapshot {
  id: string;
  token: string;
  title: string;
  summary: string;
  variant: string;
  view_count: number;
  created_at: string;
  image_path: string | null;
}

export async function fetchSummaryStats(userId: string): Promise<UserSummaryStats | null> {
  const { data, error } = await supabase.rpc("get_user_summary_stats", { _user_id: userId });
  if (error) {
    console.error("fetchSummaryStats", error);
    return null;
  }
  const row = (data as UserSummaryStats[] | null)?.[0];
  return row ?? null;
}

export async function fetchPatternCounts(userId: string): Promise<UserPatternCount[]> {
  const { data, error } = await supabase.rpc("get_user_pattern_counts", { _user_id: userId });
  if (error) {
    console.error("fetchPatternCounts", error);
    return [];
  }
  return (data as UserPatternCount[]) ?? [];
}

export async function fetchActivityTimeline(userId: string, days = 30): Promise<ActivityPoint[]> {
  const { data, error } = await supabase.rpc("get_user_activity_timeline", {
    _user_id: userId,
    _days: days,
  });
  if (error) {
    console.error("fetchActivityTimeline", error);
    return [];
  }
  return (data as ActivityPoint[]) ?? [];
}

export async function fetchRecentSnapshots(limit = 8): Promise<RecentSnapshot[]> {
  const { data, error } = await supabase
    .from("reflection_sessions")
    .select("id, title, completed_at, folder_id")
    .eq("status", "complete")
    .is("deleted_at", null)
    .not("completed_at", "is", null)
    .order("completed_at", { ascending: false })
    .limit(limit);
  if (error) {
    console.error("fetchRecentSnapshots", error);
    return [];
  }
  return (data as RecentSnapshot[]) ?? [];
}

export async function fetchSharedSnapshots(limit = 6): Promise<SharedSnapshot[]> {
  const { data, error } = await supabase
    .from("shared_snapshots")
    .select("id, token, title, summary, variant, view_count, created_at, image_path")
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) {
    console.error("fetchSharedSnapshots", error);
    return [];
  }
  return (data as SharedSnapshot[]) ?? [];
}
