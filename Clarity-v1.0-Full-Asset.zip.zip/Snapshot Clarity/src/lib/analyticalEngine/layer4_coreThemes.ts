/**
 * Layer 4 — Core Themes (replaces "clusters").
 *
 * Wraps existing pe_pattern_clusters data — old cluster code paths are
 * NOT modified or removed. They are simply re-presented as CoreTheme.
 *
 * @deprecated — old "cluster" terminology in upstream tables. Surface via
 *   CoreTheme.
 *
 * If no cluster data is available, falls back to deriving themes from
 * top patterns (heuristic: a theme = a pattern_type group).
 */

import type { CoreTheme } from "./types";
import { type EngineInputs, withDefaults } from "./adapters";
import { _allPatternsForLayer2 } from "./layer2_patterns";

function clamp01(n: number): number { return Math.max(0, Math.min(1, n)); }

export function getCoreThemes(_userId: string, inputs?: EngineInputs): CoreTheme[] {
  void _userId;
  const i = withDefaults(inputs);

  if (i.clusters.length > 0) {
    return i.clusters
      .map<CoreTheme>((c) => ({
        id: `theme:${c.id}`,
        title: c.cluster_label,
        description: c.cluster_summary,
        supportingPatterns: (c.member_pattern_ids ?? []).map((p) => `pat:${p}`),
        confidenceScore: clamp01(Number(c.cohesion_score ?? 0)),
      }))
      .sort((a, b) => b.confidenceScore - a.confidenceScore || a.id.localeCompare(b.id));
  }

  // Fallback: derive themes from grouped patterns. Heuristic v1.
  const all = _allPatternsForLayer2(i);
  if (all.length === 0) return [];
  const groups = new Map<string, typeof all>();
  for (const p of all) {
    const arr = groups.get(p.type) ?? [];
    arr.push(p);
    groups.set(p.type, arr);
  }
  const out: CoreTheme[] = [];
  for (const [type, ps] of groups) {
    if (ps.length < 2) continue;
    const top = ps.slice(0, 5);
    const avg = top.reduce((s, p) => s + p.confidenceScore, 0) / top.length;
    out.push({
      id: `theme:${type}`,
      title: type.replace(/_/g, " "),
      description: `Recurring ${type.replace(/_/g, " ")} pattern grouping.`,
      supportingPatterns: top.map((p) => p.id),
      confidenceScore: clamp01(avg),
    });
  }
  return out.sort((a, b) => b.confidenceScore - a.confidenceScore || a.id.localeCompare(b.id));
}
