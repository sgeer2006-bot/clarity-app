/**
 * Layer 8 — Time + Evolution v1.
 *
 * Inputs: current macroPatterns + optional priorMacroPatterns (prior window).
 * Heuristic: compare frequency between windows; direction is increasing if
 * delta > +20%, decreasing if < -20%, stabilizing otherwise. ConfidenceScore
 * scales with the magnitude of the change capped at 1.
 *
 * If no prior window is provided, returns []. (TODO: derive prior window
 * from timestamped reflections in a later wiring module.)
 */

import type {
  WeekOverWeekShift, PatternEvolution, EmotionalTrend, ShiftDirection,
} from "./types";
import { type EngineInputs, withDefaults } from "./adapters";

function clamp01(n: number): number { return Math.max(0, Math.min(1, n)); }

interface Delta { what: string; type: string; direction: ShiftDirection; confidenceScore: number; }

function computeDeltas(inputs: EngineInputs): Delta[] {
  const i = withDefaults(inputs);
  if (i.priorMacroPatterns.length === 0 || i.macroPatterns.length === 0) return [];
  const prior = new Map<string, number>();
  for (const p of i.priorMacroPatterns) prior.set(`${p.pattern_type}:${p.pattern_label}`, p.raw_count ?? 0);
  const out: Delta[] = [];
  for (const p of i.macroPatterns) {
    const key = `${p.pattern_type}:${p.pattern_label}`;
    const before = prior.get(key) ?? 0;
    const now = p.raw_count ?? 0;
    if (before === 0 && now === 0) continue;
    const delta = (now - before) / Math.max(1, before);
    let direction: ShiftDirection = "stabilizing";
    if (delta > 0.2) direction = "increasing";
    else if (delta < -0.2) direction = "decreasing";
    out.push({
      what: p.pattern_label,
      type: p.pattern_type,
      direction,
      confidenceScore: clamp01(Math.min(1, Math.abs(delta))),
    });
  }
  return out.sort((a, b) => b.confidenceScore - a.confidenceScore || a.what.localeCompare(b.what));
}

export function getWeekOverWeekShifts(_userId: string, inputs?: EngineInputs): WeekOverWeekShift[] {
  void _userId;
  return computeDeltas(inputs ?? {}).map(({ what, direction, confidenceScore }) => ({ what, direction, confidenceScore }));
}

export function getPatternEvolution(_userId: string, inputs?: EngineInputs): PatternEvolution[] {
  void _userId;
  return computeDeltas(inputs ?? {}).map(({ what, direction, confidenceScore }) => ({ what, direction, confidenceScore }));
}

export function getEmotionalTrends(_userId: string, inputs?: EngineInputs): EmotionalTrend[] {
  void _userId;
  return computeDeltas(inputs ?? {})
    .filter((d) => d.type === "emotional_loop" || d.type === "emotion")
    .map(({ what, direction, confidenceScore }) => ({ what, direction, confidenceScore }));
}
