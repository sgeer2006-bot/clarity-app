/**
 * Layer 5 — Self-Understanding Model.
 *
 * Inputs: pe_identity_profile (read-only) + Layer 2/3 patterns/loops.
 * Output: IdentitySignal[] + IdentityTheme[].
 *
 * Heuristic v1:
 *   - Each item in identityProfile.{strengths|vulnerabilities|blind_spots|recurring_triggers}
 *     becomes one IdentitySignal.
 *   - Confidence scales with the number of items in that section
 *     (more items → higher consistency).
 *   - IdentityTheme groups signals by section.
 *
 * Tone: observational, non-prescriptive, non-clinical.
 */

import type { IdentitySignal, IdentityTheme } from "./types";
import { type EngineInputs, withDefaults } from "./adapters";

function clamp01(n: number): number { return Math.max(0, Math.min(1, n)); }
function asArray(v: unknown): string[] {
  if (Array.isArray(v)) return v.filter((x): x is string => typeof x === "string");
  return [];
}

const SECTIONS: Array<{
  key: "strengths" | "vulnerabilities" | "blind_spots" | "recurring_triggers";
  themeTitle: string;
  themeDescription: string;
}> = [
  { key: "strengths", themeTitle: "Strengths", themeDescription: "Tendencies that tend to support you." },
  { key: "vulnerabilities", themeTitle: "Vulnerabilities", themeDescription: "Areas where you tend to feel exposed." },
  { key: "blind_spots", themeTitle: "Blind spots", themeDescription: "Patterns that often go unnoticed." },
  { key: "recurring_triggers", themeTitle: "Recurring triggers", themeDescription: "Situations that often stir something up." },
];

export function getIdentitySignals(_userId: string, inputs?: EngineInputs): IdentitySignal[] {
  void _userId;
  const i = withDefaults(inputs);
  const profile = i.identityProfile;
  if (!profile) return [];
  const out: IdentitySignal[] = [];
  for (const s of SECTIONS) {
    const items = asArray((profile as Record<string, unknown>)[s.key]);
    const max = Math.max(1, items.length);
    items.forEach((label, idx) => {
      out.push({
        id: `id:${s.key}:${idx}`,
        label,
        confidenceScore: clamp01(0.4 + 0.6 * (items.length / Math.max(3, max))),
        supporting: [],
      });
    });
  }
  return out.sort((a, b) => b.confidenceScore - a.confidenceScore || a.id.localeCompare(b.id));
}

export function getIdentityThemes(_userId: string, inputs?: EngineInputs): IdentityTheme[] {
  void _userId;
  const i = withDefaults(inputs);
  const profile = i.identityProfile;
  if (!profile) return [];
  const out: IdentityTheme[] = [];
  for (const s of SECTIONS) {
    const items = asArray((profile as Record<string, unknown>)[s.key]);
    if (items.length === 0) continue;
    out.push({
      id: `idTheme:${s.key}`,
      title: s.themeTitle,
      description: s.themeDescription,
      confidenceScore: clamp01(0.4 + 0.1 * items.length),
      supportingIdentitySignals: items.map((_, idx) => `id:${s.key}:${idx}`),
    });
  }
  return out.sort((a, b) => b.confidenceScore - a.confidenceScore || a.id.localeCompare(b.id));
}
