/**
 * Analytical Engine — Data Adapter (read-only)
 *
 * Purpose:
 *   Fetches all relevant Clarity user data from the existing Supabase tables
 *   and maps it into the engine's `EngineInputs` shape. Then exposes async
 *   per-page convenience functions that compose fetching with the engine's
 *   existing per-page output functions.
 *
 * Contract:
 *   - Strictly READ-ONLY. No insert/update/upsert/delete/RPC mutation. No
 *     writes to any client-side store. No UI/route/analytics side effects.
 *   - Never throws. Every public function resolves with a safe value. On
 *     fetch error, the affected slice degrades to []; on engine error, the
 *     per-page function returns a documented empty shape.
 *   - Deterministic for a given DB state (only `metadata.fetchedAt` reflects
 *     wall-clock time).
 *   - No retries, no caching, no memoization in v1.
 *     // TODO: a small in-memory cache or React Query layer could live here.
 *   - This module does NOT modify the Analytical Engine internals; it only
 *     consumes its existing exports.
 *   - Not wired into any UI/route in this module; wiring is reserved for a
 *     later, explicit module.
 */

import { supabase } from "@/integrations/supabase/client";
import {
  getPatternsPageData,
  getInsightsPageData,
  getYourStoryPageData,
  getTimelinePageData,
  getClarityPlusInsights,
  getFastClarityContext as engineGetFastClarityContext,
} from "./index";
import type {
  PatternsPageData,
  InsightsPageData,
  YourStoryPageData,
  TimelinePageData,
  ClarityPlusInsights,
  FastClarityContext,
} from "./types";
import type { EngineInputs as EngineInputsBase } from "./adapters";

const LOG_PREFIX = "[analyticalEngine.dataAdapter]";

// ---------- Local row types ----------
// Where existing types are not exported as a single typed row, we declare
// minimal local interfaces matching the columns we actually consume.

// wraps existing reflection_answers rows (per Supabase schema)
// TODO: replace with shared type if/when one is exported by the data layer.
export interface ReflectionRow {
  id: string;
  session_id: string;
  question_index: number;
  question_text: string;
  answer_text: string;
  question_type: string;
  created_at: string;
}

// wraps existing pe_markers rows
export interface MarkerRow {
  id: string;
  kind: "linguistic" | "emotional" | "communication" | "behavioral" | "identity";
  subtype: string;
  valence: number | null;
  answer_id: string | null;
  session_id: string | null;
  created_at: string | null;
}

// wraps existing pe_macro_patterns rows
export interface MacroPatternRow {
  id: string;
  pattern_type: string;
  pattern_label: string;
  confidence: number | null;
  raw_count: number | null;
  weighted_score: number | null;
  last_seen_at: string | null;
}

// wraps existing pe_pattern_tags rows
export interface PatternTagRow {
  id: string;
  tag_key: string;
  tag_label: string;
  category: "linguistic" | "emotional" | "communication" | "behavioral" | "identity" | "relational";
  answer_id: string | null;
  session_id: string | null;
  created_at: string | null;
}

// wraps existing pe_pattern_clusters rows (legacy "cluster" → CoreTheme)
// TODO: rename surface in a later module; engine already wraps as CoreTheme.
export interface ExistingPatternRow {
  id: string;
  cluster_label: string;
  cluster_summary: string;
  cohesion_score: number;
  member_pattern_ids: string[];
}

// wraps existing pe_timeline_events rows
export interface TimelineEventRow {
  id: string;
  event_date: string;
  event_type: string;
  short_label: string;
  summary: string;
}

// wraps existing pe_identity_profile row
export interface IdentityProfileRow {
  strengths: unknown;
  vulnerabilities: unknown;
  blind_spots: unknown;
  recurring_triggers: unknown;
  narrative_md: string | null;
}

// ---------- Public input shape ----------

export interface EngineInputs {
  reflections: ReflectionRow[];
  markers: MarkerRow[];
  macroPatterns: MacroPatternRow[];
  patternTags: PatternTagRow[];
  existingPatterns: ExistingPatternRow[];
  // Auxiliary (used by Layers 5/6/8) — kept here so the engine has full
  // context without a second adapter call.
  timelineEvents: TimelineEventRow[];
  identityProfile: IdentityProfileRow | null;
  metadata: {
    fetchedAt: string;
    userId: string;
    counts: {
      reflections: number;
      markers: number;
      macroPatterns: number;
      patternTags: number;
      existingPatterns: number;
    };
  };
  // TODO: extend with sessions, questionIds, prior-window patterns, etc.
}

function emptyInputs(userId: string): EngineInputs {
  return {
    reflections: [],
    markers: [],
    macroPatterns: [],
    patternTags: [],
    existingPatterns: [],
    timelineEvents: [],
    identityProfile: null,
    metadata: {
      fetchedAt: new Date().toISOString(),
      userId,
      counts: {
        reflections: 0,
        markers: 0,
        macroPatterns: 0,
        patternTags: 0,
        existingPatterns: 0,
      },
    },
  };
}

/** Run a fetch and return [] on error. Never throws. */
async function safeList<T>(label: string, fn: () => Promise<{ data: T[] | null; error: unknown }>): Promise<T[]> {
  try {
    const { data, error } = await fn();
    if (error) {
      console.warn(`${LOG_PREFIX} ${label} failed`, error);
      return [];
    }
    return (data ?? []) as T[];
  } catch (err) {
    console.warn(`${LOG_PREFIX} ${label} threw`, err);
    return [];
  }
}

async function safeOne<T>(label: string, fn: () => Promise<{ data: T | null; error: unknown }>): Promise<T | null> {
  try {
    const { data, error } = await fn();
    if (error) {
      console.warn(`${LOG_PREFIX} ${label} failed`, error);
      return null;
    }
    return (data ?? null) as T | null;
  } catch (err) {
    console.warn(`${LOG_PREFIX} ${label} threw`, err);
    return null;
  }
}

/**
 * Fetch all engine inputs for the given user. Read-only, never throws.
 * Returns a fully-populated EngineInputs (empty arrays where data is missing).
 */
export async function getEngineInputs(userId: string): Promise<EngineInputs> {
  if (!userId) return emptyInputs("");

  // Parallel reads — match existing query patterns elsewhere in the codebase
  // (see src/hooks/usePatternData.ts).
  const [
    reflections,
    markers,
    macroPatterns,
    patternTags,
    existingPatterns,
    timelineEvents,
    identityProfile,
  ] = await Promise.all([
    // reflection_answers — joined to user via reflection_sessions; RLS filters by user.
    // TODO: if cross-session ordering matters for engine, revisit limit/order.
    safeList<ReflectionRow>("reflection_answers", () =>
      supabase
        .from("reflection_answers")
        .select("id, session_id, question_index, question_text, answer_text, question_type, created_at")
        .order("created_at", { ascending: false })
        .limit(500) as unknown as Promise<{ data: ReflectionRow[] | null; error: unknown }>
    ),
    // pe_markers — Layer 1 raw signals (RLS by user_id)
    safeList<MarkerRow>("pe_markers", () =>
      supabase
        .from("pe_markers")
        .select("id, kind, subtype, valence, answer_id, session_id, created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(1000) as unknown as Promise<{ data: MarkerRow[] | null; error: unknown }>
    ),
    // pe_macro_patterns — Layer 2 source.
    // raw_count/weighted_score/last_seen_at live on pe_macro_frequency, not
    // here. Map created_at → last_seen_at as a best-effort recency hint and
    // leave numeric aggregates null.
    // TODO: optionally join pe_macro_frequency to enrich aggregates.
    safeList<MacroPatternRow>("pe_macro_patterns", async () => {
      const res = await supabase
        .from("pe_macro_patterns")
        .select("id, pattern_type, pattern_label, confidence, created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(200);
      const data = (res.data ?? []).map((r) => ({
        id: r.id,
        pattern_type: r.pattern_type,
        pattern_label: r.pattern_label,
        confidence: r.confidence,
        raw_count: null,
        weighted_score: null,
        last_seen_at: r.created_at,
      })) as MacroPatternRow[];
      return { data, error: res.error };
    }),
    // pe_pattern_tags — labeling system
    safeList<PatternTagRow>("pe_pattern_tags", () =>
      supabase
        .from("pe_pattern_tags")
        .select("id, tag_key, tag_label, category, answer_id, session_id, created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(1000) as unknown as Promise<{ data: PatternTagRow[] | null; error: unknown }>
    ),
    // pe_pattern_clusters — legacy "cluster" → engine wraps as CoreTheme
    safeList<ExistingPatternRow>("pe_pattern_clusters", () =>
      supabase
        .from("pe_pattern_clusters")
        .select("id, cluster_label, cluster_summary, cohesion_score, member_pattern_ids")
        .eq("user_id", userId)
        .order("cohesion_score", { ascending: false })
        .limit(80) as unknown as Promise<{ data: ExistingPatternRow[] | null; error: unknown }>
    ),
    // pe_timeline_events — TurningPoint candidates / Layer 6/8
    safeList<TimelineEventRow>("pe_timeline_events", () =>
      supabase
        .from("pe_timeline_events")
        .select("id, event_date, event_type, short_label, summary")
        .eq("user_id", userId)
        .order("event_date", { ascending: false })
        .limit(200) as unknown as Promise<{ data: TimelineEventRow[] | null; error: unknown }>
    ),
    // pe_identity_profile — Layer 5 baseline
    safeOne<IdentityProfileRow>("pe_identity_profile", () =>
      supabase
        .from("pe_identity_profile")
        .select("strengths, vulnerabilities, blind_spots, recurring_triggers, narrative_md")
        .eq("user_id", userId)
        .maybeSingle() as unknown as Promise<{ data: IdentityProfileRow | null; error: unknown }>
    ),
  ]);

  return {
    reflections,
    markers,
    macroPatterns,
    patternTags,
    existingPatterns,
    timelineEvents,
    identityProfile,
    metadata: {
      fetchedAt: new Date().toISOString(),
      userId,
      counts: {
        reflections: reflections.length,
        markers: markers.length,
        macroPatterns: macroPatterns.length,
        patternTags: patternTags.length,
        existingPatterns: existingPatterns.length,
      },
    },
  };
}

/** Map our adapter's EngineInputs to the engine's internal EngineInputs shape. */
function toEngineInputs(inputs: EngineInputs): EngineInputsBase {
  return {
    markers: inputs.markers.map((m) => ({
      id: m.id,
      kind: m.kind,
      subtype: m.subtype,
      valence: m.valence,
      answer_id: m.answer_id,
      session_id: m.session_id,
      created_at: m.created_at,
    })),
    patternTags: inputs.patternTags.map((t) => ({
      id: t.id,
      tag_key: t.tag_key,
      tag_label: t.tag_label,
      category: t.category,
      answer_id: t.answer_id,
      session_id: t.session_id,
      created_at: t.created_at,
    })),
    macroPatterns: inputs.macroPatterns.map((p) => ({
      id: p.id,
      pattern_type: p.pattern_type,
      pattern_label: p.pattern_label,
      confidence: p.confidence,
      raw_count: p.raw_count,
      weighted_score: p.weighted_score,
      last_seen_at: p.last_seen_at,
    })),
    clusters: inputs.existingPatterns.map((c) => ({
      id: c.id,
      cluster_label: c.cluster_label,
      cluster_summary: c.cluster_summary,
      cohesion_score: c.cohesion_score,
      member_pattern_ids: c.member_pattern_ids,
    })),
    identityProfile: inputs.identityProfile ?? undefined,
    timelineEvents: inputs.timelineEvents.map((e) => ({
      id: e.id,
      event_date: e.event_date,
      event_type: e.event_type,
      short_label: e.short_label,
      summary: e.summary,
    })),
  };
}

// ---------- Per-page convenience functions ----------

const EMPTY_PATTERNS: PatternsPageData = {
  emotionalPatterns: [], behavioralPatterns: [], emotionalLoops: [],
  triggerTypes: [], emotionalSignatures: [],
};
const EMPTY_INSIGHTS: InsightsPageData = {
  coreThemes: [], identitySignals: [], weekOverWeekShifts: [],
  emotionalTrends: [], highConfidencePatterns: [],
};
const EMPTY_STORY: YourStoryPageData = {
  identityThemes: [], lifePatterns: [], selfConceptPatterns: [], turningPoints: [],
};
const EMPTY_TIMELINE: TimelinePageData = {
  patternEvolution: [], emotionalTrends: [], turningPoints: [],
};

function safeRun<T>(label: string, fn: () => T, fallback: T): T {
  try { return fn(); } catch (err) {
    console.warn(`${LOG_PREFIX} ${label} threw`, err);
    return fallback;
  }
}

/** Read-only. Fetches inputs and returns Patterns page data. Never throws. */
export async function getPatternsPageEngineData(userId: string): Promise<PatternsPageData> {
  const inputs = await getEngineInputs(userId);
  return safeRun("getPatternsPageData", () => getPatternsPageData(userId, toEngineInputs(inputs)), EMPTY_PATTERNS);
}

/** Read-only. Fetches inputs and returns Insights page data. Never throws. */
export async function getInsightsPageEngineData(userId: string): Promise<InsightsPageData> {
  const inputs = await getEngineInputs(userId);
  return safeRun("getInsightsPageData", () => getInsightsPageData(userId, toEngineInputs(inputs)), EMPTY_INSIGHTS);
}

/** Read-only. Fetches inputs and returns Your Story page data. Never throws. */
export async function getYourStoryPageEngineData(userId: string): Promise<YourStoryPageData> {
  const inputs = await getEngineInputs(userId);
  return safeRun("getYourStoryPageData", () => getYourStoryPageData(userId, toEngineInputs(inputs)), EMPTY_STORY);
}

/** Read-only. Fetches inputs and returns Timeline page data. Never throws. */
export async function getTimelinePageEngineData(userId: string): Promise<TimelinePageData> {
  const inputs = await getEngineInputs(userId);
  return safeRun("getTimelinePageData", () => getTimelinePageData(userId, toEngineInputs(inputs)), EMPTY_TIMELINE);
}

/** Read-only. Fetches inputs and returns the full Clarity+ insights bundle. Never throws. */
export async function getClarityPlusEngineData(userId: string): Promise<ClarityPlusInsights> {
  const inputs = await getEngineInputs(userId);
  const empty: ClarityPlusInsights = {
    patterns: EMPTY_PATTERNS,
    insights: EMPTY_INSIGHTS,
    story: EMPTY_STORY,
    timeline: EMPTY_TIMELINE,
    predictionSignals: [],
    futureTriggers: [],
    stabilityIndicators: [],
  };
  return safeRun("getClarityPlusInsights", () => getClarityPlusInsights(userId, toEngineInputs(inputs)), empty);
}

/**
 * Read-only Fast Clarity context.
 * Fast Clarity is read-only and does NOT update the analytical engine.
 */
export async function getFastClarityContext(userId: string): Promise<FastClarityContext> {
  const inputs = await getEngineInputs(userId);
  const empty: FastClarityContext = {
    recentEmotionalSignals: [],
    recentSituationalSignals: [],
    recentPatterns: [],
  };
  return safeRun("getFastClarityContext", () => engineGetFastClarityContext(userId, toEngineInputs(inputs)), empty);
}
