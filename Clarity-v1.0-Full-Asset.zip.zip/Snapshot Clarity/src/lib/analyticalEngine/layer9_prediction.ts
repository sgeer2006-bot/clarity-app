/**
 * Layer 9 — Prediction v1 (basic, safe).
 *
 * Heuristic: extrapolate from current high-confidence Patterns and Loops.
 * Language is probabilistic only — never clinical, never diagnostic, never
 * a specific life-event prediction.
 *
 * v1 scaffolding — function signatures are stable; internals will evolve.
 */

import type { PredictionSignal, FutureTrigger, StabilityIndicator } from "./types";
import type { EngineInputs } from "./adapters";
import { _allPatternsForLayer2 } from "./layer2_patterns";
import { getEmotionalLoops, getTriggerTypes } from "./layer3_loops";

function clamp01(n: number): number { return Math.max(0, Math.min(1, n)); }

export function getPredictionSignals(_userId: string, inputs?: EngineInputs): PredictionSignal[] {
  void _userId;
  const top = _allPatternsForLayer2(inputs ?? {})
    .filter((p) => p.confidenceScore >= 0.5)
    .slice(0, 5);
  return top.map<PredictionSignal>((p) => ({
    id: `pred:${p.id}`,
    label: `${p.description} may continue to show up in the near term`,
    confidenceScore: clamp01(p.confidenceScore * 0.8),
  }));
}

export function getFutureTriggers(userId: string, inputs?: EngineInputs): FutureTrigger[] {
  return getTriggerTypes(userId, inputs)
    .filter((t) => t.confidenceScore >= 0.4)
    .slice(0, 5)
    .map<FutureTrigger>((t) => ({
      id: `ftrig:${t.id}`,
      label: `${t.label} is likely to come up again`,
      confidenceScore: clamp01(t.confidenceScore * 0.8),
    }));
}

export function getStabilityIndicators(userId: string, inputs?: EngineInputs): StabilityIndicator[] {
  const loops = getEmotionalLoops(userId, inputs);
  if (loops.length === 0) return [];
  // v1: more loops at high confidence → "stabilizing" pattern picture
  // (the user is repeatedly noticing the same things). TODO: refine.
  const avg = loops.reduce((s, l) => s + l.confidenceScore, 0) / loops.length;
  return [
    {
      id: "stab:overall",
      label: "Overall pattern picture",
      direction: avg > 0.6 ? "stabilizing" : avg > 0.3 ? "increasing" : "decreasing",
      confidenceScore: clamp01(avg),
    },
  ];
}
