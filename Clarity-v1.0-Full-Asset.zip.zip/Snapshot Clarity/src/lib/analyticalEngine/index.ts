/**
 * Analytical Engine v1 — Output Surfaces (Layer 10).
 *
 * Ten layers, read-only:
 *   1. Raw Signals          — layer1_signals.ts
 *   2. Patterns             — layer2_patterns.ts
 *   3. Loop Engine          — layer3_loops.ts
 *   4. Core Themes          — layer4_coreThemes.ts (replaces "clusters")
 *   5. Self-Understanding   — layer5_identity.ts
 *   6. Story Model          — layer6_story.ts
 *   7. Safety + Accuracy    — layer7_safety.ts
 *   8. Time + Evolution     — layer8_evolution.ts
 *   9. Prediction           — layer9_prediction.ts
 *  10. Output Surfaces      — this file
 *
 * Contract:
 *   - All functions are pure read.
 *   - Functions never throw; missing inputs yield empty arrays/objects.
 *   - Internal applyErrorCorrection runs before each Layer 10 read,
 *     adjusting confidence on entities tied to detected contradictions.
 *   - Output is deterministic: sorted by confidenceScore desc, then id asc.
 *   - This module does NOT modify user data, the questioning engine,
 *     subscription/credits/gating, routing, or any other engine.
 *   - Not wired into any UI/route. Wiring is reserved for a future module.
 */

import type {
  PatternsPageData, InsightsPageData, YourStoryPageData, TimelinePageData,
  ClarityPlusInsights, FastClarityContext,
  AnyPattern,
} from "./types";
import type { EngineInputs } from "./adapters";

import {
  getEmotionalSignals, getSituationalSignals, getBeliefSignals, getBehavioralSignals,
} from "./layer1_signals";
import {
  getEmotionalPatterns, getSituationalPatterns, getBeliefPatterns, getBehavioralPatterns,
} from "./layer2_patterns";
import { getEmotionalLoops, getTriggerTypes, getEmotionalSignatures } from "./layer3_loops";
import { getCoreThemes } from "./layer4_coreThemes";
import { getIdentitySignals, getIdentityThemes } from "./layer5_identity";
import { getLifePatterns, getSelfConceptPatterns, getTurningPoints } from "./layer6_story";
import { detectContradictions, correctAndSort } from "./layer7_safety";
import { getWeekOverWeekShifts, getPatternEvolution, getEmotionalTrends } from "./layer8_evolution";
import { getPredictionSignals, getFutureTriggers, getStabilityIndicators } from "./layer9_prediction";

function safeRead<T>(fn: () => T, fallback: T): T {
  try { return fn(); } catch { return fallback; }
}

export function getPatternsPageData(userId: string, inputs?: EngineInputs): PatternsPageData {
  const contradictions = safeRead(() => detectContradictions(userId, inputs), []);
  return {
    emotionalPatterns: correctAndSort(safeRead(() => getEmotionalPatterns(userId, inputs), []), contradictions),
    behavioralPatterns: correctAndSort(safeRead(() => getBehavioralPatterns(userId, inputs), []), contradictions),
    emotionalLoops: correctAndSort(safeRead(() => getEmotionalLoops(userId, inputs), []), contradictions),
    triggerTypes: correctAndSort(safeRead(() => getTriggerTypes(userId, inputs), []), contradictions),
    emotionalSignatures: correctAndSort(safeRead(() => getEmotionalSignatures(userId, inputs), []), contradictions),
  };
}

export function getInsightsPageData(userId: string, inputs?: EngineInputs): InsightsPageData {
  const contradictions = safeRead(() => detectContradictions(userId, inputs), []);
  const allPatterns: AnyPattern[] = [
    ...safeRead(() => getEmotionalPatterns(userId, inputs), []),
    ...safeRead(() => getSituationalPatterns(userId, inputs), []),
    ...safeRead(() => getBeliefPatterns(userId, inputs), []),
    ...safeRead(() => getBehavioralPatterns(userId, inputs), []),
  ];
  return {
    coreThemes: correctAndSort(safeRead(() => getCoreThemes(userId, inputs), []), contradictions),
    identitySignals: correctAndSort(safeRead(() => getIdentitySignals(userId, inputs), []), contradictions),
    weekOverWeekShifts: safeRead(() => getWeekOverWeekShifts(userId, inputs), []),
    emotionalTrends: safeRead(() => getEmotionalTrends(userId, inputs), []),
    highConfidencePatterns: correctAndSort(allPatterns, contradictions).filter((p) => p.confidenceScore >= 0.5),
  };
}

export function getYourStoryPageData(userId: string, inputs?: EngineInputs): YourStoryPageData {
  const contradictions = safeRead(() => detectContradictions(userId, inputs), []);
  return {
    identityThemes: correctAndSort(safeRead(() => getIdentityThemes(userId, inputs), []), contradictions),
    lifePatterns: correctAndSort(safeRead(() => getLifePatterns(userId, inputs), []), contradictions),
    selfConceptPatterns: correctAndSort(safeRead(() => getSelfConceptPatterns(userId, inputs), []), contradictions),
    turningPoints: correctAndSort(safeRead(() => getTurningPoints(userId, inputs), []), contradictions),
  };
}

export function getTimelinePageData(userId: string, inputs?: EngineInputs): TimelinePageData {
  const contradictions = safeRead(() => detectContradictions(userId, inputs), []);
  return {
    patternEvolution: safeRead(() => getPatternEvolution(userId, inputs), []),
    emotionalTrends: safeRead(() => getEmotionalTrends(userId, inputs), []),
    turningPoints: correctAndSort(safeRead(() => getTurningPoints(userId, inputs), []), contradictions),
  };
}

export function getClarityPlusInsights(userId: string, inputs?: EngineInputs): ClarityPlusInsights {
  return {
    patterns: getPatternsPageData(userId, inputs),
    insights: getInsightsPageData(userId, inputs),
    story: getYourStoryPageData(userId, inputs),
    timeline: getTimelinePageData(userId, inputs),
    predictionSignals: safeRead(() => getPredictionSignals(userId, inputs), []),
    futureTriggers: safeRead(() => getFutureTriggers(userId, inputs), []),
    stabilityIndicators: safeRead(() => getStabilityIndicators(userId, inputs), []),
  };
}

/**
 * Read-only context for Fast Clarity. Explicitly does NOT update the engine
 * or write any data — Fast Clarity reads recent context only.
 */
export function getFastClarityContext(userId: string, inputs?: EngineInputs): FastClarityContext {
  const RECENT = 10;
  const byTsDesc = <T extends { ts?: string; id: string }>(arr: T[]) =>
    [...arr].sort((a, b) => (b.ts ?? "").localeCompare(a.ts ?? "") || a.id.localeCompare(b.id)).slice(0, RECENT);

  const recentEmotionalSignals = byTsDesc(safeRead(() => getEmotionalSignals(userId, inputs), []));
  const recentSituationalSignals = byTsDesc(safeRead(() => getSituationalSignals(userId, inputs), []));
  // ensure belief/behavioral helpers stay imported (for future expansion)
  void getBeliefSignals; void getBehavioralSignals;

  const allPatterns: AnyPattern[] = [
    ...safeRead(() => getEmotionalPatterns(userId, inputs), []),
    ...safeRead(() => getSituationalPatterns(userId, inputs), []),
    ...safeRead(() => getBeliefPatterns(userId, inputs), []),
    ...safeRead(() => getBehavioralPatterns(userId, inputs), []),
  ];
  const recentPatterns = [...allPatterns]
    .sort((a, b) => (b.recency ?? "").localeCompare(a.recency ?? "") || a.id.localeCompare(b.id))
    .slice(0, RECENT);

  return { recentEmotionalSignals, recentSituationalSignals, recentPatterns };
}

// Re-export types for consumers.
export type * from "./types";
