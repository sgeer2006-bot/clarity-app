/**
 * Layer 1 — Raw Signals.
 *
 * Pure read. Produces signals from pre-fetched inputs (markers, pattern tags).
 * Heuristic: a marker/tag becomes a single signal; the marker's kind is
 * mapped to a SignalKind via `markerKindToSignalKind`. Pattern tags whose
 * category is "relational" are treated as situational signals.
 *
 * Inputs: optional EngineInputs. When absent, returns [] (resilient).
 * Outputs: deterministic arrays sorted by id.
 */

import type {
  EmotionalSignals, SituationalSignals, BeliefSignals, BehavioralSignals,
  EmotionalSignal, SituationalSignal, BeliefSignal, BehavioralSignal,
} from "./types";
import { type EngineInputs, markerToSignal, withDefaults } from "./adapters";

function buildAll(inputs: EngineInputs) {
  const i = withDefaults(inputs);
  const emotional: EmotionalSignal[] = [];
  const situational: SituationalSignal[] = [];
  const belief: BeliefSignal[] = [];
  const behavioral: BehavioralSignal[] = [];

  for (const m of i.markers) {
    const s = markerToSignal(m);
    if (s.kind === "emotional") emotional.push(s);
    else if (s.kind === "situational") situational.push(s);
    else if (s.kind === "belief") belief.push(s);
    else behavioral.push(s);
  }

  for (const t of i.patternTags) {
    const base = {
      id: `tag:${t.id}`,
      label: t.tag_label || t.tag_key,
      ts: t.created_at ?? undefined,
      sourceRef: { kind: "tag" as const, id: t.id },
    };
    if (t.category === "emotional") emotional.push({ ...base, kind: "emotional" });
    else if (t.category === "behavioral" || t.category === "communication") behavioral.push({ ...base, kind: "behavioral" });
    else if (t.category === "identity" || t.category === "linguistic") belief.push({ ...base, kind: "belief" });
    else situational.push({ ...base, kind: "situational" });
  }

  const sortById = <T extends { id: string }>(a: T[]) => a.sort((x, y) => x.id.localeCompare(y.id));
  return {
    emotional: sortById(emotional),
    situational: sortById(situational),
    belief: sortById(belief),
    behavioral: sortById(behavioral),
  };
}

/** @param userId reserved for future per-user fetching wiring. */
export function getEmotionalSignals(_userId: string, inputs?: EngineInputs): EmotionalSignals {
  // TODO: read live user data when wiring lands.
  void _userId;
  return buildAll(inputs ?? {}).emotional;
}
export function getSituationalSignals(_userId: string, inputs?: EngineInputs): SituationalSignals {
  void _userId;
  return buildAll(inputs ?? {}).situational;
}
export function getBeliefSignals(_userId: string, inputs?: EngineInputs): BeliefSignals {
  void _userId;
  return buildAll(inputs ?? {}).belief;
}
export function getBehavioralSignals(_userId: string, inputs?: EngineInputs): BehavioralSignals {
  void _userId;
  return buildAll(inputs ?? {}).behavioral;
}
