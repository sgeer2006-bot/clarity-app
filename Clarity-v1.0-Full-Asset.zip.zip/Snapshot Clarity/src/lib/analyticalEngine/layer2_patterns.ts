/**
 * Layer 2 — Patterns.
 *
 * Wraps existing macro pattern data (pe_macro_patterns / pe_macro_frequency)
 * via adapters. Existing pattern logic is NOT modified.
 *
 * Heuristic for type mapping (v1):
 *   pattern_type ∈ { emotional_loop } → emotional
 *   pattern_type ∈ { communication_style, conflict_role } → behavioral
 *   pattern_type ∈ { cognitive_distortion } → belief
 *   pattern_type ∈ { recurring_theme, * } → situational (default)
 *
 * Confidence (v1):
 *   confidenceScore = clamp01( 0.6 * normFreq + 0.4 * normWeighted )
 *   where normFreq = raw_count / max(raw_count) and
 *         normWeighted = weighted_score / max(weighted_score)
 */

import type {
  EmotionalPattern, SituationalPattern, BeliefPattern, BehavioralPattern,
  PatternType,
} from "./types";
import { type EngineInputs, withDefaults } from "./adapters";

function clamp01(n: number): number { return Math.max(0, Math.min(1, n)); }

function mapPatternType(t: string): PatternType {
  if (t === "emotional_loop" || t === "emotion") return "emotional";
  if (t === "communication_style" || t === "conflict_role" || t === "behavior") return "behavioral";
  if (t === "cognitive_distortion" || t === "belief") return "belief";
  return "situational";
}

interface BuiltPattern {
  id: string; type: PatternType; description: string;
  frequency: number; recency?: string; supportingExamples: string[]; confidenceScore: number;
}

function buildPatterns(inputs: EngineInputs): BuiltPattern[] {
  const i = withDefaults(inputs);
  const rows = i.macroPatterns;
  if (rows.length === 0) return [];
  const maxCount = Math.max(1, ...rows.map((r) => r.raw_count ?? 0));
  const maxWeighted = Math.max(1, ...rows.map((r) => Number(r.weighted_score ?? 0)));

  return rows
    .map<BuiltPattern>((r) => {
      const type = mapPatternType(r.pattern_type);
      const freq = r.raw_count ?? 0;
      const w = Number(r.weighted_score ?? 0);
      const cs = clamp01(0.6 * (freq / maxCount) + 0.4 * (w / maxWeighted));
      return {
        id: `pat:${r.id}`,
        type,
        description: r.pattern_label,
        frequency: freq,
        recency: r.last_seen_at ?? undefined,
        supportingExamples: [],
        confidenceScore: cs,
      };
    })
    .sort((a, b) => b.confidenceScore - a.confidenceScore || a.id.localeCompare(b.id));
}

export function getEmotionalPatterns(_userId: string, inputs?: EngineInputs): EmotionalPattern[] {
  void _userId;
  return buildPatterns(inputs ?? {}).filter((p) => p.type === "emotional") as EmotionalPattern[];
}
export function getSituationalPatterns(_userId: string, inputs?: EngineInputs): SituationalPattern[] {
  void _userId;
  return buildPatterns(inputs ?? {}).filter((p) => p.type === "situational") as SituationalPattern[];
}
export function getBeliefPatterns(_userId: string, inputs?: EngineInputs): BeliefPattern[] {
  void _userId;
  return buildPatterns(inputs ?? {}).filter((p) => p.type === "belief") as BeliefPattern[];
}
export function getBehavioralPatterns(_userId: string, inputs?: EngineInputs): BehavioralPattern[] {
  void _userId;
  return buildPatterns(inputs ?? {}).filter((p) => p.type === "behavioral") as BehavioralPattern[];
}

/** @deprecated internal helper; use the typed exports above. */
export function _allPatternsForLayer2(inputs?: EngineInputs): BuiltPattern[] {
  return buildPatterns(inputs ?? {});
}
