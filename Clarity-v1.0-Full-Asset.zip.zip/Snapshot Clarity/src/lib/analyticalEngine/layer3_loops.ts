/**
 * Layer 3 — Loop Engine.
 *
 * Heuristic v1: a loop is approximated from macro patterns of type
 * "emotional_loop". Trigger types and behaviors are inferred from
 * co-occurring behavioral patterns. When source data is insufficient,
 * returns []. Non-clinical, non-diagnostic.
 */

import type { EmotionalLoop, TriggerType, EmotionalSignature } from "./types";
import { type EngineInputs, withDefaults } from "./adapters";
import { _allPatternsForLayer2 } from "./layer2_patterns";

function clamp01(n: number): number { return Math.max(0, Math.min(1, n)); }

export function getEmotionalLoops(_userId: string, inputs?: EngineInputs): EmotionalLoop[] {
  void _userId;
  const i = withDefaults(inputs);
  const all = _allPatternsForLayer2(i);
  const loops = all.filter((p) => p.type === "emotional");
  if (loops.length === 0) return [];

  const behaviors = all.filter((p) => p.type === "behavioral").slice(0, 3).map((p) => p.description);
  const triggers = all.filter((p) => p.type === "situational").slice(0, 3).map((p) => p.description);

  return loops
    .map<EmotionalLoop>((p) => ({
      id: `loop:${p.id}`,
      triggerTypes: triggers,
      dominantEmotions: [p.description],
      typicalBehaviors: behaviors,
      typicalConsequences: [],
      frequency: p.frequency,
      confidenceScore: clamp01(p.confidenceScore),
    }))
    .sort((a, b) => b.confidenceScore - a.confidenceScore || a.id.localeCompare(b.id));
}

export function getTriggerTypes(_userId: string, inputs?: EngineInputs): TriggerType[] {
  void _userId;
  const all = _allPatternsForLayer2(inputs ?? {});
  return all
    .filter((p) => p.type === "situational")
    .map((p) => ({
      id: `trig:${p.id}`,
      label: p.description,
      frequency: p.frequency,
      confidenceScore: p.confidenceScore,
    }))
    .sort((a, b) => b.confidenceScore - a.confidenceScore || a.id.localeCompare(b.id));
}

export function getEmotionalSignatures(_userId: string, inputs?: EngineInputs): EmotionalSignature[] {
  void _userId;
  const all = _allPatternsForLayer2(inputs ?? {});
  const emotions = all.filter((p) => p.type === "emotional");
  if (emotions.length === 0) return [];
  // v1: a single signature aggregating top emotions.
  return [
    {
      id: "sig:dominant",
      label: "Recurring emotional signature",
      dominantEmotions: emotions.slice(0, 3).map((e) => e.description),
      confidenceScore: emotions[0].confidenceScore,
    },
  ];
}
