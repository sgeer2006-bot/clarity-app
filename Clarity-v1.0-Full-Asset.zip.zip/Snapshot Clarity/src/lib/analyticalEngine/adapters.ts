/**
 * Analytical Engine — Adapters
 *
 * Read-only mapping from existing data shapes into the Analytical Engine's
 * naming system. This module DOES NOT modify, rename, or replace any
 * existing logic, schema, or table.
 *
 * Old → New name mappings:
 *   - "cluster" / pe_pattern_clusters → CoreTheme
 *   - pe_macro_patterns / pe_macro_frequency → Pattern (Layer 2)
 *   - pe_markers (kind: emotional/communication/behavioral/identity) → Raw Signals (Layer 1)
 *   - pe_pattern_tags → Raw Signals (categorized) / Pattern supporting examples
 *   - pe_identity_profile (strengths/vulnerabilities/blind_spots/triggers) → IdentitySignal / IdentityTheme
 *   - pe_timeline_events → TurningPoint candidates
 *
 * v1 NOTE: To keep this module isolated and synchronous, adapters return
 * empty arrays by default. Callers/tests can inject pre-fetched rows via
 * the optional `EngineInputs` parameter on layer functions in future
 * wiring. Network/database fetching is intentionally out-of-scope for this
 * module — wiring is reserved for a later, explicit module.
 */

import type {
  EmotionalSignal, SituationalSignal, BeliefSignal, BehavioralSignal,
} from "./types";

/** Optional pre-fetched inputs the engine can read from. All fields optional. */
export interface EngineInputs {
  // Layer 1 sources
  markers?: Array<{
    id: string;
    kind: "linguistic" | "emotional" | "communication" | "behavioral" | "identity";
    subtype: string;
    valence?: number | null;
    answer_id?: string | null;
    session_id?: string | null;
    created_at?: string | null;
  }>;
  patternTags?: Array<{
    id: string;
    tag_key: string;
    tag_label: string;
    category: "linguistic" | "emotional" | "communication" | "behavioral" | "identity" | "relational";
    answer_id?: string | null;
    session_id?: string | null;
    created_at?: string | null;
  }>;
  // Layer 2 source
  macroPatterns?: Array<{
    id: string;
    pattern_type: string;
    pattern_label: string;
    confidence?: number | null;
    raw_count?: number | null;
    weighted_score?: number | null;
    last_seen_at?: string | null;
  }>;
  // Layer 4 (legacy "cluster" data — wrapped, not modified)
  /** @deprecated old name; surfaces as CoreTheme via Layer 4 */
  clusters?: Array<{
    id: string;
    cluster_label: string;
    cluster_summary: string;
    cohesion_score: number;
    member_pattern_ids: string[];
  }>;
  // Layer 5 source
  identityProfile?: {
    strengths?: unknown;
    vulnerabilities?: unknown;
    blind_spots?: unknown;
    recurring_triggers?: unknown;
    narrative_md?: string | null;
  } | null;
  // Layer 6/8 source
  timelineEvents?: Array<{
    id: string;
    event_date: string;
    event_type: string;
    short_label: string;
    summary?: string;
  }>;
  // Layer 8 prior window (optional)
  priorMacroPatterns?: EngineInputs["macroPatterns"];
}

export const EMPTY_INPUTS: Required<EngineInputs> = {
  markers: [],
  patternTags: [],
  macroPatterns: [],
  clusters: [],
  identityProfile: null as never,
  timelineEvents: [],
  priorMacroPatterns: [],
};

export function withDefaults(inputs?: EngineInputs): Required<EngineInputs> {
  return {
    markers: inputs?.markers ?? [],
    patternTags: inputs?.patternTags ?? [],
    macroPatterns: inputs?.macroPatterns ?? [],
    clusters: inputs?.clusters ?? [],
    identityProfile: (inputs?.identityProfile ?? null) as never,
    timelineEvents: inputs?.timelineEvents ?? [],
    priorMacroPatterns: inputs?.priorMacroPatterns ?? [],
  };
}

/** Map a marker kind to a Layer 1 SignalKind. Linguistic markers are
 *  classified as belief signals when they convey belief content (heuristic;
 *  v1 maps "linguistic" → "belief", others to their natural kind). */
export function markerKindToSignalKind(
  k: "linguistic" | "emotional" | "communication" | "behavioral" | "identity"
): "emotional" | "situational" | "belief" | "behavioral" {
  if (k === "emotional") return "emotional";
  if (k === "behavioral" || k === "communication") return "behavioral";
  if (k === "linguistic" || k === "identity") return "belief";
  return "situational";
}

/** Build a Layer 1 signal from a marker row. */
export function markerToSignal(m: NonNullable<EngineInputs["markers"]>[number]):
  EmotionalSignal | SituationalSignal | BeliefSignal | BehavioralSignal {
  const kind = markerKindToSignalKind(m.kind);
  const base = {
    id: `mk:${m.id}`,
    label: m.subtype || m.kind,
    ts: m.created_at ?? undefined,
    sourceRef: { kind: "marker" as const, id: m.id },
  };
  if (kind === "emotional") return { ...base, kind, valence: m.valence ?? undefined };
  if (kind === "behavioral") return { ...base, kind };
  if (kind === "belief") return { ...base, kind };
  return { ...base, kind };
}
