/**
 * Analytical Engine v1 — Type System
 *
 * Layered naming system. Names are deliberate and must not be abbreviated.
 * Every entity that surfaces to a page carries a `confidenceScore` in [0, 1].
 *
 * v1 confidence formula (default, where applicable):
 *   confidenceScore = clamp01( 0.6 * normalizedFrequency + 0.4 * consistency )
 *   - normalizedFrequency: occurrences / max(occurrences across siblings)
 *   - consistency: fraction of distinct sources (sessions/days) supporting the entity
 */

export type ConfidenceScore = number; // [0, 1]

export type SignalKind = "emotional" | "situational" | "belief" | "behavioral";

// ---------- Layer 1 — Raw Signals ----------
export interface RawSignalBase {
  id: string;
  kind: SignalKind;
  /** Free-form short label (e.g. "anxious", "work-conflict", "I'm not enough", "withdraws"). */
  label: string;
  /** Optional ISO timestamp when the source was created. */
  ts?: string;
  /** Reference back to the underlying record id (no PII duplicated). */
  sourceRef: { kind: "answer" | "session" | "snapshot" | "marker" | "tag"; id: string };
}

export interface EmotionalSignal extends RawSignalBase { kind: "emotional"; valence?: number /* -1..1 */ }
export interface SituationalSignal extends RawSignalBase { kind: "situational" }
export interface BeliefSignal extends RawSignalBase { kind: "belief" }
export interface BehavioralSignal extends RawSignalBase { kind: "behavioral" }

export type EmotionalSignals = EmotionalSignal[];
export type SituationalSignals = SituationalSignal[];
export type BeliefSignals = BeliefSignal[];
export type BehavioralSignals = BehavioralSignal[];

// ---------- Layer 2 — Patterns ----------
export type PatternType = SignalKind;

export interface PatternBase {
  id: string;
  type: PatternType;
  description: string; // human-readable, non-clinical
  frequency: number; // raw occurrence count
  recency?: string; // ISO of last occurrence
  supportingExamples: string[]; // signal ids
  confidenceScore: ConfidenceScore;
}
export interface EmotionalPattern extends PatternBase { type: "emotional" }
export interface SituationalPattern extends PatternBase { type: "situational" }
export interface BeliefPattern extends PatternBase { type: "belief" }
export interface BehavioralPattern extends PatternBase { type: "behavioral" }

export type AnyPattern = EmotionalPattern | SituationalPattern | BeliefPattern | BehavioralPattern;

// ---------- Layer 3 — Loop Engine ----------
export interface TriggerType {
  id: string;
  label: string;
  frequency: number;
  confidenceScore: ConfidenceScore;
}

export interface EmotionalSignature {
  id: string;
  label: string;
  dominantEmotions: string[];
  confidenceScore: ConfidenceScore;
}

export interface EmotionalLoop {
  id: string;
  triggerTypes: string[]; // labels
  dominantEmotions: string[];
  typicalBehaviors: string[];
  typicalConsequences: string[];
  frequency: number;
  confidenceScore: ConfidenceScore;
}

// ---------- Layer 4 — Core Themes (replaces "clusters") ----------
export interface CoreTheme {
  id: string;
  title: string;
  description: string;
  supportingPatterns: string[]; // pattern ids
  confidenceScore: ConfidenceScore;
}

// ---------- Layer 5 — Self-Understanding Model ----------
export interface IdentitySignal {
  id: string;
  label: string;
  confidenceScore: ConfidenceScore;
  supporting: string[]; // pattern/loop ids
}

export interface IdentityTheme {
  id: string;
  title: string;
  description: string;
  confidenceScore: ConfidenceScore;
  supportingIdentitySignals: string[];
}

// ---------- Layer 6 — Story Model v1 ----------
export interface LifePattern {
  id: string;
  title: string;
  description: string;
  confidenceScore: ConfidenceScore;
}
export interface SelfConceptPattern {
  id: string;
  title: string;
  description: string;
  confidenceScore: ConfidenceScore;
}
export interface TurningPoint {
  id: string;
  ts?: string;
  label: string;
  description: string;
  confidenceScore: ConfidenceScore;
}

// ---------- Layer 7 — Safety + Accuracy ----------
export interface Contradiction {
  id: string;
  references: string[]; // ids of conflicting entities
  note: string;
}

export interface DeprecatedSignal {
  id: string;
  reason: string;
  since?: string;
}

// ---------- Layer 8 — Time + Evolution ----------
export type ShiftDirection = "increasing" | "decreasing" | "stabilizing";

export interface WeekOverWeekShift {
  what: string;
  direction: ShiftDirection;
  confidenceScore: ConfidenceScore;
}
export interface PatternEvolution {
  what: string;
  direction: ShiftDirection;
  confidenceScore: ConfidenceScore;
}
export interface EmotionalTrend {
  what: string;
  direction: ShiftDirection;
  confidenceScore: ConfidenceScore;
}

// ---------- Layer 9 — Prediction v1 ----------
export interface PredictionSignal {
  id: string;
  label: string; // probabilistic language only
  confidenceScore: ConfidenceScore;
}
export interface FutureTrigger {
  id: string;
  label: string;
  confidenceScore: ConfidenceScore;
}
export interface StabilityIndicator {
  id: string;
  label: string;
  direction: ShiftDirection;
  confidenceScore: ConfidenceScore;
}

// ---------- Layer 10 — Output Surfaces ----------
export interface PatternsPageData {
  emotionalPatterns: EmotionalPattern[];
  behavioralPatterns: BehavioralPattern[];
  emotionalLoops: EmotionalLoop[];
  triggerTypes: TriggerType[];
  emotionalSignatures: EmotionalSignature[];
}

export interface InsightsPageData {
  coreThemes: CoreTheme[];
  identitySignals: IdentitySignal[];
  weekOverWeekShifts: WeekOverWeekShift[];
  emotionalTrends: EmotionalTrend[];
  highConfidencePatterns: AnyPattern[];
}

export interface YourStoryPageData {
  identityThemes: IdentityTheme[];
  lifePatterns: LifePattern[];
  selfConceptPatterns: SelfConceptPattern[];
  turningPoints: TurningPoint[];
}

export interface TimelinePageData {
  patternEvolution: PatternEvolution[];
  emotionalTrends: EmotionalTrend[];
  turningPoints: TurningPoint[];
}

export interface ClarityPlusInsights {
  patterns: PatternsPageData;
  insights: InsightsPageData;
  story: YourStoryPageData;
  timeline: TimelinePageData;
  predictionSignals: PredictionSignal[];
  futureTriggers: FutureTrigger[];
  stabilityIndicators: StabilityIndicator[];
}

export interface FastClarityContext {
  recentEmotionalSignals: EmotionalSignal[];
  recentSituationalSignals: SituationalSignal[];
  recentPatterns: AnyPattern[];
}
