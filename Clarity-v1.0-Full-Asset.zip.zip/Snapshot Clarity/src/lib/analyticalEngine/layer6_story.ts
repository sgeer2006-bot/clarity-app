/**
 * Layer 6 — Story Model v1 (lightweight).
 *
 * v1 derives:
 *   - LifePattern[]: from top CoreThemes (a "life pattern" mirrors a stable
 *     core theme that has appeared consistently).
 *   - SelfConceptPattern[]: from IdentityThemes (how the user tends to
 *     see themselves).
 *   - TurningPoint[]: from pe_timeline_events when present.
 *
 * Returns [] when source data is insufficient.
 *
 * TODO: deeper narrative synthesis once historical timestamping is richer.
 */

import type { LifePattern, SelfConceptPattern, TurningPoint } from "./types";
import { type EngineInputs, withDefaults } from "./adapters";
import { getCoreThemes } from "./layer4_coreThemes";
import { getIdentityThemes } from "./layer5_identity";

function clamp01(n: number): number { return Math.max(0, Math.min(1, n)); }

export function getLifePatterns(userId: string, inputs?: EngineInputs): LifePattern[] {
  const themes = getCoreThemes(userId, inputs);
  return themes.map<LifePattern>((t) => ({
    id: `life:${t.id}`,
    title: t.title,
    description: t.description,
    confidenceScore: clamp01(t.confidenceScore),
  }));
}

export function getSelfConceptPatterns(userId: string, inputs?: EngineInputs): SelfConceptPattern[] {
  const themes = getIdentityThemes(userId, inputs);
  return themes.map<SelfConceptPattern>((t) => ({
    id: `self:${t.id}`,
    title: t.title,
    description: t.description,
    confidenceScore: clamp01(t.confidenceScore),
  }));
}

export function getTurningPoints(_userId: string, inputs?: EngineInputs): TurningPoint[] {
  void _userId;
  const i = withDefaults(inputs);
  return i.timelineEvents
    .map<TurningPoint>((e) => ({
      id: `tp:${e.id}`,
      ts: e.event_date,
      label: e.short_label,
      description: e.summary ?? "",
      confidenceScore: 0.5, // v1 default; TODO: derive from event richness
    }))
    .sort((a, b) => (b.ts ?? "").localeCompare(a.ts ?? "") || a.id.localeCompare(b.id));
}
