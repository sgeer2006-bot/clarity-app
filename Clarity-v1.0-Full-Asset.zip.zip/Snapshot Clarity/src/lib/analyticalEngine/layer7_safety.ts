/**
 * Layer 7 — Safety + Accuracy.
 *
 * detectContradictions: scans IdentitySignals + CoreThemes + Patterns for
 *   conflicting labels (heuristic v1: an identity signal label appearing
 *   in both "strengths" and "vulnerabilities" is a contradiction).
 *
 * assignConfidenceScores: ensures every entity has a confidenceScore. The
 *   v1 formula is documented at the top of types.ts.
 *
 * getDeprecatedSignals: flags low-confidence (<0.2) entities as candidates
 *   for deprecation. Does NOT delete or write any data.
 *
 * applyErrorCorrection: internal pass — when contradictions appear,
 *   confidence is reduced on the conflicting entities. This function
 *   returns adjusted entity arrays so callers can re-sort/filter.
 *
 * No I/O, no writes.
 */

import type {
  Contradiction, DeprecatedSignal, IdentitySignal, CoreTheme, AnyPattern, ConfidenceScore,
} from "./types";
import type { EngineInputs } from "./adapters";
import { getIdentitySignals } from "./layer5_identity";
import { getCoreThemes } from "./layer4_coreThemes";
import { _allPatternsForLayer2 } from "./layer2_patterns";

function clamp01(n: number): number { return Math.max(0, Math.min(1, n)); }

export function detectContradictions(userId: string, inputs?: EngineInputs): Contradiction[] {
  const signals = getIdentitySignals(userId, inputs);
  const seen = new Map<string, IdentitySignal[]>();
  for (const s of signals) {
    const key = s.label.trim().toLowerCase();
    const arr = seen.get(key) ?? [];
    arr.push(s);
    seen.set(key, arr);
  }
  const out: Contradiction[] = [];
  for (const [label, arr] of seen) {
    const sections = new Set(arr.map((a) => a.id.split(":")[1]));
    if (sections.has("strengths") && sections.has("vulnerabilities")) {
      out.push({
        id: `contradiction:${label}`,
        references: arr.map((a) => a.id),
        note: `Same label "${label}" appears in conflicting identity sections.`,
      });
    }
  }
  return out.sort((a, b) => a.id.localeCompare(b.id));
}

export function assignConfidenceScores(entities: Array<{ id: string; confidenceScore?: ConfidenceScore }>):
  Record<string, ConfidenceScore> {
  const out: Record<string, ConfidenceScore> = {};
  for (const e of entities) out[e.id] = clamp01(typeof e.confidenceScore === "number" ? e.confidenceScore : 0);
  return out;
}

export function getDeprecatedSignals(userId: string, inputs?: EngineInputs): DeprecatedSignal[] {
  const all: Array<{ id: string; confidenceScore: number }> = [
    ...getIdentitySignals(userId, inputs),
    ...getCoreThemes(userId, inputs),
    ..._allPatternsForLayer2(inputs ?? {}),
  ];
  return all
    .filter((e) => e.confidenceScore < 0.2)
    .map<DeprecatedSignal>((e) => ({
      id: e.id,
      reason: "Low confidence (below 0.2 threshold)",
    }))
    .sort((a, b) => a.id.localeCompare(b.id));
}

/**
 * Internal pass. Lowers confidence on entities referenced by a contradiction.
 * Returns adjusted copies. Does NOT mutate inputs.
 */
export function applyErrorCorrection<T extends { id: string; confidenceScore: ConfidenceScore }>(
  entities: T[],
  contradictions: Contradiction[]
): T[] {
  if (contradictions.length === 0) return entities;
  const conflicted = new Set(contradictions.flatMap((c) => c.references));
  return entities.map((e) =>
    conflicted.has(e.id)
      ? { ...e, confidenceScore: clamp01(e.confidenceScore * 0.5) }
      : e
  );
}

export function correctAndSort<T extends { id: string; confidenceScore: ConfidenceScore }>(
  entities: T[],
  contradictions: Contradiction[]
): T[] {
  return applyErrorCorrection(entities, contradictions)
    .sort((a, b) => b.confidenceScore - a.confidenceScore || a.id.localeCompare(b.id));
}
