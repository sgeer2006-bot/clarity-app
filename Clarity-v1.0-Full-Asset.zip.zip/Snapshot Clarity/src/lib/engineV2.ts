import { supabase } from "@/integrations/supabase/client";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

// ---- Feature flag ----
// Default ON. Per-session pinning is stored in reflection_sessions.engine_version.
// You can also force it off globally by setting VITE_NEW_ENGINE_V2="false".
export const NEW_ENGINE_V2_DEFAULT =
  (import.meta.env.VITE_NEW_ENGINE_V2 ?? "true").toString().toLowerCase() !== "false";

export const ALL_CONTEXT_FIELDS = [
  "situation",
  "emotions",
  "intentions",
  "triggers",
  "expectations",
  "fears",
  "desired_outcome",
  "relationships",
  "history",
  "unspoken_needs",
] as const;
export type ContextField = typeof ALL_CONTEXT_FIELDS[number];

export interface ContextModel {
  situation: string;
  emotions: string[];
  intentions: string[];
  triggers: string[];
  expectations: string[];
  fears: string[];
  desired_outcome: string;
  relationships: string[];
  history: string[];
  unspoken_needs: string[];
}

export type CoverageState = "empty" | "partial" | "filled";
export type CoverageMap = Record<ContextField, CoverageState>;

export interface NextQuestionV2 {
  done: boolean;
  question?: string;
  target_fields?: ContextField[];
  depth?: 1 | 2 | 3;
  rationale?: string;
  slot?: number;
  hard_cap?: number;
  coverage_map?: CoverageMap;
  saturation_score?: number;
  critical_empty?: ContextField[];
  reason?: string;
}

export interface ClarifyExplanation {
  repair_id: string | null;
  confused_about: string;
  hypothesis: string;
  interpretations: string[];
}

export interface ClarifyPatchResult {
  ack: string;
  patch: Partial<ContextModel>;
  coverage_map: CoverageMap;
  saturation_score: number;
}

async function callFn<T>(fn: string, body: unknown): Promise<T> {
  const { data: sess } = await supabase.auth.getSession();
  const token = sess.session?.access_token;
  if (!token) throw new Error("Not signed in");
  const resp = await fetch(`${SUPABASE_URL}/functions/v1/${fn}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: ANON_KEY,
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body),
  });
  let payload: any = null;
  try { payload = await resp.json(); } catch { /* noop */ }
  if (!resp.ok) {
    const message = payload?.error || `Request failed (${resp.status})`;
    throw new Error(message);
  }
  return payload as T;
}

export async function generateNextQuestionV2(
  sessionId: string,
  priorAnswers: { question: string; answer: string }[],
): Promise<NextQuestionV2> {
  return await callFn<NextQuestionV2>("generate-next-question-v2", {
    sessionId,
    priorAnswers,
  });
}

export async function explainQuestion(
  sessionId: string,
  questionIndex: number,
  questionText: string,
): Promise<ClarifyExplanation> {
  return await callFn<ClarifyExplanation>("clarify-question", {
    sessionId,
    mode: "explain",
    questionIndex,
    questionText,
  });
}

export async function submitClarification(
  sessionId: string,
  questionIndex: number,
  questionText: string,
  clarification: string,
  repairId: string | null,
): Promise<ClarifyPatchResult> {
  return await callFn<ClarifyPatchResult>("clarify-question", {
    sessionId,
    mode: "patch",
    questionIndex,
    questionText,
    clarification,
    repairId,
  });
}

/** Pin a session to a specific engine version (called once on first question). */
export async function pinSessionEngineVersion(sessionId: string, version: "v1" | "v2") {
  await supabase
    .from("reflection_sessions")
    .update({ engine_version: version } as any)
    .eq("id", sessionId);
}

/** Returns the engine version this session is pinned to (defaults to flag). */
export async function getSessionEngineVersion(sessionId: string): Promise<"v1" | "v2"> {
  const { data } = await supabase
    .from("reflection_sessions")
    .select("engine_version" as any)
    .eq("id", sessionId)
    .maybeSingle();
  const v = (data as any)?.engine_version as string | undefined;
  if (v === "v2" || v === "v1") return v;
  return NEW_ENGINE_V2_DEFAULT ? "v2" : "v1";
}

// ---- Lightweight client analytics (best-effort, no PII) ----
type AnalyticsEvent =
  | "question_shown"
  | "question_answered"
  | "question_skipped"
  | "misunderstanding_repair_triggered"
  | "misunderstanding_repair_completed"
  | "engine_v2_session_started"
  | "engine_v2_done"
  | "continuation_started"
  | "continuation_completed"
  | "continuation_exited_by_guard";

export function trackEvent(event: AnalyticsEvent, props: Record<string, unknown> = {}) {
  try {
    // Console-only sink for now; aggregations live in the analytics dashboard tables.
    // eslint-disable-next-line no-console
    console.info(`[analytics] ${event}`, props);
  } catch {
    /* swallow */
  }
}
