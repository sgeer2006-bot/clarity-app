/**
 * Capability Detection Layer
 *
 * Read-only, pure detection of user response signals inside Questions
 * (Reflection Engine). This layer is intentionally NOT wired into any
 * consumer. It exists so future wrapper layers can subscribe to a single,
 * predictable signals object without duplicating ad-hoc detection.
 *
 * Output shape is fixed:
 *   { shortAnswer, lowContext, confused, stalled }
 *
 * No writes. No persistence. No analytics. No navigation. No state mutation.
 */

export interface CapabilitySignals {
  shortAnswer: boolean;
  lowContext: boolean;
  confused: boolean;
  stalled: boolean;
}

export interface CapabilityInput {
  /** The current draft / submitted answer text. */
  answer?: string | null;
  /** Prior answers in the same session, oldest → newest. */
  priorAnswers?: Array<{ question?: string; answer?: string }>;
  /** ms since the user last typed/interacted with the current question. */
  msSinceLastInput?: number;
  /** Whether the engine is currently waiting on the user (no generation in flight). */
  awaitingUser?: boolean;
}

// ---------- Internal sub-detectors (mirror existing implicit rules) ----------

const CONFUSED_PHRASES = [
  "i don't know",
  "i dont know",
  "idk",
  "not sure",
  "no idea",
  "confused",
  "i'm confused",
  "im confused",
  "what do you mean",
  "huh",
  "what",
  "?",
];

const NON_ANSWER_PHRASES = [
  "idk",
  "i don't know",
  "i dont know",
  "no",
  "nothing",
  "n/a",
  "na",
  "skip",
  "pass",
  "dunno",
];

const AVOIDANCE_PHRASES = [
  "i'd rather not",
  "id rather not",
  "don't want to talk about it",
  "dont want to talk about it",
  "next question",
  "skip this",
  "move on",
];

const STALLED_MS_THRESHOLD = 45_000;

function norm(s: string | null | undefined): string {
  return (s ?? "").trim().toLowerCase();
}

function wordCount(s: string): number {
  const t = s.trim();
  if (!t) return 0;
  return t.split(/\s+/).length;
}

function isShortAnswer(answer: string): boolean {
  const t = answer.trim();
  if (!t) return false;
  return t.length < 10 || wordCount(t) <= 1;
}

function isLowContext(answer: string): boolean {
  const t = answer.trim();
  if (!t) return false;
  // Has some length but lacks specifics: no who/what/when markers and few words.
  if (wordCount(t) >= 12) return false;
  const hasSpecifics = /\b(i|he|she|they|we|my|because|when|after|before|said|told|did|felt)\b/i.test(t);
  return !hasSpecifics;
}

function isConfused(answer: string): boolean {
  const n = norm(answer);
  if (!n) return false;
  if (n === "?" || n === "??" || n === "???") return true;
  return CONFUSED_PHRASES.some((p) => n === p || n.startsWith(p + " ") || n.endsWith(" " + p));
}

function isNonAnswer(answer: string): boolean {
  const n = norm(answer);
  return NON_ANSWER_PHRASES.includes(n);
}

function isAvoidance(answer: string): boolean {
  const n = norm(answer);
  return AVOIDANCE_PHRASES.some((p) => n.includes(p));
}

function hasRepeatedNonAnswers(prior: NonNullable<CapabilityInput["priorAnswers"]>): boolean {
  if (prior.length < 2) return false;
  const tail = prior.slice(-2);
  return tail.every((p) => isNonAnswer(p.answer ?? "") || isAvoidance(p.answer ?? ""));
}

// ---------- Public API ----------

export function detectCapabilities(input: CapabilityInput): CapabilitySignals {
  const answer = input.answer ?? "";
  const prior = input.priorAnswers ?? [];

  const shortAnswer = isShortAnswer(answer);
  const lowContext = !shortAnswer && isLowContext(answer);
  const confused = isConfused(answer);

  const stalledByTime =
    !!input.awaitingUser &&
    typeof input.msSinceLastInput === "number" &&
    input.msSinceLastInput >= STALLED_MS_THRESHOLD &&
    answer.trim().length === 0;

  const stalled =
    stalledByTime || isAvoidance(answer) || hasRepeatedNonAnswers(prior);

  return { shortAnswer, lowContext, confused, stalled };
}
