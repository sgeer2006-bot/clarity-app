/**
 * Centralized tone + wording templates for the Questions (Reflection Engine) surface.
 *
 * Voice mirrors Calm, Welcome (FTUE), Insights, and the continuation surfaces:
 * simple, readable, emotionally safe. No condescension. No childish phrasing.
 * No internal terminology in user-visible strings.
 *
 * This module is read-only data. It does not introduce state, context, or hooks.
 */

export const QUESTION_TONE_TEMPLATES = {
  /** Soft openers used when asking the user to clarify. */
  clarifying: [
    "Could you say a little more about that?",
    "Tell me a bit more, in your own words.",
    "What part of this feels most true right now?",
  ],

  /** Gentle fallback transitions when the flow needs to soften. */
  fallbackTransitions: [
    "Let me make this part easier.",
    "I'll simplify this step.",
    "Here are some quick options.",
    "Pick the one that fits best.",
    "Let's take this one step at a time.",
  ],

  /** Quiet reassurance when something feels heavy or uncertain. */
  emotionalSafety: [
    "Take your time — there's no wrong answer here.",
    "Whatever shows up is okay.",
    "A few words is enough.",
  ],

  /** Light forward nudges when the user seems ready to continue. */
  moveForward: [
    "Whenever you're ready, we can keep going.",
    "When it feels right, continue.",
  ],

  /** Simplify nudges shown when responses are short or low-context. */
  simplify: [
    "Let me make this part easier.",
    "I'll simplify this step.",
    "Let's take this one step at a time.",
  ],
} as const;

export type ToneCategory = keyof typeof QUESTION_TONE_TEMPLATES;

/** Pick the first template in a category (stable, no randomness). */
export function getToneLine(category: ToneCategory): string {
  return QUESTION_TONE_TEMPLATES[category][0];
}
