/**
 * Phase 6 folders — strictly client-side. No backend writes. Stored in
 * localStorage under `clarity.folders.v1`.
 */

const KEY = "clarity.folders.v1";

export interface FolderEntry {
  id: string;
  text: string;
  createdAt: string;
}

export interface Folder {
  id: string;
  name: string;
  createdAt: string;
  entries: FolderEntry[];
}

interface Shape {
  version: 1;
  folders: Folder[];
}

function read(): Shape {
  if (typeof window === "undefined") return { version: 1, folders: [] };
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { version: 1, folders: [] };
    const parsed = JSON.parse(raw);
    if (parsed?.version === 1 && Array.isArray(parsed.folders)) return parsed;
  } catch { /* ignore */ }
  return { version: 1, folders: [] };
}

function write(s: Shape) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
    window.dispatchEvent(new Event("clarity:folders"));
  } catch { /* ignore */ }
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export function listFolders(): Folder[] {
  return read().folders.slice().sort((a, b) => a.name.localeCompare(b.name));
}

export function getFolder(id: string): Folder | undefined {
  return read().folders.find((f) => f.id === id);
}

export function createFolder(name: string): Folder {
  const s = read();
  const folder: Folder = {
    id: uid(),
    name: name.trim() || "Untitled",
    createdAt: new Date().toISOString(),
    entries: [],
  };
  s.folders.push(folder);
  write(s);
  return folder;
}

export function renameFolder(id: string, name: string): void {
  const s = read();
  const f = s.folders.find((x) => x.id === id);
  if (!f) return;
  f.name = name.trim() || f.name;
  write(s);
}

export function deleteFolder(id: string): void {
  const s = read();
  s.folders = s.folders.filter((f) => f.id !== id);
  write(s);
}

export function addEntry(folderId: string, text: string): void {
  const s = read();
  const f = s.folders.find((x) => x.id === folderId);
  if (!f) return;
  f.entries.unshift({ id: uid(), text: text.trim(), createdAt: new Date().toISOString() });
  write(s);
}

export function deleteEntry(folderId: string, entryId: string): void {
  const s = read();
  const f = s.folders.find((x) => x.id === folderId);
  if (!f) return;
  f.entries = f.entries.filter((e) => e.id !== entryId);
  write(s);
}
