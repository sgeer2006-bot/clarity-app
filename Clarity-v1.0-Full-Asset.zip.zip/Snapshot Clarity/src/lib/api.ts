import { supabase } from "@/integrations/supabase/client";
import type { SnapshotJson } from "@/lib/types";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

export class FriendlyError extends Error {
  kind: "network" | "auth" | "ai" | "unknown";
  constructor(kind: FriendlyError["kind"], message: string) {
    super(message);
    this.kind = kind;
  }
}

const NETWORK_MSG =
  "We couldn't reach the server. Please check your connection and try again.";
const AI_MSG =
  "Something went wrong generating your next question. Please try again in a moment.";
const AUTH_MSG = "Your session expired. Please sign in again.";

async function withRetry<T>(fn: () => Promise<T>, maxAttempts = 3): Promise<T> {
  let lastError: unknown;
  for (let i = 0; i < maxAttempts; i++) {
    try {
      return await fn();
    } catch (e) {
      lastError = e;
      // Don't retry auth failures
      if (e instanceof FriendlyError && e.kind === "auth") throw e;
      if (i < maxAttempts - 1) {
        await new Promise((r) => setTimeout(r, 500 * Math.pow(2, i)));
      }
    }
  }
  throw lastError instanceof Error ? lastError : new FriendlyError("unknown", AI_MSG);
}

async function callEdge<T>(path: string, body: unknown): Promise<T> {
  const { data: sess } = await supabase.auth.getSession();
  const token = sess.session?.access_token;
  if (!token) throw new FriendlyError("auth", AUTH_MSG);

  let resp: Response;
  try {
    resp = await fetch(`${SUPABASE_URL}/functions/v1/${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: ANON_KEY,
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(body),
    });
  } catch {
    throw new FriendlyError("network", NETWORK_MSG);
  }

  let payload: any = null;
  try { payload = await resp.json(); } catch { /* ignore */ }

  if (resp.status === 401) throw new FriendlyError("auth", AUTH_MSG);
  if (!resp.ok) throw new FriendlyError("ai", payload?.error || AI_MSG);
  return payload as T;
}

export interface NextQuestion {
  question: string;
  question_type: "open" | "yesno";
  min_chars: number;
  sufficiency_score: number;
  done: boolean;
  target: number;
  max: number;
}

export async function generateNextQuestion(
  sessionId: string,
  priorAnswers: { question: string; answer: string; type?: string }[],
  opts?: { forceRegenerate?: boolean },
): Promise<NextQuestion> {
  const data = await withRetry(() =>
    callEdge<NextQuestion>("generate-next-question", {
      sessionId,
      priorAnswers,
      forceRegenerate: !!opts?.forceRegenerate,
    }),
  );
  // `done` responses can have an empty question — that's valid.
  if (!data.done && (!data.question || typeof data.question !== "string")) {
    throw new FriendlyError("ai", AI_MSG);
  }
  return data;
}

export async function generateAnswerNudge(
  sessionId: string,
  currentQuestion: string,
  answer: string,
): Promise<string> {
  try {
    const data = await callEdge<{ nudge: string }>("generate-next-question", {
      sessionId,
      mode: "nudge",
      currentQuestion,
      answer,
    });
    return data.nudge || "Could you add a bit more detail so I can understand this better?";
  } catch {
    return "Could you add a bit more detail so I can understand this better?";
  }
}

export async function generateSnapshot(sessionId: string): Promise<SnapshotJson> {
  const data = await withRetry(() =>
    callEdge<{ snapshot: SnapshotJson }>("generate-snapshot", {
      sessionId,
    }),
  );
  if (!data.snapshot) throw new FriendlyError("ai", AI_MSG);
  return data.snapshot;
}

export async function generateFollowUpQuestion(
  sessionId: string,
  section: string,
  priorMessages: { role: string; content: string }[],
): Promise<string> {
  const data = await withRetry(() =>
    callEdge<{ question: string }>("generate-follow-up", {
      sessionId,
      section,
      priorMessages,
    }),
  );
  if (!data.question) throw new FriendlyError("ai", AI_MSG);
  return data.question;
}

export async function generateCorrectionQuestion(
  sessionId: string,
  corrections: { role: string; content: string }[],
): Promise<string> {
  const data = await withRetry(() =>
    callEdge<{ question: string }>("generate-correction", {
      sessionId,
      mode: "question",
      corrections,
    }),
  );
  if (!data.question) throw new FriendlyError("ai", AI_MSG);
  return data.question;
}

export async function regenerateSnapshot(
  sessionId: string,
  corrections: { role: string; content: string }[],
): Promise<{ snapshot: import("@/lib/types").SnapshotJson; version: number }> {
  const data = await withRetry(() =>
    callEdge<{ snapshot: import("@/lib/types").SnapshotJson; version: number }>("generate-correction", {
      sessionId,
      mode: "regenerate",
      corrections,
    }),
  );
  if (!data.snapshot) throw new FriendlyError("ai", AI_MSG);
  return data;
}

export async function suggestFolder(sessionId: string): Promise<{
  folder_id: string;
  folder_name: string;
  created_new: boolean;
  already_assigned: boolean;
}> {
  return await callEdge("suggest-folder", { sessionId });
}

export interface LocalResourceSuggestion {
  title: string;
  why: string;
  search_query: string;
  category: string;
}

export async function suggestLocalResources(
  sessionId: string,
): Promise<LocalResourceSuggestion[]> {
  const data = await callEdge<{ suggestions: LocalResourceSuggestion[] }>(
    "suggest-local-resources",
    { sessionId },
  );
  return data.suggestions ?? [];
}

export interface PatternMatch {
  pattern_id: string;
  confidence: number;
  reason: string;
}

/**
 * Fire-and-forget: classify the session against the public pattern catalog.
 * Errors are swallowed so a failure here never blocks the snapshot UX.
 */
export async function detectPatterns(sessionId: string): Promise<PatternMatch[]> {
  try {
    const data = await callEdge<{ matches: PatternMatch[] }>("detect-patterns", {
      sessionId,
    });
    return data.matches ?? [];
  } catch (e) {
    console.warn("detect-patterns failed", e);
    return [];
  }
}

export function makeShareToken(): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const arr = new Uint32Array(32);
  crypto.getRandomValues(arr);
  let out = "";
  for (let i = 0; i < 32; i++) out += chars[arr[i] % chars.length];
  return out;
}

export interface AssignedPatternIdentity {
  id: string;
  slug: string;
  name: string;
  short_description: string;
  long_description?: string;
  emotional_signature?: string;
  communication_tendency?: string;
  growth_edge?: string;
}

/**
 * Tag a completed snapshot with one named pattern identity from the catalog.
 * Idempotent — safe to call multiple times. Returns the assigned identity.
 */
export async function assignPatternIdentity(sessionId: string): Promise<AssignedPatternIdentity | null> {
  try {
    const data = await callEdge<{ identity: AssignedPatternIdentity }>(
      "assign-pattern-identity",
      { sessionId },
    );
    return data.identity ?? null;
  } catch (e) {
    console.warn("assignPatternIdentity failed", e);
    return null;
  }
}
