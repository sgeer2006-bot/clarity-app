/**
 * Phase 1 — Centralized feature gating.
 *
 * Encodes the verbatim tier rules from the Phase 1 restructure spec and
 * provides thin wrappers around the existing premium check (`usePremium`
 * / `readTier`). Existing code is **not** modified — call sites can
 * progressively migrate to `canUse(...)` and `getQuota(...)` here.
 *
 * Tiers: free | basic | premium
 */

import type { Tier } from "@/lib/continuation/gate";
import { readTier } from "@/lib/continuation/gate";

export type FeatureTier = Tier;

/** Feature keys used by the new gate. */
export type GatedFeature =
  | "conversations"
  | "insights_full"
  | "identity_card"
  | "identity_deep"
  | "timeline_full"
  | "reflective_prompts_full"
  | "communication_patterns"
  | "emotional_loops"
  | "situational_patterns"
  | "weekly_digest_basic"
  | "weekly_digest_premium"
  | "analytics_basic"
  | "analytics_premium"
  | "folders_unlimited"
  | "history_unlimited"
  | "two_person"
  | "cluster_intelligence"
  | "continuation_engine"
  | "premium_calm_layer"
  | "premium_visual_themes"
  | "premium_onboarding"
  | "trend_shifts"
  | "narrative_summary_long"
  | "relationship_insights";

/**
 * Lowest tier that unlocks a feature. Anything not listed here is treated
 * as "free" (always available within the free quota limits below).
 */
const MIN_TIER: Record<GatedFeature, FeatureTier> = {
  // Free-tier observable surfaces (capped via quotas below)
  conversations: "free",
  identity_card: "free",
  insights_full: "basic",

  // Basic
  timeline_full: "basic",
  reflective_prompts_full: "basic",
  communication_patterns: "basic",
  emotional_loops: "basic",
  situational_patterns: "basic",
  weekly_digest_basic: "basic",
  analytics_basic: "basic",
  folders_unlimited: "basic",
  history_unlimited: "basic",

  // Premium
  identity_deep: "premium",
  two_person: "premium",
  cluster_intelligence: "premium",
  continuation_engine: "premium",
  premium_calm_layer: "premium",
  premium_visual_themes: "premium",
  premium_onboarding: "premium",
  trend_shifts: "premium",
  narrative_summary_long: "premium",
  weekly_digest_premium: "premium",
  analytics_premium: "premium",
  relationship_insights: "premium",
};

const TIER_RANK: Record<FeatureTier, number> = { free: 0, basic: 1, premium: 2 };

/** Quotas for the free tier. Basic/premium are unlimited (`null`). */
export const FREE_QUOTAS = {
  conversationsPerDay: 3,
  insights: { emotional: 1, situational: 1, communication: 1 },
  identityRecurringTriggers: 1,
  timelineEntries: 3,
  reflectivePromptsPerDay: 2,
  folders: 1,
  historyItems: 5,
} as const;

/** True when the current tier has access to the named feature. */
export function canUse(feature: GatedFeature, tier: FeatureTier = readTier()): boolean {
  const min = MIN_TIER[feature];
  return TIER_RANK[tier] >= TIER_RANK[min];
}

/**
 * Returns the cap for a counted feature on the free tier, or `null` for
 * unlimited (basic/premium). Unknown keys return `null`.
 */
export function getQuota(
  key: keyof typeof FREE_QUOTAS,
  tier: FeatureTier = readTier()
): number | null {
  if (tier !== "free") return null;
  const v = FREE_QUOTAS[key];
  return typeof v === "number" ? v : null;
}

/** Convenience: current tier (read-only snapshot). */
export function currentTier(): FeatureTier {
  return readTier();
}
