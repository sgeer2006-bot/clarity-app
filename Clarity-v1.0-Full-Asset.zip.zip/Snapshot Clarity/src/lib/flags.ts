/**
 * Phase 2 — A/B + experiment flags. Lightweight localStorage-backed
 * toggles. Defaults are conservative (most off) so free flow is unaffected.
 */

const PREFIX = "clarity.flags.";

export type ExperimentFlag =
  | "successChip"
  | "continuationBadge"
  | "dailyMicroDigest"
  | "premiumOnboardingTease"
  | "premiumCalm";

const DEFAULTS: Record<ExperimentFlag, boolean> = {
  successChip: true,
  continuationBadge: true,
  dailyMicroDigest: false,
  premiumOnboardingTease: true,
  premiumCalm: false,
};

export function getFlag(name: ExperimentFlag): boolean {
  if (typeof window === "undefined") return DEFAULTS[name];
  const raw = localStorage.getItem(PREFIX + name);
  if (raw == null) return DEFAULTS[name];
  return raw === "true";
}

export function setFlag(name: ExperimentFlag, on: boolean) {
  localStorage.setItem(PREFIX + name, String(on));
  window.dispatchEvent(new CustomEvent("clarity:flags"));
}

export const FLAG_LIST: ExperimentFlag[] = [
  "successChip",
  "continuationBadge",
  "dailyMicroDigest",
  "premiumOnboardingTease",
  "premiumCalm",
];
