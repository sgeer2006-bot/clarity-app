export type ReflectionStatus = "in_progress" | "complete" | "abandoned";

export interface ReflectionSessionRow {
  id: string;
  user_id: string;
  title: string;
  status: ReflectionStatus;
  snapshot: string | null;
  snapshot_json: SnapshotJson | null;
  share_token: string | null;
  folder_id: string | null;
  created_at: string;
  completed_at: string | null;
  deleted_at: string | null;
}

export interface FolderRow {
  id: string;
  user_id: string;
  name: string;
  created_at: string;
}

export type QuestionType = "open" | "yesno";

export interface ReflectionAnswerRow {
  id: string;
  session_id: string;
  question_index: number;
  question_text: string;
  answer_text: string;
  question_type: QuestionType;
  min_chars: number;
  sufficiency_score: number | null;
  created_at: string;
}

export interface SnapshotJson {
  summary: string;
  observations: string[];
  possible_paths: string[];
  /** Gentle, neutral suggestions for what someone might do next. Optional — older snapshots may not have this. */
  recommended_next_steps?: string[];
  /** Things the other person might be misreading or misunderstanding. Optional. */
  common_misunderstandings?: string[];
  /** Phrasing ideas for talking about the situation with the other person. Optional. */
  how_to_communicate?: string[];
  disclaimer: string;
}

export const FIRST_QUESTION =
  "What situation would you like to talk about today? You can describe it in your own words.";

export const FIRST_QUESTION_PLACEHOLDER =
  "For example: something that happened at work, with a friend, with family…";

export const FIRST_QUESTION_MIN_CHARS = 40;

export const SNAPSHOT_DISCLAIMER =
  "This tool does not give advice. It generates general perspectives based solely on the information you provide. You are responsible for your own decisions.";

// Soft target — UI shows progress against this; flow can continue beyond it.
export const TARGET_QUESTIONS = 5;
// Hard cap — the flow will always end by this question.
export const MAX_QUESTIONS = 10;

// Kept for any legacy references; treat as the soft target.
export const TOTAL_QUESTIONS = TARGET_QUESTIONS;

export type FollowUpSection = "summary" | "consider" | "paths";

export interface FollowUpMessageRow {
  id: string;
  session_id: string;
  section: FollowUpSection;
  role: "user" | "ai";
  content: string;
  created_at: string;
}

export interface SnapshotVersionRow {
  id: string;
  session_id: string;
  version_number: number;
  summary: string;
  observations: string[];
  possible_paths: string[];
  recommended_next_steps?: string[];
  common_misunderstandings?: string[];
  how_to_communicate?: string[];
  disclaimer: string;
  created_at: string;
}
