import { toPng } from "html-to-image";
import { supabase } from "@/integrations/supabase/client";
import type { SnapshotJson } from "@/lib/types";
import type { ShareVariant } from "@/components/ShareSnapshotCard";
import { makeShareToken } from "@/lib/api";

export interface CreatedShare {
  token: string;
  url: string;
  imageUrl: string | null;
}

/**
 * Render a snapshot card node to a PNG blob.
 * Uses devicePixelRatio of 1 because the card itself is rendered at full
 * 1080-px export size — we don't want the browser to upscale further.
 */
export async function renderCardToPng(node: HTMLElement): Promise<Blob> {
  const dataUrl = await toPng(node, {
    pixelRatio: 1,
    cacheBust: true,
    skipFonts: false,
    backgroundColor: "#f5efe6",
  });
  const resp = await fetch(dataUrl);
  return await resp.blob();
}

/**
 * Persist a shared snapshot: upload PNG to storage and insert a row.
 * Returns the public share URL and the image URL.
 */
export async function createSharedSnapshot(opts: {
  sessionId: string;
  userId: string;
  title: string;
  snapshot: SnapshotJson;
  variant: ShareVariant;
  imageBlob: Blob;
}): Promise<CreatedShare> {
  const token = makeShareToken();

  // Upload PNG to public bucket under user's own folder (matches RLS policy)
  const path = `${opts.userId}/${token}.png`;
  const { error: upErr } = await supabase.storage
    .from("snapshot-shares")
    .upload(path, opts.imageBlob, {
      contentType: "image/png",
      cacheControl: "31536000",
      upsert: false,
    });
  if (upErr) throw upErr;

  const { data: pub } = supabase.storage.from("snapshot-shares").getPublicUrl(path);
  const imageUrl = pub.publicUrl;

  const { error: insErr } = await supabase.from("shared_snapshots").insert({
    user_id: opts.userId,
    session_id: opts.sessionId,
    token,
    variant: opts.variant,
    title: opts.title,
    summary: opts.snapshot.summary,
    observations: opts.snapshot.observations,
    possible_paths: opts.snapshot.possible_paths,
    image_path: path,
  });
  if (insErr) throw insErr;

  const url = `${window.location.origin}/s/${token}`;
  return { token, url, imageUrl };
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
