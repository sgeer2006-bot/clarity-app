/**
 * Phase 6 one-time local data reset.
 *
 * Wipes all `clarity.*` localStorage keys EXCEPT a small preserve list, then
 * marks the reset complete so it never runs again. Designed to be safe to call
 * on every boot — it is a no-op after the first successful run.
 *
 * Per Phase 6 spec, but adjusted: we preserve the user's subscription token
 * and onboarding completion flag so existing premium users are not silently
 * downgraded and returning users are not forced through onboarding.
 */

const RESET_FLAG = "clarity.phase6.reset";
const RESET_VERSION = "v1";

const PRESERVE_KEYS = new Set<string>([
  "clarity.subscription_token",
  "clarity.onboarding.done",
]);

const DEFAULT_FLAGS: Record<string, string> = {
  "clarity.flags.calmCanvas": "true",
  "clarity.flags.habitLoops": "true",
  "clarity.flags.continuationEngine": "true",
};

export function runPhase6ResetOnce(): void {
  if (typeof window === "undefined") return;
  try {
    if (localStorage.getItem(RESET_FLAG) === RESET_VERSION) return;

    const preserved: Record<string, string> = {};
    for (const key of PRESERVE_KEYS) {
      const v = localStorage.getItem(key);
      if (v != null) preserved[key] = v;
    }

    const toRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith("clarity.") && !PRESERVE_KEYS.has(k)) {
        toRemove.push(k);
      }
    }
    for (const k of toRemove) localStorage.removeItem(k);

    for (const [k, v] of Object.entries(preserved)) {
      localStorage.setItem(k, v);
    }
    for (const [k, v] of Object.entries(DEFAULT_FLAGS)) {
      if (localStorage.getItem(k) == null) localStorage.setItem(k, v);
    }

    localStorage.setItem(RESET_FLAG, RESET_VERSION);

    // Best-effort calm notification — don't block if sonner not ready.
    queueMicrotask(() => {
      try {
        // Lazy import to avoid pulling toast into the boot path.
        import("sonner").then(({ toast }) => {
          toast("Clarity has been refreshed.", {
            description: "Your account, subscription, and reflections in the cloud are unchanged.",
          });
        }).catch(() => {});
      } catch {
        /* noop */
      }
    });
  } catch {
    /* localStorage unavailable — skip silently */
  }
}
