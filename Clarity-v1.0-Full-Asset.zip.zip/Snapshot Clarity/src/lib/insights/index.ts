import type { Insight, InsightContext } from "./types";
import { deriveFrequencyInsights } from "./rules/frequency";
import { deriveTimelineInsights } from "./rules/timeline";
import { deriveClusterInsights } from "./rules/clusters";
import { deriveIdentityInsights } from "./rules/identity";
import { deriveLoopInsights } from "./rules/loops";
import { deriveRoleInsights } from "./rules/roles";

export * from "./types";
export { sanitize, DISALLOWED_TERMS, HEDGES } from "./lexicon";
export { hedge, titleCase, truncate, stableId } from "./format";
export { deriveFrequencyInsights } from "./rules/frequency";
export { deriveTimelineInsights } from "./rules/timeline";
export { deriveClusterInsights } from "./rules/clusters";
export { deriveIdentityInsights } from "./rules/identity";
export { deriveLoopInsights } from "./rules/loops";
export { deriveRoleInsights } from "./rules/roles";
export { buildWeeklyDigest } from "./digest";

const CONF_ORDER = { high: 0, medium: 1, low: 2 } as const;

export function buildInsights(ctx: InsightContext): Insight[] {
  const all: Insight[] = [
    ...deriveLoopInsights({ rows: ctx.frequency ?? [] }),
    ...deriveRoleInsights({ rows: ctx.frequency ?? [] }),
    ...deriveClusterInsights({ rows: ctx.clusters ?? [] }),
    ...deriveFrequencyInsights({ rows: ctx.frequency ?? [] }),
    ...deriveIdentityInsights({ identity: ctx.identity ?? null }),
    ...deriveTimelineInsights({ rows: ctx.timeline ?? [] }),
  ];

  const dedup = new Map<string, Insight>();
  for (const i of all) if (!dedup.has(i.id)) dedup.set(i.id, i);

  return Array.from(dedup.values())
    .sort((a, b) => {
      const c = CONF_ORDER[a.confidence] - CONF_ORDER[b.confidence];
      if (c !== 0) return c;
      return a.title.localeCompare(b.title);
    })
    .slice(0, 12);
}
