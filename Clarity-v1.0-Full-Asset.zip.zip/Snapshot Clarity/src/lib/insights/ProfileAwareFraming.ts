/**
 * ProfileAwareFraming — pure-logic module.
 *
 * Reads from the Psychological Profile Engine (Module #9) and the
 * Profile-Driven Insights Engine (Module #10) and returns three optional,
 * context-preserving outputs:
 *   - a short framing line (drawn from Module #5 tone templates)
 *   - a gentle guardrail line (drawn from Module #5 tone templates)
 *   - a small, balanced set of optional exploration prompts
 *
 * Pure: no I/O, no React, no navigation, no analytics, no storage,
 * no side effects. Deterministic for a given input. Not wired into
 * any consumer in this module.
 *
 * Tone matches the Module #5 Tone + Wording Templates: warm, simple,
 * emotionally safe, non-clinical, non-diagnostic, non-prescriptive.
 */

import { QUESTION_TONE_TEMPLATES } from "@/lib/questions/toneTemplates";
import type {
  PsychologicalProfileLike,
  ProfileEntryLike,
  GeneratedInsights,
  IdentityInsight,
  SituationInsight,
  TrendInsight,
  Confidence,
} from "@/lib/insights/ProfileInsightsEngine";

// ---------- Public types ----------

export interface FramingMessage {
  text: string;
  category: "framing";
}

export type GuardrailTrigger =
  | "overwhelm"
  | "avoidance"
  | "overload"
  | "rumination";

export interface GuardrailMessage {
  text: string;
  category: "guardrail";
  trigger: GuardrailTrigger;
}

export interface ExplorationPrompt {
  text: string;
  source: "identity" | "situation" | "trend";
  relatedKey?: string;
}

export interface ProfileAwareFramingResult {
  framing: FramingMessage | null;
  guardrails: GuardrailMessage | null;
  optionalExplorations: ExplorationPrompt[];
}

// ---------- Internal constants ----------

const CONF_RANK: Record<Confidence, number> = {
  emerging: 0,
  recurring: 1,
  consistent: 2,
};

const FORBIDDEN_FRAGMENTS = [
  "disorder", "diagnosis", "diagnostic", "symptom", "pathology", "trauma response",
  "you should", "you need to", "you must",
  "always", "never", "definitely", "cured", "fixed",
];

const EXPLORATION_CAP = 3;

// ---------- Internal tone helper ----------

/**
 * Enforces tone constraints on any text-emitting path:
 *  - 1-2 sentences max
 *  - no clinical / prescriptive / certainty language
 *  - trims and ensures terminal punctuation
 */
function sanitizeTone(text: string): string {
  if (typeof text !== "string") return "";
  let out = text;
  for (const frag of FORBIDDEN_FRAGMENTS) {
    const re = new RegExp(frag.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
    out = out.replace(re, "");
  }
  out = out.replace(/\s+/g, " ").trim();
  if (out.length === 0) return "";
  if (!/[.!?]$/.test(out)) out += ".";
  const parts = out.split(/(?<=[.!?])\s+/);
  return parts.slice(0, 2).join(" ");
}

function confidenceOf(e: ProfileEntryLike | undefined): Confidence {
  if (!e) return "emerging";
  if (e.confidence) return e.confidence;
  const n = typeof e.observationCount === "number" ? e.observationCount : 0;
  if (n >= 5) return "consistent";
  if (n >= 2) return "recurring";
  return "emerging";
}

function meetsMinConfidence(e: ProfileEntryLike | undefined): boolean {
  return CONF_RANK[confidenceOf(e)] >= CONF_RANK.recurring;
}

function pickTemplate(
  category: keyof typeof QUESTION_TONE_TEMPLATES,
  index = 0,
): string | null {
  const list = QUESTION_TONE_TEMPLATES[category] as readonly string[];
  if (!list || list.length < 1) return null;
  const safeIndex = Math.max(0, Math.min(index, list.length - 1));
  const raw = list[safeIndex];
  const cleaned = sanitizeTone(raw);
  return cleaned.length > 0 ? cleaned : null;
}

// ---------- generateFraming ----------

/**
 * Returns at most one short, warm framing line drawn from the existing
 * Module #5 templates. Lightly biases template selection on profile
 * signals (e.g., over-explaining / perfectionism leans toward an
 * emotional-safety line). Returns null when no template line fits.
 */
export function generateFraming(
  profile: PsychologicalProfileLike | null | undefined,
  recentInsights: GeneratedInsights | null | undefined,
): FramingMessage | null {
  // If we have neither profile nor insights signal, fall back to a
  // neutral "move forward" line if available.
  const hasProfile = !!profile && Object.keys(profile).length > 0;
  const hasInsights =
    !!recentInsights &&
    ((recentInsights.identityInsights?.length ?? 0) > 0 ||
      (recentInsights.situationInsights?.length ?? 0) > 0 ||
      (recentInsights.trendInsights?.length ?? 0) > 0 ||
      !!recentInsights.topInsight);

  if (!hasProfile && !hasInsights) {
    const line = pickTemplate("moveForward", 0);
    return line ? { text: line, category: "framing" } : null;
  }

  // Heuristic bias: if the profile shows perfectionism / over-explaining /
  // self-critical thinking patterns at recurring+ confidence, prefer an
  // emotional-safety line. Otherwise default to a "simplify" line.
  const lookFor = ["perfection", "over-explain", "over explain", "self-critical", "self critical", "rumination"];
  let leansSafety = false;
  if (profile) {
    const pools: ProfileEntryLike[][] = [
      profile.thinkingPatterns ?? [],
      profile.emotionalPatterns ?? [],
      profile.communicationStyle ?? [],
      profile.behaviorPatterns ?? [],
    ];
    outer: for (const pool of pools) {
      for (const e of pool) {
        if (!meetsMinConfidence(e)) continue;
        const hay = `${e.key ?? ""} ${e.label ?? ""}`.toLowerCase();
        if (lookFor.some((needle) => hay.includes(needle))) {
          leansSafety = true;
          break outer;
        }
      }
    }
  }

  const category: keyof typeof QUESTION_TONE_TEMPLATES = leansSafety
    ? "emotionalSafety"
    : "simplify";
  const line = pickTemplate(category, 0) ?? pickTemplate("moveForward", 0);
  if (!line) return null;
  return { text: line, category: "framing" };
}

// ---------- generateGuardrails ----------

interface TriggerDetection {
  trigger: GuardrailTrigger;
  rank: number; // higher = stronger signal, used for deterministic tie-break
}

function detectTrigger(
  profile: PsychologicalProfileLike,
): TriggerDetection | null {
  const stressList = (profile.stressResponses ?? []).filter(meetsMinConfidence);
  const avoidList = (profile.avoidancePatterns ?? []).filter(meetsMinConfidence);
  const emoList = (profile.emotionalPatterns ?? []).filter(meetsMinConfidence);
  const thinkList = (profile.thinkingPatterns ?? []).filter(meetsMinConfidence);

  const overwhelmHints = ["overwhelm", "shutdown", "flooded", "panic"];
  const avoidanceHints = ["avoid", "withdraw", "shut down", "deflect", "freeze"];
  const overloadHints = ["over-explain", "over explain", "overshare", "overthink", "overload"];
  const ruminationHints = ["rumination", "ruminate", "loop", "spiraling", "spiral"];

  const candidates: TriggerDetection[] = [];

  const scan = (
    pool: ProfileEntryLike[],
    hints: string[],
    trigger: GuardrailTrigger,
    weight: number,
  ) => {
    for (const e of pool) {
      const hay = `${e.key ?? ""} ${e.label ?? ""}`.toLowerCase();
      if (hints.some((h) => hay.includes(h))) {
        const obs = typeof e.observationCount === "number" ? e.observationCount : 0;
        candidates.push({ trigger, rank: weight + obs });
        break;
      }
    }
  };

  scan(stressList, overwhelmHints, "overwhelm", 100);
  scan(emoList, overwhelmHints, "overwhelm", 90);
  scan(avoidList, avoidanceHints, "avoidance", 100);
  scan(thinkList, ruminationHints, "rumination", 100);
  scan(emoList, ruminationHints, "rumination", 90);
  scan(thinkList, overloadHints, "overload", 100);
  scan(emoList, overloadHints, "overload", 80);

  if (candidates.length === 0) return null;
  candidates.sort((a, b) => {
    if (b.rank !== a.rank) return b.rank - a.rank;
    return a.trigger.localeCompare(b.trigger);
  });
  return candidates[0];
}

/**
 * Returns at most one gentle, optional guardrail line drawn from the
 * existing Module #5 emotional-safety templates, only when a qualifying
 * trigger (overwhelm / avoidance / overload / rumination) is observed
 * at recurring or consistent confidence in the profile.
 */
export function generateGuardrails(
  profile: PsychologicalProfileLike | null | undefined,
): GuardrailMessage | null {
  if (!profile) return null;
  const detection = detectTrigger(profile);
  if (!detection) return null;

  // Choose a stable safety line; index 0 reads as a clear, gentle pause.
  const line = pickTemplate("emotionalSafety", 0);
  if (!line) return null;

  return {
    text: line,
    category: "guardrail",
    trigger: detection.trigger,
  };
}

// ---------- generateOptionalExploration ----------

function buildIdentityPrompt(i: IdentityInsight): ExplorationPrompt | null {
  const subject = i.text.replace(/\.$/, "");
  // Re-frame as an invitation; rely on sanitizer to enforce tone.
  const text = sanitizeTone(
    `Want to explore this a little later? ${subject}.`,
  );
  if (!text) return null;
  return { text, source: "identity", relatedKey: i.category };
}

function buildSituationPrompt(s: SituationInsight): ExplorationPrompt | null {
  const text = sanitizeTone(
    `Would you like to look at the moments around ${s.theme} more deeply?`,
  );
  if (!text) return null;
  return { text, source: "situation", relatedKey: s.theme };
}

function buildTrendPrompt(t: TrendInsight): ExplorationPrompt | null {
  const subject = t.text.replace(/\.$/, "");
  const text = sanitizeTone(`Want to explore this shift later? ${subject}.`);
  if (!text) return null;
  return { text, source: "trend", relatedKey: t.category };
}

/**
 * Returns up to 3 optional exploration prompts, balanced so that at most
 * one comes from each of identity / situation / trend sources. The Top
 * Insight is intentionally excluded to avoid duplication. Deterministic
 * ordering: identity → situation → trend, with internal ties broken
 * alphabetically by text.
 */
export function generateOptionalExploration(
  _profile: PsychologicalProfileLike | null | undefined,
  insights: GeneratedInsights | null | undefined,
): ExplorationPrompt[] {
  if (!insights) return [];

  const prompts: ExplorationPrompt[] = [];

  // Identity: prefer highest confidence first.
  const identitySorted = (insights.identityInsights ?? [])
    .slice()
    .sort((a, b) => {
      const cd = CONF_RANK[b.confidence] - CONF_RANK[a.confidence];
      if (cd !== 0) return cd;
      return a.text.localeCompare(b.text);
    });
  if (identitySorted.length > 0) {
    const p = buildIdentityPrompt(identitySorted[0]);
    if (p) prompts.push(p);
  }

  // Situation: take the first (already deterministically ordered upstream).
  const situations = insights.situationInsights ?? [];
  if (situations.length > 0) {
    const sorted = situations.slice().sort((a, b) => a.theme.localeCompare(b.theme));
    const p = buildSituationPrompt(sorted[0]);
    if (p) prompts.push(p);
  }

  // Trend: take the first (already deterministically ordered upstream).
  const trends = insights.trendInsights ?? [];
  if (trends.length > 0) {
    const sorted = trends.slice().sort((a, b) => a.text.localeCompare(b.text));
    const p = buildTrendPrompt(sorted[0]);
    if (p) prompts.push(p);
  }

  return prompts.slice(0, EXPLORATION_CAP);
}

// ---------- Single entry point ----------

export function getProfileAwareFraming(
  profile: PsychologicalProfileLike | null | undefined,
  recentInsights: GeneratedInsights | null | undefined,
): ProfileAwareFramingResult {
  return {
    framing: generateFraming(profile ?? null, recentInsights ?? null),
    guardrails: generateGuardrails(profile ?? null),
    optionalExplorations: generateOptionalExploration(profile ?? null, recentInsights ?? null),
  };
}
