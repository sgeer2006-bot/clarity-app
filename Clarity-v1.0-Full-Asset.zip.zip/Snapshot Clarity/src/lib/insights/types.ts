export type InsightTag =
  | "frequency"
  | "timeline"
  | "cluster"
  | "identity"
  | "loop"
  | "role"
  | "digest";

export type InsightSource =
  | "pattern_frequency"
  | "timeline_event"
  | "cluster_membership"
  | "identity_narrative"
  | "emotional_loop"
  | "communication_role"
  | "conflict_role"
  | "weekly_digest";

export interface Insight {
  id: string;
  title: string;
  body: string;
  tags: InsightTag[];
  confidence: "low" | "medium" | "high";
  source: InsightSource;
}

export interface DigestResult {
  summary: string;
  insights: Insight[];
  trendShift: string;
  windowStart: string;
  windowEnd: string;
}

// Structural subsets of Phase 2 hook data
export interface FrequencyDatum {
  pattern_type: string;
  pattern_label: string;
  weighted_score: number;
  raw_count: number;
  last_seen_at: string | null;
}

export interface TimelineDatum {
  id: string;
  event_date: string;
  event_type: string;
  short_label: string;
  summary: string;
  linked_pattern_ids?: string[];
}

export interface ClusterDatum {
  id: string;
  cluster_label: string;
  cluster_summary: string;
  cohesion_score: number;
  member_pattern_ids: string[];
}

export interface IdentityDatum {
  narrative_md: string | null;
  strengths?: unknown;
  vulnerabilities?: unknown;
  blind_spots?: unknown;
  attachment_signals?: unknown;
  recurring_triggers?: unknown;
  last_updated_at?: string | null;
}

export interface FrequencyInput { rows: FrequencyDatum[] }
export interface TimelineInput { rows: TimelineDatum[] }
export interface ClusterInput { rows: ClusterDatum[] }
export interface IdentityInput { identity: IdentityDatum | null }
export interface LoopInput { rows: FrequencyDatum[] } // emotional_loop type rows
export interface RoleInput { rows: FrequencyDatum[] } // communication_style + conflict_role rows

export interface InsightContext {
  frequency: FrequencyDatum[];
  timeline: TimelineDatum[];
  clusters: ClusterDatum[];
  identity: IdentityDatum | null;
  // Optional prior week frequency for digest deltas
  priorFrequency?: FrequencyDatum[];
}
