export const DISALLOWED_TERMS: string[] = [
  // diagnostic
  "disorder", "trauma", "depressed", "depression", "anxiety disorder",
  "adhd", "bipolar", "narcissist", "narcissistic", "abuser", "abusive",
  "victim", "ptsd", "ocd", "borderline",
  // absolute
  "always", "never", "definitely", "must", "certainly", "absolutely",
  // predictive
  "you will", "going to", "will be", "will become",
  // therapy framing
  "you should", "try to", "work on", "heal", "process this",
];

export const HEDGES: string[] = [
  "appears to",
  "tends to",
  "this week showed more",
  "leans toward",
  "has been more frequent",
  "shows up more often",
];

const REPLACEMENTS: Array<[RegExp, string | null]> = [
  [/\balways\b/gi, "tends to"],
  [/\bnever\b/gi, "rarely appears to"],
  [/\bdefinitely\b/gi, "appears to"],
  [/\bmust\b/gi, "may"],
  [/\bcertainly\b/gi, "appears to"],
  [/\babsolutely\b/gi, "appears to"],
  [/\byou will\b/gi, "you may"],
  [/\bgoing to\b/gi, "may"],
  [/\bwill be\b/gi, "may be"],
  [/\bwill become\b/gi, "may become"],
  [/\byou should\b/gi, "you might consider noticing"],
  [/\btry to\b/gi, "notice"],
  [/\bwork on\b/gi, "notice"],
];

// Terms that, if present, cause the entire sentence to be dropped.
const DROP_TERMS = [
  "disorder", "trauma", "depressed", "depression", "anxiety disorder",
  "adhd", "bipolar", "narcissist", "narcissistic", "abuser", "abusive",
  "victim", "ptsd", "ocd", "borderline", "heal", "process this",
];

function stripIntensity(s: string): string {
  // No exclamation points, no all-caps words longer than 3 chars, no markdown bold
  let out = s.replace(/!+/g, ".");
  out = out.replace(/\*\*([^*]+)\*\*/g, "$1");
  out = out.replace(/\b([A-Z]{4,})\b/g, (m) => m.charAt(0) + m.slice(1).toLowerCase());
  return out;
}

/**
 * Sanitize a string of one or more sentences.
 * - Drops any sentence containing a drop-term.
 * - Replaces absolutes/predictions/therapy framing with hedges.
 * - Strips intensity (!, all caps, bold).
 * Returns null if nothing meaningful remains.
 */
export function sanitize(text: string): string | null {
  if (!text || typeof text !== "string") return null;
  const sentences = text
    .split(/(?<=[.?])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const kept: string[] = [];
  for (let s of sentences) {
    const lower = s.toLowerCase();
    if (DROP_TERMS.some((t) => lower.includes(t))) continue;
    for (const [re, rep] of REPLACEMENTS) {
      if (rep === null) {
        if (re.test(s)) { s = ""; break; }
      } else {
        s = s.replace(re, rep);
      }
    }
    s = stripIntensity(s).trim();
    if (s) kept.push(s);
  }
  if (kept.length === 0) return null;
  return kept.join(" ");
}
