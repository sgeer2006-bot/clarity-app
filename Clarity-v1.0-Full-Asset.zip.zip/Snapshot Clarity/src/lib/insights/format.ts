import { HEDGES } from "./lexicon";

export function hedge(claim: string): string {
  const trimmed = claim.trim();
  if (!trimmed) return trimmed;
  const lower = trimmed.toLowerCase();
  if (HEDGES.some((h) => lower.includes(h))) return trimmed;
  return `${HEDGES[0]} ${trimmed.charAt(0).toLowerCase()}${trimmed.slice(1)}`;
}

export function titleCase(s: string): string {
  // Sentence case: first letter capitalized, rest lowercase, preserve internal punctuation
  const t = s.trim().replace(/\s+/g, " ");
  if (!t) return t;
  const lower = t.toLowerCase();
  return lower.charAt(0).toUpperCase() + lower.slice(1);
}

export function truncate(s: string, max: number): string {
  if (s.length <= max) return s;
  return s.slice(0, Math.max(0, max - 1)).trimEnd() + "…";
}

// FNV-1a 32-bit, then base36
export function stableId(parts: string[]): string {
  const input = parts.slice().sort().join("|");
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h.toString(36);
}

export function humanType(t: string): string {
  return t.replace(/_/g, " ");
}
