import { describe, it, expect } from "vitest";
import { deriveRoleInsights } from "../rules/roles";

describe("deriveRoleInsights", () => {
  it("empty", () => expect(deriveRoleInsights({ rows: [] })).toEqual([]));
  it("includes both communication_style and conflict_role", () => {
    const out = deriveRoleInsights({
      rows: [
        { pattern_type: "communication_style", pattern_label: "withdrawal", weighted_score: 4, raw_count: 5, last_seen_at: null },
        { pattern_type: "conflict_role", pattern_label: "peacekeeper", weighted_score: 3, raw_count: 4, last_seen_at: null },
        { pattern_type: "emotional_loop", pattern_label: "x", weighted_score: 9, raw_count: 9, last_seen_at: null },
      ],
    });
    expect(out.length).toBe(2);
  });
  it("deterministic", () => {
    const rows = [
      { pattern_type: "conflict_role", pattern_label: "peacekeeper", weighted_score: 3, raw_count: 4, last_seen_at: null },
    ];
    expect(deriveRoleInsights({ rows })).toEqual(deriveRoleInsights({ rows }));
  });
});
