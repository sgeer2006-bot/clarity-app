import { describe, it, expect } from "vitest";
import { deriveTimelineInsights } from "../rules/timeline";

const mk = (id: string, type: string, date: string, label = "shift") => ({
  id, event_type: type, event_date: date, short_label: label, summary: "x",
});

describe("deriveTimelineInsights", () => {
  it("empty", () => expect(deriveTimelineInsights({ rows: [] })).toEqual([]));

  it("sparse ≤ 1", () => {
    const out = deriveTimelineInsights({ rows: [mk("1", "shift", "2026-04-20")] });
    expect(out.length).toBeLessThanOrEqual(2);
  });

  it("deterministic", () => {
    const rows = [
      mk("1", "shift", "2026-04-20", "noticed calm"),
      mk("2", "shift", "2026-04-21"),
      mk("3", "rupture", "2026-04-22"),
      mk("4", "rupture", "2026-04-23"),
      mk("5", "rupture", "2026-04-24"),
    ];
    const a = deriveTimelineInsights({ rows });
    const b = deriveTimelineInsights({ rows });
    expect(a).toEqual(b);
  });
});
