import { describe, it, expect } from "vitest";
import { deriveLoopInsights } from "../rules/loops";

describe("deriveLoopInsights", () => {
  it("empty", () => expect(deriveLoopInsights({ rows: [] })).toEqual([]));
  it("filters non-loop types", () => {
    const out = deriveLoopInsights({
      rows: [{ pattern_type: "communication_style", pattern_label: "x", weighted_score: 5, raw_count: 5, last_seen_at: null }],
    });
    expect(out).toEqual([]);
  });
  it("deterministic", () => {
    const rows = [
      { pattern_type: "emotional_loop", pattern_label: "self-doubt", weighted_score: 5, raw_count: 6, last_seen_at: null },
      { pattern_type: "emotional_loop", pattern_label: "rumination", weighted_score: 3, raw_count: 3, last_seen_at: null },
    ];
    expect(deriveLoopInsights({ rows })).toEqual(deriveLoopInsights({ rows }));
  });
});
