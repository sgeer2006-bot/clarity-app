import { describe, it, expect } from "vitest";
import { sanitize } from "../lexicon";
import { hedge, stableId, titleCase, truncate } from "../format";

describe("sanitize", () => {
  it("drops sentences with diagnostic terms", () => {
    expect(sanitize("You have depression. You also listen well.")).toBe("You also listen well.");
  });
  it("rephrases absolutes", () => {
    const out = sanitize("You always withdraw.");
    expect(out).not.toMatch(/always/i);
    expect(out).toMatch(/tends to/i);
  });
  it("rephrases predictions", () => {
    expect(sanitize("You will do this.")).toMatch(/may/i);
  });
  it("drops therapy framing 'heal' sentences", () => {
    expect(sanitize("You should heal this. You noticed calm.")).toBe("You noticed calm.");
  });
  it("strips exclamation marks and bold", () => {
    const out = sanitize("This is **important**!");
    expect(out).not.toMatch(/\*\*/);
    expect(out).not.toMatch(/!/);
  });
  it("returns null when nothing remains", () => {
    expect(sanitize("trauma. depression.")).toBeNull();
  });
  it("bulk disallowed terms fixture", () => {
    const phrases = [
      "you have a disorder",
      "you are depressed",
      "you have ADHD",
      "you are bipolar",
      "you are a narcissist",
      "you are an abuser",
      "you are a victim",
      "you always cry",
      "you never speak",
      "you definitely care",
      "you will love them",
      "you should heal this",
    ];
    for (const p of phrases) {
      const out = sanitize(p);
      // Either dropped or rewritten to not contain the disallowed token
      if (out !== null) {
        expect(out.toLowerCase()).not.toMatch(
          /\b(disorder|depressed|adhd|bipolar|narcissist|abuser|victim|always|never|definitely|you will|heal)\b/
        );
      }
    }
  });
});

describe("format helpers", () => {
  it("hedge adds a hedge if absent", () => {
    expect(hedge("Withdrawal recurs.").toLowerCase()).toContain("appears to");
  });
  it("hedge preserves if hedge already present", () => {
    expect(hedge("This appears to recur.")).toBe("This appears to recur.");
  });
  it("titleCase is sentence case", () => {
    expect(titleCase("hello WORLD")).toBe("Hello world");
  });
  it("truncate adds ellipsis", () => {
    expect(truncate("abcdefgh", 5)).toBe("abcd…");
  });
  it("stableId is deterministic and order-independent", () => {
    expect(stableId(["a", "b"])).toBe(stableId(["b", "a"]));
  });
});
