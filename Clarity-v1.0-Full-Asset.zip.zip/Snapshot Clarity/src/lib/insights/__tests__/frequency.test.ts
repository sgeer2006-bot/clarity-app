import { describe, it, expect } from "vitest";
import { deriveFrequencyInsights } from "../rules/frequency";

describe("deriveFrequencyInsights", () => {
  it("empty input returns []", () => {
    expect(deriveFrequencyInsights({ rows: [] })).toEqual([]);
  });

  it("sparse input returns ≤ 1 insight", () => {
    const out = deriveFrequencyInsights({
      rows: [{ pattern_type: "emotional_loop", pattern_label: "self-doubt", weighted_score: 1, raw_count: 1, last_seen_at: null }],
    });
    expect(out.length).toBeLessThanOrEqual(1);
  });

  it("rich input produces deterministic ordered list", () => {
    const rows = [
      { pattern_type: "emotional_loop", pattern_label: "self-doubt", weighted_score: 5, raw_count: 7, last_seen_at: null },
      { pattern_type: "communication_style", pattern_label: "withdrawal", weighted_score: 2.5, raw_count: 4, last_seen_at: null },
      { pattern_type: "conflict_role", pattern_label: "peacekeeper", weighted_score: 1, raw_count: 2, last_seen_at: null },
    ];
    const a = deriveFrequencyInsights({ rows });
    const b = deriveFrequencyInsights({ rows });
    expect(a).toEqual(b);
    expect(a.map((i) => i.title)).toMatchSnapshot();
  });
});
