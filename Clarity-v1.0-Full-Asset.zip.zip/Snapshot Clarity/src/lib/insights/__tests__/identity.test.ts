import { describe, it, expect } from "vitest";
import { deriveIdentityInsights } from "../rules/identity";

describe("deriveIdentityInsights", () => {
  it("null identity returns []", () => expect(deriveIdentityInsights({ identity: null })).toEqual([]));
  it("sparse ≤ 1", () => {
    const out = deriveIdentityInsights({
      identity: { narrative_md: null, strengths: ["listening"] },
    });
    expect(out.length).toBeLessThanOrEqual(2);
  });
  it("deterministic rich", () => {
    const id = {
      narrative_md: "A quiet pattern of careful listening.",
      strengths: ["listening", "patience", "reflection"],
      vulnerabilities: ["self-criticism"],
      blind_spots: ["overcommitment"],
      recurring_triggers: ["raised voices"],
    };
    expect(deriveIdentityInsights({ identity: id })).toEqual(deriveIdentityInsights({ identity: id }));
  });
});
