import { describe, it, expect } from "vitest";
import { deriveClusterInsights } from "../rules/clusters";

describe("deriveClusterInsights", () => {
  it("empty", () => expect(deriveClusterInsights({ rows: [] })).toEqual([]));
  it("deterministic", () => {
    const rows = [
      { id: "a", cluster_label: "withdrawal cluster", cluster_summary: "", cohesion_score: 0.8, member_pattern_ids: ["p1", "p2"] },
      { id: "b", cluster_label: "peacekeeping cluster", cluster_summary: "", cohesion_score: 0.5, member_pattern_ids: ["p3"] },
    ];
    expect(deriveClusterInsights({ rows })).toEqual(deriveClusterInsights({ rows }));
  });
});
