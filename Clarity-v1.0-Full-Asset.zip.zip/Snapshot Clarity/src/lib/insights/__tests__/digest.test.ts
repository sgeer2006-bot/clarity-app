import { describe, it, expect } from "vitest";
import { buildWeeklyDigest } from "../digest";

describe("buildWeeklyDigest", () => {
  const now = new Date("2026-04-27T12:00:00Z");

  it("empty context yields neutral fallback trendShift", () => {
    const r = buildWeeklyDigest({ frequency: [], timeline: [], clusters: [], identity: null }, now);
    expect(r.trendShift).toMatch(/Not enough prior data/i);
    expect(r.windowStart).toBeTruthy();
    expect(r.windowEnd).toBeTruthy();
  });

  it("deterministic", () => {
    const ctx = {
      frequency: [
        { pattern_type: "emotional_loop", pattern_label: "self-doubt", weighted_score: 5, raw_count: 6, last_seen_at: null },
      ],
      timeline: [
        { id: "1", event_type: "shift", event_date: "2026-04-25", short_label: "noticed calm", summary: "x" },
      ],
      clusters: [],
      identity: null,
      priorFrequency: [
        { pattern_type: "emotional_loop", pattern_label: "self-doubt", weighted_score: 2, raw_count: 2, last_seen_at: null },
      ],
    };
    const a = buildWeeklyDigest(ctx, now);
    const b = buildWeeklyDigest(ctx, now);
    expect(a).toEqual(b);
    expect(a.trendShift).toMatch(/self-doubt/);
  });
});
