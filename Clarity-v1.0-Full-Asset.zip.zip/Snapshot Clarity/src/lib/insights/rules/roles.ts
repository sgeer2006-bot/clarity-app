import type { Insight, RoleInput } from "../types";
import { sanitize } from "../lexicon";
import { hedge, stableId, titleCase, truncate } from "../format";

export function deriveRoleInsights(input: RoleInput): Insight[] {
  const rows = (input.rows ?? []).filter(
    (r) => r && (r.pattern_type === "communication_style" || r.pattern_type === "conflict_role")
  );
  if (rows.length === 0) return [];

  const sorted = [...rows].sort((a, b) => b.weighted_score - a.weighted_score);
  const out: Insight[] = [];

  for (const r of sorted.slice(0, 5)) {
    const kind = r.pattern_type === "conflict_role" ? "way of moving through hard moments" : "way of speaking";
    const claim = `${r.pattern_label} tends to be a ${kind} you keep coming back to — ${r.raw_count} times so far, and it's becoming part of how you show up.`;
    const body = sanitize(hedge(claim));
    if (!body) continue;
    const conf: Insight["confidence"] =
      r.weighted_score >= 4 ? "high" : r.weighted_score >= 2 ? "medium" : "low";
    out.push({
      id: stableId(["role", r.pattern_type, r.pattern_label]),
      title: truncate(titleCase(r.pattern_label), 60),
      body,
      tags: ["role"],
      confidence: conf,
      source: r.pattern_type === "conflict_role" ? "conflict_role" : "communication_role",
    });
  }

  const order = { high: 0, medium: 1, low: 2 } as const;
  return out
    .sort((a, b) => order[a.confidence] - order[b.confidence] || a.title.localeCompare(b.title))
    .slice(0, 5);
}
