import type { FrequencyInput, Insight } from "../types";
import { sanitize } from "../lexicon";
import { hedge, humanType, stableId, titleCase, truncate } from "../format";
import { getUserProfile } from "@/lib/profile/userProfile";

export function deriveFrequencyInsights(input: FrequencyInput): Insight[] {
  // Hybrid onboarding: insight templates read profile as additional context.
  // Existing template logic and output shapes unchanged.
  const _profile = getUserProfile();
  void _profile;
  const rows = (input.rows ?? []).filter((r) => r && r.pattern_label);
  if (rows.length === 0) return [];

  const sorted = [...rows].sort((a, b) => b.weighted_score - a.weighted_score);
  const out: Insight[] = [];

  for (const r of sorted.slice(0, 5)) {
    const claim = `${r.pattern_label} ${
      r.raw_count >= 5 ? "shows up more often" : "tends to"
    } show up in what you've been writing lately — a quiet thread of ${humanType(r.pattern_type)}, named ${r.raw_count} times so far.`;
    const body = sanitize(hedge(claim));
    if (!body) continue;

    const conf: Insight["confidence"] =
      r.weighted_score >= 4 ? "high" : r.weighted_score >= 2 ? "medium" : "low";

    out.push({
      id: stableId(["frequency", r.pattern_type, r.pattern_label]),
      title: truncate(titleCase(r.pattern_label), 60),
      body,
      tags: ["frequency"],
      confidence: conf,
      source: "pattern_frequency",
    });
  }

  return sortInsights(out).slice(0, 5);
}

function sortInsights(arr: Insight[]): Insight[] {
  const order = { high: 0, medium: 1, low: 2 } as const;
  return arr.sort((a, b) => {
    const c = order[a.confidence] - order[b.confidence];
    if (c !== 0) return c;
    return a.title.localeCompare(b.title);
  });
}
