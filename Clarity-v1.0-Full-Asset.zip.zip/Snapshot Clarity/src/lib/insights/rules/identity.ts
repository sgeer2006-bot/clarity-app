import type { IdentityInput, Insight } from "../types";
import { sanitize } from "../lexicon";
import { hedge, stableId, titleCase, truncate } from "../format";

function asArray(v: unknown): string[] {
  if (Array.isArray(v)) return v.filter((x): x is string => typeof x === "string");
  return [];
}

export function deriveIdentityInsights(input: IdentityInput): Insight[] {
  const id = input.identity;
  if (!id) return [];
  const out: Insight[] = [];

  const sections: Array<{ key: string; label: string; items: string[] }> = [
    { key: "strengths", label: "Strengths", items: asArray(id.strengths) },
    { key: "vulnerabilities", label: "Vulnerabilities", items: asArray(id.vulnerabilities) },
    { key: "blind_spots", label: "Blind spots", items: asArray(id.blind_spots) },
    { key: "recurring_triggers", label: "Recurring triggers", items: asArray(id.recurring_triggers) },
  ];

  for (const s of sections) {
    if (s.items.length === 0) continue;
    const top = s.items.slice(0, 3).join(", ");
    const claim = `${s.label.toLowerCase()} tends to include ${top} — small parts of who you're becoming.`;
    const body = sanitize(hedge(claim));
    if (!body) continue;
    out.push({
      id: stableId(["identity", s.key]),
      title: truncate(titleCase(s.label), 60),
      body,
      tags: ["identity"],
      confidence: s.items.length >= 3 ? "medium" : "low",
      source: "identity_narrative",
    });
  }

  if (id.narrative_md && id.narrative_md.trim()) {
    const claim = id.narrative_md.trim().split(/\s+/).slice(0, 24).join(" ");
    const body = sanitize(hedge(claim));
    if (body) {
      out.push({
        id: stableId(["identity", "narrative"]),
        title: "Identity narrative",
        body,
        tags: ["identity"],
        confidence: "medium",
        source: "identity_narrative",
      });
    }
  }

  const order = { high: 0, medium: 1, low: 2 } as const;
  return out
    .sort((a, b) => order[a.confidence] - order[b.confidence] || a.title.localeCompare(b.title))
    .slice(0, 5);
}
