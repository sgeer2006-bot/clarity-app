import type { ClusterInput, Insight } from "../types";
import { sanitize } from "../lexicon";
import { hedge, stableId, titleCase, truncate } from "../format";
import { getUserProfile } from "@/lib/profile/userProfile";

export function deriveClusterInsights(input: ClusterInput): Insight[] {
  // Hybrid onboarding: pattern interpretation reads profile as supplemental context.
  // No changes to interpretation pipeline output.
  const _profile = getUserProfile();
  void _profile;
  const rows = (input.rows ?? []).filter((r) => r && r.cluster_label);
  if (rows.length === 0) return [];

  const sorted = [...rows].sort((a, b) => b.cohesion_score - a.cohesion_score);
  const out: Insight[] = [];

  for (const c of sorted.slice(0, 5)) {
    const memberCount = (c.member_pattern_ids ?? []).length;
    const claim = `${c.cluster_label} tends to hold ${memberCount} small ${
      memberCount === 1 ? "thread" : "threads"
    } that keep showing up together — like a quiet shape in your story you're starting to see.`;
    const body = sanitize(hedge(claim));
    if (!body) continue;

    const conf: Insight["confidence"] =
      c.cohesion_score >= 0.7 ? "high" : c.cohesion_score >= 0.4 ? "medium" : "low";

    out.push({
      id: stableId(["cluster", c.id]),
      title: truncate(titleCase(c.cluster_label), 60),
      body,
      tags: ["cluster"],
      confidence: conf,
      source: "cluster_membership",
    });
  }

  const order = { high: 0, medium: 1, low: 2 } as const;
  return out
    .sort((a, b) => order[a.confidence] - order[b.confidence] || a.title.localeCompare(b.title))
    .slice(0, 5);
}
