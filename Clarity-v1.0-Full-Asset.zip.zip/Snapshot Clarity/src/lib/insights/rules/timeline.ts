import type { Insight, TimelineInput } from "../types";
import { sanitize } from "../lexicon";
import { hedge, humanType, stableId, titleCase, truncate } from "../format";

export function deriveTimelineInsights(input: TimelineInput): Insight[] {
  const rows = (input.rows ?? []).filter((r) => r && r.event_date);
  if (rows.length === 0) return [];

  // Count by event_type
  const byType = new Map<string, number>();
  for (const r of rows) byType.set(r.event_type, (byType.get(r.event_type) ?? 0) + 1);
  const types = Array.from(byType.entries()).sort((a, b) => b[1] - a[1]);

  const out: Insight[] = [];
  for (const [type, count] of types.slice(0, 3)) {
    const claim = `${humanType(type)} tends to show up — ${count} ${count === 1 ? "moment" : "moments"} in your story this week, and you noticed every one.`;
    const body = sanitize(hedge(claim));
    if (!body) continue;
    out.push({
      id: stableId(["timeline-type", type]),
      title: truncate(titleCase(humanType(type)), 60),
      body,
      tags: ["timeline"],
      confidence: count >= 4 ? "high" : count >= 2 ? "medium" : "low",
      source: "timeline_event",
    });
  }

  // Most recent shift
  const sorted = [...rows].sort((a, b) => (a.event_date < b.event_date ? 1 : -1));
  const recent = sorted[0];
  if (recent && recent.short_label) {
    const claim = `The last small shift you named was ${recent.short_label} — a quiet step in who you're becoming.`;
    const body = sanitize(hedge(claim));
    if (body) {
      out.push({
        id: stableId(["timeline-recent", recent.id]),
        title: truncate(titleCase(`Recent shift: ${recent.short_label}`), 60),
        body,
        tags: ["timeline"],
        confidence: "medium",
        source: "timeline_event",
      });
    }
  }

  return sortByConfidence(out).slice(0, 5);
}

function sortByConfidence(arr: Insight[]): Insight[] {
  const order = { high: 0, medium: 1, low: 2 } as const;
  return arr.sort((a, b) => {
    const c = order[a.confidence] - order[b.confidence];
    if (c !== 0) return c;
    return a.title.localeCompare(b.title);
  });
}
