import type { Insight, LoopInput } from "../types";
import { sanitize } from "../lexicon";
import { hedge, stableId, titleCase, truncate } from "../format";

export function deriveLoopInsights(input: LoopInput): Insight[] {
  const rows = (input.rows ?? []).filter((r) => r && r.pattern_type === "emotional_loop");
  if (rows.length === 0) return [];

  const sorted = [...rows].sort((a, b) => b.weighted_score - a.weighted_score);
  const out: Insight[] = [];

  for (const r of sorted.slice(0, 5)) {
    const claim = `${r.pattern_label} tends to be a feeling that keeps circling back — you've named it ${r.raw_count} times now, and noticing it is part of who you're becoming.`;
    const body = sanitize(hedge(claim));
    if (!body) continue;
    const conf: Insight["confidence"] =
      r.weighted_score >= 4 ? "high" : r.weighted_score >= 2 ? "medium" : "low";
    out.push({
      id: stableId(["loop", r.pattern_label]),
      title: truncate(titleCase(r.pattern_label), 60),
      body,
      tags: ["loop"],
      confidence: conf,
      source: "emotional_loop",
    });
  }

  const order = { high: 0, medium: 1, low: 2 } as const;
  return out
    .sort((a, b) => order[a.confidence] - order[b.confidence] || a.title.localeCompare(b.title))
    .slice(0, 5);
}
