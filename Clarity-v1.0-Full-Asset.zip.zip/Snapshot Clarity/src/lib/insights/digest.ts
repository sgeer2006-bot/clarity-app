import type { DigestResult, FrequencyDatum, Insight, InsightContext } from "./types";
import { sanitize } from "./lexicon";
import { hedge } from "./format";
import { deriveFrequencyInsights } from "./rules/frequency";
import { deriveTimelineInsights } from "./rules/timeline";
import { deriveClusterInsights } from "./rules/clusters";
import { deriveIdentityInsights } from "./rules/identity";
import { deriveLoopInsights } from "./rules/loops";
import { deriveRoleInsights } from "./rules/roles";
import { getUserProfile } from "@/lib/profile/userProfile";

const SOURCE_PRIORITY: Record<Insight["source"], number> = {
  emotional_loop: 0,
  conflict_role: 1,
  communication_role: 2,
  cluster_membership: 3,
  pattern_frequency: 4,
  identity_narrative: 5,
  timeline_event: 6,
  weekly_digest: 7,
};

const CONF_ORDER = { high: 0, medium: 1, low: 2 } as const;

function withinWindow(iso: string | null | undefined, start: Date, end: Date): boolean {
  if (!iso) return false;
  const t = new Date(iso).getTime();
  return t >= start.getTime() && t <= end.getTime();
}

export function buildWeeklyDigest(ctx: InsightContext, now: Date): DigestResult {
  // Hybrid onboarding: profile-derived context is read here as additional input.
  // Existing digest format, sections, and delivery are unchanged.
  const _profile = getUserProfile();
  void _profile;
  const end = new Date(now);
  const start = new Date(now);
  start.setDate(start.getDate() - 7);

  const windowedTimeline = (ctx.timeline ?? []).filter((t) =>
    withinWindow(t.event_date, start, end)
  );

  const all: Insight[] = [
    ...deriveLoopInsights({ rows: ctx.frequency }),
    ...deriveRoleInsights({ rows: ctx.frequency }),
    ...deriveClusterInsights({ rows: ctx.clusters }),
    ...deriveFrequencyInsights({ rows: ctx.frequency }),
    ...deriveIdentityInsights({ identity: ctx.identity }),
    ...deriveTimelineInsights({ rows: windowedTimeline }),
  ];

  // Dedup by id
  const dedup = new Map<string, Insight>();
  for (const i of all) if (!dedup.has(i.id)) dedup.set(i.id, i);

  const ordered = Array.from(dedup.values()).sort((a, b) => {
    const c = CONF_ORDER[a.confidence] - CONF_ORDER[b.confidence];
    if (c !== 0) return c;
    const s = SOURCE_PRIORITY[a.source] - SOURCE_PRIORITY[b.source];
    if (s !== 0) return s;
    return a.title.localeCompare(b.title);
  });

  const selected = ordered.slice(0, Math.min(5, Math.max(3, ordered.length)));

  // Summary
  const top = (ctx.frequency ?? [])[0];
  const eventCount = windowedTimeline.length;
  const fragments: string[] = [];
  if (top) fragments.push(`This week, ${top.pattern_label} kept showing up in what you wrote.`);
  if (eventCount > 0)
    fragments.push(
      `${eventCount} small ${eventCount === 1 ? "moment" : "moments"} landed in the last seven days — and you noticed each one.`
    );
  if (selected.length > 0)
    fragments.push(`${selected.length} quiet things stand out from the rest, and they're worth sitting with.`);
  if (fragments.length === 0)
    fragments.push("This week stayed quiet — and that's its own kind of knowing.");

  const summary = sanitize(fragments.join(" ")) ?? fragments.join(" ");

  // Trend shift
  let trendShift = "Not enough prior data yet — your story is still gathering shape.";
  const prior = ctx.priorFrequency ?? [];
  if (prior.length > 0 && (ctx.frequency ?? []).length > 0) {
    const priorMap = new Map<string, FrequencyDatum>();
    for (const p of prior) priorMap.set(`${p.pattern_type}|${p.pattern_label}`, p);
    let bestKey = "";
    let bestDelta = 0;
    for (const cur of ctx.frequency) {
      const k = `${cur.pattern_type}|${cur.pattern_label}`;
      const p = priorMap.get(k);
      const delta = cur.weighted_score - (p?.weighted_score ?? 0);
      if (Math.abs(delta) > Math.abs(bestDelta)) {
        bestDelta = delta;
        bestKey = cur.pattern_label;
      }
    }
    if (bestKey) {
      const direction = bestDelta > 0 ? "has been showing up a little more" : "has stepped back a bit since last week";
      const candidate = sanitize(hedge(`${bestKey} ${direction}.`));
      if (candidate) trendShift = candidate;
    }
  }

  return {
    summary,
    insights: selected,
    trendShift,
    windowStart: start.toISOString(),
    windowEnd: end.toISOString(),
  };
}
