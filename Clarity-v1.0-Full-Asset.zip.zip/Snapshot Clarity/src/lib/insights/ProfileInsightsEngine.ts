/**
 * ProfileInsightsEngine — pure-logic module.
 *
 * Reads the Psychological Profile Engine output (Module #9) and recent
 * snapshots from Moments (Snapshot Engine) and produces four grouped
 * categories of reflective, non-clinical insights.
 *
 * Pure: no I/O, no React, no navigation, no analytics, no storage,
 * no side effects. Deterministic for a given input. Not wired into
 * any consumer in this module.
 */

// ---------- Public types ----------

export type Confidence = "emerging" | "recurring" | "consistent";

export type TrendDirection = "increasing" | "decreasing" | "stabilizing";

export interface TopInsight {
  text: string;
  category: string;
  confidence: Confidence;
  spotlight: true;
}

export interface IdentityInsight {
  text: string;
  category: string;
  confidence: Confidence;
}

export interface SituationInsight {
  text: string;
  theme: string;
}

export interface TrendInsight {
  text: string;
  direction: TrendDirection;
  category: string;
}

export interface GeneratedInsights {
  topInsight: TopInsight | null;
  identityInsights: IdentityInsight[];
  situationInsights: SituationInsight[];
  trendInsights: TrendInsight[];
}

// ---------- Loose input shapes (read-only; tolerant of partial data) ----------

/**
 * Mirrors a single profile entry from the Psychological Profile Engine.
 * All fields are optional/defensive — this engine never assumes presence.
 */
export interface ProfileEntryLike {
  key?: string;
  label?: string;
  observationCount?: number;
  firstObservedAt?: string | null;
  lastObservedAt?: string | null;
  confidence?: Confidence;
  notes?: string[];
}

export interface PsychologicalProfileLike {
  emotionalPatterns?: ProfileEntryLike[];
  thinkingPatterns?: ProfileEntryLike[];
  behaviorPatterns?: ProfileEntryLike[];
  communicationStyle?: ProfileEntryLike[];
  conflictResponses?: ProfileEntryLike[];
  stressResponses?: ProfileEntryLike[];
  avoidancePatterns?: ProfileEntryLike[];
  attachmentSignals?: ProfileEntryLike[];
  selfNarrativeThemes?: ProfileEntryLike[];
}

/** Loose snapshot shape — we only read the textual fields if present. */
export interface SnapshotLike {
  summary?: string | null;
  observations?: string[] | null;
  themes?: string[] | null;
  tags?: string[] | null;
  patterns?: string[] | null;
  createdAt?: string | null;
}

// ---------- Internal constants ----------

const CATEGORY_ORDER: (keyof PsychologicalProfileLike)[] = [
  "emotionalPatterns",
  "thinkingPatterns",
  "behaviorPatterns",
  "communicationStyle",
  "conflictResponses",
  "stressResponses",
  "avoidancePatterns",
  "attachmentSignals",
  "selfNarrativeThemes",
];

const PER_CATEGORY_HARD_CAP = 5;
const SNAPSHOT_WINDOW_MAX = 5;
const SNAPSHOT_WINDOW_MIN = 3;
const THEME_REPEAT_MIN = 2;

// Words to avoid in user-visible text (clinical / prescriptive / absolute).
const FORBIDDEN_FRAGMENTS = [
  "disorder", "diagnosis", "diagnostic", "symptom", "pathology", "trauma response",
  "you should", "you need to", "you must",
  "always", "never", "definitely", "cured", "fixed",
];

// ---------- filterByConfidence ----------

function countToConfidence(count: number | undefined): Confidence {
  const n = typeof count === "number" && count > 0 ? count : 0;
  if (n >= 5) return "consistent";
  if (n >= 2) return "recurring";
  return "emerging";
}

const CONF_RANK: Record<Confidence, number> = {
  emerging: 0,
  recurring: 1,
  consistent: 2,
};

/**
 * Filter entries by minimum confidence.
 * Default threshold (when minConfidence omitted) hides "emerging".
 * Preserves input order.
 */
export function filterByConfidence(
  entries: ProfileEntryLike[] | undefined | null,
  minConfidence: Confidence = "recurring",
): ProfileEntryLike[] {
  if (!Array.isArray(entries)) return [];
  const min = CONF_RANK[minConfidence];
  return entries.filter((e) => {
    const c = e?.confidence ?? countToConfidence(e?.observationCount);
    return CONF_RANK[c] >= min;
  });
}

// ---------- Tone helpers (internal) ----------

function humanizeKey(raw: string | undefined): string {
  if (!raw) return "this pattern";
  return raw
    .replace(/[_\-]+/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .toLowerCase()
    .trim();
}

function humanizeCategory(category: string): string {
  switch (category) {
    case "emotionalPatterns": return "emotional patterns";
    case "thinkingPatterns": return "thinking patterns";
    case "behaviorPatterns": return "behaviors";
    case "communicationStyle": return "communication style";
    case "conflictResponses": return "conflict responses";
    case "stressResponses": return "stress responses";
    case "avoidancePatterns": return "avoidance patterns";
    case "attachmentSignals": return "connection patterns";
    case "selfNarrativeThemes": return "self-narrative themes";
    default: return humanizeKey(category);
  }
}

/** Strip clinical/prescriptive/absolute language; keep tone warm and safe. */
function sanitizeTone(text: string): string {
  let out = text;
  for (const frag of FORBIDDEN_FRAGMENTS) {
    const re = new RegExp(frag.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
    out = out.replace(re, "");
  }
  // Collapse whitespace and ensure single trailing period.
  out = out.replace(/\s+/g, " ").trim();
  if (out.length === 0) return "";
  if (!/[.!?]$/.test(out)) out += ".";
  // Cap to two sentences.
  const parts = out.split(/(?<=[.!?])\s+/);
  return parts.slice(0, 2).join(" ");
}

function buildInsightText(category: string, entry: ProfileEntryLike): string {
  const subject = entry?.label?.trim() || humanizeKey(entry?.key);
  const catLabel = humanizeCategory(category);
  // Observational framing — never prescriptive, never absolute.
  const text = `You tend to show ${subject} in your ${catLabel}. It's something that's been showing up across your reflections.`;
  return sanitizeTone(text);
}

function buildTopInsightText(category: string, entry: ProfileEntryLike): string {
  const subject = entry?.label?.trim() || humanizeKey(entry?.key);
  const text = `Lately, you tend to lean on ${subject}. It's been a recurring thread in how you move through things.`;
  return sanitizeTone(text);
}

function buildSituationText(theme: string): string {
  const t = humanizeKey(theme);
  return sanitizeTone(`You've been navigating moments around ${t}. It's been showing up more than once recently.`);
}

function buildTrendText(category: string, direction: TrendDirection, entry: ProfileEntryLike): string {
  const subject = entry?.label?.trim() || humanizeKey(entry?.key);
  let phrasing: string;
  switch (direction) {
    case "increasing":
      phrasing = `You've been showing ${subject} more often lately`;
      break;
    case "decreasing":
      phrasing = `You've been relying on ${subject} a little less lately`;
      break;
    case "stabilizing":
    default:
      phrasing = `Your sense of ${subject} feels steadier lately`;
  }
  return sanitizeTone(`${phrasing}. It's a quiet shift in your ${humanizeCategory(category)}.`);
}

// ---------- generateTopInsight ----------

interface CandidateEntry {
  category: string;
  entry: ProfileEntryLike;
  confidence: Confidence;
  observationCount: number;
  reinforced: boolean;
}

function collectCandidates(
  profile: PsychologicalProfileLike,
  recentSnapshots: SnapshotLike[],
): CandidateEntry[] {
  const reinforcementText = snapshotsCorpus(recentSnapshots).toLowerCase();
  const out: CandidateEntry[] = [];
  for (const cat of CATEGORY_ORDER) {
    const list = filterByConfidence(profile?.[cat]);
    for (const e of list) {
      const obs = typeof e.observationCount === "number" ? e.observationCount : 0;
      const conf = e.confidence ?? countToConfidence(obs);
      const subject = (e.label || e.key || "").toLowerCase().trim();
      const reinforced = subject.length > 2 && reinforcementText.includes(subject);
      out.push({ category: cat as string, entry: e, confidence: conf, observationCount: obs, reinforced });
    }
  }
  return out;
}

function snapshotsCorpus(snapshots: SnapshotLike[]): string {
  if (!Array.isArray(snapshots)) return "";
  const parts: string[] = [];
  for (const s of snapshots) {
    if (!s) continue;
    if (typeof s.summary === "string") parts.push(s.summary);
    if (Array.isArray(s.observations)) parts.push(s.observations.filter(Boolean).join(" "));
    if (Array.isArray(s.themes)) parts.push(s.themes.filter(Boolean).join(" "));
    if (Array.isArray(s.tags)) parts.push(s.tags.filter(Boolean).join(" "));
    if (Array.isArray(s.patterns)) parts.push(s.patterns.filter(Boolean).join(" "));
  }
  return parts.join(" ");
}

function compareCandidates(a: CandidateEntry, b: CandidateEntry): number {
  // Higher confidence first.
  const cd = CONF_RANK[b.confidence] - CONF_RANK[a.confidence];
  if (cd !== 0) return cd;
  // Reinforced by snapshots wins as a soft elevation.
  if (a.reinforced !== b.reinforced) return a.reinforced ? -1 : 1;
  // Higher observationCount first.
  const od = b.observationCount - a.observationCount;
  if (od !== 0) return od;
  // Alphabetical category, then alphabetical key/label for determinism.
  const cat = a.category.localeCompare(b.category);
  if (cat !== 0) return cat;
  const ak = (a.entry.key || a.entry.label || "").toString();
  const bk = (b.entry.key || b.entry.label || "").toString();
  return ak.localeCompare(bk);
}

export function generateTopInsight(
  profile: PsychologicalProfileLike | null | undefined,
  recentSnapshots: SnapshotLike[] | null | undefined,
): TopInsight | null {
  if (!profile) return null;
  const snaps = Array.isArray(recentSnapshots) ? recentSnapshots.slice(0, SNAPSHOT_WINDOW_MAX) : [];
  const candidates = collectCandidates(profile, snaps);
  if (candidates.length === 0) return null;
  candidates.sort(compareCandidates);
  const top = candidates[0];
  const text = buildTopInsightText(top.category, top.entry);
  if (!text) return null;
  return {
    text,
    category: top.category,
    confidence: top.confidence,
    spotlight: true,
  };
}

// ---------- generateIdentityInsights ----------

export function generateIdentityInsights(
  profile: PsychologicalProfileLike | null | undefined,
): IdentityInsight[] {
  if (!profile) return [];
  const out: IdentityInsight[] = [];
  for (const cat of CATEGORY_ORDER) {
    const filtered = filterByConfidence(profile[cat]);
    if (filtered.length === 0) continue;
    const sorted = filtered
      .map((e) => ({
        e,
        conf: e.confidence ?? countToConfidence(e.observationCount),
        obs: e.observationCount ?? 0,
      }))
      .sort((a, b) => {
        const cd = CONF_RANK[b.conf] - CONF_RANK[a.conf];
        if (cd !== 0) return cd;
        const od = b.obs - a.obs;
        if (od !== 0) return od;
        return ((a.e.key || a.e.label || "") as string)
          .localeCompare((b.e.key || b.e.label || "") as string);
      })
      .slice(0, PER_CATEGORY_HARD_CAP);

    for (const item of sorted) {
      const text = buildInsightText(cat as string, item.e);
      if (!text) continue;
      out.push({ text, category: cat as string, confidence: item.conf });
    }
  }
  return out;
}

// ---------- generateSituationInsights ----------

export function generateSituationInsights(
  recentSnapshots: SnapshotLike[] | null | undefined,
): SituationInsight[] {
  if (!Array.isArray(recentSnapshots)) return [];
  const window = recentSnapshots.slice(0, SNAPSHOT_WINDOW_MAX);
  if (window.length < SNAPSHOT_WINDOW_MIN) return [];

  // Count themes/tags/patterns across snapshots; require repeat across distinct snapshots.
  const themeCounts = new Map<string, { count: number; first: number }>();
  window.forEach((snap, idx) => {
    if (!snap) return;
    const seen = new Set<string>();
    const collect = (arr: unknown) => {
      if (!Array.isArray(arr)) return;
      for (const v of arr) {
        if (typeof v !== "string") continue;
        const norm = v.trim().toLowerCase();
        if (!norm || seen.has(norm)) continue;
        seen.add(norm);
        const cur = themeCounts.get(norm);
        if (cur) cur.count += 1;
        else themeCounts.set(norm, { count: 1, first: idx });
      }
    };
    collect(snap.themes);
    collect(snap.tags);
    collect(snap.patterns);
  });

  const repeated = Array.from(themeCounts.entries())
    .filter(([, v]) => v.count >= THEME_REPEAT_MIN)
    .sort((a, b) => {
      const cd = b[1].count - a[1].count;
      if (cd !== 0) return cd;
      return a[0].localeCompare(b[0]);
    });

  if (repeated.length === 0) return [];

  return repeated
    .map(([theme]) => ({ text: buildSituationText(theme), theme }))
    .filter((r) => r.text.length > 0);
}

// ---------- generateTrendInsights ----------

function parseTime(iso: string | null | undefined): number | null {
  if (!iso) return null;
  const t = Date.parse(iso);
  return Number.isFinite(t) ? t : null;
}

export function generateTrendInsights(
  profile: PsychologicalProfileLike | null | undefined,
): TrendInsight[] {
  if (!profile) return [];

  // Gather entries that expose enough history (both first and last observed timestamps).
  interface TrendCandidate {
    category: string;
    entry: ProfileEntryLike;
    first: number;
    last: number;
    obs: number;
  }
  const candidates: TrendCandidate[] = [];
  for (const cat of CATEGORY_ORDER) {
    const list = profile[cat];
    if (!Array.isArray(list)) continue;
    for (const e of list) {
      const first = parseTime(e.firstObservedAt);
      const last = parseTime(e.lastObservedAt);
      const obs = e.observationCount ?? 0;
      if (first === null || last === null || obs < 2) continue;
      candidates.push({ category: cat as string, entry: e, first, last, obs });
    }
  }

  if (candidates.length === 0) return [];

  // Determine global midpoint to split early vs recent.
  const allTimes = candidates.flatMap((c) => [c.first, c.last]);
  const minT = Math.min(...allTimes);
  const maxT = Math.max(...allTimes);
  if (maxT === minT) return [];
  const mid = (minT + maxT) / 2;
  const span = maxT - minT;

  const out: TrendInsight[] = [];
  for (const c of candidates) {
    const recencyFrac = (c.last - mid) / span; // positive => recent activity
    let direction: TrendDirection;
    if (recencyFrac > 0.15) direction = "increasing";
    else if (recencyFrac < -0.15) direction = "decreasing";
    else direction = "stabilizing";

    const text = buildTrendText(c.category, direction, c.entry);
    if (!text) continue;
    out.push({ text, direction, category: c.category });
  }

  // Deterministic ordering.
  out.sort((a, b) => {
    const cat = a.category.localeCompare(b.category);
    if (cat !== 0) return cat;
    return a.text.localeCompare(b.text);
  });

  return out;
}

// ---------- Single entry point ----------

export function generateInsights(
  profile: PsychologicalProfileLike | null | undefined,
  recentSnapshots: SnapshotLike[] | null | undefined,
): GeneratedInsights {
  const snaps = Array.isArray(recentSnapshots)
    ? recentSnapshots.slice(0, SNAPSHOT_WINDOW_MAX)
    : [];
  return {
    topInsight: generateTopInsight(profile ?? {}, snaps),
    identityInsights: generateIdentityInsights(profile ?? {}),
    situationInsights: generateSituationInsights(snaps),
    trendInsights: generateTrendInsights(profile ?? {}),
  };
}
