/**
 * SubscriptionEngine — pure-logic unification of tier detection, pricing,
 * locked-in tier descriptions, and upgrade prompt copy for Clarity+.
 *
 * Read-only with respect to the existing Subscription Engine, Credits Engine,
 * and the user object. No I/O, no React, no navigation, no analytics,
 * no storage, no DOM, no side effects.
 *
 * Tier detection delegates to ClarityPlusGating (Module #12) so there is
 * exactly one source of truth across the app. UserTier is imported, never
 * redeclared. This module is intentionally unwired.
 */

import {
  UserTier,
  getUserTier as gatingGetUserTier,
  type GatingUser,
} from "@/lib/premium/ClarityPlusGating";

export { UserTier } from "@/lib/premium/ClarityPlusGating";

/* ----------------------------- Types ----------------------------- */

export interface PricingMetadata {
  basicMonthly: number;
  basicAnnual: number;
  premiumMonthly: number;
  premiumAnnual: number;
}

export interface TierDescription {
  title: string;
  description: string;
  bulletPointFeatures: string[];
  whyPeopleChoose: string[];
}

export interface TierDescriptions {
  free: TierDescription;
  basic: TierDescription;
  premium: TierDescription;
}

export interface UpgradePrompt {
  text: string;
  targetTier: UserTier.Basic | UserTier.Premium;
}

export interface SubscriptionMetadata {
  tier: UserTier;
  pricing: PricingMetadata;
  descriptions: TierDescriptions;
  upgradePrompt: UpgradePrompt | null;
}

/* ----------------------- Locked-in constants ----------------------- */

const PRICING: PricingMetadata = Object.freeze({
  basicMonthly: 4.99,
  basicAnnual: 39.99,
  premiumMonthly: 9.99,
  premiumAnnual: 69.99,
});

const TIER_DESCRIPTIONS: TierDescriptions = Object.freeze({
  free: Object.freeze({
    title: "Start reflecting. See how Clarity works.",
    description:
      "Free lets you try Clarity's reflection engine and get a feel for how the app works.",
    bulletPointFeatures: Object.freeze([
      "Limited weekly reflection credits",
      "Full access to the reflection engine",
      "Basic flow + pacing",
      "Blurred insights",
      "No identity patterns",
      "No trend analysis",
    ]) as unknown as string[],
    whyPeopleChoose: Object.freeze([
      "They want to try the app first",
      "They're exploring how Clarity feels",
      "They're not ready for deeper insights yet",
    ]) as unknown as string[],
  }) as TierDescription,
  basic: Object.freeze({
    title: "Reflect as much as you want, without limits.",
    description:
      "Basic removes the weekly limits so you can reflect whenever you need to. It's for people who want Clarity to be part of their daily rhythm.",
    bulletPointFeatures: Object.freeze([
      "Unlimited reflections",
      "No weekly credit limits",
      "Full access to the reflection engine",
      "Blurred insights",
      "No identity patterns",
      "No trend analysis",
    ]) as unknown as string[],
    whyPeopleChoose: Object.freeze([
      "They reflect often",
      "They don't want to think about credits",
      "They use Clarity as a daily tool",
    ]) as unknown as string[],
  }) as TierDescription,
  premium: Object.freeze({
    title: "See the patterns behind your reflections.",
    description:
      "Premium shows you the deeper themes in your reflections — the patterns, the shifts, the things that repeat, and the things that change. It's the complete clarity experience.",
    bulletPointFeatures: Object.freeze([
      "Full insights (unblurred)",
      "Identity patterns",
      "Emotional themes",
      "Long-term trends",
      "Psychological shifts over time",
      "Premium digest",
      "Premium dashboard",
      "Premium continuation engine",
      "Premium themes",
      "Premium onboarding",
    ]) as unknown as string[],
    whyPeopleChoose: Object.freeze([
      "They want the full picture",
      "They're curious about deeper patterns",
      "They want to understand themselves more clearly over time",
    ]) as unknown as string[],
  }) as TierDescription,
});

/* ----------------------- Public helpers ----------------------- */

export function getUserTier(user?: GatingUser): UserTier {
  try {
    return gatingGetUserTier(user);
  } catch {
    return UserTier.Free;
  }
}

export function getPricing(): PricingMetadata {
  return PRICING;
}

export function getTierDescriptions(): TierDescriptions {
  return TIER_DESCRIPTIONS;
}

export function getUpgradePrompt(user?: GatingUser): UpgradePrompt | null {
  const tier = getUserTier(user);
  if (tier === UserTier.Premium) return null;
  // Free and Basic both target Premium with locked-in premium title copy.
  return {
    text: TIER_DESCRIPTIONS.premium.title,
    targetTier: UserTier.Premium,
  };
}

/* ----------------------- Entry point ----------------------- */

export function getSubscriptionMetadata(
  user?: GatingUser,
): SubscriptionMetadata {
  try {
    return {
      tier: getUserTier(user),
      pricing: PRICING,
      descriptions: TIER_DESCRIPTIONS,
      upgradePrompt: getUpgradePrompt(user),
    };
  } catch {
    return {
      tier: UserTier.Free,
      pricing: PRICING,
      descriptions: TIER_DESCRIPTIONS,
      upgradePrompt: null,
    };
  }
}
