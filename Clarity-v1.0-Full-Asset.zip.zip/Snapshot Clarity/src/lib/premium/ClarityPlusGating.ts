/**
 * ClarityPlusGating — centralized, pure-logic premium tier + gating layer
 * for Clarity+ (Subscription Engine) and Credits (Credit Engine).
 *
 * Read-only with respect to subscriptions, credits, and the user object.
 * The single permitted side effect is `deductReflectionCredit`, which
 * delegates to the existing Credits engine deduction path
 * (`recordAction("reflection")`). No new persistence, analytics, UI,
 * routing, or schema is introduced. No existing engine is modified.
 *
 * This module is intentionally unwired. Wiring is handled later.
 */

import {
  ACTION_COST,
  canPerform,
  creditsRemaining,
  recordAction,
} from "@/premium/limits";
import { currentTier, type Tier } from "@/premium/tier";
import { QUESTION_TONE_TEMPLATES } from "@/lib/questions/toneTemplates";

/* ----------------------------- Types ----------------------------- */

export enum UserTier {
  Free = "free",
  Basic = "basic",
  Premium = "premium",
}

export interface UpgradePrompt {
  text: string;
  targetTier: UserTier.Basic | UserTier.Premium;
}

export interface ClarityPlusGating {
  tier: UserTier;
  remainingCredits: number;
  canUseReflection: boolean;
  blurInsights: boolean;
  showTrends: boolean;
  upgradePrompt: UpgradePrompt | null;
}

/**
 * Optional, structurally-typed user input. The function never reads
 * arbitrary fields off it — tier resolution defers to the existing
 * Subscription Engine surface (`currentTier()`), which already accounts
 * for the active session. The parameter is accepted for API symmetry and
 * for future extension.
 */
export type GatingUser = unknown;

/* ----------------------- Internal helpers ----------------------- */

function tierFromString(t: Tier | string | null | undefined): UserTier {
  if (t === "premium") return UserTier.Premium;
  if (t === "basic") return UserTier.Basic;
  return UserTier.Free;
}

function safeTier(): UserTier {
  try {
    return tierFromString(currentTier());
  } catch {
    return UserTier.Free;
  }
}

/**
 * Internal tone guardrail. Enforces:
 *  - 1–2 sentences max
 *  - strips clinical / prescriptive / certainty language
 *  - trims length, no childish phrasing, no internal naming
 * Returns null if nothing safe remains.
 */
function sanitizeUpgradeText(raw: string | null | undefined): string | null {
  if (!raw) return null;
  let s = String(raw).trim();
  if (!s) return null;

  const forbidden =
    /\b(diagnos\w*|disorder|clinical|cure|treatment|prescrib\w*|you\s+must|you\s+should|always|never|guarantee\w*|toddler)\b/i;
  if (forbidden.test(s)) return null;

  // Cap to first two sentences.
  const sentences = s.match(/[^.!?]+[.!?]?/g) ?? [s];
  s = sentences.slice(0, 2).join(" ").trim();

  if (s.length === 0 || s.length > 220) return null;
  return s;
}

/* ----------------------- Public helpers ----------------------- */

export function getUserTier(_user?: GatingUser): UserTier {
  return safeTier();
}

/**
 * Free: remaining credits from existing Credit Engine.
 * Basic / Premium: not credit-limited — sentinel `Infinity`.
 */
export function getRemainingCredits(_user?: GatingUser): number {
  const tier = safeTier();
  if (tier !== UserTier.Free) return Number.POSITIVE_INFINITY;
  try {
    return Math.max(0, creditsRemaining());
  } catch {
    return 0;
  }
}

export function canUseReflectionCredit(_user?: GatingUser): boolean {
  const tier = safeTier();
  if (tier === UserTier.Premium || tier === UserTier.Basic) return true;
  try {
    return canPerform("reflection", "free");
  } catch {
    return false;
  }
}

/**
 * No-op for Basic / Premium. For Free, calls the existing Credits engine
 * deduction path exactly as it is called today (`recordAction("reflection")`).
 */
export function deductReflectionCredit(_user?: GatingUser): void {
  const tier = safeTier();
  if (tier === UserTier.Premium || tier === UserTier.Basic) return;
  try {
    recordAction("reflection", "free");
  } catch {
    /* swallow — never throw from gating layer */
  }
  // Reference to keep ACTION_COST import meaningful for future tuning.
  void ACTION_COST;
}

export function canViewFullInsights(_user?: GatingUser): boolean {
  return safeTier() === UserTier.Premium;
}

export function shouldBlurInsights(_user?: GatingUser): boolean {
  return safeTier() !== UserTier.Premium;
}

export function canViewTrends(_user?: GatingUser): boolean {
  return safeTier() === UserTier.Premium;
}

/**
 * Upgrade prompt drawn only from existing Module #5 tone templates.
 * Returns null when no suitable template line exists or for Premium.
 */
export function getUpgradePrompt(_user?: GatingUser): UpgradePrompt | null {
  const tier = safeTier();
  if (tier === UserTier.Premium) return null;

  const candidates: string[] = [
    ...QUESTION_TONE_TEMPLATES.moveForward,
    ...QUESTION_TONE_TEMPLATES.emotionalSafety,
  ];

  let text: string | null = null;
  for (const line of candidates) {
    const safe = sanitizeUpgradeText(line);
    if (safe) {
      text = safe;
      break;
    }
  }
  if (!text) return null;

  // Free → Premium (preferred). Basic → Premium.
  return { text, targetTier: UserTier.Premium };
}

/* ----------------------- Entry point ----------------------- */

export function getClarityPlusGating(user?: GatingUser): ClarityPlusGating {
  try {
    const tier = getUserTier(user);
    return {
      tier,
      remainingCredits: getRemainingCredits(user),
      canUseReflection: canUseReflectionCredit(user),
      blurInsights: shouldBlurInsights(user),
      showTrends: canViewTrends(user),
      upgradePrompt: getUpgradePrompt(user),
    };
  } catch {
    // Safe Free-tier default.
    return {
      tier: UserTier.Free,
      remainingCredits: 0,
      canUseReflection: false,
      blurInsights: true,
      showTrends: false,
      upgradePrompt: null,
    };
  }
}
