import { supabase } from "@/integrations/supabase/client";

export type TwoPersonStatus =
  | "awaiting_owner"
  | "awaiting_invitee"
  | "awaiting_other"
  | "ready"
  | "complete";

export interface TwoPersonSessionRow {
  id: string;
  owner_id: string;
  topic: string;
  invite_token: string;
  status: TwoPersonStatus;
  combined_summary: string | null;
  shared_themes: string[];
  misread_points: string[];
  created_at: string;
  completed_at: string | null;
  deleted_at: string | null;
}

export interface TwoPersonPerspectiveRow {
  id: string;
  session_id: string;
  side: "owner" | "invitee";
  display_name: string | null;
  perspective_text: string;
  suggested_rewrite: string | null;
  created_at: string;
  updated_at: string;
}

export interface TwoPersonInviteSummary {
  id: string;
  topic: string;
  status: TwoPersonStatus;
  has_owner_perspective: boolean;
  has_invitee_perspective: boolean;
  created_at: string;
}

function generateToken(): string {
  // URL-safe random token, ~32 hex chars
  const arr = new Uint8Array(20);
  crypto.getRandomValues(arr);
  return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}

export async function createTwoPersonSession(params: {
  ownerId: string;
  topic: string;
  ownerDisplayName: string;
  ownerPerspective: string;
}): Promise<TwoPersonSessionRow> {
  const token = generateToken();
  const { data: session, error } = await supabase
    .from("two_person_sessions")
    .insert({
      owner_id: params.ownerId,
      topic: params.topic.trim(),
      invite_token: token,
      status: "awaiting_invitee",
    })
    .select("*")
    .single();
  if (error || !session) throw error ?? new Error("Failed to create session");

  const { error: pErr } = await supabase.from("two_person_perspectives").insert({
    session_id: session.id,
    side: "owner",
    display_name: params.ownerDisplayName.trim() || null,
    perspective_text: params.ownerPerspective.trim(),
  });
  if (pErr) throw pErr;

  return session as TwoPersonSessionRow;
}

export async function listTwoPersonSessions(ownerId: string) {
  const { data, error } = await supabase
    .from("two_person_sessions")
    .select("*")
    .eq("owner_id", ownerId)
    .is("deleted_at", null)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as TwoPersonSessionRow[];
}

export async function getTwoPersonSession(id: string) {
  const { data, error } = await supabase
    .from("two_person_sessions")
    .select("*")
    .eq("id", id)
    .is("deleted_at", null)
    .maybeSingle();
  if (error) throw error;
  return data as TwoPersonSessionRow | null;
}

export async function getTwoPersonPerspectives(sessionId: string) {
  const { data, error } = await supabase
    .from("two_person_perspectives")
    .select("*")
    .eq("session_id", sessionId)
    .order("side", { ascending: true });
  if (error) throw error;
  return (data ?? []) as TwoPersonPerspectiveRow[];
}

export async function getInviteSummary(token: string): Promise<TwoPersonInviteSummary | null> {
  const { data, error } = await supabase.rpc("get_two_person_session_by_token", { _token: token });
  if (error) {
    console.error("getInviteSummary", error);
    return null;
  }
  const row = (data as TwoPersonInviteSummary[] | null)?.[0];
  return row ?? null;
}

export async function submitInviteePerspective(
  token: string,
  displayName: string,
  perspectiveText: string,
) {
  const { error } = await supabase.rpc("submit_invitee_perspective", {
    _token: token,
    _display_name: displayName,
    _perspective_text: perspectiveText,
  });
  if (error) throw error;
}

export async function generateCombinedInsight(sessionId: string) {
  const { data, error } = await supabase.functions.invoke("two-person-insight", {
    body: { session_id: sessionId },
  });
  if (error) throw error;
  return data;
}

export async function deleteTwoPersonSession(id: string) {
  const { error } = await supabase
    .from("two_person_sessions")
    .update({ deleted_at: new Date().toISOString() })
    .eq("id", id);
  if (error) throw error;
}

export function inviteUrl(token: string): string {
  return `${window.location.origin}/two-person/invite/${token}`;
}
