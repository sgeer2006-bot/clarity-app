// Lazy Stripe.js client loader for Clarity+ checkout.
// Reads the publishable token Lovable provisions in .env.development /
// .env.production via VITE_PAYMENTS_CLIENT_TOKEN. Sandbox vs. live is
// derived from the token prefix so the same code works in both.

import { loadStripe, type Stripe } from "@stripe/stripe-js";

export type StripeEnv = "sandbox" | "live";

const clientToken = import.meta.env.VITE_PAYMENTS_CLIENT_TOKEN as string | undefined;

export const stripeEnvironment: StripeEnv =
  clientToken?.startsWith("pk_live_") ? "live" : "sandbox";

let stripePromise: Promise<Stripe | null> | null = null;

export function getStripe(): Promise<Stripe | null> {
  if (!stripePromise) {
    if (!clientToken) {
      // Don't crash the app; surface a clear warning so devs/users know.
      console.warn(
        "[Clarity+] VITE_PAYMENTS_CLIENT_TOKEN is not set. Stripe checkout is disabled.",
      );
      stripePromise = Promise.resolve(null);
    } else {
      stripePromise = loadStripe(clientToken);
    }
  }
  return stripePromise;
}

export function getStripeEnvironment(): StripeEnv {
  return stripeEnvironment;
}

export function isStripeConfigured(): boolean {
  return Boolean(clientToken);
}
