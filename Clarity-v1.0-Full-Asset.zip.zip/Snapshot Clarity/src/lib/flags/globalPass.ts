/**
 * Master kill switch for the clarity_global_pass_v1 transformation pass.
 *
 * Off by default. Enable per-device by running in DevTools:
 *   localStorage.setItem("clarity_global_pass_v1", "true"); location.reload();
 * Disable: remove the key (or set to "false") and reload.
 *
 * When OFF, every new surface introduced by this pass (FTUE A, FTUE B,
 * Guided Tour, the new bottom navigation) is bypassed and the app behaves
 * exactly as before. This is the rollback path.
 */

const KEY = "clarity_global_pass_v1";

export function isGlobalPassEnabled(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return localStorage.getItem(KEY) === "true";
  } catch {
    return false;
  }
}

export function setGlobalPassEnabled(on: boolean): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(KEY, on ? "true" : "false");
  } catch {
    /* ignore */
  }
}
