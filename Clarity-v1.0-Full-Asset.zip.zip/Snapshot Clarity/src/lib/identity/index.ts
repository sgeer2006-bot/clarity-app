/**
 * Public Identity Model API. All functions are deterministic, client-side,
 * and never call the network.
 */
import { recordEventInternal, getStateInternal } from "./reducer";
import { getInsightsInternal, explainInternal } from "./explain";
import { getTimelineInternal } from "./timeline";
import type { IdentityEvent, IdentityState, Insight, Scope, TimelineEntry, Window } from "./types";

export function recordEvent(e: IdentityEvent): void {
  recordEventInternal(e);
}

export function getState(): IdentityState {
  return getStateInternal();
}

export function getInsights(scope: Scope = "all"): Insight[] {
  return getInsightsInternal(getStateInternal(), scope);
}

export function getTimeline(window: Window = "30d"): TimelineEntry[] {
  return getTimelineInternal(getStateInternal(), window);
}

export function explain(id: string): string {
  return explainInternal(id);
}

export type { IdentityEvent, IdentityState, Insight, TimelineEntry, Scope, Window };
