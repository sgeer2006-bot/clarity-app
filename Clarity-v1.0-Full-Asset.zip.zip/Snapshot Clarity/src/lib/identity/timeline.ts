import type { IdentityState, TimelineEntry, Window } from "./types";
import { DIMENSION_LABEL } from "./dimensions";
import { getUserProfile } from "@/lib/profile/userProfile";

const WINDOW_MS: Record<Window, number> = {
  "7d": 7 * 24 * 60 * 60 * 1000,
  "30d": 30 * 24 * 60 * 60 * 1000,
  "90d": 90 * 24 * 60 * 60 * 1000,
  all: Number.POSITIVE_INFINITY,
};

export function getTimelineInternal(state: IdentityState, window: Window): TimelineEntry[] {
  // Hybrid onboarding: story evolution reads profile values as supplemental context.
  // No state machine or transition changes.
  const _profile = getUserProfile();
  void _profile;
  const cutoff = Date.now() - WINDOW_MS[window];
  return state.events
    .filter((e) => new Date(e.ts).getTime() >= cutoff)
    .map((e) => ({
      ts: e.ts,
      dimension: e.dimension,
      delta: e.delta,
      explanation: `${DIMENSION_LABEL[e.dimension]} — you named “${e.label}”`,
    }));
}
