/** Identity Model — deterministic, client-side, 7 dimensions. */

export type Dimension =
  | "emotional"
  | "communication"
  | "roles"
  | "relational"
  | "cognitive"
  | "behavioral"
  | "stability";

export type Scope = "all" | Dimension;
export type Window = "7d" | "30d" | "90d" | "all";

export interface IdentityEvent {
  /** ISO timestamp; defaults to now() inside reducer. */
  ts?: string;
  /** Source surface so we can explain provenance. */
  source:
    | "snapshot"
    | "micro_reflection"
    | "pattern_conversation"
    | "continuation"
    | "two_person"
    | "habit_loop"
    | "manual";
  /** Free-form tags — counted per dimension. */
  tags?: Partial<Record<Dimension, string[]>>;
  /** Optional named role (e.g. "partner"). */
  role?: string;
  /** Optional named relationship. */
  relationship?: string;
  /** Free-text excerpt used only for cognitive framing detection. */
  text?: string;
}

export interface DimensionState {
  /** tag → count */
  counts: Record<string, number>;
  /** Last time this dimension received an event (ISO). */
  lastTs?: string;
}

export interface IdentityState {
  version: 1;
  createdAt: string;
  updatedAt: string;
  dimensions: Record<Dimension, DimensionState>;
  roles: Record<string, { count: number; lastTs: string }>;
  relationships: Record<string, { count: number; lastTs: string }>;
  /** Append-only log of recent events for timeline output. Capped. */
  events: Array<{
    ts: string;
    dimension: Dimension;
    delta: number;
    explanationId: string;
    label: string;
  }>;
}

export interface Insight {
  id: string;
  dimension: Dimension;
  text: string;
  strength: "soft" | "clear" | "strong";
}

export interface TimelineEntry {
  ts: string;
  dimension: Dimension;
  delta: number;
  explanation: string;
}
