import type { Dimension } from "./types";

export const DIMENSIONS: Dimension[] = [
  "emotional",
  "communication",
  "roles",
  "relational",
  "cognitive",
  "behavioral",
  "stability",
];

export const DIMENSION_LABEL: Record<Dimension, string> = {
  emotional: "How you feel",
  communication: "How you talk about things",
  roles: "Who you show up as",
  relational: "The people in your story",
  cognitive: "The way you think about things",
  behavioral: "What you tend to do",
  stability: "What stays steady",
};

/** Non-clinical short descriptors used by explain.ts. */
export const DIMENSION_DESCRIPTOR: Record<Dimension, string> = {
  emotional: "how you tend to feel",
  communication: "how you usually say things",
  roles: "the parts of you that step forward",
  relational: "the people who keep showing up",
  cognitive: "the thoughts you keep coming back to",
  behavioral: "the small things you keep doing",
  stability: "what stays the same, even when things shift",
};

/** Cognitive framings detected from raw text. Word-boundary matched. */
export const COGNITIVE_FRAMINGS: { tag: string; pattern: RegExp }[] = [
  { tag: "should", pattern: /\bshould(n't|n’t)?\b/i },
  { tag: "always", pattern: /\balways\b/i },
  { tag: "never", pattern: /\bnever\b/i },
  { tag: "must", pattern: /\bmust\b/i },
  { tag: "have_to", pattern: /\bhave to\b/i },
  { tag: "cant", pattern: /\bcan(?:'|’)?t\b/i },
];
