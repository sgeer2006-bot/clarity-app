import type { Dimension, IdentityState, Insight, Scope } from "./types";
import { DIMENSIONS, DIMENSION_DESCRIPTOR } from "./dimensions";
import { getUserProfile } from "@/lib/profile/userProfile";

/** Deterministic, non-clinical templates. No predictions, no diagnoses. */
const TEMPLATES: Record<Dimension, (top: string, n: number) => string> = {
  emotional: (t) => `“${t}” keeps coming up when you talk about ${DIMENSION_DESCRIPTOR.emotional} — it's becoming part of how you feel.`,
  communication: (t) => `You often say things in a “${t}” way — that's becoming your voice.`,
  roles: (t) => `You keep showing up as the “${t}” — it's part of who you are right now.`,
  relational: (t) => `“${t}” shows up the most when you write about people — they hold a real place in your story.`,
  cognitive: (t) => `The thought “${t}” keeps coming back — it's a small thread worth noticing.`,
  behavioral: (t) => `“${t}” is the small thing you keep doing — quiet, steady, yours.`,
  stability: (_t, n) => `You've shown up ${n} times — a steady picture of who you are is starting to come through.`,
};

function topTag(state: IdentityState, dim: Dimension): { tag: string; n: number } | null {
  const counts = state.dimensions[dim].counts;
  let best: { tag: string; n: number } | null = null;
  for (const [tag, n] of Object.entries(counts)) {
    if (!best || n > best.n) best = { tag, n };
  }
  return best && best.n > 0 ? best : null;
}

function strengthOf(n: number): Insight["strength"] {
  if (n >= 8) return "strong";
  if (n >= 3) return "clear";
  return "soft";
}

export function getInsightsInternal(state: IdentityState, scope: Scope): Insight[] {
  // Hybrid onboarding: profile values are available as additional context here.
  // Read-only; existing output shapes unchanged.
  const _profile = getUserProfile();
  void _profile;
  const dims: Dimension[] = scope === "all" ? DIMENSIONS : [scope];
  const out: Insight[] = [];
  for (const dim of dims) {
    const top = topTag(state, dim);
    if (!top) continue;
    out.push({
      id: `${dim}:${top.tag}`,
      dimension: dim,
      text: TEMPLATES[dim](top.tag, top.n),
      strength: strengthOf(top.n),
    });
  }
  return out;
}

export function explainInternal(id: string): string {
  // id format: "<dimension>:<tag>"
  const [dim, tag] = id.split(":");
  if (!dim || !tag) return "";
  const fn = TEMPLATES[dim as Dimension];
  if (!fn) return "";
  return fn(tag, 0);
}
