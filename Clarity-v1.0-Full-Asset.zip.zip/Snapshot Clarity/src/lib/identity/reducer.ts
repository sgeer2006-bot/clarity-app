import type { Dimension, IdentityEvent, IdentityState } from "./types";
import { DIMENSIONS, COGNITIVE_FRAMINGS } from "./dimensions";

const STORAGE_KEY = "clarity.identity.state.v1";
const EVENT_CAP = 500;

function freshState(): IdentityState {
  const now = new Date().toISOString();
  const dimensions = Object.fromEntries(
    DIMENSIONS.map((d) => [d, { counts: {} }]),
  ) as IdentityState["dimensions"];
  return {
    version: 1,
    createdAt: now,
    updatedAt: now,
    dimensions,
    roles: {},
    relationships: {},
    events: [],
  };
}

export function loadState(): IdentityState {
  if (typeof window === "undefined") return freshState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return freshState();
    const parsed = JSON.parse(raw) as IdentityState;
    if (parsed?.version !== 1) return freshState();
    // Defensive: ensure all dimensions present.
    for (const d of DIMENSIONS) {
      if (!parsed.dimensions[d]) parsed.dimensions[d] = { counts: {} };
    }
    return parsed;
  } catch {
    return freshState();
  }
}

export function saveState(state: IdentityState): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* quota or disabled — ignore */
  }
}

/** Pure reducer. (state, event) -> state. No randomness, no side effects. */
export function reduce(state: IdentityState, event: IdentityEvent): IdentityState {
  const ts = event.ts ?? new Date().toISOString();
  const next: IdentityState = {
    ...state,
    dimensions: { ...state.dimensions },
    roles: { ...state.roles },
    relationships: { ...state.relationships },
    events: state.events.slice(),
    updatedAt: ts,
  };

  // Apply tag counts per dimension.
  if (event.tags) {
    for (const dim of DIMENSIONS) {
      const tags = event.tags[dim];
      if (!tags || tags.length === 0) continue;
      const dimState = { ...next.dimensions[dim] };
      const counts = { ...dimState.counts };
      for (const tag of tags) {
        const key = tag.trim().toLowerCase();
        if (!key) continue;
        counts[key] = (counts[key] ?? 0) + 1;
      }
      dimState.counts = counts;
      dimState.lastTs = ts;
      next.dimensions[dim] = dimState;
      next.events.push({
        ts,
        dimension: dim,
        delta: tags.length,
        explanationId: `tag:${dim}`,
        label: tags[0] ?? dim,
      });
    }
  }

  // Roles (always counted in `roles` dimension too).
  if (event.role) {
    const key = event.role.trim().toLowerCase();
    if (key) {
      const prev = next.roles[key];
      next.roles[key] = { count: (prev?.count ?? 0) + 1, lastTs: ts };
      const rolesDim = { ...next.dimensions.roles };
      rolesDim.counts = { ...rolesDim.counts, [key]: (rolesDim.counts[key] ?? 0) + 1 };
      rolesDim.lastTs = ts;
      next.dimensions.roles = rolesDim;
    }
  }

  // Relationships (also relational dimension).
  if (event.relationship) {
    const key = event.relationship.trim().toLowerCase();
    if (key) {
      const prev = next.relationships[key];
      next.relationships[key] = { count: (prev?.count ?? 0) + 1, lastTs: ts };
      const relDim = { ...next.dimensions.relational };
      relDim.counts = { ...relDim.counts, [key]: (relDim.counts[key] ?? 0) + 1 };
      relDim.lastTs = ts;
      next.dimensions.relational = relDim;
    }
  }

  // Cognitive framings from raw text.
  if (event.text) {
    const cogDim = { ...next.dimensions.cognitive };
    const counts = { ...cogDim.counts };
    let touched = false;
    for (const { tag, pattern } of COGNITIVE_FRAMINGS) {
      if (pattern.test(event.text)) {
        counts[tag] = (counts[tag] ?? 0) + 1;
        touched = true;
      }
    }
    if (touched) {
      cogDim.counts = counts;
      cogDim.lastTs = ts;
      next.dimensions.cognitive = cogDim;
    }
  }

  // Stability is derived: bump a "activity" counter so variance reads update.
  const stab = { ...next.dimensions.stability };
  stab.counts = { ...stab.counts, activity: (stab.counts.activity ?? 0) + 1 };
  stab.lastTs = ts;
  next.dimensions.stability = stab;

  // Cap events log.
  if (next.events.length > EVENT_CAP) {
    next.events = next.events.slice(-EVENT_CAP);
  }

  return next;
}

let cached: IdentityState | null = null;
function getCached(): IdentityState {
  if (!cached) cached = loadState();
  return cached;
}

export function recordEventInternal(event: IdentityEvent): IdentityState {
  const next = reduce(getCached(), event);
  cached = next;
  saveState(next);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("clarity:identity-updated"));
  }
  return next;
}

export function getStateInternal(): IdentityState {
  return getCached();
}

/** Test helper — clears in-memory + persisted state. */
export function _resetForTests(): void {
  cached = null;
  if (typeof window !== "undefined") localStorage.removeItem(STORAGE_KEY);
}
