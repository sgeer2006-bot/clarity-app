import { getState } from "@/lib/identity";
import type { Dimension } from "@/lib/identity/types";
import { DIMENSIONS } from "@/lib/identity/dimensions";
import { CURIOSITY } from "./curiosity";
import { readTier } from "./gate";
import { getUserProfile } from "@/lib/profile/userProfile";
import type { ContinuationContext, NextStep, RecencyBucket, UpsellCard } from "./types";

// Hybrid onboarding: continuation engine reads profile as supplemental context.
// No structural, scheduling, ordering, or interface changes.
const _continuationProfileRead = () => getUserProfile();
void _continuationProfileRead;

function dominantDimension(): Dimension {
  const state = getState();
  let best: { dim: Dimension; n: number } = { dim: "emotional", n: -1 };
  for (const dim of DIMENSIONS) {
    let total = 0;
    for (const v of Object.values(state.dimensions[dim].counts)) total += v;
    if (total > best.n) best = { dim, n: total };
  }
  return best.dim;
}

function recencyBucket(ts?: string): RecencyBucket {
  if (!ts) return "stale";
  const ageMs = Date.now() - new Date(ts).getTime();
  if (ageMs < 5 * 60_000) return "fresh";
  if (ageMs < 24 * 60 * 60_000) return "today";
  if (ageMs < 7 * 24 * 60 * 60_000) return "this_week";
  return "stale";
}

interface DecisionRow {
  title: string;
  body: string;
  cta: { label: string; href: string };
}

const DECISIONS: Record<ContinuationContext["lastActionType"], DecisionRow> = {
  snapshot_saved: {
    title: "Sit with this for a moment",
    body: "You named something true. When you're ready, one little line can tie it to the rest of your story.",
    cta: { label: "Add a small note", href: "/patterns/timeline" },
  },
  reflection_saved: {
    title: "One small step",
    body: "What you just wrote is part of who you are now. Keep going at your own pace.",
    cta: { label: "See how it fits", href: "/patterns/dashboard" },
  },
  pattern_conversation_completed: {
    title: "Something new opened up",
    body: "Something shifted just now — a small piece of your story found its place.",
    cta: { label: "See where it lands", href: "/patterns/clusters" },
  },
  two_person_event: {
    title: "A shared thread",
    body: "What came up here belongs to both of you. A short shared note can hold it gently.",
    cta: { label: "Open shared room", href: "/two-person-room" },
  },
  insight_viewed: {
    title: "Let it settle",
    body: "Notice if anything here surprised you. That little spark is worth a breath of attention.",
    cta: { label: "Look at your story", href: "/patterns/timeline" },
  },
  idle: {
    title: "A gentle hello",
    body: "Whenever you're ready, one sentence is enough. You're still here, and that matters.",
    cta: { label: "Open Clarity", href: "/" },
  },
};

export function getNextStep(ctx: ContinuationContext): NextStep | UpsellCard {
  const tier = readTier();
  const dim = ctx.dominantDimension ?? dominantDimension();
  const bucket = recencyBucket(ctx.lastActionTs); // computed for determinism / future use
  void bucket;

  if (tier === "free") {
    return {
      kind: "upsell",
      title: "Keep your story going",
      body: "Clarity can quietly point to the next small step, shaped by what you've already noticed.",
      cta: { label: "See what's inside", href: "/clarity-plus/pricing" },
    };
  }

  const base = DECISIONS[ctx.lastActionType];
  const step: NextStep = {
    kind: "next_step",
    title: base.title,
    body: base.body,
    cta: base.cta,
  };
  if (tier === "premium") step.curiosity = CURIOSITY[dim];
  return step;
}
