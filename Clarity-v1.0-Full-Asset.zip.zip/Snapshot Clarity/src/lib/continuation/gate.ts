/**
 * Premium gating for the Continuation Engine. Reads the same subscription
 * token used by `usePremium`. Pure read-only.
 */
const KEY = "clarity.subscription_token";

export type Tier = "free" | "basic" | "premium";

export function readTier(): Tier {
  if (typeof window === "undefined") return "free";
  const raw = localStorage.getItem(KEY);
  if (!raw) return "free";
  try {
    const parsed = JSON.parse(atob(raw.split(".")[0] ?? raw));
    if (parsed?.exp && parsed.exp < Date.now() / 1000) return "free";
    if (parsed?.tier === "basic" || parsed?.tier === "premium") return parsed.tier;
  } catch {
    /* ignore */
  }
  return "free";
}
