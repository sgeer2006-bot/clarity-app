import type { Dimension } from "@/lib/identity/types";

export interface ContinuationContext {
  lastActionType:
    | "snapshot_saved"
    | "reflection_saved"
    | "pattern_conversation_completed"
    | "two_person_event"
    | "insight_viewed"
    | "idle";
  /** Optional dominant dimension hint; otherwise computed from identity state. */
  dominantDimension?: Dimension;
  /** ISO timestamp of the last action, if known. */
  lastActionTs?: string;
}

export type RecencyBucket = "fresh" | "today" | "this_week" | "stale";

export interface NextStep {
  kind: "next_step";
  title: string;
  body: string;
  /** Premium tier shows a curiosity-gap line; basic tier omits it. */
  curiosity?: string;
  cta: { label: string; href: string };
}

export interface UpsellCard {
  kind: "upsell";
  title: string;
  body: string;
  cta: { label: string; href: string };
}
