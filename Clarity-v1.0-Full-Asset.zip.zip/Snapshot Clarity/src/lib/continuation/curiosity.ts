import type { Dimension } from "@/lib/identity/types";

/**
 * Curiosity-gap templates. Calm, non-clinical, no clickbait, no predictions.
 * One template per dimension; deterministic selection.
 */
export const CURIOSITY: Record<Dimension, string> = {
  emotional: "There's a feeling here you haven't quite put a name to yet.",
  communication: "There's a small way you say things that's starting to feel like yours.",
  roles: "There's a part of you that keeps showing up lately.",
  relational: "There's someone in your story whose shape is getting clearer.",
  cognitive: "There's a thought you keep coming back to — and it means something.",
  behavioral: "There's a small thing you keep doing, like a soft little signal.",
  stability: "There's a steady thread running under everything that's moved.",
};
