// Canonical pattern taxonomy (seed). Shared by client UI and edge functions.
import type { TagCategory } from "../types";

export interface TaxonomyEntry {
  id: string;
  label: string;
  category: TagCategory;
  description: string;
  clusterGroup: string;
}

export const TAXONOMY: TaxonomyEntry[] = [
  // Loops
  { id: "loop.anxious_reassurance", label: "Looking for reassurance when you feel anxious", category: "emotional", clusterGroup: "loops", description: "When you feel uneasy, you reach out for comfort — and it helps for a moment, then comes back." },
  { id: "loop.shame_withdraw", label: "Pulling away when you feel small", category: "emotional", clusterGroup: "loops", description: "When shame shows up, you tend to step back from people." },
  { id: "loop.anger_guilt_repair", label: "Getting upset, then trying to make it right", category: "emotional", clusterGroup: "loops", description: "Anger comes up, guilt follows, and then you try to fix things." },
  { id: "loop.control_collapse", label: "Holding it all together until you can't", category: "emotional", clusterGroup: "loops", description: "You hold tight to control until it gets to be too much." },
  { id: "loop.abandonment_test", label: "Checking if people will stay", category: "relational", clusterGroup: "loops", description: "When you're worried someone might leave, you test whether they'll stick around." },

  // Roles
  { id: "role.pursuer", label: "The one who reaches out", category: "relational", clusterGroup: "roles", description: "You move closer when there's distance between you and someone else." },
  { id: "role.withdrawer", label: "The one who needs space", category: "relational", clusterGroup: "roles", description: "You step back when things feel like a lot." },
  { id: "role.fixer", label: "The one who tries to fix things", category: "relational", clusterGroup: "roles", description: "You reach for solutions to make hard feelings smaller — yours or someone else's." },
  { id: "role.victim", label: "The one who feels stuck", category: "relational", clusterGroup: "roles", description: "You speak from a place of feeling like there's nothing you can do." },
  { id: "role.peacemaker", label: "The one who keeps the peace", category: "relational", clusterGroup: "roles", description: "You smooth things over, even when it costs you." },

  // Communication
  { id: "comm.over_explaining", label: "Explaining a lot so people understand", category: "communication", clusterGroup: "communication", description: "You add a lot of reasons and background so people get where you're coming from." },
  { id: "comm.minimizing", label: "Making things sound smaller than they are", category: "communication", clusterGroup: "communication", description: "You shrink what you feel or what happened so it feels easier to hold." },
  { id: "comm.stonewalling", label: "Going quiet when it's too much", category: "communication", clusterGroup: "communication", description: "You stop talking to make the hard moment end." },
  { id: "comm.deflecting", label: "Turning the conversation somewhere else", category: "communication", clusterGroup: "communication", description: "You move attention away from the hard part." },
  { id: "comm.placating", label: "Agreeing to keep things calm", category: "communication", clusterGroup: "communication", description: "You go along with things to keep the peace, even when it's not how you really feel." },

  // Conflict shapes
  { id: "conflict.criticism_defensiveness", label: "One person points it out, the other defends", category: "relational", clusterGroup: "conflict", description: "A complaint meets a wall, and nothing really gets through." },
  { id: "conflict.demand_withdraw", label: "One person pushes, the other steps back", category: "relational", clusterGroup: "conflict", description: "One of you wants to talk; the other wants space." },
  { id: "conflict.contempt_withdrawal", label: "Hurt words meet quiet distance", category: "relational", clusterGroup: "conflict", description: "Sharp feelings on one side, pulling away on the other." },

  // Identity
  { id: "identity.inner_critic_dominant", label: "A voice inside that's hard on you", category: "identity", clusterGroup: "identity", description: "There's a voice in your head that's tougher on you than the world is." },
  { id: "identity.perfectionist_self", label: "Feeling worth it when you get things right", category: "identity", clusterGroup: "identity", description: "Your sense of being okay leans on doing things well." },
  { id: "identity.caretaker_self", label: "Taking care of others first", category: "identity", clusterGroup: "identity", description: "You tend to other people's feelings before your own." },
  { id: "identity.fragile_self_worth", label: "Self-worth that wobbles with the moment", category: "identity", clusterGroup: "identity", description: "How you feel about yourself can shift a lot, depending on what's going on." },

  // Attachment
  { id: "attach.anxious", label: "Wanting closeness, worrying about losing it", category: "relational", clusterGroup: "attachment", description: "You want to feel close, and uncertainty in that closeness is hard to sit with." },
  { id: "attach.avoidant", label: "Feeling safer on your own", category: "relational", clusterGroup: "attachment", description: "Standing on your own feels safer than leaning on someone." },
  { id: "attach.disorganized", label: "Wanting closeness and pulling away at the same time", category: "relational", clusterGroup: "attachment", description: "You want to be close and want space, sometimes in the same breath." },
  { id: "attach.secure_leaning", label: "Feeling held, in yourself and with others", category: "relational", clusterGroup: "attachment", description: "Connection and being your own person both feel okay." },

  // Distortions
  { id: "distortion.all_or_nothing", label: "Seeing things as all good or all bad", category: "linguistic", clusterGroup: "distortions", description: "Things land as either one thing or the other, with not much in between." },
  { id: "distortion.catastrophizing", label: "Jumping to the worst-case", category: "linguistic", clusterGroup: "distortions", description: "A hard outcome feels like the worst that could happen." },
  { id: "distortion.mind_reading", label: "Guessing what someone else is thinking", category: "linguistic", clusterGroup: "distortions", description: "You're sure you know what they think or feel." },
  { id: "distortion.personalization", label: "Taking neutral things personally", category: "linguistic", clusterGroup: "distortions", description: "Something not really about you feels like it is." },
  { id: "distortion.shoulding", label: "Telling yourself how it should have been", category: "linguistic", clusterGroup: "distortions", description: "You measure things by what you think should have happened." },
  { id: "distortion.labeling", label: "Naming yourself or someone by one thing", category: "linguistic", clusterGroup: "distortions", description: "You call yourself or someone else by a single trait, like that's the whole story." },
  { id: "distortion.overgeneralization", label: "One time becomes always", category: "linguistic", clusterGroup: "distortions", description: "One thing that happened starts to feel like it's how things always go." },

  // Needs
  { id: "need.validation", label: "Wanting to feel believed", category: "identity", clusterGroup: "needs", description: "Wanting someone to say, yes, what you feel is real." },
  { id: "need.safety", label: "Wanting to feel safe", category: "identity", clusterGroup: "needs", description: "Wanting to feel okay in your body and around people." },
  { id: "need.autonomy", label: "Wanting room to be yourself", category: "identity", clusterGroup: "needs", description: "Wanting space to be your own person." },
  { id: "need.belonging", label: "Wanting to feel like you belong", category: "identity", clusterGroup: "needs", description: "Wanting to feel like you fit in and matter." },
  { id: "need.being_seen", label: "Wanting to be seen for who you are", category: "identity", clusterGroup: "needs", description: "Wanting people to notice the real you." },

  // Fallbacks
  { id: "observation.too_brief_for_pattern", label: "A short note", category: "linguistic", clusterGroup: "meta", description: "Not quite enough yet to notice a pattern." },
  { id: "observation.insufficient_signal", label: "A quiet moment", category: "linguistic", clusterGroup: "meta", description: "What you wrote stays gentle on the surface — the shape isn't clear yet." },
];

export const TAXONOMY_BY_ID: Record<string, TaxonomyEntry> = Object.fromEntries(
  TAXONOMY.map((t) => [t.id, t]),
);
