// Seed lexicons for fast lexical sweep. Edge function imports these.
// Each subtype maps to a list of regex patterns with weights.

export interface LexiconHit {
  pattern: RegExp;
  weight: number;
}

export const LINGUISTIC_LEX: Record<string, LexiconHit[]> = {
  certainty: [
    { pattern: /\balways\b/gi, weight: 0.7 },
    { pattern: /\bnever\b/gi, weight: 0.7 },
    { pattern: /\bdefinitely\b/gi, weight: 0.6 },
    { pattern: /\bobviously\b/gi, weight: 0.6 },
    { pattern: /\bcompletely\b/gi, weight: 0.5 },
  ],
  uncertainty: [
    { pattern: /\bmaybe\b/gi, weight: 0.5 },
    { pattern: /\bkind of\b/gi, weight: 0.5 },
    { pattern: /\bI guess\b/gi, weight: 0.6 },
    { pattern: /\bsort of\b/gi, weight: 0.5 },
    { pattern: /\bnot sure\b/gi, weight: 0.6 },
  ],
  avoidance: [
    { pattern: /\bwhatever\b/gi, weight: 0.6 },
    { pattern: /\bit'?s fine\b/gi, weight: 0.7 },
    { pattern: /\bdoesn'?t matter\b/gi, weight: 0.7 },
    { pattern: /\bI'?m over it\b/gi, weight: 0.7 },
  ],
  blame_outward: [
    { pattern: /\b(he|she|they) (always|never)\b/gi, weight: 0.7 },
    { pattern: /\bnever listens?\b/gi, weight: 0.7 },
    { pattern: /\bmakes me\b/gi, weight: 0.6 },
  ],
  blame_inward: [
    { pattern: /\bmy fault\b/gi, weight: 0.8 },
    { pattern: /\bbecause of me\b/gi, weight: 0.7 },
    { pattern: /\bI ruined\b/gi, weight: 0.7 },
  ],
  self_protective: [
    { pattern: /\bI'?m just\b/gi, weight: 0.5 },
    { pattern: /\bit'?s not like I\b/gi, weight: 0.6 },
    { pattern: /\bI wasn'?t trying to\b/gi, weight: 0.6 },
  ],
  minimizing: [
    { pattern: /\bit'?s not a big deal\b/gi, weight: 0.7 },
    { pattern: /\bI shouldn'?t even\b/gi, weight: 0.6 },
    { pattern: /\bit'?s nothing\b/gi, weight: 0.6 },
  ],
};

export const EMOTION_LEX: Record<string, LexiconHit[]> = {
  sadness: [{ pattern: /\b(sad|hurt|crying|grief|miss|lonely)\b/gi, weight: 0.6 }],
  anger: [{ pattern: /\b(angry|furious|pissed|mad|rage|resent)\b/gi, weight: 0.7 }],
  fear: [{ pattern: /\b(scared|afraid|terrified|nervous|worried)\b/gi, weight: 0.6 }],
  shame: [{ pattern: /\b(ashamed|embarrass|humiliat|stupid|worthless)\b/gi, weight: 0.7 }],
  joy: [{ pattern: /\b(happy|joy|grateful|delighted|excited)\b/gi, weight: 0.5 }],
  love: [{ pattern: /\b(love|adore|cherish|connected)\b/gi, weight: 0.5 }],
  contempt: [{ pattern: /\b(disgust|pathetic|ridiculous|contempt)\b/gi, weight: 0.7 }],
  hope: [{ pattern: /\b(hope|hopeful|maybe.*will|could.*work)\b/gi, weight: 0.4 }],
  numbness: [{ pattern: /\b(numb|empty|nothing|don'?t feel)\b/gi, weight: 0.6 }],
  anxiety: [{ pattern: /\b(anxious|panic|spiral|overwhelm)\b/gi, weight: 0.7 }],
};

export const DISTORTION_LEX: Record<string, LexiconHit[]> = {
  "distortion.all_or_nothing": [
    { pattern: /\balways\b/gi, weight: 0.4 },
    { pattern: /\bnever\b/gi, weight: 0.4 },
    { pattern: /\beveryone\b/gi, weight: 0.4 },
  ],
  "distortion.catastrophizing": [
    { pattern: /\bruined\b/gi, weight: 0.7 },
    { pattern: /\bdisaster\b/gi, weight: 0.7 },
    { pattern: /\bworst\b/gi, weight: 0.5 },
    { pattern: /\bend of\b/gi, weight: 0.5 },
  ],
  "distortion.mind_reading": [
    { pattern: /\bthey think\b/gi, weight: 0.6 },
    { pattern: /\b(he|she) knows\b/gi, weight: 0.6 },
    { pattern: /\b(he|she|they) (don'?t|doesn'?t) (care|love)\b/gi, weight: 0.7 },
  ],
  "distortion.personalization": [
    { pattern: /\bmy fault\b/gi, weight: 0.7 },
    { pattern: /\bbecause of me\b/gi, weight: 0.7 },
  ],
  "distortion.shoulding": [
    { pattern: /\bshould have\b/gi, weight: 0.6 },
    { pattern: /\bmust\b/gi, weight: 0.4 },
    { pattern: /\bhave to\b/gi, weight: 0.4 },
  ],
  "distortion.labeling": [
    { pattern: /\bI'?m (a |such a )?(failure|loser|idiot|bad)\b/gi, weight: 0.8 },
  ],
  "distortion.overgeneralization": [
    { pattern: /\balways happens to me\b/gi, weight: 0.8 },
    { pattern: /\bevery time\b/gi, weight: 0.5 },
  ],
};
