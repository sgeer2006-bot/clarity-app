// Shared types for the Pattern Engine v1 (parallel system).
// The "entry" unit of analysis is a single reflection_answers row.

export type MarkerKind =
  | "linguistic"
  | "emotional"
  | "communication"
  | "behavioral"
  | "identity";

export type TagCategory = MarkerKind | "relational";

export interface EvidenceSnippet {
  quote: string;
  offset: number;
}

export interface Marker {
  id?: string;
  answerId: string;
  sessionId: string;
  kind: MarkerKind;
  subtype: string;
  intensity: number; // 0..1
  valence?: number; // -1..1 (emotional only)
  certainty?: number; // 0..1 (linguistic only)
  evidence: EvidenceSnippet[];
}

export interface PatternTag {
  id?: string;
  answerId: string;
  sessionId: string;
  tagKey: string;
  tagLabel: string;
  category: TagCategory;
  intensity: number;
  confidence: number;
  clusterId?: string | null;
  evidence: EvidenceSnippet[];
}

export interface EmotionalLoop {
  id: string;
  label: string;
  stages: { emotion: string; trigger?: string }[];
  frequency?: number;
  lastSeen?: string;
}

export interface PatternFrequency {
  tagKey: string;
  windowStart: string;
  windowEnd: string;
  count: number;
  weightedScore: number;
  trend: "rising" | "falling" | "stable" | "new";
}

export interface SnapshotSections {
  primaryPattern: { id: string; label: string; summary: string };
  secondaryPatterns: { id: string; label: string; summary: string }[];
  emotionalLoop?: EmotionalLoop;
  communicationStyle: { label: string; notes: string };
  behavioralTendencies: { label: string; notes: string }[];
  meaning: string;
  why: string;
  howItShowsUp: string;
  whatAINotices: string[];
  pathsForward: string[];
}

export interface SnapshotAnalysis {
  id: string;
  answerId: string;
  sessionId: string;
  createdAt: string;
  primaryPatternId: string;
  secondaryPatternIds: string[];
  loopId?: string | null;
  communicationStyle?: string | null;
  behavioralTendencies: string[];
  sections: SnapshotSections;
  narrativeMd?: string | null;
  status: "complete" | "markers_only" | "too_brief" | "safety_blocked";
  model?: string | null;
}
