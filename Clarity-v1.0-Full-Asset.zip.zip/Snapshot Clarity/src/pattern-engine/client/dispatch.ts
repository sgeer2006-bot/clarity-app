// Phase 2 Pattern Engine — thin client dispatch.
// Fire-and-forget: never throws, never blocks, never returns anything the caller needs to await.
import { supabase } from "@/integrations/supabase/client";

export function firePatternEnginePipeline(answerId: string | null | undefined) {
  if (!answerId) return;
  try {
    void supabase.functions
      .invoke("pe-on-answer-saved", { body: { answerId } })
      .catch(() => {});
  } catch {
    // swallow — Phase 2 must never affect the save flow
  }
}
