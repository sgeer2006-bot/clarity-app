import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

async function getUserId(): Promise<string | null> {
  const { data } = await supabase.auth.getSession();
  return data?.session?.user?.id ?? null;
}

export interface FrequencyRow {
  pattern_type: string;
  pattern_label: string;
  weighted_score: number;
  raw_count: number;
  last_seen_at: string | null;
}

export interface IdentityRow {
  narrative_md: string | null;
  version: number | null;
  last_updated_at: string | null;
  strengths: any;
  vulnerabilities: any;
  blind_spots: any;
  attachment_signals: any;
  recurring_triggers: any;
  conflict_role_baseline: any;
  communication_baseline: any;
  emotional_baseline: any;
}

export interface MacroPatternRow {
  id: string;
  pattern_type: string;
  pattern_label: string;
  confidence: number;
  source_answer_ids: string[];
  payload: any;
  created_at: string;
}

export interface TimelineRow {
  id: string;
  event_date: string;
  event_type: string;
  short_label: string;
  summary: string;
  detail: any;
  linked_pattern_ids: string[];
  created_at: string;
}

export interface HeatmapCellRow {
  cell_date: string;
  pattern_count: number;
  intensity_score: number;
  dominant_pattern_type: string | null;
}

export interface ClusterRow {
  id: string;
  cluster_label: string;
  cluster_summary: string;
  cohesion_score: number;
  member_pattern_ids: string[];
  last_updated_at: string;
}

export interface IdentityHistoryRow {
  id: string;
  version: number;
  narrative_md: string | null;
  snapshot: any;
  created_at: string;
}

export function useFrequency() {
  return useQuery({
    queryKey: ["pe_macro_frequency"],
    queryFn: async (): Promise<FrequencyRow[]> => {
      const uid = await getUserId();
      if (!uid) return [];
      const { data, error } = await supabase
        .from("pe_macro_frequency")
        .select("pattern_type, pattern_label, weighted_score, raw_count, last_seen_at")
        .eq("user_id", uid)
        .order("weighted_score", { ascending: false });
      if (error) throw error;
      return (data ?? []) as FrequencyRow[];
    },
  });
}

export function useIdentity() {
  return useQuery({
    queryKey: ["pe_identity_profile"],
    queryFn: async (): Promise<IdentityRow | null> => {
      const uid = await getUserId();
      if (!uid) return null;
      const { data, error } = await supabase
        .from("pe_identity_profile")
        .select("*")
        .eq("user_id", uid)
        .maybeSingle();
      if (error) throw error;
      return (data as IdentityRow) ?? null;
    },
  });
}

export function useMacroPatterns() {
  return useQuery({
    queryKey: ["pe_macro_patterns"],
    queryFn: async (): Promise<MacroPatternRow[]> => {
      const uid = await getUserId();
      if (!uid) return [];
      const { data, error } = await supabase
        .from("pe_macro_patterns")
        .select("*")
        .eq("user_id", uid)
        .order("created_at", { ascending: false })
        .limit(80);
      if (error) throw error;
      return (data ?? []) as MacroPatternRow[];
    },
  });
}

export function useTimeline() {
  return useQuery({
    queryKey: ["pe_timeline_events"],
    queryFn: async (): Promise<TimelineRow[]> => {
      const uid = await getUserId();
      if (!uid) return [];
      const { data, error } = await supabase
        .from("pe_timeline_events")
        .select("*")
        .eq("user_id", uid)
        .order("event_date", { ascending: false })
        .limit(120);
      if (error) throw error;
      return (data ?? []) as TimelineRow[];
    },
  });
}

export function useHeatmap() {
  return useQuery({
    queryKey: ["pe_heatmap_cells"],
    queryFn: async (): Promise<HeatmapCellRow[]> => {
      const uid = await getUserId();
      if (!uid) return [];
      const { data, error } = await supabase
        .from("pe_heatmap_cells")
        .select("cell_date, pattern_count, intensity_score, dominant_pattern_type")
        .eq("user_id", uid)
        .order("cell_date", { ascending: false })
        .limit(120);
      if (error) throw error;
      return (data ?? []) as HeatmapCellRow[];
    },
  });
}

export function useClusters() {
  return useQuery({
    queryKey: ["pe_pattern_clusters"],
    queryFn: async (): Promise<ClusterRow[]> => {
      const uid = await getUserId();
      if (!uid) return [];
      const { data, error } = await supabase
        .from("pe_pattern_clusters")
        .select("*")
        .eq("user_id", uid)
        .order("cohesion_score", { ascending: false })
        .limit(40);
      if (error) throw error;
      return (data ?? []) as ClusterRow[];
    },
  });
}

export function useIdentityHistory() {
  return useQuery({
    queryKey: ["pe_identity_profile_history"],
    queryFn: async (): Promise<IdentityHistoryRow[]> => {
      const uid = await getUserId();
      if (!uid) return [];
      const { data, error } = await supabase
        .from("pe_identity_profile_history")
        .select("id, version, narrative_md, snapshot, created_at")
        .eq("user_id", uid)
        .order("version", { ascending: false })
        .limit(20);
      if (error) throw error;
      return (data ?? []) as IdentityHistoryRow[];
    },
  });
}
