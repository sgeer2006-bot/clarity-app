import { useEffect, useState } from "react";
import { listFolders, getFolder, type Folder } from "@/lib/folders/store";

export function useFolders(): Folder[] {
  const [folders, setFolders] = useState<Folder[]>(() => listFolders());
  useEffect(() => {
    const update = () => setFolders(listFolders());
    window.addEventListener("clarity:folders", update);
    window.addEventListener("storage", update);
    return () => {
      window.removeEventListener("clarity:folders", update);
      window.removeEventListener("storage", update);
    };
  }, []);
  return folders;
}

export function useFolder(id: string | undefined): Folder | undefined {
  const [folder, setFolder] = useState<Folder | undefined>(() =>
    id ? getFolder(id) : undefined,
  );
  useEffect(() => {
    const update = () => setFolder(id ? getFolder(id) : undefined);
    update();
    window.addEventListener("clarity:folders", update);
    window.addEventListener("storage", update);
    return () => {
      window.removeEventListener("clarity:folders", update);
      window.removeEventListener("storage", update);
    };
  }, [id]);
  return folder;
}
