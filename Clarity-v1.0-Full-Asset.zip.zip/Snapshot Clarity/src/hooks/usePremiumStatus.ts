import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getStripeEnvironment } from "@/lib/stripe/loadStripe";
import { setClarityPlusUser } from "@/premium/clarityPlus/usePremium";

const LS_KEY = "clarity_plus.premium";

/**
 * Premium status for Clarity+. Reads from the project's `subscriptions`
 * table when the user is signed in; falls back to the local flag
 * already used by the existing Clarity+ funnel for unauthenticated
 * sessions. Refresh after a successful checkout to flip the UI.
 */
export function usePremiumStatus() {
  const [isPremium, setIsPremium] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    try {
      return localStorage.getItem(LS_KEY) === "1";
    } catch {
      return false;
    }
  });

  const refresh = useCallback(async () => {
    let premium = false;
    try {
      const { data: userData } = await supabase.auth.getUser();
      const userId = userData?.user?.id;
      if (userId) {
        const { data } = await supabase
          .from("subscriptions")
          .select("status,current_period_end,cancel_at_period_end")
          .eq("user_id", userId)
          .eq("environment", getStripeEnvironment())
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (data) {
          const status = data.status as string;
          const end = data.current_period_end ? new Date(data.current_period_end).getTime() : null;
          const now = Date.now();
          if (status === "active" || status === "trialing" || status === "past_due") {
            premium = !end || end > now;
          } else if (status === "canceled" && end && end > now) {
            premium = true;
          }
        }
      } else {
        premium = localStorage.getItem(LS_KEY) === "1";
      }
    } catch (err) {
      console.warn("[Clarity+] usePremiumStatus.refresh failed:", err);
      try {
        premium = localStorage.getItem(LS_KEY) === "1";
      } catch {
        /* ignore */
      }
    }

    setIsPremium(premium);
    // Mirror to the existing local flag so UpsellCard / PremiumGatePreview update too.
    setClarityPlusUser(premium);
    return premium;
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  return { isPremium, refresh };
}
