import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { SnapshotSections } from "@/pattern-engine/types";

export interface PESnapshotRow {
  id: string;
  answer_id: string;
  session_id: string;
  user_id: string;
  primary_pattern_id: string;
  secondary_pattern_ids: string[];
  loop_id: string | null;
  communication_style: string | null;
  behavioral_tendencies: string[];
  sections: SnapshotSections;
  narrative_md: string | null;
  status: string;
  model: string | null;
  created_at: string;
}

export function usePatternSnapshot(answerId: string | undefined) {
  const [data, setData] = useState<PESnapshotRow | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const analyze = useCallback(async (force = false) => {
    if (!answerId) return;
    setLoading(true);
    setError(null);
    try {
      const { data: res, error: fnErr } = await supabase.functions.invoke("pe-analyze-answer", {
        body: { answerId, force },
      });
      if (fnErr) throw fnErr;
      if (res?.error) throw new Error(res.error);
      setData(res.snapshot as unknown as PESnapshotRow);
    } catch (e: any) {
      setError(e?.message ?? "Failed to analyze");
    } finally {
      setLoading(false);
    }
  }, [answerId]);

  // Initial load: fetch existing or trigger analysis
  useEffect(() => {
    if (!answerId) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data: existing } = await supabase
        .from("pe_snapshots")
        .select("*")
        .eq("answer_id", answerId)
        .maybeSingle();
      if (cancelled) return;
      if (existing) {
        setData(existing as unknown as PESnapshotRow);
        setLoading(false);
      } else {
        await analyze(false);
      }
    })();
    return () => { cancelled = true; };
  }, [answerId, analyze]);

  return { data, loading, error, analyze };
}
