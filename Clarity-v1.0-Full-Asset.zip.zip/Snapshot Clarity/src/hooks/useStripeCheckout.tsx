import { useCallback, useState } from "react";
import { ClarityPlusEmbeddedCheckout } from "@/premium/clarityPlus/ClarityPlusEmbeddedCheckout";
import { isStripeConfigured } from "@/lib/stripe/loadStripe";

export type ClarityPlan =
  | "clarity_basic_monthly"
  | "clarity_basic_yearly"
  | "clarity_plus_monthly"
  | "clarity_plus_yearly_v2";

// Backwards-compat aliases
export type ClarityPlusPlan = "monthly" | "yearly";

const LEGACY_TO_PRICE: Record<ClarityPlusPlan, ClarityPlan> = {
  monthly: "clarity_plus_monthly",
  yearly: "clarity_plus_yearly_v2",
};

/**
 * Hook for opening Stripe Embedded Checkout for any Clarity plan
 * (Clarity Basic monthly/yearly, Clarity+ monthly/yearly).
 */
export function useStripeCheckout() {
  const [isOpen, setIsOpen] = useState(false);
  const [priceId, setPriceId] = useState<ClarityPlan | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startCheckout = useCallback((p: ClarityPlan) => {
    setError(null);
    if (!isStripeConfigured()) {
      const msg = "Payments aren't configured yet. Please try again later.";
      console.warn("[Clarity] " + msg);
      setError(msg);
      return;
    }
    setPriceId(p);
    setIsOpen(true);
  }, []);

  const startMonthlyCheckout = useCallback(() => {
    startCheckout(LEGACY_TO_PRICE.monthly);
  }, [startCheckout]);

  const startYearlyCheckout = useCallback(() => {
    startCheckout(LEGACY_TO_PRICE.yearly);
  }, [startCheckout]);

  const closeCheckout = useCallback(() => {
    setIsOpen(false);
    setPriceId(null);
  }, []);

  const checkoutElement =
    isOpen && priceId ? <ClarityPlusEmbeddedCheckout priceId={priceId} /> : null;

  return {
    startCheckout,
    startMonthlyCheckout,
    startYearlyCheckout,
    closeCheckout,
    isOpen,
    priceId,
    plan: priceId,
    error,
    checkoutElement,
  };
}
