/**
 * FTUE controller — single source of truth for what (if anything) should
 * appear on top of the app's normal surface.
 *
 * Decision order (Part 3 — Safety Net):
 *   1. Global pass flag must be on, ftue_enabled must be true, user signed in.
 *   2. Never fire while another modal/paywall path is already active (caller
 *      may pass `suppress` to gate this).
 *   3. FTUE A — exactly once per account.
 *   4. Guided Tour — exactly once, immediately after FTUE A.
 *   5. FTUE B — only on a fresh sign-in event, once per session, with 24h
 *      cooldown.
 *
 * Returns the next surface to render, or "none".
 */

import { useEffect, useState } from "react";
import { isGlobalPassEnabled } from "@/lib/flags/globalPass";
import {
  fetchProfile,
  getProfileSync,
  subscribeProfile,
  type UserProfileFlags,
} from "@/lib/userProfile/store";
import { useAuthSession } from "@/hooks/useAuthSession";
import { supabase } from "@/integrations/supabase/client";

export type FTUESurface = "none" | "ftue_a" | "tour" | "ftue_b";

const SESSION_KEY = "clarity.ftueB.shownThisSession";
const SIGN_IN_KEY = "clarity.ftueB.armed";
const COOLDOWN_MS = 24 * 60 * 60 * 1000;

/** Arm FTUE B — call from sign-in success. */
export function armFTUEB() {
  try {
    sessionStorage.removeItem(SESSION_KEY);
    sessionStorage.setItem(SIGN_IN_KEY, "1");
  } catch {
    /* ignore */
  }
}

/** Mark FTUE B shown this session (so it never re-fires until next sign-in). */
export function markFTUEBShown() {
  try {
    sessionStorage.setItem(SESSION_KEY, "1");
    sessionStorage.removeItem(SIGN_IN_KEY);
  } catch {
    /* ignore */
  }
}

function ftueBEligible(profile: UserProfileFlags): boolean {
  if (!profile.ftue_a_completed) return false;
  try {
    if (sessionStorage.getItem(SESSION_KEY) === "1") return false;
    if (sessionStorage.getItem(SIGN_IN_KEY) !== "1") return false;
  } catch {
    return false;
  }
  if (profile.ftue_b_last_shown_at) {
    const last = new Date(profile.ftue_b_last_shown_at).getTime();
    if (Number.isFinite(last) && Date.now() - last < COOLDOWN_MS) return false;
  }
  return true;
}

export interface FTUEDecision {
  surface: FTUESurface;
  ready: boolean;
  profile: UserProfileFlags;
}

export function useFTUEController(opts?: { suppress?: boolean }): FTUEDecision {
  const { isAuthed, loading } = useAuthSession();
  const [profile, setProfile] = useState<UserProfileFlags>(getProfileSync);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (loading) return;
    if (!isAuthed) {
      setReady(true);
      return;
    }
    let active = true;
    fetchProfile().then((p) => {
      if (!active) return;
      setProfile(p);
      setReady(true);
    });
    const unsub = subscribeProfile(() => setProfile(getProfileSync()));
    return () => {
      active = false;
      unsub();
    };
  }, [isAuthed, loading]);

  // Auth state changes: arm FTUE B on a fresh SIGNED_IN event.
  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_IN") armFTUEB();
      if (event === "SIGNED_OUT") {
        try {
          sessionStorage.removeItem(SESSION_KEY);
          sessionStorage.removeItem(SIGN_IN_KEY);
        } catch {
          /* ignore */
        }
      }
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!isGlobalPassEnabled()) return { surface: "none", ready: true, profile };
  if (!ready || loading) return { surface: "none", ready: false, profile };
  if (!isAuthed) return { surface: "none", ready: true, profile };
  if (!profile.ftue_enabled) return { surface: "none", ready: true, profile };
  if (opts?.suppress) return { surface: "none", ready: true, profile };

  if (!profile.ftue_a_completed) return { surface: "ftue_a", ready: true, profile };
  if (!profile.tour_completed) return { surface: "tour", ready: true, profile };
  if (ftueBEligible(profile)) return { surface: "ftue_b", ready: true, profile };
  return { surface: "none", ready: true, profile };
}
