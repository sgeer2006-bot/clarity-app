/**
 * FTUE B — welcome-back surface (clarity_global_pass_v1, Part 2).
 *
 * Shown once per fresh sign-in (armed by the controller on SIGNED_IN),
 * with a 24h cooldown enforced by the controller. Single screen, one
 * primary action, one quiet dismiss. No teaching, no upsell — just a soft
 * re-entry.
 */

import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { getProfileSync } from "@/lib/userProfile/store";
import { getSeed } from "../ftueA/copy";
import "./ftueB.css";

export interface FTUEBFlowProps {
  onComplete: () => void;
}

const TIME_GREETINGS = [
  { until: 5, text: "It's late. Glad you're here." },
  { until: 12, text: "Good morning." },
  { until: 17, text: "Welcome back." },
  { until: 21, text: "Good evening." },
  { until: 24, text: "Welcome back." },
];

function greetingForNow(): string {
  const h = new Date().getHours();
  return TIME_GREETINGS.find((g) => h < g.until)?.text ?? "Welcome back.";
}

export function FTUEBFlow({ onComplete }: FTUEBFlowProps) {
  const headingRef = useRef<HTMLHeadingElement | null>(null);
  const navigate = useNavigate();
  const profile = getProfileSync();
  const seed = getSeed(profile.identity_seed);

  useEffect(() => {
    headingRef.current?.focus();
  }, []);

  const continueOn = () => {
    onComplete();
  };

  const reflectNow = () => {
    onComplete();
    navigate("/reflect");
  };

  return (
    <div
      className="ftueB-root"
      role="dialog"
      aria-modal="true"
      aria-label="Welcome back to Clarity"
    >
      <div aria-hidden className="ftueB-orb ftueB-orb--a" />
      <div aria-hidden className="ftueB-orb ftueB-orb--b" />

      <button type="button" className="ftueB-skip" onClick={continueOn}>
        Not now
      </button>

      <main className="ftueB-card ftueB-fade">
        <p className="ftueB-eyebrow">{greetingForNow()}</p>
        <h1 ref={headingRef} tabIndex={-1} className="ftueB-title">
          {seed.mirror}
        </h1>
        <p className="ftueB-body">
          Take a breath. When you're ready, you can drop in what's on your
          mind — or just look around.
        </p>

        <div className="ftueB-actions">
          <button
            type="button"
            className="ftueB-btn"
            onClick={continueOn}
          >
            Just look around
          </button>
          <button
            type="button"
            className="ftueB-btn ftueB-btn--primary"
            onClick={reflectNow}
          >
            Reflect on something
          </button>
        </div>
      </main>
    </div>
  );
}
