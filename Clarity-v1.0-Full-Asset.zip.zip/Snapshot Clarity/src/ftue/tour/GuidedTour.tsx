/**
 * Guided Tour (clarity_global_pass_v1, Part 4).
 *
 * Shown exactly once, immediately after FTUE A. A short, calm,
 * coachmark-style introduction to the four spaces a user will use most.
 * Nav-agnostic on purpose: Phase 5 will rebuild the bottom nav and the tour
 * will then point at real tab targets. Until then, we present the same ideas
 * as soft "here's what lives where" cards with a single primary action.
 *
 * Persists `tour_completed` via the shared user_profiles store. Skipping
 * marks completion too, so the tour never re-fires.
 */

import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { patchProfile } from "@/lib/userProfile/store";
import "./tour.css";

interface TourStep {
  id: string;
  eyebrow: string;
  title: string;
  body: string;
  cta: string;
  /** Optional route to open when the user taps the primary CTA on the final step. */
  route?: string;
}

const STEPS: TourStep[] = [
  {
    id: "home",
    eyebrow: "Home",
    title: "A calm place to land.",
    body:
      "Your home is just that — a soft beginning. Nothing demands attention. Start here whenever you open Clarity.",
    cta: "Next",
  },
  {
    id: "reflect",
    eyebrow: "Reflect",
    title: "When something's on your mind.",
    body:
      "Drop in a thought, a feeling, or a decision. Clarity will sit with you and help it take shape — at your pace.",
    cta: "Next",
  },
  {
    id: "patterns",
    eyebrow: "Patterns",
    title: "Gentle threads, over time.",
    body:
      "As you return, Clarity quietly notices the threads that keep coming back. You'll see them when you're ready — never before.",
    cta: "Next",
  },
  {
    id: "you",
    eyebrow: "You",
    title: "Everything stays yours.",
    body:
      "Settings, your account, and Clarity+ live here. Always optional. Always within reach.",
    cta: "Open Clarity",
  },
];

export interface GuidedTourProps {
  onComplete: () => void;
}

export function GuidedTour({ onComplete }: GuidedTourProps) {
  const [idx, setIdx] = useState(0);
  const headingRef = useRef<HTMLHeadingElement | null>(null);
  const navigate = useNavigate();
  const step = STEPS[idx];
  const isLast = idx === STEPS.length - 1;

  useEffect(() => {
    headingRef.current?.focus();
  }, [idx]);

  const finish = async () => {
    await patchProfile({
      tour_completed: true,
      tour_completed_at: new Date().toISOString(),
    });
    onComplete();
    if (step.route) navigate(step.route);
  };

  const next = () => {
    if (isLast) {
      void finish();
    } else {
      setIdx((i) => i + 1);
    }
  };

  return (
    <div
      className="tour-root"
      role="dialog"
      aria-modal="true"
      aria-label="A short tour of Clarity"
    >
      <div aria-hidden className="tour-orb tour-orb--a" />
      <div aria-hidden className="tour-orb tour-orb--b" />

      <button
        type="button"
        className="tour-skip"
        onClick={() => void finish()}
      >
        Skip tour
      </button>

      <main className="tour-card tour-fade" key={step.id}>
        <p className="tour-eyebrow">{step.eyebrow}</p>
        <h1 ref={headingRef} tabIndex={-1} className="tour-title">
          {step.title}
        </h1>
        <p className="tour-body">{step.body}</p>

        <div className="tour-dots" aria-hidden>
          {STEPS.map((s, i) => (
            <span
              key={s.id}
              className={`tour-dot${i === idx ? " tour-dot--active" : ""}`}
            />
          ))}
        </div>

        <div className="tour-actions">
          <button
            type="button"
            className="tour-btn tour-btn--primary"
            onClick={next}
          >
            {step.cta}
          </button>
        </div>
      </main>
    </div>
  );
}
