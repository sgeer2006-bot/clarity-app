/**
 * FTUE A — Signup WOW (clarity_global_pass_v1, Part 1).
 *
 * 9-step warm welcome flow shown once per account, immediately after signup.
 * UI-only; no logic outside writing identity_seed + ftue_a_completed via the
 * shared user_profiles store.
 */

import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { patchProfile } from "@/lib/userProfile/store";
import { SEED_OPTIONS, getSeed } from "./copy";
import "./ftueA.css";

type StepId =
  | "seed"
  | "mirror"
  | "drift"
  | "continuation"
  | "patterns"
  | "curiosity"
  | "bloom"
  | "dopamine"
  | "plus_intro";

const STEP_ORDER: StepId[] = [
  "seed",
  "mirror",
  "drift",
  "continuation",
  "patterns",
  "curiosity",
  "bloom",
  "dopamine",
  "plus_intro",
];

export interface FTUEAFlowProps {
  onComplete: () => void;
}

export function FTUEAFlow({ onComplete }: FTUEAFlowProps) {
  const [stepIdx, setStepIdx] = useState(0);
  const [seedId, setSeedId] = useState<string | null>(null);
  const headingRef = useRef<HTMLHeadingElement | null>(null);
  const step = STEP_ORDER[stepIdx];
  const seed = getSeed(seedId);

  const next = () => setStepIdx((i) => Math.min(i + 1, STEP_ORDER.length - 1));

  // Auto-advance steps
  useEffect(() => {
    if (step === "drift") {
      const t = setTimeout(next, 7000);
      return () => clearTimeout(t);
    }
    if (step === "curiosity") {
      const t = setTimeout(next, 2200);
      return () => clearTimeout(t);
    }
    if (step === "bloom") {
      const t = setTimeout(next, 1600);
      return () => clearTimeout(t);
    }
  }, [step]);

  useEffect(() => {
    headingRef.current?.focus();
  }, [stepIdx]);

  const finish = async () => {
    await patchProfile({
      ftue_a_completed: true,
      ftue_a_completed_at: new Date().toISOString(),
    });
    onComplete();
  };

  const skip = async () => {
    // Skipping still marks A complete so it never re-shows.
    await patchProfile({
      ftue_a_completed: true,
      ftue_a_completed_at: new Date().toISOString(),
      ...(seedId ? { identity_seed: seedId, identity_seed_at: new Date().toISOString() } : {}),
    });
    onComplete();
  };

  const dismissPlusIntro = async () => {
    await patchProfile({ clarity_plus_intro_dismissed: true });
    finish();
  };

  return (
    <div
      className="ftueA-root"
      role="dialog"
      aria-modal="true"
      aria-label="Welcome to Clarity"
    >
      <div aria-hidden className="ftueA-orb ftueA-orb--a" />
      <div aria-hidden className="ftueA-orb ftueA-orb--b" />

      <button type="button" className="ftueA-skip" onClick={skip}>
        Skip
      </button>

      <main className="ftueA-card ftueA-fade" key={step}>
        {step === "seed" && (
          <>
            <h1 ref={headingRef} tabIndex={-1} className="ftueA-h1">
              What do you want clarity about, right now?
            </h1>
            <p className="ftueA-lead">Pick one. You can change this anytime.</p>
            <div className="ftueA-chips" role="group" aria-label="What's on your mind">
              {SEED_OPTIONS.map((opt) => {
                const selected = seedId === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    className="ftueA-chip"
                    aria-pressed={selected}
                    onClick={() => setSeedId(opt.id)}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
            <div className="ftueA-actions">
              <button
                type="button"
                className="ftueA-btn ftueA-btn--primary"
                disabled={!seedId}
                onClick={async () => {
                  if (!seedId) return;
                  await patchProfile({
                    identity_seed: seedId,
                    identity_seed_at: new Date().toISOString(),
                  });
                  next();
                }}
              >
                Continue
              </button>
            </div>
          </>
        )}

        {step === "mirror" && (
          <>
            <h1 ref={headingRef} tabIndex={-1} className="ftueA-h1 ftueA-h1--center">
              {seed.mirror}
            </h1>
            <DelayedReveal delay={1500}>
              <div className="ftueA-actions ftueA-actions--center">
                <button type="button" className="ftueA-btn ftueA-btn--primary" onClick={next}>
                  Continue
                </button>
              </div>
            </DelayedReveal>
          </>
        )}

        {step === "drift" && (
          <>
            <div className="ftueA-breath-wrap" aria-hidden>
              <div className="ftueA-breath" />
            </div>
            <h2 ref={headingRef} tabIndex={-1} className="ftueA-h2 ftueA-h2--center">
              Take a breath. There's no rush here.
            </h2>
          </>
        )}

        {step === "continuation" && (
          <>
            <div className="ftueA-dots" aria-hidden>
              <span className="ftueA-dot" />
              <span className="ftueA-dotline" />
              <span className="ftueA-dot" />
            </div>
            <h2 ref={headingRef} tabIndex={-1} className="ftueA-h2 ftueA-h2--center">
              Clarity remembers the threads you start, so you can come back to them.
            </h2>
            <div className="ftueA-actions ftueA-actions--center">
              <button type="button" className="ftueA-btn ftueA-btn--primary" onClick={next}>
                Got it
              </button>
            </div>
          </>
        )}

        {step === "patterns" && (
          <>
            <h2 ref={headingRef} tabIndex={-1} className="ftueA-h2">
              Over time, Clarity gently shows you patterns like these.
            </h2>
            <ul className="ftueA-examples">
              <li>You think clearer in the mornings.</li>
              <li>You go quiet when something feels uncertain.</li>
              <li>The same question keeps coming back, in different shapes.</li>
            </ul>
            <div className="ftueA-actions ftueA-actions--center">
              <button type="button" className="ftueA-btn ftueA-btn--primary" onClick={next}>
                Continue
              </button>
            </div>
          </>
        )}

        {step === "curiosity" && (
          <h2 ref={headingRef} tabIndex={-1} className="ftueA-h2 ftueA-h2--center ftueA-quiet">
            There's one thing most people notice on day three. We'll show you when you're ready.
          </h2>
        )}

        {step === "bloom" && (
          <>
            <div className="ftueA-bloom" aria-hidden />
            <h2 ref={headingRef} tabIndex={-1} className="ftueA-h2 ftueA-h2--center">
              You're set up.
            </h2>
          </>
        )}

        {step === "dopamine" && (
          <>
            <h1 ref={headingRef} tabIndex={-1} className="ftueA-h1 ftueA-h1--center">
              {seed.firstWin}
            </h1>
            <div className="ftueA-actions ftueA-actions--center">
              <button type="button" className="ftueA-btn ftueA-btn--primary" onClick={next}>
                Open Clarity
              </button>
            </div>
          </>
        )}

        {step === "plus_intro" && (
          <>
            <h2 ref={headingRef} tabIndex={-1} className="ftueA-h2 ftueA-h2--center">
              Clarity+ adds deeper patterns and gentler nudges as you grow.
            </h2>
            <p className="ftueA-lead ftueA-lead--center">
              The basics are always free. Take your time.
            </p>
            <div className="ftueA-actions ftueA-actions--row">
              <button type="button" className="ftueA-btn" onClick={dismissPlusIntro}>
                Maybe later
              </button>
              <Link
                to="/clarity-plus"
                className="ftueA-btn ftueA-btn--primary"
                onClick={() => finish()}
              >
                See Clarity+
              </Link>
            </div>
          </>
        )}
      </main>
    </div>
  );
}

function DelayedReveal({ delay, children }: { delay: number; children: React.ReactNode }) {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setShow(true), delay);
    return () => clearTimeout(t);
  }, [delay]);
  if (!show) return null;
  return <div className="ftueA-fade">{children}</div>;
}
