/**
 * Copy + identity-seed map for FTUE A. Toddler-readable, warm, first-person.
 */

export interface SeedOption {
  id: string;
  label: string;
  /** First-win line shown on the Dopamine Clarity Moment screen. */
  firstWin: string;
  /** One-sentence mirror used on the Emotional Resonance screen. */
  mirror: string;
}

export const SEED_OPTIONS: SeedOption[] = [
  {
    id: "thoughts",
    label: "My thoughts",
    mirror: "Okay. We'll start with what's on your mind.",
    firstWin: "Whenever a thought is loud, drop it in. Clarity will help it settle.",
  },
  {
    id: "feelings",
    label: "My feelings",
    mirror: "Okay. We'll start with what you're feeling.",
    firstWin: "Whenever a feeling shows up, name it here. Clarity will sit with it with you.",
  },
  {
    id: "decision",
    label: "A decision",
    mirror: "Okay. We'll start with the choice in front of you.",
    firstWin: "Whenever you're ready, drop the decision in. Clarity will help you see it more clearly.",
  },
  {
    id: "pattern",
    label: "A pattern I keep noticing",
    mirror: "Okay. We'll start with what keeps coming back.",
    firstWin: "Bring the pattern in when you see it. Clarity will gently trace it with you.",
  },
  {
    id: "unnamed",
    label: "Something I can't name yet",
    mirror: "Okay. We'll start with what you're noticing.",
    firstWin: "You don't have to name it yet. Just bring it in. Clarity will help it take shape.",
  },
  {
    id: "exploring",
    label: "Just exploring",
    mirror: "Okay. We'll go gently.",
    firstWin: "No agenda. Open Clarity whenever you want, and start anywhere.",
  },
];

export function getSeed(id: string | null): SeedOption {
  return SEED_OPTIONS.find((s) => s.id === id) ?? SEED_OPTIONS[5];
}
