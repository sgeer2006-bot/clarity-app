/**
 * FTUE host — mounts the appropriate FTUE surface (A, Tour, B) on top of
 * the app shell. Single mount point so we never stack FTUE surfaces.
 *
 * Phase 1: FTUE A wired.
 * Phase 2: Guided Tour wired.
 * Phase 5: FTUE B welcome-back wired.
 */

import { useFTUEController, markFTUEBShown } from "./useFTUEController";
import { FTUEAFlow } from "./ftueA/FTUEAFlow";
import { GuidedTour } from "./tour/GuidedTour";
import { FTUEBFlow } from "./ftueB/FTUEBFlow";
import { patchProfile } from "@/lib/userProfile/store";

export function FTUEHost() {
  const { surface } = useFTUEController();

  if (surface === "ftue_a") {
    return <FTUEAFlow onComplete={() => { /* controller re-evaluates via profile event */ }} />;
  }
  if (surface === "tour") {
    return <GuidedTour onComplete={() => { /* controller re-evaluates via profile event */ }} />;
  }
  if (surface === "ftue_b") {
    return (
      <FTUEBFlow
        onComplete={() => {
          patchProfile({ ftue_b_last_shown_at: new Date().toISOString() });
          markFTUEBShown();
        }}
      />
    );
  }
  return null;
}
