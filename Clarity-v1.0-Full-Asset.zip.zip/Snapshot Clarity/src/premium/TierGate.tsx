/**
 * Phase 3 — Tier-aware gate UI.
 *
 * Shows warm scarcity messaging + an upsell CTA when a user lacks access
 * to a feature, has run out of credits, or has hit the Fast Clarity cap.
 * Logic-only wrapper; copy is intentionally minimal and reused.
 */
import { useState, type ReactNode } from "react";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ClarityPlusPaywall, type PlanKey } from "@/premium/clarityPlus/ClarityPlusPaywall";
import { useTier, type Tier } from "@/premium/tier";
import {
  useUsage,
  canPerform,
  fastClarityRemainingToday,
  ACTION_COST,
  FREE_WEEKLY_CREDITS,
} from "@/premium/limits";

type Action = keyof typeof ACTION_COST | "fast_clarity";

interface Props {
  /** Lowest tier required to access this feature. */
  requires?: Tier;
  /** Optional usage action this view consumes. */
  action?: Action;
  children: ReactNode;
  /** Fallback to render in place of children when blocked. */
  fallback?: ReactNode;
}

/**
 * Renders children when the user has access. Otherwise renders an upsell
 * panel with the appropriate CTA (Basic vs Clarity+) and opens the
 * existing Clarity+ paywall sheet.
 */
export function TierGate({ requires = "free", action, children, fallback }: Props) {
  const { tier } = useTier();
  const usage = useUsage();
  const [paywallOpen, setPaywallOpen] = useState(false);
  const [defaultPlan, setDefaultPlan] = useState<PlanKey>("yearly");

  // Tier check
  const hasTier = (() => {
    const rank: Record<Tier, number> = { free: 0, basic: 1, premium: 2 };
    return rank[tier] >= rank[requires];
  })();

  // Limit check (only matters when tier is sufficient)
  const withinLimit = !action || canPerform(action, tier);

  if (hasTier && withinLimit) return <>{children}</>;

  // Determine which upsell to show
  const needsPremium = !hasTier && requires === "premium";
  const targetTier: Tier = needsPremium ? "premium" : tier === "free" ? "basic" : "premium";
  const ctaLabel = targetTier === "premium" ? "Unlock Clarity+" : "Unlock Clarity Basic";

  const reason = (() => {
    if (!hasTier) {
      return targetTier === "premium"
        ? "This is part of Clarity+."
        : "This is part of Clarity Basic.";
    }
    if (action === "fast_clarity" && tier === "basic") {
      const left = fastClarityRemainingToday("basic");
      return `You've used all ${3 - (left ?? 0)} Fast Clarity sessions for today.`;
    }
    if (tier === "free") {
      return `You've hit your weekly limit. Your clarity resets in ${usage.daysUntilReset} ${usage.daysUntilReset === 1 ? "day" : "days"}.`;
    }
    return "You've reached this week's limit.";
  })();

  const open = () => {
    setDefaultPlan(targetTier === "premium" ? "yearly" : "monthly");
    setPaywallOpen(true);
  };

  return (
    <div className="rounded-2xl border border-border/60 bg-card/40 p-5">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 inline-flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Sparkles className="h-4 w-4" aria-hidden />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-base font-medium text-foreground/90">{reason}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {targetTier === "premium"
              ? "Your deeper clarity starts here — unlimited reflections, deep insights, and more."
              : "Unlimited reflections, insights, tools, and history. The everyday rhythm of Clarity."}
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button onClick={open} size="sm" className="h-9 rounded-full px-4">
              {ctaLabel}
            </Button>
          </div>
        </div>
      </div>
      {fallback ? <div className="mt-4">{fallback}</div> : null}

      <ClarityPlusPaywall
        open={paywallOpen}
        onOpenChange={setPaywallOpen}
        defaultPlan={defaultPlan}
      />
    </div>
  );
}

/**
 * Compact scarcity banner for Free users — shows when usage is near or at
 * the limit. Returns null otherwise.
 */
export function CreditMeterBanner() {
  const { tier } = useTier();
  const usage = useUsage();
  const [paywallOpen, setPaywallOpen] = useState(false);

  if (tier !== "free") return null;
  if (usage.percentConsumed < 80) return null;

  const atLimit = usage.percentConsumed >= 100;
  const headline = atLimit
    ? "You've hit your weekly limit"
    : "You're close to your weekly limit";
  const sub = `Your clarity resets in ${usage.daysUntilReset} ${usage.daysUntilReset === 1 ? "day" : "days"}. ${usage.creditsRemaining}/${FREE_WEEKLY_CREDITS} credits left.`;

  return (
    <div className="rounded-xl border border-border/60 bg-card/40 px-4 py-3 text-sm">
      <div className="flex items-start gap-3">
        <Sparkles className="mt-0.5 h-4 w-4 text-primary" aria-hidden />
        <div className="min-w-0 flex-1">
          <p className="font-medium text-foreground/90">{headline}</p>
          <p className="mt-0.5 text-xs text-muted-foreground">{sub}</p>
        </div>
        <Button size="sm" variant="ghost" onClick={() => setPaywallOpen(true)} className="h-8 rounded-full text-xs">
          Unlock unlimited clarity
        </Button>
      </div>
      <ClarityPlusPaywall open={paywallOpen} onOpenChange={setPaywallOpen} defaultPlan="monthly" />
    </div>
  );
}
