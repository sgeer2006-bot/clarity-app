import { useEffect, useState } from "react";
import { FEATURE_MATRIX, type Feature, type TierId } from "./tiers";

const KEY = "clarity.subscription_token";

function readTier(): TierId {
  if (typeof window === "undefined") return "free";
  const raw = localStorage.getItem(KEY);
  if (!raw) return "free";
  try {
    // Token format reuse: assume base64 JSON { tier, exp }. If invalid → free.
    const parsed = JSON.parse(atob(raw.split(".")[0] ?? raw));
    if (parsed?.exp && parsed.exp < Date.now() / 1000) return "free";
    if (parsed?.tier === "basic" || parsed?.tier === "premium") return parsed.tier;
  } catch {
    /* ignore */
  }
  return "free";
}

export function usePremium() {
  const [tier, setTier] = useState<TierId>(readTier);

  useEffect(() => {
    const onStorage = () => setTier(readTier());
    window.addEventListener("storage", onStorage);
    window.addEventListener("clarity:subscription", onStorage as EventListener);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("clarity:subscription", onStorage as EventListener);
    };
  }, []);

  const has = (feature: Feature): boolean =>
    (FEATURE_MATRIX[feature] as readonly string[]).includes(tier);

  return { tier, has };
}
