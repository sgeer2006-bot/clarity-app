import type { ReactNode } from "react";
import { usePremium } from "./usePremium";
import type { Feature } from "./tiers";
import { UpsellInline } from "./UpsellInline";

interface Props {
  feature: Feature;
  children: ReactNode;
  fallback?: ReactNode;
}

export function PremiumGate({ feature, children, fallback }: Props) {
  const { has } = usePremium();
  if (has(feature)) return <>{children}</>;
  return <>{fallback ?? <UpsellInline feature={feature} />}</>;
}
