/**
 * Phase 3 — Free weekly credit bucket + Basic Fast Clarity daily cap.
 *
 * Local-only, additive. Does NOT touch backend, Stripe, identity model,
 * continuation engine, Fast Clarity logic, or insights logic. Just a
 * usage meter callers can consult before performing a gated action.
 */
import { useCallback, useEffect, useState } from "react";
import { currentTier, type Tier } from "./tier";

/** Weekly credits a Free user gets, by category. Calibrated to run out
 *  ~1–2 days before reset for typical usage. Adjust here only. */
export const FREE_WEEKLY_CREDITS = 25;

/** Per-action credit cost. Keep small numbers — bucket is shared. */
export const ACTION_COST: Record<string, number> = {
  reflection: 4, // Your Thoughts (full session)
  fast_clarity: 2,
  daily_insight: 1,
  tool_use: 2,
  share_basic: 1,
};

export const BASIC_FAST_CLARITY_DAILY_CAP = 3;

const STORAGE_KEY = "clarity.usage.v1";
const EVT = "clarity:usage-updated";
const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

interface UsageState {
  weekStart: number; // ms epoch — start of current 7-day window
  used: number; // credits consumed this week
  fastClarityDay: string; // YYYY-MM-DD
  fastClarityCount: number;
}

function todayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function fresh(): UsageState {
  return {
    weekStart: Date.now(),
    used: 0,
    fastClarityDay: todayKey(),
    fastClarityCount: 0,
  };
}

function load(): UsageState {
  if (typeof window === "undefined") return fresh();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return fresh();
    const parsed = JSON.parse(raw) as UsageState;
    if (typeof parsed.weekStart !== "number") return fresh();
    // Reset weekly bucket when window expires.
    if (Date.now() - parsed.weekStart >= WEEK_MS) {
      return { ...fresh(), fastClarityDay: parsed.fastClarityDay, fastClarityCount: parsed.fastClarityCount };
    }
    // Reset Fast Clarity cap if day changed.
    if (parsed.fastClarityDay !== todayKey()) {
      parsed.fastClarityDay = todayKey();
      parsed.fastClarityCount = 0;
    }
    return parsed;
  } catch {
    return fresh();
  }
}

function save(s: UsageState) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
    window.dispatchEvent(new CustomEvent(EVT));
  } catch {
    /* ignore */
  }
}

/* ----------------------------- Public API ----------------------------- */

export function getUsage(): UsageState {
  return load();
}

export function daysUntilReset(): number {
  const s = load();
  const ms = s.weekStart + WEEK_MS - Date.now();
  return Math.max(0, Math.ceil(ms / (24 * 60 * 60 * 1000)));
}

export function creditsRemaining(): number {
  return Math.max(0, FREE_WEEKLY_CREDITS - load().used);
}

export function percentConsumed(): number {
  return Math.min(100, Math.round((load().used / FREE_WEEKLY_CREDITS) * 100));
}

/** Can this action proceed for the given tier? */
export function canPerform(action: keyof typeof ACTION_COST | "fast_clarity", tier: Tier = currentTier()): boolean {
  if (tier === "premium") return true;
  if (action === "fast_clarity" && tier === "basic") {
    const s = load();
    return (s.fastClarityDay === todayKey() ? s.fastClarityCount : 0) < BASIC_FAST_CLARITY_DAILY_CAP;
  }
  if (tier === "basic") return true;
  // free
  const cost = ACTION_COST[action] ?? 1;
  return creditsRemaining() >= cost;
}

/** Record an action's cost. Returns the new usage state. No-op for premium. */
export function recordAction(action: keyof typeof ACTION_COST | "fast_clarity", tier: Tier = currentTier()): UsageState {
  if (tier === "premium") return load();
  const s = load();
  if (action === "fast_clarity" && tier === "basic") {
    if (s.fastClarityDay !== todayKey()) {
      s.fastClarityDay = todayKey();
      s.fastClarityCount = 0;
    }
    s.fastClarityCount += 1;
    save(s);
    return s;
  }
  if (tier === "basic") return s;
  // free
  const cost = ACTION_COST[action] ?? 1;
  s.used = Math.min(FREE_WEEKLY_CREDITS, s.used + cost);
  save(s);
  return s;
}

export function fastClarityRemainingToday(tier: Tier = currentTier()): number | null {
  if (tier === "premium") return null; // unlimited
  if (tier === "basic") {
    const s = load();
    const used = s.fastClarityDay === todayKey() ? s.fastClarityCount : 0;
    return Math.max(0, BASIC_FAST_CLARITY_DAILY_CAP - used);
  }
  return null; // free uses the credit bucket instead
}

/** Test-only: clear local usage. */
export function _resetUsage(): void {
  if (typeof window !== "undefined") localStorage.removeItem(STORAGE_KEY);
}

/* ----------------------------- React hook ----------------------------- */

export function useUsage() {
  const [state, setState] = useState<UsageState>(() => load());

  const sync = useCallback(() => setState(load()), []);

  useEffect(() => {
    sync();
    const onEvt = () => sync();
    window.addEventListener(EVT, onEvt);
    window.addEventListener("storage", onEvt);
    return () => {
      window.removeEventListener(EVT, onEvt);
      window.removeEventListener("storage", onEvt);
    };
  }, [sync]);

  return {
    ...state,
    creditsRemaining: Math.max(0, FREE_WEEKLY_CREDITS - state.used),
    percentConsumed: Math.min(100, Math.round((state.used / FREE_WEEKLY_CREDITS) * 100)),
    daysUntilReset: Math.max(
      0,
      Math.ceil((state.weekStart + WEEK_MS - Date.now()) / (24 * 60 * 60 * 1000)),
    ),
    refresh: sync,
  };
}
