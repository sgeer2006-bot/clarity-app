import { Link } from "react-router-dom";
import type { Feature } from "./tiers";

const LABELS: Record<Feature, string> = {
  unlimited_chats: "Unlimited reflections",
  unlimited_snapshots: "Unlimited snapshots",
  analytics: "Trends",
  continuation: "Gentle continuation",
  calming_background: "Calm visual layer",
  two_person: "Two-Person Mode",
  deep_dive_insights: "A deeper read of you",
  pattern_conversations: "The patterns under the patterns",
  identity_timeline: "How you're quietly changing",
  weekly_digest_plus: "Your week, gently summed up",
};

const PREMIUM_ONLY: Feature[] = [
  "two_person", "deep_dive_insights", "pattern_conversations",
  "identity_timeline", "weekly_digest_plus",
];

export function UpsellInline({ feature }: { feature: Feature }) {
  const isPremium = PREMIUM_ONLY.includes(feature);
  const tierName = isPremium ? "Clarity+" : "Clarity";
  return (
    <div
      className="my-4 rounded-[14px] p-4 text-sm"
      style={{ background: "#F4ECE0", borderLeft: "4px solid #8FA88F", color: "#2A2520" }}
    >
      <div className="font-medium">
        {LABELS[feature]} is part of {tierName}.
      </div>
      {isPremium ? (
        <p className="mt-1 text-xs" style={{ color: "#5A524A" }}>
          Your deeper clarity starts here.
        </p>
      ) : null}
      <Link
        to={isPremium ? "/clarity-plus" : "/clarity-plus/pricing"}
        className="mt-2 inline-block text-xs underline"
        style={{ color: "#5E7A60" }}
      >
        {isPremium ? "Unlock Clarity+ →" : "See plans →"}
      </Link>
    </div>
  );
}
