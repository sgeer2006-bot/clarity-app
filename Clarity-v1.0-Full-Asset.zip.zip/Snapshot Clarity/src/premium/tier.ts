/**
 * Phase 3 — 3-tier system: tier detection.
 *
 * Single source of truth for the user's current tier (free | basic | premium).
 * Reads from the `subscriptions` table and maps `price_id` → tier. Mirrors
 * the result to a localStorage cache so synchronous reads (e.g. legacy
 * `readTier()` in the continuation gate) stay aligned across the app.
 *
 * Logic only — no UI here. Does not modify Stripe integration. Does not
 * modify identity, continuation, or insights logic.
 */
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getStripeEnvironment } from "@/lib/stripe/loadStripe";
import { setClarityPlusUser } from "@/premium/clarityPlus/usePremium";

export type Tier = "free" | "basic" | "premium";

const TIER_CACHE_KEY = "clarity.tier";
const TIER_EVT = "clarity:tier-updated";

/** Stripe price_id (lookup_key) → tier mapping. */
const PRICE_TIER: Record<string, Tier> = {
  clarity_basic_monthly: "basic",
  clarity_basic_yearly: "basic",
  clarity_plus_monthly: "premium",
  clarity_plus_yearly: "premium",
  clarity_plus_yearly_v2: "premium",
};

export function tierForPriceId(priceId: string | null | undefined): Tier {
  if (!priceId) return "free";
  return PRICE_TIER[priceId] ?? "free";
}

function readCachedTier(): Tier {
  if (typeof window === "undefined") return "free";
  try {
    const raw = localStorage.getItem(TIER_CACHE_KEY);
    if (raw === "basic" || raw === "premium" || raw === "free") return raw;
  } catch {
    /* ignore */
  }
  return "free";
}

function writeCachedTier(tier: Tier) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(TIER_CACHE_KEY, tier);
    // Mirror to legacy Clarity+ flag for components still using it.
    setClarityPlusUser(tier === "premium");
    window.dispatchEvent(new CustomEvent(TIER_EVT, { detail: tier }));
  } catch {
    /* ignore */
  }
}

/**
 * Synchronous tier read for non-React call sites.
 * Returns the most recently cached tier (refreshed by useTier).
 */
export function currentTier(): Tier {
  return readCachedTier();
}

export function isAtLeast(actual: Tier, required: Tier): boolean {
  const rank: Record<Tier, number> = { free: 0, basic: 1, premium: 2 };
  return rank[actual] >= rank[required];
}

/**
 * React hook returning the user's current tier and a refresh function.
 * Re-fetches on auth state change and on `clarity:tier-updated` events.
 */
export function useTier() {
  const [tier, setTier] = useState<Tier>(() => readCachedTier());
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    let next: Tier = "free";
    try {
      const { data: userData } = await supabase.auth.getUser();
      const userId = userData?.user?.id;
      if (userId) {
        const { data } = await supabase
          .from("subscriptions")
          .select("status,current_period_end,price_id")
          .eq("user_id", userId)
          .eq("environment", getStripeEnvironment())
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (data) {
          const status = data.status as string;
          const end = data.current_period_end
            ? new Date(data.current_period_end).getTime()
            : null;
          const now = Date.now();
          const stillActive =
            status === "active" ||
            status === "trialing" ||
            status === "past_due"
              ? !end || end > now
              : status === "canceled" && end && end > now;
          if (stillActive) next = tierForPriceId(data.price_id);
        }
      }
    } catch (err) {
      console.warn("[Tier] refresh failed:", err);
      next = readCachedTier();
    }
    writeCachedTier(next);
    setTier(next);
    setLoading(false);
    return next;
  }, []);

  useEffect(() => {
    void refresh();
    const onEvt = (e: Event) => {
      const t = (e as CustomEvent<Tier>).detail;
      if (t === "free" || t === "basic" || t === "premium") setTier(t);
    };
    window.addEventListener(TIER_EVT, onEvt);
    const { data: sub } = supabase.auth.onAuthStateChange(() => {
      void refresh();
    });
    return () => {
      window.removeEventListener(TIER_EVT, onEvt);
      sub.subscription.unsubscribe();
    };
  }, [refresh]);

  return {
    tier,
    loading,
    refresh,
    isFree: tier === "free",
    isBasic: tier === "basic",
    isPremium: tier === "premium",
    isPaid: tier !== "free",
    isAtLeast: (req: Tier) => isAtLeast(tier, req),
  };
}
