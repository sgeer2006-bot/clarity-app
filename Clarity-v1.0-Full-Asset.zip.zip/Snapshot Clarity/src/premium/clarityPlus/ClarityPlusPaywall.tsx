import { useEffect, useState } from "react";
import { Sparkles, X, ExternalLink } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useStripeCheckout, type ClarityPlan } from "@/hooks/useStripeCheckout";
import { usePremiumStatus } from "@/hooks/usePremiumStatus";
import { useTier } from "@/premium/tier";
import { supabase } from "@/integrations/supabase/client";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { CLARITY_PLUS_FEATURES } from "./features";
import {
  PAYWALL,
  EMOTIONAL_BENEFITS_SHORT,
  CLOSE,
  TAGLINE_FULL,
} from "./copy";

// Legacy alias retained for callers that pass "monthly" | "yearly" — both
// map to Clarity+ price IDs for backwards compatibility.
export type PlanKey = "monthly" | "yearly" | ClarityPlan;

const RESOLVE_PLAN: Record<string, ClarityPlan> = {
  monthly: "clarity_plus_monthly",
  yearly: "clarity_plus_yearly_v2",
  clarity_plus_monthly: "clarity_plus_monthly",
  clarity_plus_yearly_v2: "clarity_plus_yearly_v2",
  clarity_basic_monthly: "clarity_basic_monthly",
  clarity_basic_yearly: "clarity_basic_yearly",
};

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultPlan?: PlanKey;
  onUpgradeClick?: (plan: PlanKey) => void;
}

export function ClarityPlusPaywall({
  open,
  onOpenChange,
  defaultPlan = "yearly",
  onUpgradeClick,
}: Props) {
  const navigate = useNavigate();
  const { isPremium } = usePremiumStatus();
  const { tier } = useTier();
  const [authChecked, setAuthChecked] = useState(false);
  const [isAuthed, setIsAuthed] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const {
    startCheckout,
    closeCheckout,
    isOpen: checkoutOpen,
    error: checkoutError,
    checkoutElement,
  } = useStripeCheckout();

  useEffect(() => {
    let active = true;
    supabase.auth.getUser().then(({ data }) => {
      if (!active) return;
      setIsAuthed(Boolean(data?.user));
      setAuthChecked(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setIsAuthed(Boolean(session?.user));
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const handleUpgrade = (plan: PlanKey) => {
    setAuthError(null);
    onUpgradeClick?.(plan);
    if (!authChecked) return;
    if (!isAuthed) {
      const returnTo = `${window.location.pathname}${window.location.search}`;
      onOpenChange(false);
      navigate(`/auth?next=${encodeURIComponent(returnTo)}`);
      return;
    }
    if (isPremium) {
      setAuthError("You're already on Clarity+. You can manage your plan from Settings → Billing.");
      return;
    }
    const priceId = RESOLVE_PLAN[plan] ?? "clarity_plus_yearly_v2";
    startCheckout(priceId);
  };

  const handleOpenChange = (next: boolean) => {
    if (!next) closeCheckout();
    onOpenChange(next);
  };

  return (
    <Sheet open={open} onOpenChange={handleOpenChange}>
      <SheetContent
        side="bottom"
        className="max-h-[92vh] overflow-y-auto rounded-t-2xl p-0"
      >
        <PaymentTestModeBanner />
        <div className="mx-auto w-full max-w-xl px-6 py-6">
          <header className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Sparkles className="h-4 w-4" aria-hidden />
              </span>
              <div>
                <h2 className="font-display text-xl font-semibold">{PAYWALL.title}</h2>
                <p className="text-sm text-muted-foreground">{PAYWALL.subtitle}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleOpenChange(false)}
              aria-label={PAYWALL.closeAria}
              className="h-9 w-9"
            >
              <X className="h-4 w-4" aria-hidden />
            </Button>
          </header>

          {isPremium ? (
            <section className="mt-6 rounded-xl border border-primary/30 bg-primary/5 p-4">
              <p className="text-sm text-foreground/90">
                You're already on Clarity+. You can manage your plan, update your card, or cancel any time — no fuss.
              </p>
              <Button
                size="sm"
                variant="outline"
                className="mt-3 h-9 rounded-full"
                onClick={() => {
                  onOpenChange(false);
                  navigate("/clarity-plus/pricing");
                }}
              >
                Manage subscription
                <ExternalLink className="ml-1.5 h-3.5 w-3.5" aria-hidden />
              </Button>
            </section>
          ) : null}

          {checkoutOpen && checkoutElement ? (
            <section className="mt-6">
              <div className="rounded-xl border border-border/50 bg-card/40 p-2">
                {checkoutElement}
              </div>
              <div className="mt-3 flex justify-end">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => closeCheckout()}
                  className="h-9 rounded-full px-3 text-muted-foreground"
                >
                  Back to plans
                </Button>
              </div>
            </section>
          ) : null}

          {authError ? (
            <p className="mt-3 text-sm text-destructive">{authError}</p>
          ) : null}
          {checkoutError ? (
            <p className="mt-3 text-sm text-destructive">{checkoutError}</p>
          ) : null}

          <section className="mt-6">
            <h3 className="text-xs uppercase tracking-[0.14em] text-muted-foreground/80">
              What you unlock
            </h3>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {CLARITY_PLUS_FEATURES.map((f) => (
                <li
                  key={f.id}
                  className="rounded-xl border border-border/50 bg-card/40 p-3"
                >
                  <p className="text-sm font-medium text-foreground/90">{f.title}</p>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {f.description}
                  </p>
                </li>
              ))}
            </ul>
          </section>

          <section className="mt-6">
            <h3 className="text-xs uppercase tracking-[0.14em] text-muted-foreground/80">
              Why people choose Clarity+
            </h3>
            <ul className="mt-3 space-y-1.5 text-sm text-foreground/85">
              {EMOTIONAL_BENEFITS_SHORT.map((b) => (
                <li key={b} className="flex items-start gap-2">
                  <span className="mt-1.5 inline-block h-1.5 w-1.5 rounded-full bg-primary/70" />
                  {b}
                </li>
              ))}
            </ul>
          </section>

          {!isPremium ? (
            <section className="mt-6 grid gap-3 sm:grid-cols-2">
              {tier === "free" ? (
                <>
                  <PlanLine
                    label="Clarity Basic — Monthly"
                    price="$5.99 / mo"
                    sub="Unlimited reflections, insights, tools."
                    cta="Unlock Clarity Basic"
                    onClick={() => handleUpgrade("clarity_basic_monthly")}
                  />
                  <PlanLine
                    label="Clarity Basic — Yearly"
                    price="$49 / yr"
                    sub="Save vs monthly. Same unlimited everything."
                    cta="Unlock Clarity Basic"
                    onClick={() => handleUpgrade("clarity_basic_yearly")}
                  />
                </>
              ) : null}
              <PlanLine
                label="Clarity+ — Monthly"
                price="$9.99 / mo"
                sub="Deep insights, identity evolution, premium themes."
                cta="Unlock Clarity+"
                highlighted={defaultPlan === "monthly" || defaultPlan === "clarity_plus_monthly"}
                onClick={() => handleUpgrade("clarity_plus_monthly")}
              />
              <PlanLine
                label="Clarity+ — Yearly"
                price="$99 / yr"
                sub="Best value. Your deeper clarity, all year."
                cta="Unlock Clarity+"
                highlighted={defaultPlan === "yearly" || defaultPlan === "clarity_plus_yearly_v2"}
                onClick={() => handleUpgrade("clarity_plus_yearly_v2")}
              />
            </section>
          ) : null}

          <div className="mt-6 flex justify-center">
            <Button
              variant="outline"
              size="lg"
              onClick={() => onOpenChange(false)}
              className="h-11 rounded-full px-6"
            >
              {CLOSE}
            </Button>
          </div>

          <p className="mt-4 text-center text-xs text-muted-foreground/80">
            You can close this any time. Free Clarity stays exactly as it is.
          </p>
          <p className="mt-2 text-center text-xs text-primary/80">{TAGLINE_FULL}</p>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function PlanLine({
  label,
  price,
  sub,
  cta,
  highlighted,
  onClick,
}: {
  label: string;
  price: string;
  sub: string;
  cta: string;
  highlighted?: boolean;
  onClick: () => void;
}) {
  return (
    <div
      className={`relative rounded-2xl border p-4 ${
        highlighted ? "border-primary/50 bg-primary/5" : "border-border/60 bg-card/40"
      }`}
    >
      <p className="text-sm font-medium text-foreground/90">{label}</p>
      <p className="mt-1 text-2xl font-semibold tracking-tight">{price}</p>
      <p className="mt-1 text-xs text-muted-foreground">{sub}</p>
      <Button onClick={onClick} size="lg" className="mt-4 h-11 w-full rounded-full">
        {cta}
      </Button>
    </div>
  );
}
