import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link, useNavigate } from "react-router-dom";
import { Sparkles, ArrowRight } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { ClarityPlusPaywall } from "./ClarityPlusPaywall";
import { CLARITY_PLUS_FEATURES } from "./features";
import {
  HERO,
  TAGLINE,
  TAGLINE_FULL,
  WHY_IT_HELPS,
  EMOTIONAL_BENEFITS,
  UPGRADE_CTA,
  SECONDARY_CTA,
  MAYBE_LATER,
} from "./copy";

export default function ClarityPlusPage() {
  const navigate = useNavigate();
  const [paywallOpen, setPaywallOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Clarity+ — Your deeper clarity starts here</title>
        <meta
          name="description"
          content="Clarity+ — Your deeper clarity starts here. The same calm reflections, read more deeply, with one small next step you can actually take."
        />
        <link rel="canonical" href="/clarity-plus" />
      </Helmet>
      <TopBar />
      <main className="mx-auto w-full max-w-2xl px-5 py-12 sm:py-16">
        <section aria-labelledby="cp-hero">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 text-xs text-primary">
            <Sparkles className="h-3 w-3" aria-hidden /> {HERO.title}
          </span>
          <h1
            id="cp-hero"
            className="mt-4 font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl"
          >
            Clarity+ — {TAGLINE}
          </h1>
          <p className="mt-3 text-base text-muted-foreground">
            A natural next step for the work you're already doing here. Same calm. Just farther in.
          </p>
        </section>

        <section className="mt-10" aria-labelledby="cp-why">
          <h2 id="cp-why" className="font-display text-xl font-semibold">
            Why people choose Clarity+
          </h2>
          <div className="mt-3 space-y-3 text-base leading-relaxed text-foreground/85">
            {WHY_IT_HELPS.map((line, i) => (
              <p key={i}>{line}</p>
            ))}
          </div>
        </section>

        <section className="mt-10" aria-labelledby="cp-feel">
          <h2 id="cp-feel" className="font-display text-xl font-semibold">
            What it feels like
          </h2>
          <ul className="mt-3 grid gap-2 sm:grid-cols-2">
            {EMOTIONAL_BENEFITS.map((b) => (
              <li
                key={b}
                className="flex items-start gap-2 rounded-xl border border-border/50 bg-card/30 px-3 py-2 text-sm text-foreground/85"
              >
                <span className="mt-1.5 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-primary/70" />
                {b}
              </li>
            ))}
          </ul>
        </section>

        <section className="mt-10" aria-labelledby="cp-features">
          <h2 id="cp-features" className="font-display text-xl font-semibold">
            What you unlock
          </h2>
          <ul className="mt-3 space-y-2">
            {CLARITY_PLUS_FEATURES.map((f) => (
              <li
                key={f.id}
                className="rounded-xl border border-border/50 bg-card/30 p-3"
              >
                <p className="text-sm font-medium text-foreground/90">{f.title}</p>
                <p className="mt-0.5 text-sm leading-relaxed text-muted-foreground">
                  {f.description}
                </p>
              </li>
            ))}
          </ul>
        </section>

        <section className="mt-12 flex flex-col items-start gap-3 sm:flex-row sm:items-center">
          <Button
            size="lg"
            className="h-12 rounded-full px-6 text-base"
            onClick={() => setPaywallOpen(true)}
          >
            {UPGRADE_CTA}
            <ArrowRight className="ml-2 h-4 w-4" aria-hidden />
          </Button>
          <Button asChild size="lg" variant="outline" className="h-12 rounded-full px-6 text-base">
            <Link to="/clarity-plus/pricing">{SECONDARY_CTA}</Link>
          </Button>
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="text-sm text-muted-foreground underline-offset-4 hover:underline"
          >
            {MAYBE_LATER}
          </button>
        </section>

        <section className="mt-12" aria-labelledby="cp-faq">
          <h2 id="cp-faq" className="font-display text-xl font-semibold">A few common questions</h2>
          <dl className="mt-4 space-y-4 text-sm leading-relaxed text-foreground/85">
            <div>
              <dt className="font-medium text-foreground/90">Will my free Clarity change?</dt>
              <dd className="mt-1 text-muted-foreground">No. Everything you use today stays exactly as it is. Clarity+ only adds a deeper layer.</dd>
            </div>
            <div>
              <dt className="font-medium text-foreground/90">Can I cancel any time?</dt>
              <dd className="mt-1 text-muted-foreground">Yes. One tap from Settings. No emails to send, no hoops to jump through.</dd>
            </div>
            <div>
              <dt className="font-medium text-foreground/90">Are my reflections private?</dt>
              <dd className="mt-1 text-muted-foreground">Always. Your reflections are yours. We treat them with the same care you do.</dd>
            </div>
          </dl>
        </section>

        <p className="mt-8 text-center text-xs text-muted-foreground/80">{TAGLINE_FULL}</p>
      </main>

      <ClarityPlusPaywall open={paywallOpen} onOpenChange={setPaywallOpen} />
    </div>
  );
}
