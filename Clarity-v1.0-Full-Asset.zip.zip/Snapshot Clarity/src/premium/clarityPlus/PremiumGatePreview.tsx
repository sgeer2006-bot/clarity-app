import { useEffect, useState, type ReactNode } from "react";
import { Lock, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ClarityPlusPaywall } from "./ClarityPlusPaywall";
import { GATE_PREVIEW_LEAD, NOT_NOW, UNLOCK_CTA } from "./copy";
import { CLARITY_PLUS_FEATURES, type ClarityPlusFeatureId } from "./features";
import { useAuthSession } from "@/hooks/useAuthSession";
import { getClarityPlusEngineData } from "@/lib/analyticalEngine/dataAdapter";
import type { ClarityPlusInsights } from "@/lib/analyticalEngine/types";

interface Props {
  feature: ClarityPlusFeatureId;
  /** Optional sample/blurred preview content. No real private data should be passed. */
  previewContent?: ReactNode;
  /** Called when user dismisses ("Not now"). Should return them to where they were. */
  onClose?: () => void;
}

/**
 * Derive engine-driven preview lines from a ClarityPlusInsights bundle
 * for the given feature. Returns null if engine output has nothing usable
 * for this feature (so the caller can fall back to the existing sample).
 */
function deriveEnginePreview(
  feature: ClarityPlusFeatureId,
  data: ClarityPlusInsights | null,
): { title: string; lines: string[] } | null {
  if (!data) return null;

  // The seven Clarity+ preview surface fields mapped from the engine bundle:
  const premiumIdentityThemes = data.story?.identityThemes ?? [];
  const deepNarrativeInsights = data.insights?.coreThemes ?? [];
  const emotionalLoopDetection = data.patterns?.emotionalLoops ?? [];
  const situationalPatternDetection = data.patterns?.triggerTypes ?? [];
  const weekOverWeekShiftHighlights = data.insights?.weekOverWeekShifts ?? [];
  const clusterIntelligencePreview = data.patterns?.emotionalSignatures ?? [];
  const predictionLayerPreview = [
    ...(data.predictionSignals ?? []),
    ...(data.futureTriggers ?? []),
  ];

  const pick = (arr: any[], get: (x: any) => string | undefined, n = 3): string[] =>
    arr
      .map(get)
      .filter((s): s is string => typeof s === "string" && s.trim().length > 0)
      .slice(0, n);

  let title = "";
  let lines: string[] = [];

  switch (feature) {
    case "deep_insights":
      title = "A deeper look at what's going on beneath the surface";
      lines = pick(deepNarrativeInsights, (t) => t?.description ?? t?.label);
      break;
    case "deep_patterns":
      title = "Patterns that influence how you feel and act";
      lines = pick(clusterIntelligencePreview, (s) => s?.description ?? s?.label);
      break;
    case "identity_evolution":
      title = "How your story is evolving";
      lines = pick(premiumIdentityThemes, (t) => t?.description ?? t?.label ?? t?.theme);
      break;
    case "weekly_deep_digest":
      title = "Your week, gently summed up";
      lines = pick(weekOverWeekShiftHighlights, (s) => s?.description ?? s?.label);
      break;
    case "emotional_loop_detection":
      title = "Feelings you tend to get stuck in";
      lines = pick(emotionalLoopDetection, (l) => l?.description ?? l?.label);
      break;
    case "situational_pattern_detection":
      title = "When this tends to happen for you";
      lines = pick(situationalPatternDetection, (t) => t?.description ?? t?.label);
      break;
    case "relationship_insights":
      title = "How you show up with the people around you";
      lines = pick(situationalPatternDetection, (t) => t?.description ?? t?.label);
      break;
    case "premium_themes":
      title = "Themes that shape your inner world";
      lines = pick(premiumIdentityThemes, (t) => t?.description ?? t?.label ?? t?.theme);
      break;
    case "fast_clarity_pro":
      title = "Fast Clarity, taken a little further";
      lines = pick(predictionLayerPreview, (p) => p?.description ?? p?.label);
      break;
    default:
      return null;
  }

  if (lines.length === 0) return null;
  return { title, lines };
}

export function PremiumGatePreview({ feature, previewContent, onClose }: Props) {
  const meta = CLARITY_PLUS_FEATURES.find((f) => f.id === feature);
  const [paywallOpen, setPaywallOpen] = useState(false);

  const { session } = useAuthSession();
  const userId = session?.user?.id ?? null;
  const [engineData, setEngineData] = useState<ClarityPlusInsights | null>(null);
  const [engineLoading, setEngineLoading] = useState(false);
  const [engineError, setEngineError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    if (!userId) {
      setEngineData(null);
      return;
    }
    setEngineLoading(true);
    setEngineError(false);
    (async () => {
      try {
        const data = await getClarityPlusEngineData(userId);
        if (!cancelled) setEngineData(data ?? null);
      } catch {
        if (!cancelled) {
          setEngineData(null);
          setEngineError(true);
        }
      } finally {
        if (!cancelled) setEngineLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [userId]);

  // Only derive engine-driven preview when no explicit previewContent prop was passed,
  // i.e. when we'd otherwise render the existing sample/placeholder content.
  const derived = previewContent ? null : deriveEnginePreview(feature, engineData);

  return (
    <div className="rounded-2xl border border-border/60 bg-card/50 p-5">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 inline-flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Sparkles className="h-4 w-4" aria-hidden />
        </span>
        <div className="min-w-0">
          <h3 className="font-display text-base font-semibold text-foreground">
            {meta?.title ?? "A deeper view"}
          </h3>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
            {GATE_PREVIEW_LEAD}
          </p>
          {engineLoading ? (
            <p className="mt-2 text-xs text-muted-foreground">Loading…</p>
          ) : engineError ? (
            <p className="mt-2 text-xs text-muted-foreground">
              Something went wrong — showing your saved version instead.
            </p>
          ) : null}
        </div>
      </div>

      <div className="relative mt-5 overflow-hidden rounded-xl border border-border/40 bg-background/40 p-4">
        <div
          aria-hidden
          className="pointer-events-none select-none blur-[3px] opacity-70"
        >
          {previewContent ?? (
            derived ? (
              <div className="space-y-2 text-sm text-foreground/80">
                <p className="font-medium">{derived.title}</p>
                {derived.lines.map((line, i) => (
                  <p key={i} className="text-muted-foreground">{line}</p>
                ))}
              </div>
            ) : (
              <div className="space-y-2 text-sm text-foreground/80">
                <p className="font-medium">{meta?.title ?? "Sample preview"}</p>
                <p className="text-muted-foreground">{meta?.description}</p>
                <p className="text-muted-foreground">
                  A longer, gentler read of what you've been noticing — paragraph-style,
                  with the small shifts highlighted softly.
                </p>
              </div>
            )
          )}
        </div>
        <div className="pointer-events-none absolute inset-0 flex items-end justify-center bg-gradient-to-t from-background/80 to-transparent">
          <span className="mb-2 inline-flex items-center gap-1.5 rounded-full bg-background/80 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
            <Lock className="h-3 w-3" aria-hidden /> Preview
          </span>
        </div>
      </div>

      <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-end">
        <Button
          variant="ghost"
          size="lg"
          onClick={onClose}
          className="h-11 rounded-full px-5"
        >
          {NOT_NOW}
        </Button>
        <Button
          size="lg"
          onClick={() => setPaywallOpen(true)}
          className="h-11 rounded-full px-5"
        >
          {UNLOCK_CTA}
        </Button>
      </div>

      <ClarityPlusPaywall open={paywallOpen} onOpenChange={setPaywallOpen} />
    </div>
  );
}
