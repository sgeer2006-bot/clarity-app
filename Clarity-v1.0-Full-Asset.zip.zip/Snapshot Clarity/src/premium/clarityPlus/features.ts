/**
 * Clarity+ unlocks — outcome-led, plain language.
 * Each entry reads like a benefit a friend would describe, not a feature list.
 */

export type ClarityPlusFeatureId =
  | "deep_insights"
  | "deep_patterns"
  | "identity_evolution"
  | "weekly_deep_digest"
  | "emotional_loop_detection"
  | "situational_pattern_detection"
  | "relationship_insights"
  | "premium_themes"
  | "fast_clarity_pro";

export interface ClarityPlusFeature {
  id: ClarityPlusFeatureId;
  title: string;
  description: string;
}

export const CLARITY_PLUS_FEATURES: ClarityPlusFeature[] = [
  {
    id: "deep_insights",
    title: "A deeper read of you",
    description:
      "Longer, gentler insights that explain what your reflections are really pointing at — in plain words.",
  },
  {
    id: "deep_patterns",
    title: "The patterns under the patterns",
    description:
      "See the bigger shapes behind what keeps showing up, so you can name what's happening instead of guessing.",
  },
  {
    id: "identity_evolution",
    title: "How you're quietly changing",
    description:
      "A soft timeline that shows how you're growing over weeks and months — even on the days it doesn't feel like it.",
  },
  {
    id: "weekly_deep_digest",
    title: "Your week, gently summed up",
    description:
      "Each week, a calm, honest read of what mattered most — what shifted, what held steady, and one small thing to try.",
  },
  {
    id: "emotional_loop_detection",
    title: "The feelings that keep coming back",
    description:
      "Spot the emotional loops you didn't know you were in — named clearly, without judgment.",
  },
  {
    id: "situational_pattern_detection",
    title: "When and where it tends to happen",
    description:
      "Notice the moments, places, and people that quietly trigger the same response in you.",
  },
  {
    id: "relationship_insights",
    title: "How you show up with others",
    description:
      "A clearer view of how you tend to connect, pull back, or repeat the same dynamic with the people in your life.",
  },
  {
    id: "premium_themes",
    title: "Calmer, more personal themes",
    description:
      "Softer visual themes that match the way Clarity+ feels — quieter, warmer, more yours.",
  },
  {
    id: "fast_clarity_pro",
    title: "Fast Clarity, taken further",
    description:
      "When you need to settle quickly, Clarity+ gives you a deeper grounding and one calm, doable next step.",
  },
];
