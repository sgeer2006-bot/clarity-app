/**
 * Isolated Clarity+ premium status.
 *
 * Reads/writes its OWN local flag. Does NOT touch the existing premium
 * tier system in src/premium/usePremium.ts or any other global state.
 *
 * Storage key: 'clarity_plus.premium' ('1' = premium, anything else = not).
 */
import { useEffect, useState } from "react";

const KEY = "clarity_plus.premium";
const EVT = "clarity-plus:premium";

export function isClarityPlusUser(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return localStorage.getItem(KEY) === "1";
  } catch {
    return false;
  }
}

export function setClarityPlusUser(on: boolean): void {
  if (typeof window === "undefined") return;
  try {
    if (on) localStorage.setItem(KEY, "1");
    else localStorage.removeItem(KEY);
    window.dispatchEvent(new CustomEvent(EVT));
  } catch {
    /* ignore */
  }
}

export function useClarityPlus(): { isPremium: boolean } {
  const [isPremium, setIsPremium] = useState<boolean>(isClarityPlusUser);
  useEffect(() => {
    const sync = () => setIsPremium(isClarityPlusUser());
    window.addEventListener(EVT, sync as EventListener);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync as EventListener);
      window.removeEventListener("storage", sync);
    };
  }, []);
  return { isPremium };
}
