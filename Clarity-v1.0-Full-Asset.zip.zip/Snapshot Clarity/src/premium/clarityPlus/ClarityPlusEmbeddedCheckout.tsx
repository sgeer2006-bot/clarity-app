import {
  EmbeddedCheckout,
  EmbeddedCheckoutProvider,
} from "@stripe/react-stripe-js";
import { supabase } from "@/integrations/supabase/client";
import { getStripe, getStripeEnvironment } from "@/lib/stripe/loadStripe";

interface Props {
  priceId:
    | "clarity_plus_monthly"
    | "clarity_plus_yearly_v2"
    | "clarity_basic_monthly"
    | "clarity_basic_yearly";
  returnUrl?: string;
}

/**
 * Inline Stripe Embedded Checkout for Clarity+. Fetches a session
 * client_secret from the `clarity-plus-create-checkout` edge function
 * and mounts the official Stripe form. PCI-compliant by construction.
 */
export function ClarityPlusEmbeddedCheckout({ priceId, returnUrl }: Props) {
  const fetchClientSecret = async (): Promise<string> => {
    const finalReturnUrl =
      returnUrl ??
      `${window.location.origin}/clarity-plus/success?session_id={CHECKOUT_SESSION_ID}`;

    const { data, error } = await supabase.functions.invoke(
      "clarity-plus-create-checkout",
      {
        body: {
          priceId,
          returnUrl: finalReturnUrl,
          environment: getStripeEnvironment(),
        },
      },
    );

    if (error || !data?.clientSecret) {
      throw new Error(error?.message ?? "Could not start checkout");
    }
    return data.clientSecret as string;
  };

  return (
    <div id="clarity-plus-checkout">
      <EmbeddedCheckoutProvider stripe={getStripe()} options={{ fetchClientSecret }}>
        <EmbeddedCheckout />
      </EmbeddedCheckoutProvider>
    </div>
  );
}
