/**
 * Clarity+ — centralized strings.
 * Voice: warm, clear, motivational. Plain words. No jargon.
 * Tagline (required, used everywhere premium is surfaced):
 *   "Clarity+ — Your deeper clarity starts here."
 */

export const BRAND = "Clarity+";
export const TAGLINE = "Your deeper clarity starts here.";
export const TAGLINE_FULL = "Clarity+ — Your deeper clarity starts here.";

export const HERO = {
  title: "Clarity+",
  tagline: TAGLINE,
};

export const WHY_IT_HELPS = [
  "Clarity+ takes the same reflections you're already doing and reads them more deeply.",
  "It gently surfaces the through-lines you'd be hard-pressed to spot on your own.",
  "Everything you already love about Clarity stays free. Clarity+ is simply the deeper layer, when you want it.",
];

export const EMOTIONAL_BENEFITS: string[] = [
  "Feel more understood, in your own words",
  "See the patterns underneath your patterns",
  "Get a small, doable next step — never a list of demands",
  "Watch the quiet shifts in who you're becoming",
];

export const EMOTIONAL_BENEFITS_SHORT: string[] = [
  "Feel more understood",
  "See your patterns more clearly",
  "Move forward with one calm next step",
];

// Global CTA replacements
export const UPGRADE_CTA = "Unlock Clarity+";
export const UNLOCK_CTA = "Unlock Clarity+";
export const SECONDARY_CTA = "See what's inside";
export const MAYBE_LATER = "Maybe later";
export const NOT_NOW = "Maybe later";
export const CLOSE = "Close";
export const LEARN_MORE = "See what's inside";

export const PAYWALL = {
  title: "Clarity+",
  subtitle: "This is where Clarity+ goes a little deeper.",
  closeAria: "Close",
  footerTagline: TAGLINE_FULL,
};

export const GATE_PREVIEW_LEAD =
  "A deeper look at what's going on beneath the surface — same calm, just a little further in.";

export const PRICING_INTRO =
  "Pick the rhythm that fits your life. Change or cancel any time, with no fuss.";

export const PRICING = {
  monthly: {
    label: "Monthly",
    price: "$5.99",
    per: "/month",
    note: "Easy month-to-month. Stop any time.",
  },
  yearly: {
    label: "Yearly",
    price: "$99",
    per: "/year",
    note: "Best value — about $8.25 a month.",
    tag: "Best value",
  },
};

export const UPSELL_COPY = {
  insights:
    "There's a deeper read of this waiting for you. Clarity+ shows the bigger picture under your reflections.",
  "fast-clarity":
    "Want a deeper grounding next time? Clarity+ adds a calmer next step when you need it most.",
  reflect:
    "Your reflections are starting to add up. Clarity+ helps you see what they mean over time.",
  patterns:
    "There's a quieter pattern underneath this one. Clarity+ helps you see it clearly.",
  digest:
    "Clarity+ turns your week into a soft, honest read of what mattered most.",
} as const;

export type UpsellVariant = keyof typeof UPSELL_COPY;
