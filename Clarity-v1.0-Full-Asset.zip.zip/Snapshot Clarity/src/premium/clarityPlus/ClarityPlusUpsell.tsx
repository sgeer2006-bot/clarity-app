import { useState } from "react";
import { Link } from "react-router-dom";
import { Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ClarityPlusPaywall } from "./ClarityPlusPaywall";
import { useClarityPlus } from "./usePremium";
import { LEARN_MORE, UPGRADE_CTA, UPSELL_COPY, type UpsellVariant } from "./copy";

interface Props {
  variant: UpsellVariant;
  className?: string;
}

/**
 * Small, isolated, in-screen upsell card. Dismissal is in-memory only
 * (no persistence). When the user is already on Clarity+, the component
 * renders nothing.
 */
export function ClarityPlusUpsell({ variant, className }: Props) {
  const { isPremium } = useClarityPlus();
  const [dismissed, setDismissed] = useState(false);
  const [paywallOpen, setPaywallOpen] = useState(false);

  if (isPremium || dismissed) return null;

  return (
    <aside
      className={
        "rounded-2xl border border-border/60 bg-card/40 p-4 sm:p-5 " + (className ?? "")
      }
      aria-label="Clarity+ suggestion"
    >
      <div className="flex items-start gap-3">
        <span className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Sparkles className="h-4 w-4" aria-hidden />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm leading-relaxed text-foreground/90">
            {UPSELL_COPY[variant]}
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button
              size="sm"
              onClick={() => setPaywallOpen(true)}
              className="h-9 rounded-full px-4"
            >
              {UPGRADE_CTA}
            </Button>
            <Button
              asChild
              size="sm"
              variant="ghost"
              className="h-9 rounded-full px-3 text-muted-foreground"
            >
              <Link to="/clarity-plus">{LEARN_MORE}</Link>
            </Button>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setDismissed(true)}
          aria-label="Hide for now"
          className="ml-1 rounded-full p-1.5 text-muted-foreground hover:bg-muted/40"
        >
          <X className="h-4 w-4" aria-hidden />
        </button>
      </div>

      <ClarityPlusPaywall open={paywallOpen} onOpenChange={setPaywallOpen} />
    </aside>
  );
}
