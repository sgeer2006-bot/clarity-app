import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { ClarityPlusPaywall, type PlanKey } from "./ClarityPlusPaywall";
import { CLARITY_PLUS_FEATURES } from "./features";
import {
  PRICING,
  PRICING_INTRO,
  UPGRADE_CTA,
  TAGLINE,
  TAGLINE_FULL,
  EMOTIONAL_BENEFITS_SHORT,
} from "./copy";

export default function PricingPage() {
  const [paywallOpen, setPaywallOpen] = useState(false);
  const [plan, setPlan] = useState<PlanKey>("yearly");

  const open = (p: PlanKey) => {
    setPlan(p);
    setPaywallOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Clarity+ Pricing — Your deeper clarity starts here</title>
        <meta
          name="description"
          content="Clarity+ — Your deeper clarity starts here. Choose monthly or yearly, cancel any time, your reflections stay private."
        />
        <link rel="canonical" href="/clarity-plus/pricing" />
      </Helmet>
      <TopBar />
      <main className="mx-auto w-full max-w-3xl px-5 py-12 sm:py-16">
        <header>
          <p className="text-sm text-primary">Clarity+</p>
          <h1 className="mt-1 font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
            {TAGLINE}
          </h1>
          <p className="mt-3 text-base text-muted-foreground">{PRICING_INTRO}</p>
        </header>

        <section className="mt-10 grid gap-4 sm:grid-cols-2">
          <PlanCard plan="monthly" onUpgrade={open} />
          <PlanCard plan="yearly" highlighted onUpgrade={open} />
        </section>

        <section className="mt-12">
          <h2 className="font-display text-xl font-semibold">What you unlock</h2>
          <ul className="mt-3 grid gap-2 sm:grid-cols-2">
            {CLARITY_PLUS_FEATURES.map((f) => (
              <li
                key={f.id}
                className="rounded-xl border border-border/50 bg-card/30 p-3"
              >
                <p className="text-sm font-medium text-foreground/90">{f.title}</p>
                <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                  {f.description}
                </p>
              </li>
            ))}
          </ul>
        </section>

        <section className="mt-10">
          <h2 className="font-display text-xl font-semibold">Why Clarity+</h2>
          <ul className="mt-3 space-y-1.5 text-sm text-foreground/85">
            {EMOTIONAL_BENEFITS_SHORT.map((b) => (
              <li key={b} className="flex items-start gap-2">
                <span className="mt-1.5 inline-block h-1.5 w-1.5 rounded-full bg-primary/70" />
                {b}
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs text-muted-foreground">
            Cancel any time. Your reflections stay private — they're yours, always.
          </p>
        </section>

        <p className="mt-10 text-center text-xs text-muted-foreground/80">{TAGLINE_FULL}</p>
      </main>

      <ClarityPlusPaywall
        open={paywallOpen}
        onOpenChange={setPaywallOpen}
        defaultPlan={plan}
      />
    </div>
  );
}

function PlanCard({
  plan,
  highlighted,
  onUpgrade,
}: {
  plan: PlanKey;
  highlighted?: boolean;
  onUpgrade: (p: PlanKey) => void;
}) {
  const p = PRICING[plan];
  const tag = "tag" in p ? (p as { tag: string }).tag : null;
  return (
    <div
      className={`relative rounded-2xl border p-5 ${
        highlighted ? "border-primary/50 bg-primary/5" : "border-border/60 bg-card/40"
      }`}
    >
      {tag ? (
        <span className="absolute -top-2 right-4 rounded-full bg-primary px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-primary-foreground">
          {tag}
        </span>
      ) : null}
      <p className="text-sm font-medium text-foreground/90">{p.label}</p>
      <p className="mt-1 text-3xl font-semibold tracking-tight">
        {p.price}
        <span className="ml-1 text-sm font-normal text-muted-foreground">{p.per}</span>
      </p>
      <p className="mt-1 text-xs text-muted-foreground">{p.note}</p>
      <Button
        onClick={() => onUpgrade(plan)}
        size="lg"
        className="mt-5 h-11 w-full rounded-full"
      >
        {UPGRADE_CTA}
      </Button>
    </div>
  );
}
