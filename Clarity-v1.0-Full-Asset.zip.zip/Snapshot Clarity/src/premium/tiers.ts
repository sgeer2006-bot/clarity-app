export const TIERS = {
  free:    { id: "free",    monthly: 0,    yearly: 0    },
  basic:   { id: "basic",   monthly: 5.99, yearly: null as number | null },
  premium: { id: "premium", monthly: null as number | null, yearly: 99 },
} as const;

export type TierId = keyof typeof TIERS;

export const FEATURE_MATRIX = {
  unlimited_chats:       ["basic", "premium"],
  unlimited_snapshots:   ["basic", "premium"],
  analytics:             ["basic", "premium"],
  continuation:          ["basic", "premium"],
  calming_background:    ["basic", "premium"],
  two_person:            ["premium"],
  deep_dive_insights:    ["premium"],
  pattern_conversations: ["premium"],
  identity_timeline:     ["premium"],
  weekly_digest_plus:    ["premium"],
} as const;

export type Feature = keyof typeof FEATURE_MATRIX;

export const FREE_LIMITS = {
  chatsPer24h: 5,
  snapshotsPer24h: 3,
} as const;
