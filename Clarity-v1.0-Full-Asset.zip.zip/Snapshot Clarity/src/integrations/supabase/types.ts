export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      continuation_messages: {
        Row: {
          content: string
          continuation_id: string
          created_at: string
          id: string
          role: string
          target_fields: string[]
        }
        Insert: {
          content: string
          continuation_id: string
          created_at?: string
          id?: string
          role: string
          target_fields?: string[]
        }
        Update: {
          content?: string
          continuation_id?: string
          created_at?: string
          id?: string
          role?: string
          target_fields?: string[]
        }
        Relationships: [
          {
            foreignKeyName: "continuation_messages_continuation_id_fkey"
            columns: ["continuation_id"]
            isOneToOne: false
            referencedRelation: "continuation_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      continuation_sessions: {
        Row: {
          completed_at: string | null
          created_at: string
          exit_reason: string
          fields_touched: string[]
          id: string
          mode: string
          questions_asked: number
          session_id: string
          status: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          exit_reason?: string
          fields_touched?: string[]
          id?: string
          mode: string
          questions_asked?: number
          session_id: string
          status?: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          exit_reason?: string
          fields_touched?: string[]
          id?: string
          mode?: string
          questions_asked?: number
          session_id?: string
          status?: string
        }
        Relationships: []
      }
      folders: {
        Row: {
          created_at: string
          id: string
          name: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          user_id?: string
        }
        Relationships: []
      }
      follow_up_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          role: string
          section: string
          session_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          role: string
          section: string
          session_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          role?: string
          section?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "follow_up_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "reflection_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      mini_snapshots: {
        Row: {
          changed_sections: Json
          continuation_id: string
          created_at: string
          id: string
          insights: Json
          mode: string
          session_id: string
          summary: string
          title: string
        }
        Insert: {
          changed_sections?: Json
          continuation_id: string
          created_at?: string
          id?: string
          insights?: Json
          mode: string
          session_id: string
          summary?: string
          title: string
        }
        Update: {
          changed_sections?: Json
          continuation_id?: string
          created_at?: string
          id?: string
          insights?: Json
          mode?: string
          session_id?: string
          summary?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "mini_snapshots_continuation_id_fkey"
            columns: ["continuation_id"]
            isOneToOne: false
            referencedRelation: "continuation_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      misunderstanding_repairs: {
        Row: {
          clarification: string
          context_patch: Json
          created_at: string
          hypothesis: string
          id: string
          interpretations: Json
          question_index: number
          question_text: string
          resolved: boolean
          session_id: string
        }
        Insert: {
          clarification?: string
          context_patch?: Json
          created_at?: string
          hypothesis?: string
          id?: string
          interpretations?: Json
          question_index: number
          question_text: string
          resolved?: boolean
          session_id: string
        }
        Update: {
          clarification?: string
          context_patch?: Json
          created_at?: string
          hypothesis?: string
          id?: string
          interpretations?: Json
          question_index?: number
          question_text?: string
          resolved?: boolean
          session_id?: string
        }
        Relationships: []
      }
      pattern_identities: {
        Row: {
          communication_tendency: string
          created_at: string
          emotional_signature: string
          growth_edge: string
          id: string
          long_description: string
          name: string
          short_description: string
          slug: string
        }
        Insert: {
          communication_tendency?: string
          created_at?: string
          emotional_signature?: string
          growth_edge?: string
          id?: string
          long_description?: string
          name: string
          short_description: string
          slug: string
        }
        Update: {
          communication_tendency?: string
          created_at?: string
          emotional_signature?: string
          growth_edge?: string
          id?: string
          long_description?: string
          name?: string
          short_description?: string
          slug?: string
        }
        Relationships: []
      }
      patterns: {
        Row: {
          created_at: string
          emotional_meaning: string
          id: string
          name: string
          other_person_tip: string
          short_description: string
          slug: string
        }
        Insert: {
          created_at?: string
          emotional_meaning: string
          id?: string
          name: string
          other_person_tip: string
          short_description: string
          slug: string
        }
        Update: {
          created_at?: string
          emotional_meaning?: string
          id?: string
          name?: string
          other_person_tip?: string
          short_description?: string
          slug?: string
        }
        Relationships: []
      }
      pe_heatmap_cells: {
        Row: {
          cell_date: string
          dominant_pattern_type: string | null
          id: string
          intensity_score: number
          pattern_count: number
          updated_at: string
          user_id: string
        }
        Insert: {
          cell_date: string
          dominant_pattern_type?: string | null
          id?: string
          intensity_score?: number
          pattern_count?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          cell_date?: string
          dominant_pattern_type?: string | null
          id?: string
          intensity_score?: number
          pattern_count?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      pe_identity_profile: {
        Row: {
          attachment_signals: Json
          blind_spots: Json
          communication_baseline: Json
          conflict_role_baseline: Json
          emotional_baseline: Json
          last_updated_at: string
          narrative_md: string | null
          recurring_triggers: Json
          strengths: Json
          user_id: string
          version: number
          vulnerabilities: Json
        }
        Insert: {
          attachment_signals?: Json
          blind_spots?: Json
          communication_baseline?: Json
          conflict_role_baseline?: Json
          emotional_baseline?: Json
          last_updated_at?: string
          narrative_md?: string | null
          recurring_triggers?: Json
          strengths?: Json
          user_id: string
          version?: number
          vulnerabilities?: Json
        }
        Update: {
          attachment_signals?: Json
          blind_spots?: Json
          communication_baseline?: Json
          conflict_role_baseline?: Json
          emotional_baseline?: Json
          last_updated_at?: string
          narrative_md?: string | null
          recurring_triggers?: Json
          strengths?: Json
          user_id?: string
          version?: number
          vulnerabilities?: Json
        }
        Relationships: []
      }
      pe_identity_profile_history: {
        Row: {
          created_at: string
          id: string
          narrative_md: string | null
          snapshot: Json
          user_id: string
          version: number
        }
        Insert: {
          created_at?: string
          id?: string
          narrative_md?: string | null
          snapshot?: Json
          user_id: string
          version: number
        }
        Update: {
          created_at?: string
          id?: string
          narrative_md?: string | null
          snapshot?: Json
          user_id?: string
          version?: number
        }
        Relationships: []
      }
      pe_job_runs: {
        Row: {
          completed_at: string | null
          details: Json
          error_message: string | null
          id: string
          job_name: string
          source_answer_id: string | null
          started_at: string
          status: string
          triggered_by: string
          user_id: string | null
        }
        Insert: {
          completed_at?: string | null
          details?: Json
          error_message?: string | null
          id?: string
          job_name: string
          source_answer_id?: string | null
          started_at?: string
          status?: string
          triggered_by?: string
          user_id?: string | null
        }
        Update: {
          completed_at?: string | null
          details?: Json
          error_message?: string | null
          id?: string
          job_name?: string
          source_answer_id?: string | null
          started_at?: string
          status?: string
          triggered_by?: string
          user_id?: string | null
        }
        Relationships: []
      }
      pe_macro_frequency: {
        Row: {
          id: string
          last_seen_at: string | null
          pattern_label: string
          pattern_type: string
          raw_count: number
          updated_at: string
          user_id: string
          weighted_score: number
        }
        Insert: {
          id?: string
          last_seen_at?: string | null
          pattern_label: string
          pattern_type: string
          raw_count?: number
          updated_at?: string
          user_id: string
          weighted_score?: number
        }
        Update: {
          id?: string
          last_seen_at?: string | null
          pattern_label?: string
          pattern_type?: string
          raw_count?: number
          updated_at?: string
          user_id?: string
          weighted_score?: number
        }
        Relationships: []
      }
      pe_macro_patterns: {
        Row: {
          confidence: number
          created_at: string
          id: string
          pattern_label: string
          pattern_type: string
          payload: Json
          source_answer_ids: string[]
          user_id: string
        }
        Insert: {
          confidence?: number
          created_at?: string
          id?: string
          pattern_label: string
          pattern_type: string
          payload?: Json
          source_answer_ids?: string[]
          user_id: string
        }
        Update: {
          confidence?: number
          created_at?: string
          id?: string
          pattern_label?: string
          pattern_type?: string
          payload?: Json
          source_answer_ids?: string[]
          user_id?: string
        }
        Relationships: []
      }
      pe_markers: {
        Row: {
          answer_id: string
          certainty: number | null
          created_at: string
          id: string
          intensity: number
          kind: string
          payload: Json
          session_id: string
          subtype: string
          user_id: string
          valence: number | null
        }
        Insert: {
          answer_id: string
          certainty?: number | null
          created_at?: string
          id?: string
          intensity?: number
          kind: string
          payload?: Json
          session_id: string
          subtype: string
          user_id: string
          valence?: number | null
        }
        Update: {
          answer_id?: string
          certainty?: number | null
          created_at?: string
          id?: string
          intensity?: number
          kind?: string
          payload?: Json
          session_id?: string
          subtype?: string
          user_id?: string
          valence?: number | null
        }
        Relationships: []
      }
      pe_pattern_clusters: {
        Row: {
          cluster_label: string
          cluster_summary: string
          cohesion_score: number
          created_at: string
          id: string
          last_updated_at: string
          member_pattern_ids: string[]
          user_id: string
        }
        Insert: {
          cluster_label: string
          cluster_summary?: string
          cohesion_score?: number
          created_at?: string
          id?: string
          last_updated_at?: string
          member_pattern_ids?: string[]
          user_id: string
        }
        Update: {
          cluster_label?: string
          cluster_summary?: string
          cohesion_score?: number
          created_at?: string
          id?: string
          last_updated_at?: string
          member_pattern_ids?: string[]
          user_id?: string
        }
        Relationships: []
      }
      pe_pattern_frequency: {
        Row: {
          count: number
          tag_key: string
          trend: string
          user_id: string
          weighted_score: number
          window_end: string
          window_start: string
        }
        Insert: {
          count?: number
          tag_key: string
          trend?: string
          user_id: string
          weighted_score?: number
          window_end: string
          window_start: string
        }
        Update: {
          count?: number
          tag_key?: string
          trend?: string
          user_id?: string
          weighted_score?: number
          window_end?: string
          window_start?: string
        }
        Relationships: []
      }
      pe_pattern_tags: {
        Row: {
          answer_id: string
          category: string
          cluster_id: string | null
          confidence: number
          created_at: string
          evidence_snippets: Json
          id: string
          intensity: number
          session_id: string
          tag_key: string
          tag_label: string
          user_id: string
        }
        Insert: {
          answer_id: string
          category: string
          cluster_id?: string | null
          confidence?: number
          created_at?: string
          evidence_snippets?: Json
          id?: string
          intensity?: number
          session_id: string
          tag_key: string
          tag_label: string
          user_id: string
        }
        Update: {
          answer_id?: string
          category?: string
          cluster_id?: string | null
          confidence?: number
          created_at?: string
          evidence_snippets?: Json
          id?: string
          intensity?: number
          session_id?: string
          tag_key?: string
          tag_label?: string
          user_id?: string
        }
        Relationships: []
      }
      pe_psych_profile: {
        Row: {
          blind_spots: Json
          last_updated: string
          profile_version: number
          recurring_conflicts: Json
          recurring_loops: Json
          recurring_roles: Json
          self_perception: Json
          strengths: Json
          unmet_needs: Json
          user_id: string
          vulnerabilities: Json
          what_ai_notices: Json
        }
        Insert: {
          blind_spots?: Json
          last_updated?: string
          profile_version?: number
          recurring_conflicts?: Json
          recurring_loops?: Json
          recurring_roles?: Json
          self_perception?: Json
          strengths?: Json
          unmet_needs?: Json
          user_id: string
          vulnerabilities?: Json
          what_ai_notices?: Json
        }
        Update: {
          blind_spots?: Json
          last_updated?: string
          profile_version?: number
          recurring_conflicts?: Json
          recurring_loops?: Json
          recurring_roles?: Json
          self_perception?: Json
          strengths?: Json
          unmet_needs?: Json
          user_id?: string
          vulnerabilities?: Json
          what_ai_notices?: Json
        }
        Relationships: []
      }
      pe_snapshots: {
        Row: {
          answer_id: string
          behavioral_tendencies: string[]
          communication_style: string | null
          created_at: string
          id: string
          loop_id: string | null
          model: string | null
          narrative_md: string | null
          primary_pattern_id: string
          secondary_pattern_ids: string[]
          sections: Json
          session_id: string
          status: string
          user_id: string
        }
        Insert: {
          answer_id: string
          behavioral_tendencies?: string[]
          communication_style?: string | null
          created_at?: string
          id?: string
          loop_id?: string | null
          model?: string | null
          narrative_md?: string | null
          primary_pattern_id: string
          secondary_pattern_ids?: string[]
          sections?: Json
          session_id: string
          status?: string
          user_id: string
        }
        Update: {
          answer_id?: string
          behavioral_tendencies?: string[]
          communication_style?: string | null
          created_at?: string
          id?: string
          loop_id?: string | null
          model?: string | null
          narrative_md?: string | null
          primary_pattern_id?: string
          secondary_pattern_ids?: string[]
          sections?: Json
          session_id?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      pe_timeline_events: {
        Row: {
          created_at: string
          detail: Json
          event_date: string
          event_type: string
          id: string
          linked_pattern_ids: string[]
          short_label: string
          summary: string
          user_id: string
        }
        Insert: {
          created_at?: string
          detail?: Json
          event_date?: string
          event_type: string
          id?: string
          linked_pattern_ids?: string[]
          short_label: string
          summary?: string
          user_id: string
        }
        Update: {
          created_at?: string
          detail?: Json
          event_date?: string
          event_type?: string
          id?: string
          linked_pattern_ids?: string[]
          short_label?: string
          summary?: string
          user_id?: string
        }
        Relationships: []
      }
      question_history: {
        Row: {
          created_at: string
          depth: number
          id: string
          question_index: number
          question_text: string
          rationale: string
          session_id: string
          target_fields: string[]
        }
        Insert: {
          created_at?: string
          depth?: number
          id?: string
          question_index: number
          question_text: string
          rationale?: string
          session_id: string
          target_fields?: string[]
        }
        Update: {
          created_at?: string
          depth?: number
          id?: string
          question_index?: number
          question_text?: string
          rationale?: string
          session_id?: string
          target_fields?: string[]
        }
        Relationships: []
      }
      reflection_answers: {
        Row: {
          answer_text: string
          created_at: string
          depth: number
          id: string
          min_chars: number
          pe_analysis_version: number | null
          pe_analyzed_at: string | null
          question_index: number
          question_text: string
          question_type: string
          session_id: string
          sufficiency_score: number | null
          targeted_fields: string[]
        }
        Insert: {
          answer_text: string
          created_at?: string
          depth?: number
          id?: string
          min_chars?: number
          pe_analysis_version?: number | null
          pe_analyzed_at?: string | null
          question_index: number
          question_text: string
          question_type?: string
          session_id: string
          sufficiency_score?: number | null
          targeted_fields?: string[]
        }
        Update: {
          answer_text?: string
          created_at?: string
          depth?: number
          id?: string
          min_chars?: number
          pe_analysis_version?: number | null
          pe_analyzed_at?: string | null
          question_index?: number
          question_text?: string
          question_type?: string
          session_id?: string
          sufficiency_score?: number | null
          targeted_fields?: string[]
        }
        Relationships: [
          {
            foreignKeyName: "reflection_answers_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "reflection_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      reflection_sessions: {
        Row: {
          completed_at: string | null
          created_at: string
          deleted_at: string | null
          engine_version: string
          folder_id: string | null
          id: string
          pattern_identity_id: string | null
          share_token: string | null
          snapshot: string | null
          snapshot_json: Json | null
          status: string
          title: string
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          deleted_at?: string | null
          engine_version?: string
          folder_id?: string | null
          id?: string
          pattern_identity_id?: string | null
          share_token?: string | null
          snapshot?: string | null
          snapshot_json?: Json | null
          status?: string
          title?: string
          user_id: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          deleted_at?: string | null
          engine_version?: string
          folder_id?: string | null
          id?: string
          pattern_identity_id?: string | null
          share_token?: string | null
          snapshot?: string | null
          snapshot_json?: Json | null
          status?: string
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reflection_sessions_folder_id_fkey"
            columns: ["folder_id"]
            isOneToOne: false
            referencedRelation: "folders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reflection_sessions_pattern_identity_id_fkey"
            columns: ["pattern_identity_id"]
            isOneToOne: false
            referencedRelation: "pattern_identities"
            referencedColumns: ["id"]
          },
        ]
      }
      safety_events: {
        Row: {
          acknowledged: boolean
          category: string
          created_at: string
          id: string
          matched_terms: string[]
          session_id: string | null
          severity: string
          shown: boolean
          source: string
          user_id: string
        }
        Insert: {
          acknowledged?: boolean
          category: string
          created_at?: string
          id?: string
          matched_terms?: string[]
          session_id?: string | null
          severity?: string
          shown?: boolean
          source?: string
          user_id: string
        }
        Update: {
          acknowledged?: boolean
          category?: string
          created_at?: string
          id?: string
          matched_terms?: string[]
          session_id?: string | null
          severity?: string
          shown?: boolean
          source?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "safety_events_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "reflection_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      session_context_models: {
        Row: {
          coverage_map: Json
          created_at: string
          desired_outcome: string
          emotions: Json
          expectations: Json
          fears: Json
          history: Json
          id: string
          intentions: Json
          relationships: Json
          saturation_score: number
          session_id: string
          situation: string
          triggers: Json
          unspoken_needs: Json
          updated_at: string
        }
        Insert: {
          coverage_map?: Json
          created_at?: string
          desired_outcome?: string
          emotions?: Json
          expectations?: Json
          fears?: Json
          history?: Json
          id?: string
          intentions?: Json
          relationships?: Json
          saturation_score?: number
          session_id: string
          situation?: string
          triggers?: Json
          unspoken_needs?: Json
          updated_at?: string
        }
        Update: {
          coverage_map?: Json
          created_at?: string
          desired_outcome?: string
          emotions?: Json
          expectations?: Json
          fears?: Json
          history?: Json
          id?: string
          intentions?: Json
          relationships?: Json
          saturation_score?: number
          session_id?: string
          situation?: string
          triggers?: Json
          unspoken_needs?: Json
          updated_at?: string
        }
        Relationships: []
      }
      session_patterns: {
        Row: {
          confidence: number
          created_at: string
          id: string
          pattern_id: string
          reason: string | null
          session_id: string
        }
        Insert: {
          confidence?: number
          created_at?: string
          id?: string
          pattern_id: string
          reason?: string | null
          session_id: string
        }
        Update: {
          confidence?: number
          created_at?: string
          id?: string
          pattern_id?: string
          reason?: string | null
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "session_patterns_pattern_id_fkey"
            columns: ["pattern_id"]
            isOneToOne: false
            referencedRelation: "patterns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "session_patterns_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "reflection_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      shared_snapshots: {
        Row: {
          created_at: string
          id: string
          image_path: string | null
          observations: Json
          possible_paths: Json
          session_id: string
          summary: string
          title: string
          token: string
          user_id: string
          variant: string
          view_count: number
        }
        Insert: {
          created_at?: string
          id?: string
          image_path?: string | null
          observations?: Json
          possible_paths?: Json
          session_id: string
          summary: string
          title: string
          token: string
          user_id: string
          variant?: string
          view_count?: number
        }
        Update: {
          created_at?: string
          id?: string
          image_path?: string | null
          observations?: Json
          possible_paths?: Json
          session_id?: string
          summary?: string
          title?: string
          token?: string
          user_id?: string
          variant?: string
          view_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "shared_snapshots_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "reflection_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      snapshot_versions: {
        Row: {
          common_misunderstandings: Json
          created_at: string
          disclaimer: string
          how_to_communicate: Json
          id: string
          observations: Json
          possible_paths: Json
          recommended_next_steps: Json
          session_id: string
          summary: string
          version_number: number
        }
        Insert: {
          common_misunderstandings?: Json
          created_at?: string
          disclaimer?: string
          how_to_communicate?: Json
          id?: string
          observations?: Json
          possible_paths?: Json
          recommended_next_steps?: Json
          session_id: string
          summary: string
          version_number?: number
        }
        Update: {
          common_misunderstandings?: Json
          created_at?: string
          disclaimer?: string
          how_to_communicate?: Json
          id?: string
          observations?: Json
          possible_paths?: Json
          recommended_next_steps?: Json
          session_id?: string
          summary?: string
          version_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "snapshot_versions_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "reflection_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          cancel_at_period_end: boolean
          created_at: string
          current_period_end: string | null
          environment: string
          id: string
          price_id: string | null
          product_id: string | null
          status: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end?: string | null
          environment?: string
          id?: string
          price_id?: string | null
          product_id?: string | null
          status: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end?: string | null
          environment?: string
          id?: string
          price_id?: string | null
          product_id?: string | null
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      two_person_perspectives: {
        Row: {
          created_at: string
          display_name: string | null
          id: string
          perspective_text: string
          session_id: string
          side: string
          suggested_rewrite: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          id?: string
          perspective_text: string
          session_id: string
          side: string
          suggested_rewrite?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          id?: string
          perspective_text?: string
          session_id?: string
          side?: string
          suggested_rewrite?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "two_person_perspectives_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "two_person_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      two_person_sessions: {
        Row: {
          combined_summary: string | null
          completed_at: string | null
          created_at: string
          deleted_at: string | null
          id: string
          invite_token: string
          misread_points: Json
          owner_id: string
          shared_themes: Json
          status: string
          topic: string
        }
        Insert: {
          combined_summary?: string | null
          completed_at?: string | null
          created_at?: string
          deleted_at?: string | null
          id?: string
          invite_token: string
          misread_points?: Json
          owner_id: string
          shared_themes?: Json
          status?: string
          topic: string
        }
        Update: {
          combined_summary?: string | null
          completed_at?: string | null
          created_at?: string
          deleted_at?: string | null
          id?: string
          invite_token?: string
          misread_points?: Json
          owner_id?: string
          shared_themes?: Json
          status?: string
          topic?: string
        }
        Relationships: []
      }
      user_profiles: {
        Row: {
          clarity_plus_intro_dismissed: boolean
          created_at: string
          ftue_a_completed: boolean
          ftue_a_completed_at: string | null
          ftue_b_last_shown_at: string | null
          ftue_enabled: boolean
          identity_seed: string | null
          identity_seed_at: string | null
          tour_completed: boolean
          tour_completed_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          clarity_plus_intro_dismissed?: boolean
          created_at?: string
          ftue_a_completed?: boolean
          ftue_a_completed_at?: string | null
          ftue_b_last_shown_at?: string | null
          ftue_enabled?: boolean
          identity_seed?: string | null
          identity_seed_at?: string | null
          tour_completed?: boolean
          tour_completed_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          clarity_plus_intro_dismissed?: boolean
          created_at?: string
          ftue_a_completed?: boolean
          ftue_a_completed_at?: string | null
          ftue_b_last_shown_at?: string | null
          ftue_enabled?: boolean
          identity_seed?: string | null
          identity_seed_at?: string | null
          tour_completed?: boolean
          tour_completed_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_pattern_identity_stats: {
        Args: { _identity_id: string }
        Returns: {
          identity_count: number
          total_count: number
        }[]
      }
      get_pattern_stats: {
        Args: { _days?: number; _pattern_id: string }
        Returns: {
          pattern_count: number
          total_count: number
        }[]
      }
      get_two_person_session_by_token: {
        Args: { _token: string }
        Returns: {
          created_at: string
          has_invitee_perspective: boolean
          has_owner_perspective: boolean
          id: string
          status: string
          topic: string
        }[]
      }
      get_user_activity_timeline: {
        Args: { _days?: number; _user_id: string }
        Returns: {
          day: string
          session_count: number
        }[]
      }
      get_user_pattern_counts: {
        Args: { _user_id: string }
        Returns: {
          last_matched_at: string
          match_count: number
          name: string
          pattern_id: string
          short_description: string
          slug: string
        }[]
      }
      get_user_summary_stats: {
        Args: { _user_id: string }
        Returns: {
          completed_sessions: number
          current_streak_days: number
          total_patterns_matched: number
          total_sessions: number
          total_shared: number
          unique_patterns: number
        }[]
      }
      submit_invitee_perspective: {
        Args: {
          _display_name: string
          _perspective_text: string
          _token: string
        }
        Returns: string
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
