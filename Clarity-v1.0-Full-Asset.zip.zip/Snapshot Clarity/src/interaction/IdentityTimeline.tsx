import { useIdentityHistory } from "@/hooks/usePatternData";
import { PremiumGate } from "@/premium/PremiumGate";

export function IdentityTimeline() {
  return (
    <PremiumGate feature="identity_timeline">
      <IdentityTimelineInner />
    </PremiumGate>
  );
}

function IdentityTimelineInner() {
  const { data, isLoading, error } = useIdentityHistory();

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading…</p>;
  if (error) return <p className="text-sm text-muted-foreground">Couldn't load timeline.</p>;
  if (!data || data.length === 0) {
    return (
      <p className="text-sm italic" style={{ color: "#5A524A" }}>
        Your identity timeline will fill in as you reflect over time.
      </p>
    );
  }

  return (
    <div className="overflow-x-auto">
      <ol className="flex min-w-full items-stretch gap-4 pb-4">
        {data.map((node) => {
          const date = new Date(node.created_at).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
          const snap = (node.snapshot ?? {}) as Record<string, unknown>;
          const rawTraits = Array.isArray(snap.strengths)
            ? (snap.strengths as unknown[])
            : Array.isArray(snap.traits)
              ? (snap.traits as unknown[])
              : [];
          const traits = rawTraits.slice(0, 3).map((t) => String(t));
          const label = `Version ${node.version}`;
          const summary = node.narrative_md
            ? node.narrative_md.split("\n").find((l) => l.trim().length > 0) ?? ""
            : "";
          return (
            <li key={node.id}
              className="group relative w-48 shrink-0 rounded-[14px] p-3"
              style={{ background: "#FAF5EC", border: "1px solid #EBDFCB", color: "#2A2520" }}
            >
              <div className="text-[10px] uppercase tracking-[0.18em]" style={{ color: "#5E7A60" }}>{date}</div>
              <div className="mt-1 text-sm font-medium">{label}</div>
              {summary ? (
                <p className="mt-1 line-clamp-3 text-xs" style={{ color: "#5A524A" }}>{summary}</p>
              ) : null}
              {traits.length > 0 ? (
                <ul className="mt-2 space-y-0.5 text-xs" style={{ color: "#5A524A" }}>
                  {traits.map((t) => <li key={t}>• {t}</li>)}
                </ul>
              ) : null}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
