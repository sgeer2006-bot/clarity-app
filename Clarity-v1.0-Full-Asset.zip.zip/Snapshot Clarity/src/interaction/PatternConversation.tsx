import { useMemo, useState } from "react";
import avoidance from "@/scripts/pattern_conversations/avoidance_loop_v1.json";
import overApol from "@/scripts/pattern_conversations/over_apologizing_v1.json";
import conflictFreeze from "@/scripts/pattern_conversations/conflict_freeze_v1.json";
import rumination from "@/scripts/pattern_conversations/rumination_v1.json";
import { recordEvent } from "@/lib/identity";
import { MicroContinuation } from "@/components/habit/MicroContinuation";

interface ScriptNode {
  prompt: string;
  options: { label: string; next: string }[];
}
interface Script {
  id: string;
  title: string;
  nodes: Record<string, ScriptNode>;
}

const SCRIPTS: Record<string, Script> = {
  avoidance_loop_v1: avoidance as Script,
  over_apologizing_v1: overApol as Script,
  conflict_freeze_v1: conflictFreeze as Script,
  rumination_v1: rumination as Script,
};

export function PatternConversation({ scriptId }: { scriptId: string }) {
  const script = SCRIPTS[scriptId];
  const [currentId, setCurrentId] = useState("start");
  const [path, setPath] = useState<string[]>([]);

  const node = script?.nodes[currentId];
  const terminal = useMemo(() => !!node && node.options.length === 0, [node]);

  if (!script) {
    return <p className="text-xs italic text-muted-foreground">Reflection unavailable.</p>;
  }

  const choose = (label: string, next: string) => {
    const newPath = [...path, label];
    setPath(newPath);
    setCurrentId(next);
    if (!script.nodes[next] || script.nodes[next].options.length === 0) {
      try {
        const ts = Date.now();
        localStorage.setItem(
          `clarity.pc.${scriptId}.${ts}`,
          JSON.stringify({ scriptId, path: newPath, at: ts })
        );
      } catch { /* ignore */ }
      recordEvent({
        source: "pattern_conversation",
        tags: { cognitive: [`pc_completed:${scriptId}`] },
      });
    }
  };

  return (
    <div className="rounded-[14px] p-4" style={{ background: "#FAF5EC", border: "1px solid #EBDFCB" }}>
      <div className="text-xs uppercase tracking-[0.18em]" style={{ color: "#5E7A60" }}>
        {script.title}
      </div>
      <p className="mt-2 text-sm leading-relaxed" style={{ color: "#2A2520" }}>
        {node?.prompt}
      </p>
      {terminal ? (
        <div className="mt-3 space-y-3">
          <div className="text-xs italic" style={{ color: "#5A524A" }}>End of reflection.</div>
          <MicroContinuation ctx={{ lastActionType: "pattern_conversation_completed" }} />
        </div>
      ) : (
        <div className="mt-3 flex flex-col gap-2">
          {node?.options.map((opt) => (
            <button
              key={opt.label}
              onClick={() => choose(opt.label, opt.next)}
              className="rounded-full border px-3 py-1.5 text-left text-sm transition-colors"
              style={{ borderColor: "#A8BBA1", color: "#2A2520", background: "#F4ECE0" }}
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
