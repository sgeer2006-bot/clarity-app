import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { recordEvent } from "@/lib/identity";

const KEY = (id: string) => `clarity.mr.${id}`;

export function MicroReflection({ insightId }: { insightId: string }) {
  const [text, setText] = useState("");
  const [saved, setSaved] = useState<string | null>(null);
  const [enabled, setEnabled] = useState(true);

  useEffect(() => {
    if (typeof window === "undefined") return;
    setEnabled(localStorage.getItem("clarity.flags.microReflections") !== "false");
    setSaved(localStorage.getItem(KEY(insightId)));
  }, [insightId]);

  if (!enabled) return null;

  const save = () => {
    if (!text.trim()) return;
    localStorage.setItem(KEY(insightId), text.trim());
    setSaved(text.trim());
    const value = text.trim();
    setText("");
    window.dispatchEvent(new CustomEvent("clarity:micro-reflection", {
      detail: { insightId, text: value },
    }));
    recordEvent({
      source: "micro_reflection",
      tags: { cognitive: ["micro_reflection_saved"] },
      text: value,
    });
  };

  return (
    <div className="mt-3 space-y-2">
      {saved ? (
        <p className="text-xs italic" style={{ color: "#5E7A60" }}>Your reflection: "{saved}"</p>
      ) : null}
      <div className="flex gap-2">
        <Input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="A short reflection (optional)"
          className="h-9 text-sm"
        />
        <Button
          variant="ghost"
          size="sm"
          onClick={save}
          disabled={!text.trim()}
          style={{ color: "#5E7A60" }}
        >
          Save
        </Button>
      </div>
    </div>
  );
}
