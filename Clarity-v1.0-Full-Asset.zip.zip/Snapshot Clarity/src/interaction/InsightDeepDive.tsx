import { useEffect, useState } from "react";
import { ChevronDown } from "lucide-react";
import { PremiumGate } from "@/premium/PremiumGate";
import { recordEvent } from "@/lib/identity";

interface InsightLike {
  id?: string;
  rationale?: string;
  sources?: { id?: string; type?: string; date?: string; href?: string; label?: string }[];
}

export function InsightDeepDive({ insight }: { insight: InsightLike }) {
  const [open, setOpen] = useState(false);
  const [enabled, setEnabled] = useState(true);

  useEffect(() => {
    if (typeof window === "undefined") return;
    setEnabled(localStorage.getItem("clarity.flags.deepDivePanels") !== "false");
  }, []);

  if (!enabled) return null;

  return (
    <PremiumGate feature="deep_dive_insights" fallback={null}>
      <div className="mt-3 rounded-[12px]" style={{ background: "#F4ECE0" }}>
        <button
          type="button"
          onClick={() => {
            setOpen((o) => {
              const next = !o;
              if (next) {
                recordEvent({
                  source: "manual",
                  tags: { cognitive: ["insight_deep_dive_opened"] },
                });
              }
              return next;
            });
          }}
          className="flex w-full items-center justify-between px-3 py-2 text-left text-xs"
          style={{ color: "#5E7A60" }}
        >
          <span className="uppercase tracking-[0.18em]">Deep dive</span>
          <ChevronDown className={`h-3.5 w-3.5 transition-transform ${open ? "rotate-180" : ""}`} />
        </button>
        {open ? (
          <div className="space-y-3 px-3 pb-3 text-sm" style={{ color: "#2A2520" }}>
            <section>
              <h4 className="text-xs uppercase tracking-[0.12em]" style={{ color: "#5E7A60" }}>
                Why this insight was generated
              </h4>
              <p className="mt-1 leading-relaxed" style={{ color: "#5A524A" }}>
                {insight.rationale || "No rationale recorded for this insight."}
              </p>
            </section>
            <section>
              <h4 className="text-xs uppercase tracking-[0.12em]" style={{ color: "#5E7A60" }}>
                Data sources
              </h4>
              {insight.sources && insight.sources.length > 0 ? (
                <ul className="mt-1 space-y-1 text-xs" style={{ color: "#5A524A" }}>
                  {insight.sources.map((s, i) => (
                    <li key={s.id ?? i}>
                      {s.href ? (
                        <a href={s.href} className="underline">{s.label ?? s.type ?? s.id}</a>
                      ) : (
                        <span>{s.label ?? s.type ?? s.id}</span>
                      )}
                      {s.date ? <span> · {s.date}</span> : null}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-1 text-xs italic" style={{ color: "#5A524A" }}>
                  No source items recorded.
                </p>
              )}
            </section>
          </div>
        ) : null}
      </div>
    </PremiumGate>
  );
}
