import type { EmotionalLoop } from "@/pattern-engine/types";

export function LoopRing({ loop }: { loop: EmotionalLoop }) {
  const stages = loop.stages.slice(0, 6);
  const n = stages.length;
  if (n === 0) return null;
  const radius = 78;
  const cx = 110;
  const cy = 110;

  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 220 220" className="h-56 w-56">
        <circle cx={cx} cy={cy} r={radius} fill="none" stroke="hsl(var(--border))" strokeWidth="1.5" strokeDasharray="4 4" />
        {stages.map((s, i) => {
          const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
          const x = cx + Math.cos(angle) * radius;
          const y = cy + Math.sin(angle) * radius;
          return (
            <g key={i}>
              <circle cx={x} cy={y} r={i === 0 ? 12 : 9} fill="hsl(var(--primary))" opacity={i === 0 ? 1 : 0.55}>
                {i === 0 && (
                  <animate attributeName="r" values="12;14;12" dur="2.4s" repeatCount="indefinite" />
                )}
              </circle>
              <text
                x={x}
                y={y + (y > cy ? 24 : -16)}
                textAnchor="middle"
                className="fill-foreground text-[10px] font-medium"
              >
                {s.emotion}
              </text>
            </g>
          );
        })}
      </svg>
      <p className="text-sm text-muted-foreground mt-2 text-center max-w-xs">{loop.label}</p>
    </div>
  );
}
