import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Props {
  label: string;
  category: string;
  intensity?: number;
  trend?: "rising" | "falling" | "stable" | "new";
  summary?: string;
}

export function PatternCard({ label, category, intensity = 0.6, trend, summary }: Props) {
  const ringPct = Math.round(intensity * 100);
  const trendGlyph = trend === "rising" ? "↑" : trend === "falling" ? "↓" : trend === "new" ? "✦" : "·";

  return (
    <Card className="p-4 flex gap-4 items-start hover:shadow-[var(--shadow-elevated)] transition-shadow">
      <div className="relative h-12 w-12 shrink-0">
        <svg viewBox="0 0 36 36" className="h-12 w-12 -rotate-90">
          <circle cx="18" cy="18" r="15.9" fill="none" stroke="hsl(var(--muted))" strokeWidth="2.5" />
          <circle
            cx="18" cy="18" r="15.9" fill="none"
            stroke="hsl(var(--primary))" strokeWidth="2.5"
            strokeDasharray={`${ringPct}, 100`}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center text-xs font-medium text-primary">
          {trendGlyph}
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="font-medium text-sm leading-tight">{label}</h3>
          <Badge variant="secondary" className="text-[10px] uppercase tracking-wide">{category}</Badge>
        </div>
        {summary && <p className="text-sm text-muted-foreground leading-snug">{summary}</p>}
      </div>
    </Card>
  );
}
