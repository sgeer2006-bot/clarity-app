/**
 * Fallback Question Wrapper
 *
 * Engine-safe, additive wrapper around Questions (Reflection Engine).
 *
 * When the centralized Capability Detection Layer signals `lowContext` or
 * `shortAnswer`, this wrapper presents an adaptive fallback question type
 * (yes/no, multiple choice, pick one, or closest match) using the centralized
 * tone templates. The user's selection is converted to the engine's existing
 * accepted answer shape (a plain string) and submitted through the engine's
 * existing submission path — so summaries, Insights, continuation, and
 * identity modeling consume it identically to a typed answer.
 *
 * IMPORTANT — engine answer shape:
 *   The Reflection Engine today accepts a plain string (`answer_text: value`).
 *   It does NOT accept an answer object with extra fields. Per spec, when the
 *   engine rejects unknown fields, this wrapper must omit `source` rather than
 *   break submission. So we submit a plain string.
 *
 * This wrapper:
 *   - Reads CapabilitySignals from the existing detection layer (read-only).
 *   - Does NOT modify the detection layer, the tone templates, or the engine.
 *   - Does NOT change which question is asked, branch, skip, or alter the
 *     question sequence.
 *   - Does NOT persist anything outside the engine's existing submission path.
 *   - Does NOT remove or hide the existing free-text input — fallback options
 *     sit alongside it. The user can always type a custom answer.
 *   - Is additive: if removed, the engine behaves exactly as today.
 *   - No analytics, no gating, no routing, no new screens.
 */

import { Button } from "@/components/ui/button";
import type { QuestionType } from "@/lib/types";
import type { CapabilitySignals } from "@/lib/questions/capabilityDetection";
import {
  QUESTION_TONE_TEMPLATES,
  getToneLine,
} from "@/lib/questions/toneTemplates";

export type FallbackKind = "yesno" | "multiple" | "pickone" | "closest";

export interface FallbackQuestionWrapperProps {
  /** The current question text (read-only, used to choose closest-match paraphrases). */
  question: string;
  /** The current engine question type, if known. Drives binary detection. */
  questionType?: QuestionType;
  /**
   * Optional candidate options the engine already provides for this question
   * (e.g. predefined choices). When present and non-empty, the wrapper renders
   * multiple choice / pick one over these.
   */
  candidates?: string[];
  /** Latest signals from the Capability Detection Layer. */
  signals: CapabilitySignals;
  /**
   * The engine's existing answer submission entry point. The wrapper calls
   * this with a plain string — the same shape the engine accepts today.
   */
  onSubmit: (value: string) => void | Promise<void>;
  /** Disable the fallback controls (e.g. while submitting). */
  disabled?: boolean;
}

// ---------- Fallback type selection ----------

function isBinaryQuestion(question: string, questionType?: QuestionType): boolean {
  if (questionType === "yesno") return true;
  const q = question.trim().toLowerCase();
  if (!q) return false;
  return /^(do|did|does|are|is|was|were|can|could|would|will|have|has|had|should|am)\b/.test(q);
}

export function chooseFallbackKind(
  question: string,
  questionType: QuestionType | undefined,
  candidates: string[] | undefined,
): FallbackKind {
  const hasCandidates = Array.isArray(candidates) && candidates.length > 0;
  if (hasCandidates) {
    return (candidates as string[]).length > 5 ? "pickone" : "multiple";
  }
  if (isBinaryQuestion(question, questionType)) return "yesno";
  // Open-ended, no candidates → closest match if we have safe paraphrases,
  // otherwise default to yes/no per spec.
  const paraphrases = closestMatchOptions();
  return paraphrases.length > 0 ? "closest" : "yesno";
}

/**
 * Safe, generic paraphrases sourced ONLY from the centralized tone templates.
 * Per spec: do not invent new template categories — if a needed phrase is not
 * present, omit that fallback rather than adding to the templates here.
 */
function closestMatchOptions(): string[] {
  const simplify = QUESTION_TONE_TEMPLATES.simplify ?? [];
  const transitions = QUESTION_TONE_TEMPLATES.fallbackTransitions ?? [];
  // Use existing template strings as the displayed paraphrase choices.
  const merged = [...simplify, ...transitions];
  // Deduplicate while preserving order; cap to a small set.
  const seen = new Set<string>();
  const out: string[] = [];
  for (const s of merged) {
    if (!seen.has(s)) {
      seen.add(s);
      out.push(s);
      if (out.length >= 4) break;
    }
  }
  return out;
}

// ---------- Component ----------

export function FallbackQuestionWrapper({
  question,
  questionType,
  candidates,
  signals,
  onSubmit,
  disabled,
}: FallbackQuestionWrapperProps) {
  const active = signals.lowContext || signals.shortAnswer;
  if (!active) return null;

  const kind = chooseFallbackKind(question, questionType, candidates);

  // Build the option list for the chosen kind.
  let options: string[];
  switch (kind) {
    case "yesno":
      options = ["Yes", "No"];
      break;
    case "multiple":
    case "pickone":
      options = (candidates ?? []).slice(0, kind === "multiple" ? 5 : 8);
      break;
    case "closest":
      options = closestMatchOptions();
      break;
  }

  if (options.length === 0) return null;

  // Engine accepts a plain string today. We submit option text directly.
  // Per spec: omit `source: "fallback"` because the engine rejects unknown fields.
  const handlePick = (value: string) => {
    if (disabled) return;
    void onSubmit(value);
  };

  const helperLine = getToneLine("simplify");

  return (
    <div
      className="space-y-2 pt-1"
      role="group"
      aria-label="Quick options"
    >
      <p className="text-xs text-muted-foreground">{helperLine}</p>
      {kind === "yesno" ? (
        <div className="grid grid-cols-2 gap-3">
          {options.map((opt) => (
            <Button
              key={opt}
              type="button"
              variant="outline"
              size="lg"
              disabled={disabled}
              onClick={() => handlePick(opt)}
              className="h-14 rounded-xl bg-card text-base font-medium shadow-card transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-elevated active:translate-y-0"
            >
              {opt}
            </Button>
          ))}
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {options.map((opt) => (
            <Button
              key={opt}
              type="button"
              variant="outline"
              disabled={disabled}
              onClick={() => handlePick(opt)}
              className="h-auto justify-start whitespace-normal rounded-xl bg-card px-4 py-3 text-left text-sm font-normal leading-relaxed shadow-card transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-elevated active:translate-y-0"
            >
              {opt}
            </Button>
          ))}
        </div>
      )}
    </div>
  );
}

export default FallbackQuestionWrapper;
