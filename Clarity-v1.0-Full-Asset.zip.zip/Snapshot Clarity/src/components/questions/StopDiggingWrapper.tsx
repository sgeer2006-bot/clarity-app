/**
 * Stop-Digging Wrapper (Loop Prevention)
 *
 * Engine-safe, additive wrapper around Questions (Reflection Engine).
 *
 * Watches Capability Detection Layer signals and a small in-memory ring
 * buffer of recent question identities. When it detects repeated questions,
 * stalled progress, exhausted context, post-fallback digging, or engine
 * looping, it shows ONE gentle transition message (drawn from existing
 * tone templates) and invokes the engine's existing forward-navigation call
 * to advance one step.
 *
 * Engine-existing forward path (read-only, see src/pages/QuestionFlow.tsx):
 *   navigate(`/new/${sessionId}/${stepNum + 1}`)
 *
 * Question identity is the engine's own `stepNum` plus a normalized hash of
 * the current question text — both already exposed to the questioning surface.
 *
 * This wrapper:
 *   - Is read-only with respect to engine state.
 *   - Maintains only its own in-memory observation state for the current
 *     flow. Nothing is persisted. Nothing is exposed to other modules.
 *   - Does NOT modify the engine, the Capability Detection Layer, the Tone
 *     + Transition wrapper, or the Fallback Question Wrapper.
 *   - Does NOT change which questions exist, how they're generated/stored,
 *     or the answer/question/summary/insight structures.
 *   - No analytics, no persistence, no new state stores, no gating, no new
 *     routes, no new screens.
 *   - Coexists with prior wrappers per Module 5 coordination rules.
 *   - Removing it restores prior behavior exactly.
 */

import { useEffect, useRef } from "react";
import type { CapabilitySignals } from "@/lib/questions/capabilityDetection";
import {
  QUESTION_TONE_TEMPLATES,
  getToneLine,
} from "@/lib/questions/toneTemplates";

// ---------- Tunable thresholds (conservative defaults) ----------

const RING_BUFFER_SIZE = 4;
const LOOP_REPEAT_THRESHOLD = 2; // same identity seen 2+ times in last 4 turns
const CONSECUTIVE_STALLED_THRESHOLD = 2;
const CONSECUTIVE_EXHAUSTED_THRESHOLD = 2;

// ---------- Types ----------

export interface StopDiggingInput {
  /** Engine-exposed step number for the current question. */
  stepNum: number;
  /** Engine-exposed current question text. */
  questionText: string;
  /** Latest signals from the Capability Detection Layer. */
  signals: CapabilitySignals;
  /**
   * Whether the previous turn's answer was submitted via the Fallback Question
   * Wrapper. Pass `undefined` if not exposed by the engine — that specific
   * trigger condition is silently skipped.
   */
  priorTurnUsedFallback?: boolean;
  /**
   * Whether the Fallback Question Wrapper is currently presenting fallback
   * options for this turn. When true, the Stop-Digging Wrapper waits one
   * turn so the user has a chance to respond via fallback first.
   */
  fallbackActiveThisTurn?: boolean;
  /**
   * Whether the Visible Mode Transition Layer (Module #5) would render a
   * message this turn. When both would render, only stop-digging renders.
   * Pass `undefined` if unknown — the wrapper still renders its own message
   * but should be mounted in place of (or above) the transition layer's slot.
   */
  transitionMessageThisTurn?: boolean;
  /**
   * Engine's existing forward-navigation call. Mirrors:
   *   navigate(`/new/${sessionId}/${stepNum + 1}`)
   * The wrapper invokes it identically to skip a dug/repeated question.
   */
  advance: () => void;
}

export interface StopDiggingDecision {
  /** True when a stop-digging action fired on this render. */
  fired: boolean;
  /** The transition message to render, if any. */
  message: string | null;
}

// ---------- Internal helpers ----------

function normalizeQuestionId(stepNum: number, questionText: string): string {
  const norm = (questionText ?? "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/[^\p{L}\p{N} ]/gu, "");
  return `${stepNum}::${norm}`;
}

function pickStopDiggingLine(): string {
  // Prefer "moveForward" (existing category), fall back to fallbackTransitions,
  // then emotionalSafety. Never invent inline strings; never edit templates.
  const move = QUESTION_TONE_TEMPLATES.moveForward;
  if (Array.isArray(move) && move.length > 0) return getToneLine("moveForward");
  const fallbacks = QUESTION_TONE_TEMPLATES.fallbackTransitions;
  if (Array.isArray(fallbacks) && fallbacks.length > 0) return getToneLine("fallbackTransitions");
  return getToneLine("emotionalSafety");
}

// ---------- Hook ----------

/**
 * Read-only observation hook. Returns `{ fired, message }` for the current
 * turn. When `fired === true`, the engine's existing forward-navigation call
 * has been invoked exactly once for this turn.
 *
 * At most one stop-digging action per turn. After firing, internal counters
 * reset so the wrapper does not chain repeatedly.
 */
export function useStopDigging(input: StopDiggingInput): StopDiggingDecision {
  const {
    stepNum,
    questionText,
    signals,
    priorTurnUsedFallback,
    fallbackActiveThisTurn,
    advance,
  } = input;

  // In-memory observation state. Scoped to this hook instance only.
  const ringRef = useRef<string[]>([]);
  const stalledStreakRef = useRef(0);
  const exhaustedStreakRef = useRef(0);
  const lastFiredStepRef = useRef<number | null>(null);
  const lastSeenStepRef = useRef<number | null>(null);

  const decisionRef = useRef<StopDiggingDecision>({ fired: false, message: null });

  useEffect(() => {
    // Default: no action this render.
    decisionRef.current = { fired: false, message: null };

    if (!questionText) return;

    // Coordination: if the Fallback Wrapper is actively presenting options
    // this turn, wait one turn.
    if (fallbackActiveThisTurn) {
      lastSeenStepRef.current = stepNum;
      return;
    }

    // Only update streaks once per actual step transition. Re-renders on the
    // same step must not inflate counters.
    const isNewStep = lastSeenStepRef.current !== stepNum;
    if (isNewStep) {
      // Update consecutive-signal streaks.
      stalledStreakRef.current = signals.stalled ? stalledStreakRef.current + 1 : 0;
      const exhausted = signals.shortAnswer || signals.lowContext;
      exhaustedStreakRef.current = exhausted ? exhaustedStreakRef.current + 1 : 0;

      // Update ring buffer of recent question identities.
      const id = normalizeQuestionId(stepNum, questionText);
      const buf = ringRef.current.slice();
      buf.push(id);
      while (buf.length > RING_BUFFER_SIZE) buf.shift();
      ringRef.current = buf;

      lastSeenStepRef.current = stepNum;
    }

    // Don't fire twice for the same step.
    if (lastFiredStepRef.current === stepNum) return;

    // ----- Trigger evaluation (in priority order, but at most one fires) -----

    // Trigger A: Engine looping — same identity repeated in recent window.
    const currentId = normalizeQuestionId(stepNum, questionText);
    const repeatCount = ringRef.current.filter((x) => x === currentId).length;
    const looping = repeatCount >= LOOP_REPEAT_THRESHOLD;

    // Trigger B: Repeated question pattern — same identity as the immediately
    // prior turn (near-duplicate by id/key).
    const prior = ringRef.current.length >= 2 ? ringRef.current[ringRef.current.length - 2] : null;
    const repeatedPattern = prior !== null && prior === currentId;

    // Trigger C: Stalled progress for N+ consecutive turns.
    const stalledTrip = stalledStreakRef.current >= CONSECUTIVE_STALLED_THRESHOLD;

    // Trigger D: Exhausted context (short/low-context) for N+ consecutive turns.
    const exhaustedTrip = exhaustedStreakRef.current >= CONSECUTIVE_EXHAUSTED_THRESHOLD;

    // Trigger E: Post-fallback digging — only evaluable if exposed.
    const postFallbackDig =
      priorTurnUsedFallback === true && (repeatedPattern || looping);

    const shouldFire =
      looping || repeatedPattern || stalledTrip || exhaustedTrip || postFallbackDig;

    if (!shouldFire) return;

    // Fire exactly once for this turn.
    const message = pickStopDiggingLine();
    decisionRef.current = { fired: true, message };
    lastFiredStepRef.current = stepNum;

    // Reset relevant counters so we don't chain.
    stalledStreakRef.current = 0;
    exhaustedStreakRef.current = 0;

    // Invoke engine's existing forward-navigation call.
    try {
      advance();
    } catch {
      // Silent: never break the engine. The transition message still rendered.
    }
  }, [
    stepNum,
    questionText,
    signals.stalled,
    signals.shortAnswer,
    signals.lowContext,
    signals.confused,
    fallbackActiveThisTurn,
    priorTurnUsedFallback,
    advance,
  ]);

  return decisionRef.current;
}

// ---------- Component (alternative mount, same behavior) ----------

export interface StopDiggingWrapperProps extends StopDiggingInput {
  /**
   * When true, suppress rendering the message because the Visible Mode
   * Transition Layer (Module #5) is showing one. Per Module 5 coordination,
   * if both would render, only stop-digging renders — pass this flag from
   * the surface so the transition layer is suppressed instead.
   */
  className?: string;
}

/**
 * Optional component form. Renders the same inline message slot/style used
 * by the existing Tone + Transition wrapper (a polite live-region paragraph).
 * If not mounted, callers can use `useStopDigging` directly and render their
 * own message.
 */
export function StopDiggingWrapper(props: StopDiggingWrapperProps) {
  const { className, ...rest } = props;
  const { fired, message } = useStopDigging(rest);
  if (!fired || !message) return null;
  return (
    <p
      role="status"
      aria-live="polite"
      className={
        className ??
        "text-sm text-muted-foreground italic leading-relaxed px-1 pb-2 animate-fade-in"
      }
    >
      {message}
    </p>
  );
}

export default StopDiggingWrapper;
