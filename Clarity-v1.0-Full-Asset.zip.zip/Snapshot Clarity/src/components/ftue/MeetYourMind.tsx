import { useEffect, useRef, useState } from "react";
import type { CSSProperties } from "react";
import {
  CalmSurface,
  CalmStack,
  CalmText,
  CalmDivider,
  QuietLead,
  FadeIn,
} from "@/components/calm";
import "./MeetYourMind.css";

const headingStyle: CSSProperties = {
  fontSize: "var(--calm-h2-size)",
  lineHeight: "var(--calm-leading-tight)",
  fontWeight: "var(--calm-weight-semibold)" as CSSProperties["fontWeight"],
  color: "var(--calm-text)",
  margin: 0,
};

/**
 * Phase 2 — Commit J: Meet Your Mind FTUE.
 *
 * Self-contained, visual-only guided FTUE. No routing, analytics, auth,
 * persistence, or feature-gate changes. State is local; all styling uses
 * Calm primitives and tokens.
 */

export interface MeetYourMindProps {
  onComplete?: () => void;
}

type StepIndex = 0 | 1 | 2;

const INTERESTS: { id: string; label: string }[] = [
  { id: "patterns", label: "Notice patterns" },
  { id: "calm", label: "Stay calm" },
  { id: "clarity", label: "Find clarity" },
];

export function MeetYourMind({ onComplete }: MeetYourMindProps) {
  const [step, setStep] = useState<StepIndex>(0);
  const [selected, setSelected] = useState<string[]>([]);
  const headingRef = useRef<HTMLHeadingElement | null>(null);

  useEffect(() => {
    // Move keyboard focus to the step headline on advance.
    headingRef.current?.focus();
  }, [step]);

  const toggleInterest = (id: string) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  };

  const goNext = () => setStep((s) => (s < 2 ? ((s + 1) as StepIndex) : s));
  const goBack = () => setStep((s) => (s > 0 ? ((s - 1) as StepIndex) : s));
  const finish = () => {
    onComplete?.();
  };

  return (
    <CalmSurface
      padding="24"
      radius="lg"
      role="region"
      aria-label="Meet your mind"
    >
      <FadeIn key={step}>
        <CalmStack gap="16" className="meet-your-mind">
          {step === 0 && (
            <>
              <h2 style={headingStyle}
                tabIndex={-1}
                ref={headingRef}
                className="meet-your-mind__heading"
              >
                Meet your mind
              </h2>
              <QuietLead>
                A quiet space to notice what's surfacing. Take a breath — there's
                nothing to perform here.
              </QuietLead>
              <CalmDivider />
              <div className="meet-your-mind__actions">
                <span aria-hidden />
                <button
                  type="button"
                  className="meet-your-mind__btn meet-your-mind__btn--primary"
                  onClick={goNext}
                >
                  Get started
                </button>
              </div>
            </>
          )}

          {step === 1 && (
            <>
              <h2 style={headingStyle}
                tabIndex={-1}
                ref={headingRef}
                className="meet-your-mind__heading"
              >
                What matters to you
              </h2>
              <QuietLead>
                Pick what resonates — this only shapes the tone, nothing more.
              </QuietLead>
              <div
                className="meet-your-mind__chip-row"
                role="group"
                aria-label="Interests"
              >
                {INTERESTS.map((it) => {
                  const pressed = selected.includes(it.id);
                  return (
                    <button
                      key={it.id}
                      type="button"
                      className="meet-your-mind__chip"
                      aria-pressed={pressed}
                      onClick={() => toggleInterest(it.id)}
                    >
                      {it.label}
                    </button>
                  );
                })}
              </div>
              <CalmDivider />
              <div className="meet-your-mind__actions">
                <button
                  type="button"
                  className="meet-your-mind__btn"
                  onClick={goBack}
                >
                  Back
                </button>
                <button
                  type="button"
                  className="meet-your-mind__btn meet-your-mind__btn--primary"
                  onClick={goNext}
                >
                  Continue
                </button>
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <h2 style={headingStyle}
                tabIndex={-1}
                ref={headingRef}
                className="meet-your-mind__heading"
              >
                You're set
              </h2>
              <QuietLead>
                {selected.length > 0
                  ? "A gentle starting point — these will quietly shape what surfaces first."
                  : "A quiet starting point. Things will surface as you reflect."}
              </QuietLead>
              {selected.length > 0 && (
                <CalmStack gap="8">
                  <CalmText size="sm" soft>
                    Focused on
                  </CalmText>
                  <div className="meet-your-mind__chip-row" aria-live="polite">
                    {selected.map((id) => {
                      const item = INTERESTS.find((i) => i.id === id);
                      if (!item) return null;
                      return (
                        <span
                          key={id}
                          className="meet-your-mind__chip"
                          aria-pressed="true"
                        >
                          {item.label}
                        </span>
                      );
                    })}
                  </div>
                </CalmStack>
              )}
              <CalmDivider />
              <div className="meet-your-mind__actions">
                <button
                  type="button"
                  className="meet-your-mind__btn"
                  onClick={goBack}
                >
                  Back
                </button>
                <button
                  type="button"
                  className="meet-your-mind__btn meet-your-mind__btn--primary"
                  onClick={finish}
                >
                  Start using Reflect
                </button>
              </div>
            </>
          )}
        </CalmStack>
      </FadeIn>
    </CalmSurface>
  );
}

export default MeetYourMind;
