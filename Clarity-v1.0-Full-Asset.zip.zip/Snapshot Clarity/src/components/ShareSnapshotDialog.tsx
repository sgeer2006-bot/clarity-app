import { useRef, useState } from "react";
import { Copy, Download, Loader2, Share2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ShareSnapshotCard, type ShareVariant } from "@/components/ShareSnapshotCard";
import {
  createSharedSnapshot,
  downloadBlob,
  renderCardToPng,
} from "@/lib/share";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import type { SnapshotJson } from "@/lib/types";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sessionId: string;
  title: string;
  snapshot: SnapshotJson;
}

export const ShareSnapshotDialog = ({
  open,
  onOpenChange,
  sessionId,
  title,
  snapshot,
}: Props) => {
  const [variant, setVariant] = useState<ShareVariant>("square");
  const [generating, setGenerating] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  const generate = async (action: "download" | "share") => {
    if (!cardRef.current) return;
    setGenerating(true);
    try {
      const blob = await renderCardToPng(cardRef.current);

      if (action === "download") {
        downloadBlob(blob, `clarity-snapshot-${variant}.png`);
        toast({ title: "Image saved", description: "Snapshot downloaded." });
      } else {
        const { data: sess } = await supabase.auth.getSession();
        const userId = sess.session?.user.id;
        if (!userId) throw new Error("You need to be signed in to share.");
        const { url } = await createSharedSnapshot({
          sessionId,
          userId,
          title,
          snapshot,
          variant,
          imageBlob: blob,
        });
        setShareUrl(url);
        await navigator.clipboard.writeText(url).catch(() => {});
        toast({
          title: "Share link copied",
          description: "Anyone with the link can view this snapshot.",
        });
      }
    } catch (e: any) {
      console.error("share failed", e);
      toast({
        title: "Couldn't share snapshot",
        description: e?.message ?? "Please try again.",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  const copy = async () => {
    if (!shareUrl) return;
    await navigator.clipboard.writeText(shareUrl);
    toast({ title: "Link copied" });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">
            Share this snapshot
          </DialogTitle>
          <DialogDescription>
            Pick a format, then download the image or copy a link.
          </DialogDescription>
        </DialogHeader>

        <div className="flex gap-2">
          <Button
            type="button"
            variant={variant === "square" ? "default" : "outline"}
            size="sm"
            onClick={() => setVariant("square")}
            className="flex-1"
          >
            Square · 1:1
          </Button>
          <Button
            type="button"
            variant={variant === "vertical" ? "default" : "outline"}
            size="sm"
            onClick={() => setVariant("vertical")}
            className="flex-1"
          >
            Vertical · 9:16
          </Button>
        </div>

        {/* Preview — scaled down via CSS transform of an off-screen full-size card */}
        <div className="relative mx-auto overflow-hidden rounded-lg border border-border bg-muted/30">
          <div
            className="origin-top-left"
            style={{
              transform: "scale(0.28)",
              width: variant === "vertical" ? 1080 * 0.28 : 1080 * 0.28,
              height: variant === "vertical" ? 1920 * 0.28 : 1080 * 0.28,
            }}
          >
            <ShareSnapshotCard
              ref={cardRef}
              title={title}
              snapshot={snapshot}
              variant={variant}
            />
          </div>
        </div>

        {shareUrl && (
          <div className="flex items-center gap-2 rounded-md border border-border bg-muted/40 p-2">
            <input
              readOnly
              value={shareUrl}
              className="flex-1 bg-transparent px-2 text-sm outline-none"
            />
            <Button size="sm" variant="ghost" onClick={copy}>
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-2">
          <Button
            variant="outline"
            onClick={() => generate("download")}
            disabled={generating}
          >
            {generating ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Download className="mr-2 h-4 w-4" />
            )}
            Download PNG
          </Button>
          <Button onClick={() => generate("share")} disabled={generating}>
            {generating ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Share2 className="mr-2 h-4 w-4" />
            )}
            Create share link
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
