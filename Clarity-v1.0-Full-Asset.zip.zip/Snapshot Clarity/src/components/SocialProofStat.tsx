import { useEffect, useState } from "react";
import { Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  patternId: string;
  /** Window in days for the stat. Defaults to 30. */
  days?: number;
  /** Minimum sample size before we show a percentage. */
  minSample?: number;
}

/**
 * "Based on 42 reflections in the last 30 days, 12% matched this pattern."
 * Falls back to a soft "still gathering data" line below the threshold.
 */
export const SocialProofStat = ({
  patternId,
  days = 30,
  minSample = 20,
}: Props) => {
  const [counts, setCounts] = useState<{ pattern: number; total: number } | null>(
    null,
  );
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase.rpc("get_pattern_stats", {
        _pattern_id: patternId,
        _days: days,
      });
      if (cancelled) return;
      if (!error && Array.isArray(data) && data[0]) {
        setCounts({
          pattern: Number((data[0] as any).pattern_count ?? 0),
          total: Number((data[0] as any).total_count ?? 0),
        });
      }
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [patternId, days]);

  if (loading) {
    return (
      <div className="rounded-lg border border-border bg-muted/30 p-4 text-sm text-muted-foreground">
        Loading community signal…
      </div>
    );
  }

  if (!counts || counts.total < minSample) {
    return (
      <div className="rounded-lg border border-border bg-muted/30 p-4 text-sm text-muted-foreground">
        <Users className="mr-2 inline h-4 w-4 align-text-bottom" />
        Still gathering data. Stats appear once the community has shared at least{" "}
        {minSample} reflections in the last {days} days.
        {counts && (
          <span className="ml-1 opacity-70">
            (currently {counts.total})
          </span>
        )}
      </div>
    );
  }

  const pct = counts.total > 0 ? (counts.pattern / counts.total) * 100 : 0;
  const pretty = pct >= 10 ? Math.round(pct) : pct.toFixed(1);

  return (
    <div className="rounded-lg border border-accent/40 bg-accent/10 p-4 text-sm">
      <Users className="mr-2 inline h-4 w-4 align-text-bottom text-accent-foreground" />
      <span className="font-medium">{pretty}% of recent reflections</span>{" "}
      matched this pattern in the last {days} days.{" "}
      <span className="text-muted-foreground">
        Based on {counts.total} reflections.
      </span>
    </div>
  );
};
