import type { SituationInsight } from "@/lib/insights/ProfileInsightsEngine";

interface Props {
  situationInsights: SituationInsight[];
  blurInsights: boolean;
}

export function SituationInsightsSection({ situationInsights, blurInsights }: Props) {
  if (!situationInsights || situationInsights.length === 0) return null;

  return (
    <section className="mx-auto w-full max-w-2xl px-4 py-10">
      <h3 className="mb-4 text-xs uppercase tracking-[0.18em] text-muted-foreground/70">
        Situations
      </h3>
      <ul className="space-y-3">
        {situationInsights.map((it, i) => (
          <li
            key={i}
            className={
              blurInsights
                ? "select-none text-base leading-relaxed text-foreground/85"
                : "text-base leading-relaxed text-foreground/85"
            }
            style={blurInsights ? { filter: "blur(6px)", userSelect: "none" } : undefined}
          >
            {it.text}
          </li>
        ))}
      </ul>
    </section>
  );
}
