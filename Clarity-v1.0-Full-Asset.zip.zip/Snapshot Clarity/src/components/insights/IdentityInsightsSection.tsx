import type { IdentityInsight } from "@/lib/insights/ProfileInsightsEngine";

interface Props {
  identityInsights: IdentityInsight[];
  blurInsights: boolean;
}

function humanize(category: string): string {
  return category.replace(/([A-Z])/g, " $1").replace(/^./, (c) => c.toUpperCase()).trim();
}

export function IdentityInsightsSection({ identityInsights, blurInsights }: Props) {
  if (!identityInsights || identityInsights.length === 0) return null;

  // Preserve engine-provided order; group by category as encountered.
  const groups: { category: string; items: IdentityInsight[] }[] = [];
  for (const it of identityInsights) {
    const last = groups[groups.length - 1];
    if (last && last.category === it.category) last.items.push(it);
    else groups.push({ category: it.category, items: [it] });
  }

  return (
    <section className="mx-auto w-full max-w-2xl px-4 py-10">
      {groups.map((g, gi) => (
        <div key={g.category} className={gi === 0 ? "" : "mt-10 border-t border-border/40 pt-10"}>
          <h3 className="mb-4 text-xs uppercase tracking-[0.18em] text-muted-foreground/70">
            {humanize(g.category)}
          </h3>
          <ul className="space-y-3">
            {g.items.map((it, i) => (
              <li
                key={i}
                className={
                  blurInsights
                    ? "select-none text-base leading-relaxed text-foreground/85"
                    : "text-base leading-relaxed text-foreground/85"
                }
                style={
                  blurInsights
                    ? { filter: "blur(6px)", userSelect: "none" }
                    : undefined
                }
              >
                {it.text}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </section>
  );
}
