import type { UpgradePrompt } from "@/lib/premium/ClarityPlusGating";

interface Props {
  upgradePrompt: UpgradePrompt | null;
}

export function UpgradePromptCard({ upgradePrompt }: Props) {
  if (!upgradePrompt) return null;

  return (
    <section className="mx-auto w-full max-w-2xl px-4 py-10">
      <div
        className="rounded-2xl border border-border/40 p-8 backdrop-blur-sm"
        style={{
          background:
            "linear-gradient(180deg, hsl(var(--card) / 0.5) 0%, hsl(var(--primary) / 0.06) 100%)",
        }}
      >
        <p className="text-base leading-relaxed text-foreground/85">
          {upgradePrompt.text}
        </p>
      </div>
    </section>
  );
}
