import type { TopInsight } from "@/lib/insights/ProfileInsightsEngine";

interface Props {
  topInsight: TopInsight | null;
  blurInsights: boolean;
}

export function TopInsightCard({ topInsight, blurInsights }: Props) {
  if (!topInsight) return null;

  return (
    <div className="relative mx-auto w-full max-w-2xl px-4 py-12">
      {/* Spotlight glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(ellipse at center, hsl(var(--primary) / 0.12) 0%, transparent 65%)",
        }}
      />
      <div className="text-center">
        <p className="mb-6 text-xs uppercase tracking-[0.22em] text-muted-foreground/70">
          {topInsight.category.replace(/([A-Z])/g, " $1").trim()}
        </p>
        <p
          className={
            blurInsights
              ? "select-none text-2xl font-light leading-relaxed tracking-tight text-foreground/90 sm:text-3xl"
              : "text-2xl font-light leading-relaxed tracking-tight text-foreground/90 sm:text-3xl"
          }
          style={
            blurInsights
              ? {
                  filter: "blur(8px)",
                  WebkitMaskImage:
                    "linear-gradient(to bottom, hsl(var(--foreground)) 50%, hsl(var(--foreground) / 0.6) 100%)",
                  maskImage:
                    "linear-gradient(to bottom, hsl(var(--foreground)) 50%, hsl(var(--foreground) / 0.6) 100%)",
                  userSelect: "none",
                }
              : undefined
          }
        >
          {topInsight.text}
        </p>
      </div>
    </div>
  );
}
