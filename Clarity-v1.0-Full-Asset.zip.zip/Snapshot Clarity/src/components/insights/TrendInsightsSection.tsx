import type { TrendInsight } from "@/lib/insights/ProfileInsightsEngine";
import type { UpgradePrompt } from "@/lib/premium/ClarityPlusGating";
import { QUESTION_TONE_TEMPLATES } from "@/lib/questions/toneTemplates";

interface Props {
  trendInsights: TrendInsight[];
  showTrends: boolean;
  upgradePrompt: UpgradePrompt | null;
}

function pickTrendCtaFromTemplates(): string | null {
  // Prefer moveForward templates (Module #5) for a calm forward-looking line.
  const pool = [
    ...(QUESTION_TONE_TEMPLATES.moveForward ?? []),
    ...(QUESTION_TONE_TEMPLATES.emotionalSafety ?? []),
  ];
  for (const line of pool) {
    if (typeof line === "string" && line.trim().length > 0 && line.length <= 220) {
      return line.trim();
    }
  }
  return null;
}

export function TrendInsightsSection({ trendInsights, showTrends, upgradePrompt }: Props) {
  if (showTrends) {
    if (!trendInsights || trendInsights.length === 0) return null;
    return (
      <section className="mx-auto w-full max-w-2xl px-4 py-10">
        <h3 className="mb-4 text-xs uppercase tracking-[0.18em] text-muted-foreground/70">
          Trends
        </h3>
        <ul className="space-y-3">
          {trendInsights.map((it, i) => (
            <li key={i} className="text-base leading-relaxed text-foreground/85">
              {it.text}
            </li>
          ))}
        </ul>
      </section>
    );
  }

  // Free / Basic: calm CTA stand-in. Source copy from templates, fall back to upgradePrompt.
  const ctaText = pickTrendCtaFromTemplates() ?? upgradePrompt?.text ?? null;
  if (!ctaText) return null;

  return (
    <section className="mx-auto w-full max-w-2xl px-4 py-10">
      <h3 className="mb-4 text-xs uppercase tracking-[0.18em] text-muted-foreground/70">
        Trends
      </h3>
      <div
        className="rounded-2xl border border-border/40 bg-card/30 p-6 backdrop-blur-sm"
        style={{
          background:
            "linear-gradient(180deg, hsl(var(--card) / 0.4) 0%, hsl(var(--primary) / 0.04) 100%)",
        }}
      >
        <p className="text-base leading-relaxed text-foreground/80">{ctaText}</p>
      </div>
    </section>
  );
}
