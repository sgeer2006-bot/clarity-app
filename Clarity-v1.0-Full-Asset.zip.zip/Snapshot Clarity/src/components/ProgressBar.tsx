interface Props {
  current: number;
  total: number;
}

const PHRASES: { upTo: number; text: string }[] = [
  { upTo: 20, text: "Just getting started…" },
  { upTo: 45, text: "Getting the full picture…" },
  { upTo: 70, text: "Building context…" },
  { upTo: 90, text: "Almost there…" },
  { upTo: 100, text: "Wrapping up…" },
];

export const ProgressBar = ({ current, total }: Props) => {
  // Cap visual progress at 95% so extra dynamic questions never break the bar.
  const raw = total > 0 ? (current / total) * 100 : 0;
  const pct = Math.max(6, Math.min(95, raw));
  const phrase = PHRASES.find((p) => pct <= p.upTo)?.text ?? PHRASES[PHRASES.length - 1].text;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs">
        <span className="font-medium text-muted-foreground">{phrase}</span>
        <span className="tabular-nums text-muted-foreground/80">{Math.round(pct)}%</span>
      </div>
      <div
        role="progressbar"
        aria-valuenow={Math.round(pct)}
        aria-valuemin={0}
        aria-valuemax={100}
        className="h-1.5 w-full overflow-hidden rounded-full bg-muted"
      >
        <div
          className="h-full rounded-full bg-gradient-to-r from-primary to-primary/70 transition-all duration-700 ease-out"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};
