import { MessageSquare, List, Signpost } from "lucide-react";
import type { FollowUpSection } from "@/lib/types";

interface Props {
  onSelect: (section: FollowUpSection) => void;
}

const sections: { key: FollowUpSection; label: string; desc: string; icon: typeof MessageSquare }[] = [
  { key: "summary", label: "Situation Summary", desc: "Explore what happened in more detail", icon: MessageSquare },
  { key: "consider", label: "Things to Consider", desc: "Dig deeper into observations and tensions", icon: List },
  { key: "paths", label: "Possible Paths", desc: "Think through the options further", icon: Signpost },
];

export const SectionSelector = ({ onSelect }: Props) => (
  <div className="space-y-4">
    <h2 className="text-lg font-medium">What would you like to explore?</h2>
    <p className="text-sm text-muted-foreground">Pick a section to continue the conversation.</p>
    <div className="grid gap-3">
      {sections.map(({ key, label, desc, icon: Icon }) => (
        <button
          key={key}
          onClick={() => onSelect(key)}
          className="flex items-start gap-4 rounded-xl border border-border bg-card p-5 text-left transition-colors hover:border-accent hover:bg-accent/5"
        >
          <Icon className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
          <div>
            <p className="font-medium">{label}</p>
            <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
          </div>
        </button>
      ))}
    </div>
  </div>
);
