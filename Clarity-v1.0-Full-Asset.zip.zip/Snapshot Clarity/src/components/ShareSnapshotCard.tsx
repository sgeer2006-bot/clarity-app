import { forwardRef } from "react";
import { Sparkles } from "lucide-react";
import type { SnapshotJson } from "@/lib/types";

export type ShareVariant = "square" | "vertical";

interface Props {
  title: string;
  snapshot: SnapshotJson;
  variant: ShareVariant;
  handle?: string;
}

/**
 * Branded snapshot card rendered off-screen and exported to PNG.
 * Fixed pixel dimensions so html-to-image produces predictable output.
 *  - square:   1080 × 1080  (Instagram feed)
 *  - vertical: 1080 × 1920  (TikTok / Reels / Stories)
 */
export const ShareSnapshotCard = forwardRef<HTMLDivElement, Props>(
  ({ title, snapshot, variant, handle = "@clarity" }, ref) => {
    const isVertical = variant === "vertical";
    const width = 1080;
    const height = isVertical ? 1920 : 1080;

    const observations = snapshot.observations.slice(0, isVertical ? 4 : 3);
    const paths = snapshot.possible_paths.slice(0, isVertical ? 4 : 3);

    return (
      <div
        ref={ref}
        style={{
          width: `${width}px`,
          height: `${height}px`,
          background:
            "linear-gradient(135deg, hsl(36, 38%, 96%) 0%, hsl(36, 30%, 92%) 50%, hsl(28, 35%, 90%) 100%)",
          fontFamily:
            "'Inter', system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
          color: "hsl(25, 20%, 18%)",
          padding: isVertical ? "96px 80px" : "80px",
          display: "flex",
          flexDirection: "column",
          position: "relative",
          overflow: "hidden",
          boxSizing: "border-box",
        }}
      >
        {/* Decorative orb */}
        <div
          style={{
            position: "absolute",
            top: "-200px",
            right: "-200px",
            width: "600px",
            height: "600px",
            borderRadius: "50%",
            background:
              "radial-gradient(circle, hsla(28, 60%, 70%, 0.35) 0%, transparent 70%)",
            pointerEvents: "none",
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: "-180px",
            left: "-180px",
            width: "500px",
            height: "500px",
            borderRadius: "50%",
            background:
              "radial-gradient(circle, hsla(200, 50%, 70%, 0.25) 0%, transparent 70%)",
            pointerEvents: "none",
          }}
        />

        {/* Header */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "16px",
            marginBottom: isVertical ? "72px" : "48px",
            position: "relative",
          }}
        >
          <div
            style={{
              width: "56px",
              height: "56px",
              borderRadius: "16px",
              background:
                "linear-gradient(135deg, hsl(28, 70%, 55%) 0%, hsl(20, 65%, 50%) 100%)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "white",
            }}
          >
            <Sparkles size={28} strokeWidth={2.4} />
          </div>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <span
              style={{
                fontFamily: "'Fraunces', Georgia, serif",
                fontSize: "32px",
                fontWeight: 600,
                lineHeight: 1,
                color: "hsl(25, 30%, 20%)",
              }}
            >
              Clarity
            </span>
            <span
              style={{
                fontSize: "16px",
                color: "hsl(25, 15%, 45%)",
                marginTop: "4px",
                letterSpacing: "0.02em",
              }}
            >
              A snapshot from a quiet reflection
            </span>
          </div>
        </div>

        {/* Title */}
        <h1
          style={{
            fontFamily: "'Fraunces', Georgia, serif",
            fontSize: isVertical ? "68px" : "52px",
            fontWeight: 600,
            lineHeight: 1.1,
            letterSpacing: "-0.02em",
            margin: 0,
            marginBottom: isVertical ? "48px" : "36px",
            color: "hsl(25, 30%, 18%)",
            position: "relative",
          }}
        >
          {title}
        </h1>

        {/* Summary */}
        <div
          style={{
            background: "hsla(0, 0%, 100%, 0.55)",
            backdropFilter: "blur(8px)",
            border: "1px solid hsla(25, 20%, 50%, 0.12)",
            borderRadius: "24px",
            padding: isVertical ? "40px" : "32px",
            marginBottom: isVertical ? "48px" : "32px",
            position: "relative",
          }}
        >
          <div
            style={{
              fontSize: "14px",
              fontWeight: 600,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              color: "hsl(28, 50%, 40%)",
              marginBottom: "16px",
            }}
          >
            Situation
          </div>
          <p
            style={{
              fontSize: isVertical ? "32px" : "26px",
              lineHeight: 1.45,
              margin: 0,
              color: "hsl(25, 20%, 22%)",
            }}
          >
            {snapshot.summary}
          </p>
        </div>

        {/* Observations + Paths grid */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: isVertical ? "1fr" : "1fr 1fr",
            gap: isVertical ? "32px" : "24px",
            position: "relative",
            flex: 1,
          }}
        >
          <Section title="To consider" items={observations} variant={variant} />
          <Section title="Possible paths" items={paths} variant={variant} />
        </div>

        {/* Footer */}
        <div
          style={{
            marginTop: isVertical ? "56px" : "40px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            position: "relative",
            paddingTop: "24px",
            borderTop: "1px solid hsla(25, 20%, 50%, 0.15)",
          }}
        >
          <span
            style={{
              fontSize: "20px",
              fontWeight: 500,
              color: "hsl(25, 25%, 30%)",
            }}
          >
            clarity.app · {handle}
          </span>
          <span
            style={{
              fontSize: "16px",
              color: "hsl(25, 15%, 50%)",
              fontStyle: "italic",
            }}
          >
            Not advice — just perspective.
          </span>
        </div>
      </div>
    );
  },
);
ShareSnapshotCard.displayName = "ShareSnapshotCard";

function Section({
  title,
  items,
  variant,
}: {
  title: string;
  items: string[];
  variant: ShareVariant;
}) {
  const isVertical = variant === "vertical";
  return (
    <div
      style={{
        background: "hsla(0, 0%, 100%, 0.4)",
        border: "1px solid hsla(25, 20%, 50%, 0.1)",
        borderRadius: "20px",
        padding: isVertical ? "32px" : "24px",
        display: "flex",
        flexDirection: "column",
        gap: "16px",
      }}
    >
      <div
        style={{
          fontSize: "13px",
          fontWeight: 600,
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          color: "hsl(28, 50%, 40%)",
        }}
      >
        {title}
      </div>
      <ul
        style={{
          listStyle: "none",
          padding: 0,
          margin: 0,
          display: "flex",
          flexDirection: "column",
          gap: "14px",
        }}
      >
        {items.map((item, i) => (
          <li
            key={i}
            style={{
              fontSize: isVertical ? "24px" : "19px",
              lineHeight: 1.4,
              color: "hsl(25, 20%, 25%)",
              display: "flex",
              gap: "12px",
              alignItems: "flex-start",
            }}
          >
            <span
              style={{
                color: "hsl(28, 60%, 50%)",
                fontWeight: 700,
                flexShrink: 0,
                marginTop: "2px",
              }}
            >
              ◆
            </span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
