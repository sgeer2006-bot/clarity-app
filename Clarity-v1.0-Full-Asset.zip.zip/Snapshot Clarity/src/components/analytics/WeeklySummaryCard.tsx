import { Sparkles, Flame } from "lucide-react";
import { ActivityPoint, UserPatternCount } from "@/lib/analytics";

interface Props {
  activity: ActivityPoint[];
  topPattern?: UserPatternCount;
  streak: number;
}

export const WeeklySummaryCard = ({ activity, topPattern, streak }: Props) => {
  const last7 = activity.slice(-7);
  const prev7 = activity.slice(-14, -7);
  const last7Total = last7.reduce((s, d) => s + Number(d.session_count), 0);
  const prev7Total = prev7.reduce((s, d) => s + Number(d.session_count), 0);
  const delta = last7Total - prev7Total;
  const deltaLabel =
    prev7Total === 0 && last7Total === 0
      ? "Quiet week"
      : delta === 0
        ? "Same as last week"
        : delta > 0
          ? `+${delta} vs. last week`
          : `${delta} vs. last week`;

  return (
    <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card/80 to-accent/10 p-5 shadow-sm">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-8 -top-8 h-32 w-32 rounded-full bg-primary/15 blur-2xl"
      />
      <div className="relative space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" aria-hidden />
          <span className="label-eyebrow">This week</span>
        </div>
        <h3 className="font-display text-2xl font-semibold leading-tight">
          {last7Total === 0
            ? "A fresh page is waiting."
            : last7Total === 1
              ? "One reflection this week."
              : `${last7Total} reflections this week.`}
        </h3>
        <p className="text-sm text-muted-foreground">{deltaLabel}</p>

        <div className="flex flex-wrap items-center gap-2 pt-2">
          {streak > 0 && (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-background/70 px-2.5 py-1 text-xs">
              <Flame className="h-3 w-3 text-accent" aria-hidden />
              {streak}-day streak
            </span>
          )}
          {topPattern && (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-background/70 px-2.5 py-1 text-xs">
              Most-seen pattern: <strong className="font-medium">{topPattern.name}</strong>
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
