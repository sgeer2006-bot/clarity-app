import { useMemo } from "react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { format, parseISO } from "date-fns";
import { ActivityPoint } from "@/lib/analytics";

interface Props {
  data: ActivityPoint[];
}

export const ActivityChart = ({ data }: Props) => {
  const chartData = useMemo(
    () =>
      data.map((d) => ({
        day: d.day,
        label: format(parseISO(d.day), "MMM d"),
        count: Number(d.session_count),
      })),
    [data],
  );

  const total = chartData.reduce((sum, p) => sum + p.count, 0);

  return (
    <div
      className="calm-transition border border-border/70 bg-card/80 shadow-sm"
      style={{
        padding: "var(--calm-space-16)",
        borderRadius: "var(--calm-radius-md)",
      }}
    >
      <div className="flex items-baseline justify-between">
        <div>
          <h3 className="font-display text-lg font-semibold">Reflection activity</h3>
          <p className="text-xs text-muted-foreground">Last 30 days</p>
        </div>
        <span className="text-xs text-muted-foreground">
          {total} {total === 1 ? "reflection" : "reflections"}
        </span>
      </div>
      <div className="mt-4 h-48">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 10, right: 8, left: -16, bottom: 0 }}>
            <defs>
              <linearGradient id="activityFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.35} />
                <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="label"
              tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={false}
              interval="preserveStartEnd"
              minTickGap={24}
            />
            <YAxis
              allowDecimals={false}
              tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
              tickLine={false}
              axisLine={false}
              width={28}
            />
            <Tooltip
              cursor={{ stroke: "hsl(var(--border))" }}
              contentStyle={{
                background: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: 8,
                fontSize: 12,
              }}
              labelStyle={{ color: "hsl(var(--muted-foreground))" }}
              formatter={(v: number) => [`${v} reflection${v === 1 ? "" : "s"}`, ""]}
            />
            <Area
              type="monotone"
              dataKey="count"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              fill="url(#activityFill)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
