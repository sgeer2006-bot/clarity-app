import { Link } from "react-router-dom";
import { Eye, Share2 } from "lucide-react";
import { format, parseISO } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { SharedSnapshot } from "@/lib/analytics";

interface Props {
  shares: SharedSnapshot[];
}

export const SnapshotsGallery = ({ shares }: Props) => {
  if (shares.length === 0) {
    return (
      <div className="rounded-2xl border border-border/70 bg-card/80 p-5 shadow-sm">
        <h3 className="font-display text-lg font-semibold">Shared snapshots</h3>
        <p className="mt-3 rounded-xl border border-dashed border-border/70 bg-muted/30 p-6 text-center text-sm text-muted-foreground">
          You haven't shared any snapshots yet. Open a reflection and tap "Share snapshot" to create one.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-border/70 bg-card/80 p-5 shadow-sm">
      <div className="flex items-baseline justify-between">
        <h3 className="font-display text-lg font-semibold">Shared snapshots</h3>
        <span className="text-xs text-muted-foreground">{shares.length} recent</span>
      </div>
      <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {shares.map((s) => {
          const imageUrl = s.image_path
            ? supabase.storage.from("snapshot-shares").getPublicUrl(s.image_path).data.publicUrl
            : null;
          const aspect = s.variant === "vertical" ? "aspect-[9/16]" : "aspect-square";
          return (
            <li key={s.id}>
              <Link
                to={`/s/${s.token}`}
                target="_blank"
                rel="noopener noreferrer"
                className="group block overflow-hidden rounded-xl border border-border/60 bg-background/60 transition-all hover:border-primary/40 hover:shadow-md"
              >
                <div className={`relative w-full ${aspect} overflow-hidden bg-muted`}>
                  {imageUrl ? (
                    <img
                      src={imageUrl}
                      alt={s.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-xs text-muted-foreground">
                      <Share2 className="h-5 w-5" />
                    </div>
                  )}
                </div>
                <div className="space-y-1 p-2.5">
                  <p className="line-clamp-1 text-xs font-medium">{s.title}</p>
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                    <span>{format(parseISO(s.created_at), "MMM d")}</span>
                    <span className="inline-flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      {s.view_count}
                    </span>
                  </div>
                </div>
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
};
