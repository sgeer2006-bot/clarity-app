import { useEffect, useRef, useState } from "react";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { canUse } from "@/lib/featureGate";

interface Props {
  label: string;
  value: number;
  hint?: string;
  icon?: LucideIcon;
  accent?: "primary" | "accent" | "muted";
}

export const StatCard = ({ label, value, hint, icon: Icon, accent = "primary" }: Props) => {
  const [display, setDisplay] = useState(0);
  const startedRef = useRef(false);

  useEffect(() => {
    if (startedRef.current) {
      setDisplay(value);
      return;
    }
    startedRef.current = true;
    const duration = 700;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(Math.round(eased * value));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);

  const accentClass =
    accent === "primary"
      ? "text-primary"
      : accent === "accent"
        ? "text-accent"
        : "text-muted-foreground";

  // Phase 2 — Commit I: tokenized spacing/radius for all users; subtle
  // premium glow gated by the existing premium calm-layer feature.
  const isPremium = canUse("premium_calm_layer");
  const calmStyle = {
    padding: "var(--calm-space-16)",
    borderRadius: "var(--calm-radius-md)",
    border: "1px solid var(--calm-border)",
    boxShadow: isPremium
      ? "0 6px 18px rgba(75, 123, 236, 0.06)"
      : undefined,
  } as const;

  return (
    <div
      className="group bg-card/80 transition-all hover:-translate-y-0.5 hover:shadow-md"
      style={calmStyle}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        {Icon && (
          <Icon className={cn("h-4 w-4", accentClass)} aria-hidden="true" />
        )}
      </div>
      <div className="mt-3 font-display text-3xl font-semibold tabular-nums">
        {display.toLocaleString()}
      </div>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
};
