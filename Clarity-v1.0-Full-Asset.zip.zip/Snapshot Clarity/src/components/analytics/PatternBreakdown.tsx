import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { UserPatternCount } from "@/lib/analytics";

interface Props {
  patterns: UserPatternCount[];
}

export const PatternBreakdown = ({ patterns }: Props) => {
  const max = patterns.reduce((m, p) => Math.max(m, Number(p.match_count)), 0) || 1;

  return (
    <div className="rounded-2xl border border-border/70 bg-card/80 p-5 shadow-sm">
      <div className="flex items-baseline justify-between">
        <div>
          <h3 className="font-display text-lg font-semibold">Your communication patterns</h3>
          <p className="text-xs text-muted-foreground">
            Patterns we've spotted across your reflections
          </p>
        </div>
      </div>

      {patterns.length === 0 ? (
        <p className="mt-6 rounded-xl border border-dashed border-border/70 bg-muted/30 p-6 text-center text-sm text-muted-foreground">
          No patterns yet. Complete a few reflections and patterns will appear here.
        </p>
      ) : (
        <ul className="mt-4 space-y-3">
          {patterns.slice(0, 8).map((p) => {
            const count = Number(p.match_count);
            const pct = Math.round((count / max) * 100);
            return (
              <li key={p.pattern_id}>
                <Link
                  to={`/p/${p.slug}`}
                  className="group block rounded-xl border border-border/60 bg-background/60 p-3 transition-colors hover:border-primary/40 hover:bg-muted/40"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{p.name}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {p.short_description}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-2 text-xs text-muted-foreground">
                      <span className="tabular-nums">{count}×</span>
                      <ArrowUpRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
                    </div>
                  </div>
                  <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-primary/70 to-accent/70 transition-[width] duration-700"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
};
