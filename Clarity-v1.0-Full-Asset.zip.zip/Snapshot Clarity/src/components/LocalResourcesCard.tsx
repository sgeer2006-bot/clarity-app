import { useEffect, useState } from "react";
import { MapPin, ExternalLink, Search, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  suggestLocalResources,
  FriendlyError,
  type LocalResourceSuggestion,
} from "@/lib/api";

interface Props {
  sessionId: string;
}

const STORAGE_KEY = "clarity:local-resources-location";

/**
 * LocalResourcesCard
 * - AI suggests categories of help that exist in the real world for this situation.
 * - The user's optional location is stored locally and appended to each search
 *   query so links go straight to a useful Google search.
 * - Suggestions are not advice, and we say so explicitly.
 */
export function LocalResourcesCard({ sessionId }: Props) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<LocalResourceSuggestion[] | null>(null);
  const [location, setLocation] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) ?? "";
    } catch {
      return "";
    }
  });

  useEffect(() => {
    try {
      if (location) localStorage.setItem(STORAGE_KEY, location);
    } catch { /* ignore */ }
  }, [location]);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await suggestLocalResources(sessionId);
      setSuggestions(list);
    } catch (e) {
      const msg =
        e instanceof FriendlyError
          ? e.message
          : "We couldn't load suggestions right now.";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const onOpen = () => {
    setOpen(true);
    if (!suggestions && !loading) load();
  };

  const buildSearchUrl = (query: string) => {
    const q = location.trim() ? `${query} ${location.trim()}` : `${query} near me`;
    return `https://www.google.com/search?q=${encodeURIComponent(q)}`;
  };

  return (
    <section className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-start gap-3">
        <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-accent-foreground" aria-hidden />
        <div className="flex-1">
          <h3 className="text-sm font-semibold">Find local help for this</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Based on what you described, here are types of real-world resources
            that often help. We don't recommend any specific provider — these
            are starting points you can search for in your own area.
          </p>
        </div>
        {!open && (
          <Button size="sm" variant="outline" onClick={onOpen}>
            Show suggestions
          </Button>
        )}
      </div>

      {open && (
        <div className="mt-4 space-y-4">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <label htmlFor="loc" className="text-xs text-muted-foreground sm:w-48">
              Your city or area (optional)
            </label>
            <Input
              id="loc"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Austin, TX"
              className="h-9"
            />
          </div>

          {loading && (
            <div className="flex items-center gap-2 py-2 text-sm text-muted-foreground">
              <span className="h-2 w-2 animate-pulse rounded-full bg-accent" />
              <span className="h-2 w-2 animate-pulse rounded-full bg-accent [animation-delay:200ms]" />
              <span className="h-2 w-2 animate-pulse rounded-full bg-accent [animation-delay:400ms]" />
              <span>Finding helpful resource categories…</span>
            </div>
          )}

          {error && !loading && (
            <div className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm">
              <p>{error}</p>
              <Button size="sm" variant="ghost" onClick={load} className="mt-2">
                <RefreshCw className="mr-1 h-3.5 w-3.5" /> Try again
              </Button>
            </div>
          )}

          {!loading && !error && suggestions && suggestions.length > 0 && (
            <ul className="space-y-2">
              {suggestions.map((s, i) => (
                <li
                  key={i}
                  className="rounded-md border border-border bg-background/60 p-3"
                >
                  <p className="text-sm font-medium">{s.title}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{s.why}</p>
                  <a
                    href={buildSearchUrl(s.search_query)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-primary underline-offset-4 hover:underline"
                  >
                    <Search className="h-3.5 w-3.5" />
                    Search
                    <span className="text-muted-foreground">
                      "{s.search_query}{location.trim() ? ` ${location.trim()}` : " near me"}"
                    </span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </li>
              ))}
            </ul>
          )}

          <p className="text-[11px] text-muted-foreground">
            These are suggestions for what to look for, not endorsements of any
            specific organization. Always verify a resource before relying on it.
          </p>
        </div>
      )}
    </section>
  );
}
