import { ReactNode } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";

export interface DashboardTab {
  key: string;
  label: string;
}

interface Props {
  tabs: DashboardTab[];
  activeKey: string;
  children: ReactNode;
}

export function TabbedDashboardLayout({ tabs, activeKey, children }: Props) {
  const navigate = useNavigate();
  const [params] = useSearchParams();

  const setTab = (k: string) => {
    const next = new URLSearchParams(params);
    next.set("tab", k);
    navigate({ search: `?${next.toString()}` }, { replace: true });
  };

  return (
    <div>
      <div className="-mx-6 mb-8 overflow-x-auto px-6 sm:mx-0 sm:px-0">
        <div className="inline-flex min-w-full gap-1 border-b border-border/60 sm:min-w-0">
          {tabs.map((t) => {
            const active = t.key === activeKey;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`relative whitespace-nowrap px-3 pb-3 pt-1 text-sm transition-colors ${
                  active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t.label}
                {active ? (
                  <span className="absolute inset-x-1 -bottom-px h-px bg-foreground/80" />
                ) : null}
              </button>
            );
          })}
        </div>
      </div>
      <div>{children}</div>
    </div>
  );
}
