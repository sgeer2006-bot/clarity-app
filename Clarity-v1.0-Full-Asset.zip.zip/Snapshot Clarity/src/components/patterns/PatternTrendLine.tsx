interface Props {
  values: number[];
  width?: number;
  height?: number;
  className?: string;
  ariaLabel?: string;
}

export function PatternTrendLine({
  values,
  width = 80,
  height = 24,
  className = "",
  ariaLabel = "Trend over time",
}: Props) {
  if (!values || values.length === 0) {
    return (
      <svg width={width} height={height} className={className} role="img" aria-label="No trend data">
        <line
          x1={0}
          y1={height / 2}
          x2={width}
          y2={height / 2}
          stroke="hsl(var(--border))"
          strokeWidth={1}
          strokeDasharray="2 3"
        />
      </svg>
    );
  }

  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const range = Math.max(max - min, 1);
  const stepX = values.length > 1 ? width / (values.length - 1) : 0;

  const pts = values
    .map((v, i) => {
      const x = i * stepX;
      const y = height - ((v - min) / range) * (height - 4) - 2;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <svg width={width} height={height} className={className} role="img" aria-label={ariaLabel}>
      <polyline
        points={pts}
        fill="none"
        stroke="hsl(var(--primary))"
        strokeOpacity={0.7}
        strokeWidth={1.25}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
