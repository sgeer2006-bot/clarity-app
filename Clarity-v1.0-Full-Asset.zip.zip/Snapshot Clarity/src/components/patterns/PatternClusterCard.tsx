import { MutedTag } from "./CalmPrimitives";

interface Props {
  name: string;
  related?: string[];
  examples?: string[];
  cohesion?: number;
}

export function PatternClusterCard({ name, related = [], examples = [], cohesion }: Props) {
  return (
    <article className="flex flex-col gap-3 rounded-2xl border border-border/60 bg-card/40 p-5 backdrop-blur-sm">
      <div className="flex items-baseline justify-between gap-3">
        <h3 className="text-sm font-medium text-foreground/90">{name}</h3>
        {typeof cohesion === "number" ? (
          <span className="text-[11px] tabular-nums text-muted-foreground/70">
            {Math.round(cohesion * 100)}% cohesion
          </span>
        ) : null}
      </div>
      {related.length > 0 ? (
        <div className="flex flex-wrap gap-1.5">
          {related.slice(0, 8).map((r) => (
            <MutedTag key={r}>{r}</MutedTag>
          ))}
        </div>
      ) : null}
      {examples.length > 0 ? (
        <ul className="mt-1 space-y-1.5 text-xs leading-relaxed text-muted-foreground">
          {examples.slice(0, 2).map((e, i) => (
            <li key={i} className="border-l border-border/60 pl-3 italic">
              "{e}"
            </li>
          ))}
        </ul>
      ) : null}
    </article>
  );
}
