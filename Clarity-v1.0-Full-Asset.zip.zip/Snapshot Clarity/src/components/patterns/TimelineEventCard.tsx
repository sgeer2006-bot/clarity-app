import { ReactNode, useState } from "react";
import { ChevronDown, Circle } from "lucide-react";

interface Props {
  date: string;
  title: string;
  summary?: string;
  icon?: ReactNode;
  children?: ReactNode;
  defaultOpen?: boolean;
}

export function TimelineEventCard({ date, title, summary, icon, children, defaultOpen = false }: Props) {
  const [open, setOpen] = useState(defaultOpen);
  const expandable = !!children;

  return (
    <div className="relative flex gap-4">
      <div className="flex flex-col items-center pt-3">
        <div className="text-muted-foreground/60">{icon ?? <Circle className="h-2.5 w-2.5 fill-current" />}</div>
        <div className="mt-2 w-px flex-1 bg-border/60" />
      </div>
      <div className="flex-1 pb-6">
        <button
          type="button"
          onClick={() => expandable && setOpen((o) => !o)}
          className="block w-full rounded-2xl border border-border/60 bg-card/40 px-4 py-3 text-left backdrop-blur-sm transition-colors hover:border-border"
          aria-expanded={expandable ? open : undefined}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground/70">{date}</p>
              <p className="mt-0.5 text-sm font-medium text-foreground/90">{title}</p>
              {summary ? (
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{summary}</p>
              ) : null}
            </div>
            {expandable ? (
              <ChevronDown
                className={`mt-1 h-4 w-4 shrink-0 text-muted-foreground transition-transform ${
                  open ? "rotate-180" : ""
                }`}
              />
            ) : null}
          </div>
          {expandable && open ? (
            <div className="mt-3 border-t border-border/40 pt-3 text-sm leading-relaxed text-muted-foreground">
              {children}
            </div>
          ) : null}
        </button>
      </div>
    </div>
  );
}
