import type { Insight } from "@/lib/insights";

export function InsightCard({ insight }: { insight: Insight }) {
  const opacity = insight.confidence === "high" ? 1 : insight.confidence === "medium" ? 0.7 : 0.4;
  return (
    <div className="rounded-xl border-l border-l-primary/40 border border-border/50 bg-muted/30 p-4">
      <div className="mb-1 flex items-center gap-2">
        <span
          aria-hidden
          className="inline-block h-1.5 w-1.5 rounded-full bg-primary"
          style={{ opacity }}
        />
        <h3 className="text-sm font-medium text-foreground/90">{insight.title}</h3>
      </div>
      <p className="text-sm leading-relaxed text-muted-foreground">{insight.body}</p>
      {insight.tags && insight.tags.length > 0 ? (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {insight.tags.map((t) => (
            <span
              key={t}
              className="rounded-full border border-primary/30 px-2 py-0.5 text-[10px] uppercase tracking-wider text-muted-foreground/80"
            >
              {t}
            </span>
          ))}
        </div>
      ) : null}
    </div>
  );
}
