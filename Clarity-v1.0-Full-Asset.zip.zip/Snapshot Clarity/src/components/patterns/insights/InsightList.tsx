import type { Insight } from "@/lib/insights";
import { InsightCard } from "./InsightCard";

export function InsightList({
  insights,
  emptyLabel = "No patterns to surface yet.",
}: {
  insights: Insight[];
  emptyLabel?: string;
}) {
  if (!insights || insights.length === 0) {
    return <p className="text-sm text-muted-foreground/80">{emptyLabel}</p>;
  }
  return (
    <div className="space-y-3">
      {insights.map((i) => (
        <InsightCard key={i.id} insight={i} />
      ))}
    </div>
  );
}
