import { useState, type ReactNode } from "react";

export function InsightNarrativeBlock({
  title,
  narrative,
  children,
  defaultOpen = false,
}: {
  title: string;
  narrative?: string;
  children?: ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className="mt-8 rounded-2xl border border-border/50 bg-card/30 p-4">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-3 text-left"
      >
        <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground/80">
          {title}
        </span>
        <span aria-hidden className="text-muted-foreground/60 text-sm">
          {open ? "−" : "+"}
        </span>
      </button>
      {open ? (
        <div className="mt-4 space-y-4">
          {narrative ? (
            <p className="max-w-prose whitespace-pre-line text-sm leading-relaxed text-foreground/85">
              {narrative}
            </p>
          ) : null}
          {children}
        </div>
      ) : null}
    </section>
  );
}
