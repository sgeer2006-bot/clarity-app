import { ReactNode } from "react";

export function EmptyState({
  icon,
  headline,
  subtext,
  className = "",
}: {
  icon?: ReactNode;
  headline: string;
  subtext?: string;
  className?: string;
}) {
  return (
    <div
      className={`flex flex-col items-center justify-center rounded-2xl border border-dashed border-border/60 bg-card/30 px-6 py-12 text-center ${className}`}
    >
      {icon ? <div className="mb-3 text-muted-foreground/50">{icon}</div> : null}
      <p className="text-sm font-medium text-foreground/80">{headline}</p>
      {subtext ? (
        <p className="mt-1.5 max-w-sm text-xs leading-relaxed text-muted-foreground/70">{subtext}</p>
      ) : null}
    </div>
  );
}
