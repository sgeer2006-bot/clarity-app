interface Props {
  heading: string;
  paragraph?: string;
  bullets?: string[];
}

export function IdentityNarrativeCard({ heading, paragraph, bullets }: Props) {
  return (
    <section className="rounded-2xl border border-border/60 bg-card/40 p-6 backdrop-blur-sm">
      <h3 className="mb-3 text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground/80">
        {heading}
      </h3>
      {paragraph ? (
        <p className="text-base leading-relaxed text-foreground/85">{paragraph}</p>
      ) : (
        <p className="text-sm italic text-muted-foreground/70">Still gathering.</p>
      )}
      {bullets && bullets.length > 0 ? (
        <ul className="mt-4 space-y-1.5 text-sm leading-relaxed text-muted-foreground">
          {bullets.slice(0, 4).map((b, i) => (
            <li key={i} className="flex gap-2">
              <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-muted-foreground/50" />
              <span>{b}</span>
            </li>
          ))}
        </ul>
      ) : null}
    </section>
  );
}
