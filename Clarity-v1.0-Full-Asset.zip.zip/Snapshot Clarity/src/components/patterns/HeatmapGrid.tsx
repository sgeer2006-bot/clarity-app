import { useMemo, useState } from "react";

export interface HeatmapCell {
  date: string; // ISO yyyy-mm-dd
  intensity: number; // 0..1
  count?: number;
  dominant?: string | null;
}

interface Props {
  cells: HeatmapCell[];
  range?: "weekly" | "monthly";
  onRangeChange?: (r: "weekly" | "monthly") => void;
}

export function HeatmapGrid({ cells, range = "weekly", onRangeChange }: Props) {
  const [hovered, setHovered] = useState<HeatmapCell | null>(null);
  const map = useMemo(() => {
    const m = new Map<string, HeatmapCell>();
    cells.forEach((c) => m.set(c.date, c));
    return m;
  }, [cells]);

  // Build a 12-week grid (7 rows × 12 cols), ending today
  const weeks = 12;
  const today = new Date();
  const grid: { date: string; cell?: HeatmapCell }[][] = [];
  // start at most-recent Sunday
  const end = new Date(today);
  end.setHours(0, 0, 0, 0);
  const dayOfWeek = end.getDay();
  const start = new Date(end);
  start.setDate(end.getDate() - (weeks * 7 - 1 - (6 - dayOfWeek)));

  for (let row = 0; row < 7; row++) {
    const rowArr: { date: string; cell?: HeatmapCell }[] = [];
    for (let col = 0; col < weeks; col++) {
      const d = new Date(start);
      d.setDate(start.getDate() + col * 7 + row);
      const iso = d.toISOString().slice(0, 10);
      rowArr.push({ date: iso, cell: map.get(iso) });
    }
    grid.push(rowArr);
  }

  const hasData = cells.length > 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-xs uppercase tracking-wider text-muted-foreground/70">Last 12 weeks</p>
        <div className="inline-flex rounded-full border border-border/60 bg-card/40 p-0.5 text-xs">
          {(["weekly", "monthly"] as const).map((r) => (
            <button
              key={r}
              onClick={() => onRangeChange?.(r)}
              className={`rounded-full px-3 py-1 transition-colors ${
                range === r
                  ? "bg-primary/10 text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {r === "weekly" ? "Weekly" : "Monthly"}
            </button>
          ))}
        </div>
      </div>
      <div className="relative">
        <div className="flex flex-col gap-1">
          {grid.map((row, ri) => (
            <div key={ri} className="flex gap-1">
              {row.map((g) => {
                const intensity = g.cell?.intensity ?? 0;
                const opacity = hasData ? Math.max(0.06, Math.min(1, intensity)) : 0.06;
                return (
                  <div
                    key={g.date}
                    onMouseEnter={() => g.cell && setHovered(g.cell)}
                    onMouseLeave={() => setHovered(null)}
                    onClick={() => g.cell && setHovered((h) => (h?.date === g.cell!.date ? null : g.cell!))}
                    className="aspect-square w-full flex-1 cursor-default rounded-[3px] border border-border/30 transition-transform hover:scale-110"
                    style={{ backgroundColor: `hsl(var(--primary) / ${opacity})` }}
                    aria-label={`${g.date}: ${g.cell ? g.cell.count ?? 0 : 0} patterns`}
                  />
                );
              })}
            </div>
          ))}
        </div>
        {hovered ? (
          <div className="mt-4 rounded-xl border border-border/60 bg-card/80 px-4 py-2.5 text-xs backdrop-blur-sm">
            <span className="font-medium text-foreground/90">
              {new Date(hovered.date).toLocaleDateString(undefined, {
                weekday: "short",
                month: "short",
                day: "numeric",
              })}
            </span>
            <span className="ml-3 text-muted-foreground">
              {hovered.count ?? 0} pattern{(hovered.count ?? 0) === 1 ? "" : "s"}
              {hovered.dominant ? ` · ${hovered.dominant}` : ""}
            </span>
          </div>
        ) : null}
      </div>
    </div>
  );
}
