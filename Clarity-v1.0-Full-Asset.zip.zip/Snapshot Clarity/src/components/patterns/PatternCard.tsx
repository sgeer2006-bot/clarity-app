import { ReactNode, useState } from "react";
import { ChevronDown } from "lucide-react";
import { PatternTrendLine } from "./PatternTrendLine";

interface Props {
  title: string;
  summary?: string;
  trend?: number[];
  defaultOpen?: boolean;
  collapsible?: boolean;
  meta?: ReactNode;
  children?: ReactNode;
}

export function PatternCard({
  title,
  summary,
  trend,
  defaultOpen = false,
  collapsible = true,
  meta,
  children,
}: Props) {
  const [open, setOpen] = useState(defaultOpen);
  const canExpand = collapsible && !!children;

  return (
    <article className="rounded-2xl border border-border/60 bg-card/40 backdrop-blur-sm transition-shadow hover:shadow-[var(--shadow-card)]">
      <button
        type="button"
        onClick={() => canExpand && setOpen((o) => !o)}
        className={`flex w-full items-start gap-4 px-5 py-4 text-left ${
          canExpand ? "cursor-pointer" : "cursor-default"
        }`}
        aria-expanded={canExpand ? open : undefined}
      >
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-medium leading-snug text-foreground/90">{title}</h3>
          {summary ? (
            <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{summary}</p>
          ) : null}
          {meta ? <div className="mt-2 text-xs text-muted-foreground/70">{meta}</div> : null}
        </div>
        {trend && trend.length > 0 ? (
          <div className="hidden shrink-0 sm:block">
            <PatternTrendLine values={trend} />
          </div>
        ) : null}
        {canExpand ? (
          <ChevronDown
            className={`mt-0.5 h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200 ${
              open ? "rotate-180" : ""
            }`}
          />
        ) : null}
      </button>
      {canExpand && open ? (
        <div className="border-t border-border/40 px-5 py-4 text-sm leading-relaxed text-muted-foreground">
          {children}
        </div>
      ) : null}
    </article>
  );
}
