import type { CSSProperties, HTMLAttributes, ReactNode } from "react";

/**
 * Phase 2 — Commit B: Calm Typography.
 *
 * Generic text wrapper using calm typography tokens.
 * Foundation only — not yet adopted anywhere.
 */

type CalmTextSize = "xs" | "sm" | "md" | "lg";
type CalmTextWeight = "regular" | "medium" | "semibold";

export interface CalmTextProps extends HTMLAttributes<HTMLSpanElement> {
  size?: CalmTextSize;
  weight?: CalmTextWeight;
  soft?: boolean;
  children?: ReactNode;
}

export function CalmText({
  size = "md",
  weight = "regular",
  soft = false,
  style,
  children,
  ...rest
}: CalmTextProps) {
  const merged: CSSProperties = {
    fontSize: `var(--calm-font-${size})`,
    fontWeight: `var(--calm-weight-${weight})` as CSSProperties["fontWeight"],
    color: soft ? "var(--calm-text-soft)" : "var(--calm-text)",
    lineHeight: "var(--calm-leading-normal)",
    ...style,
  };
  return (
    <span style={merged} {...rest}>
      {children}
    </span>
  );
}
