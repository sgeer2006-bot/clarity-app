import type { CSSProperties, ReactNode } from "react";

interface PremiumCalmLayerProps {
  children: ReactNode;
  delay?: number;
  style?: CSSProperties;
  className?: string;
}

/**
 * Phase 2 — Commit G: Premium Calm Layer.
 *
 * A pure visual wrapper that gives premium users a soft, elevated "canvas"
 * beneath their content. Token-driven, dependency-free, no logic.
 *
 * Adoption is shell-only (see AppShell). Gating happens at the call site
 * via the existing `premium_calm_layer` feature gate.
 */
export function PremiumCalmLayer({
  children,
  delay = 0,
  style,
  className,
}: PremiumCalmLayerProps) {
  const composed: CSSProperties = {
    background: "var(--calm-bg-elevated)",
    borderRadius: "var(--calm-radius-xl)",
    boxShadow: "var(--calm-shadow-lg)",
    padding: "var(--calm-space-24)",
    animationDelay: delay ? `${delay}ms` : undefined,
    ...style,
  };

  return (
    <div className={["calm-fade-in", className].filter(Boolean).join(" ")} style={composed}>
      {children}
    </div>
  );
}
