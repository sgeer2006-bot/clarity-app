import type { CSSProperties, HTMLAttributes, ReactNode } from "react";

/**
 * Phase 2 — Calm Primitives Foundation.
 *
 * Token-driven primitives that pages will adopt in later commits.
 * Foundation only — not used anywhere yet.
 *
 * Tokens consumed via CSS variables defined in `./tokens.css`.
 */

type CalmGap = "2" | "4" | "8" | "12" | "16" | "20" | "24" | "32" | "40";

const gapVar = (gap: CalmGap) => `var(--calm-space-${gap})`;

// ───────────────────────────────────────────────────────────────────────────
// CalmStack — vertical stack with token-driven gap
// ───────────────────────────────────────────────────────────────────────────
export interface CalmStackProps extends HTMLAttributes<HTMLDivElement> {
  gap?: CalmGap;
  children?: ReactNode;
}

export function CalmStack({ gap = "16", style, children, ...rest }: CalmStackProps) {
  const merged: CSSProperties = {
    display: "flex",
    flexDirection: "column",
    gap: gapVar(gap),
    ...style,
  };
  return (
    <div style={merged} {...rest}>
      {children}
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────────
// CalmSurface — generic elevated surface
// ───────────────────────────────────────────────────────────────────────────
export interface CalmSurfaceProps extends HTMLAttributes<HTMLDivElement> {
  padding?: CalmGap;
  radius?: "xs" | "sm" | "md" | "lg" | "xl";
  shadow?: "sm" | "md" | "lg" | "none";
  children?: ReactNode;
}

export function CalmSurface({
  padding,
  radius = "lg",
  shadow = "sm",
  style,
  children,
  ...rest
}: CalmSurfaceProps) {
  const merged: CSSProperties = {
    background: "var(--calm-bg-elevated)",
    borderRadius: `var(--calm-radius-${radius})`,
    boxShadow: shadow === "none" ? "none" : `var(--calm-shadow-${shadow})`,
    padding: padding ? gapVar(padding) : undefined,
    ...style,
  };
  return (
    <div style={merged} {...rest}>
      {children}
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────────
// CalmSection — opinionated elevated container
// ───────────────────────────────────────────────────────────────────────────
export interface CalmSectionProps extends HTMLAttributes<HTMLElement> {
  children?: ReactNode;
}

export function CalmSection({ style, children, ...rest }: CalmSectionProps) {
  const merged: CSSProperties = {
    background: "var(--calm-bg-elevated)",
    borderRadius: "var(--calm-radius-lg)",
    padding: "var(--calm-space-24)",
    boxShadow: "var(--calm-shadow-sm)",
    ...style,
  };
  return (
    <section style={merged} {...rest}>
      {children}
    </section>
  );
}

// ───────────────────────────────────────────────────────────────────────────
// CalmDivider — hairline separator using calm border token
// ───────────────────────────────────────────────────────────────────────────
export interface CalmDividerProps extends HTMLAttributes<HTMLHRElement> {}

export function CalmDivider({ style, ...rest }: CalmDividerProps) {
  const merged: CSSProperties = {
    border: 0,
    borderTop: "1px solid var(--calm-border)",
    width: "100%",
    margin: 0,
    ...style,
  };
  return <hr style={merged} {...rest} />;
}

// ───────────────────────────────────────────────────────────────────────────
// QuietLead — soft lead text
// ───────────────────────────────────────────────────────────────────────────
export interface QuietLeadProps extends HTMLAttributes<HTMLParagraphElement> {
  children?: ReactNode;
}

export function QuietLead({ style, children, ...rest }: QuietLeadProps) {
  const merged: CSSProperties = {
    color: "var(--calm-text-soft)",
    fontSize: "0.95rem",
    lineHeight: 1.45,
    margin: 0,
    ...style,
  };
  return (
    <p style={merged} {...rest}>
      {children}
    </p>
  );
}

// ───────────────────────────────────────────────────────────────────────────
// Backwards-compatible re-exports (legacy primitives from
// src/components/patterns/CalmPrimitives.tsx). Kept to ensure zero breakage
// while pages migrate to the new calm tokens. These remain unchanged from
// their previous behavior and are NOT yet adopted to the new tokens.
// ───────────────────────────────────────────────────────────────────────────

export function CalmCard({
  children,
  className = "",
}: {
  children?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`rounded-2xl border border-border/60 bg-card/40 p-6 backdrop-blur-sm ${className}`}
    >
      {children}
    </div>
  );
}

export function QuietHeader({
  eyebrow,
  title,
  lead,
}: {
  eyebrow?: string;
  title: string;
  lead?: string;
}) {
  return (
    <header className="mb-10 space-y-3">
      {eyebrow ? (
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground/70">{eyebrow}</p>
      ) : null}
      <h1 className="text-3xl font-light tracking-tight text-foreground sm:text-4xl">{title}</h1>
      {lead ? (
        <p className="max-w-prose text-base leading-relaxed text-muted-foreground">{lead}</p>
      ) : null}
    </header>
  );
}

export function MutedTag({ children }: { children?: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-border/50 bg-muted/40 px-2.5 py-0.5 text-xs font-normal text-muted-foreground">
      {children}
    </span>
  );
}
