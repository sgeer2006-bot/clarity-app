import { useState, type CSSProperties, type HTMLAttributes, type ReactNode } from "react";

/**
 * Phase 2 — Commit F: Calm Motion primitives.
 *
 * Tiny, dependency-free React wrappers that apply the CSS utilities
 * defined in `./motion.css`. Subtle and reduced-motion safe.
 */

// ───────────────────────────────────────────────────────────────────────────
// FadeIn
// ───────────────────────────────────────────────────────────────────────────
export interface FadeInProps extends HTMLAttributes<HTMLDivElement> {
  delay?: number;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
}

export function FadeIn({
  delay,
  className = "",
  style,
  children,
  ...rest
}: FadeInProps) {
  const merged: CSSProperties = {
    ...(delay ? { animationDelay: `${delay}ms` } : null),
    ...style,
  };
  return (
    <div className={`calm-fade-in ${className}`.trim()} style={merged} {...rest}>
      {children}
    </div>
  );
}

// ───────────────────────────────────────────────────────────────────────────
// HoverScale
// ───────────────────────────────────────────────────────────────────────────
export interface HoverScaleProps extends HTMLAttributes<HTMLSpanElement> {
  scale?: number;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
}

export function HoverScale({
  scale = 1.03,
  className = "",
  style,
  children,
  onMouseEnter,
  onMouseLeave,
  ...rest
}: HoverScaleProps) {
  const [hovered, setHovered] = useState(false);
  const merged: CSSProperties = {
    display: "inline-flex",
    transform: hovered ? `scale(${scale})` : "scale(1)",
    ...style,
  };
  return (
    <span
      className={`calm-hover-scale ${className}`.trim()}
      style={merged}
      onMouseEnter={(e) => {
        setHovered(true);
        onMouseEnter?.(e);
      }}
      onMouseLeave={(e) => {
        setHovered(false);
        onMouseLeave?.(e);
      }}
      {...rest}
    >
      {children}
    </span>
  );
}

// ───────────────────────────────────────────────────────────────────────────
// FocusRing
// ───────────────────────────────────────────────────────────────────────────
export interface FocusRingProps extends HTMLAttributes<HTMLSpanElement> {
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
}

export function FocusRing({
  className = "",
  style,
  children,
  onFocus,
  onBlur,
  ...rest
}: FocusRingProps) {
  const [focused, setFocused] = useState(false);
  return (
    <span
      data-focus={focused ? "true" : "false"}
      className={`${focused ? "calm-focus-ring" : ""} ${className}`.trim()}
      style={style}
      onFocus={(e) => {
        setFocused(true);
        onFocus?.(e);
      }}
      onBlur={(e) => {
        setFocused(false);
        onBlur?.(e);
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
