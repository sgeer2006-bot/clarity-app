import { useEffect, useState } from "react";
import { Switch } from "@/components/ui/switch";

const FLAG_KEY = "clarity.flags.calmCanvas";

function readFlag(): boolean {
  if (typeof window === "undefined") return true;
  const raw = localStorage.getItem(FLAG_KEY);
  return raw == null ? true : raw === "true";
}

export function MotionToggle() {
  const [on, setOn] = useState<boolean>(readFlag);
  useEffect(() => {
    localStorage.setItem(FLAG_KEY, String(on));
    window.dispatchEvent(new CustomEvent("clarity:visual-flags"));
  }, [on]);
  return (
    <label className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
      <span className="text-sm">
        <span className="block font-medium">Calm background motion</span>
        <span className="block text-muted-foreground text-xs">
          Soft drifting clouds. Always off if your device requests reduced motion.
        </span>
      </span>
      <Switch checked={on} onCheckedChange={setOn} />
    </label>
  );
}
