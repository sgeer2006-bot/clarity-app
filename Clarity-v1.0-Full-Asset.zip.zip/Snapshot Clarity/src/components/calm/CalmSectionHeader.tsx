import type { CSSProperties, HTMLAttributes, ReactNode } from "react";

/**
 * Phase 2 — Commit C: Calm Section Header components.
 *
 * Foundation only — not yet adopted anywhere.
 */

export interface CalmSectionHeaderProps extends HTMLAttributes<HTMLHeadingElement> {
  children?: ReactNode;
}

export function CalmSectionHeader({ style, children, ...rest }: CalmSectionHeaderProps) {
  const merged: CSSProperties = {
    fontSize: "var(--calm-h2-size)",
    lineHeight: "var(--calm-leading-tight)",
    fontWeight: "var(--calm-weight-semibold)" as CSSProperties["fontWeight"],
    marginBottom: "var(--calm-space-16)",
    color: "var(--calm-text)",
    margin: 0,
    marginBlockEnd: "var(--calm-space-16)",
    ...style,
  };
  return (
    <h2 style={merged} {...rest}>
      {children}
    </h2>
  );
}

export interface CalmSubheaderProps extends HTMLAttributes<HTMLParagraphElement> {
  children?: ReactNode;
}

export function CalmSubheader({ style, children, ...rest }: CalmSubheaderProps) {
  const merged: CSSProperties = {
    fontSize: "var(--calm-font-md)",
    lineHeight: "var(--calm-leading-normal)",
    color: "var(--calm-text-soft)",
    marginBottom: "var(--calm-space-24)",
    margin: 0,
    marginBlockEnd: "var(--calm-space-24)",
    ...style,
  };
  return (
    <p style={merged} {...rest}>
      {children}
    </p>
  );
}
