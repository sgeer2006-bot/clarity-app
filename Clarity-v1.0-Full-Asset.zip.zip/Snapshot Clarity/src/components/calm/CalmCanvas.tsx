import { useEffect, useState } from "react";

const FLAG_KEY = "clarity.flags.calmCanvas";

function readFlag(): boolean {
  if (typeof window === "undefined") return true;
  const raw = localStorage.getItem(FLAG_KEY);
  return raw == null ? true : raw === "true";
}

function prefersReducedMotion(): boolean {
  if (typeof window === "undefined" || !window.matchMedia) return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

/**
 * Phase 6 calming background — soft drifting clouds + faint horizontal eye-
 * movement gradient. GPU-light: only `transform` and `opacity`.
 *
 * Sits behind the entire app at z-index 0, pointer-events none. Phase 5's
 * `AmbientBackground` keeps working alongside it.
 */
export function CalmCanvas() {
  const [enabled, setEnabled] = useState<boolean>(() => readFlag() && !prefersReducedMotion());
  const [reduced, setReduced] = useState<boolean>(prefersReducedMotion);

  useEffect(() => {
    const onStorage = () => setEnabled(readFlag() && !prefersReducedMotion());
    const onFlag = () => setEnabled(readFlag() && !prefersReducedMotion());
    window.addEventListener("storage", onStorage);
    window.addEventListener("clarity:visual-flags", onFlag as EventListener);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("clarity:visual-flags", onFlag as EventListener);
    };
  }, []);

  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (!mq) return;
    const handler = () => {
      setReduced(mq.matches);
      setEnabled(readFlag() && !mq.matches);
    };
    mq.addEventListener?.("change", handler);
    return () => mq.removeEventListener?.("change", handler);
  }, []);

  if (!enabled) {
    // Static calm wash for reduced-motion or disabled flag.
    return (
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10"
        style={{
          background:
            "radial-gradient(ellipse 80% 50% at 30% 20%, hsl(162 28% 92% / 0.55), transparent 70%), radial-gradient(ellipse 70% 50% at 80% 80%, hsl(22 60% 90% / 0.35), transparent 70%)",
        }}
      />
    );
  }

  // Ambient mouse-driven parallax (skipped under reduced motion).
  useEffect(() => {
    if (reduced) return;
    const root = document.documentElement;
    let frame = 0;
    const onMove = (e: MouseEvent) => {
      if (frame) return;
      frame = window.requestAnimationFrame(() => {
        frame = 0;
        const x = (e.clientX / window.innerWidth - 0.5) * 12;
        const y = (e.clientY / window.innerHeight - 0.5) * 8;
        root.style.setProperty("--parallax-x", `${x.toFixed(2)}px`);
        root.style.setProperty("--parallax-y", `${y.toFixed(2)}px`);
      });
    };
    window.addEventListener("mousemove", onMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", onMove);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, [reduced]);

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden calm-breath">
      {/* faint horizontal eye-movement wash */}
      <div className="absolute inset-0 calm-eye-wash" />
      {/* slow cloud — with parallax */}
      <svg
        className="absolute -top-8 left-0 calm-drift-slow calm-parallax"
        width="60%"
        height="240"
        viewBox="0 0 800 240"
      >
        <defs>
          <radialGradient id="cloud-a" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="hsl(162 28% 90%)" stopOpacity="0.55" />
            <stop offset="100%" stopColor="hsl(162 28% 90%)" stopOpacity="0" />
          </radialGradient>
        </defs>
        <ellipse cx="400" cy="120" rx="380" ry="90" fill="url(#cloud-a)" />
      </svg>
      {/* parallax cloud */}
      <svg
        className="absolute top-1/3 right-0 calm-drift-fast calm-parallax"
        width="55%"
        height="220"
        viewBox="0 0 800 220"
      >
        <defs>
          <radialGradient id="cloud-b" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="hsl(22 60% 92%)" stopOpacity="0.4" />
            <stop offset="100%" stopColor="hsl(22 60% 92%)" stopOpacity="0" />
          </radialGradient>
        </defs>
        <ellipse cx="400" cy="110" rx="360" ry="80" fill="url(#cloud-b)" />
      </svg>
      <span className="sr-only">{reduced ? "Reduced motion active" : "Calm canvas active"}</span>
    </div>
  );
}
