/**
 * Global BackButton — renders only on non-root screens.
 *
 * Uses the existing react-router navigation (navigate(-1)) and falls back
 * to /home if there's no history. Stateless, no context, no side effects.
 */
import { ChevronLeft } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";

/** Root tab pathnames — back button is hidden on these. */
const ROOT_PATHS = new Set<string>(["/", "/home", "/reflect", "/insights", "/you"]);

export function isRootPath(pathname: string): boolean {
  return ROOT_PATHS.has(pathname);
}

interface BackButtonProps {
  className?: string;
}

export function BackButton({ className }: BackButtonProps) {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  if (isRootPath(pathname)) return null;

  const onClick = () => {
    if (window.history.length > 1) navigate(-1);
    else navigate("/home");
  };

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label="Go back"
      className={
        "inline-flex h-11 w-11 items-center justify-center rounded-md text-foreground hover:bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring " +
        (className ?? "")
      }
    >
      <ChevronLeft className="h-6 w-6" aria-hidden="true" />
    </button>
  );
}
