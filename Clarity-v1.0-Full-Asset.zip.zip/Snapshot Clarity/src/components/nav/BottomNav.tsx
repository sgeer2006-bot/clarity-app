/**
 * Bottom navigation (clarity_global_pass_v1, Part 5).
 *
 * Five-tab primary navigation: Home, Thoughts, Patterns, Tools, You.
 * Mounted globally; renders only when:
 *   - the global pass flag is on
 *   - the user is signed in
 *   - the current route is not an auth/onboarding/share surface
 *
 * Each tab maps to an existing route — this commit does not move pages
 * around, it just gives users a single, consistent way to reach the four
 * spaces. Route aliases (/thoughts, /patterns, /tools, /you) are added in
 * App.tsx so the URLs feel native to the new model.
 */

import { NavLink, useLocation } from "react-router-dom";
import {
  Home as HomeIcon,
  MessageSquareText,
  Sparkles,
  CircleUserRound,
} from "lucide-react";
import { useAuthSession } from "@/hooks/useAuthSession";
import { isGlobalPassEnabled } from "@/lib/flags/globalPass";
import { useFTUEController } from "@/ftue/useFTUEController";
import { cn } from "@/lib/utils";

interface Tab {
  to: string;
  label: string;
  Icon: typeof HomeIcon;
  /** Other paths that should also light this tab as active. */
  match: (pathname: string) => boolean;
}

const TABS: Tab[] = [
  {
    to: "/home",
    label: "Home",
    Icon: HomeIcon,
    match: (p) => p === "/" || p === "/home",
  },
  {
    to: "/reflect",
    label: "Questions",
    Icon: MessageSquareText,
    match: (p) =>
      p.startsWith("/thoughts") ||
      p.startsWith("/reflect") ||
      p.startsWith("/questions") ||
      p.startsWith("/new") ||
      p.startsWith("/follow-up") ||
      p.startsWith("/correct") ||
      p.startsWith("/snapshot") ||
      p.startsWith("/loading") ||
      p.startsWith("/fast-clarity") ||
      p.startsWith("/compose") ||
      p.startsWith("/two-person") ||
      p.startsWith("/shared"),
  },
  {
    to: "/insights",
    label: "Daily Insights",
    Icon: Sparkles,
    match: (p) =>
      p.startsWith("/insights") ||
      p.startsWith("/dashboard") ||
      p.startsWith("/patterns") ||
      p.startsWith("/pattern") ||
      p.startsWith("/story") ||
      p.startsWith("/p/"),
  },
  {
    to: "/you",
    label: "You",
    Icon: CircleUserRound,
    match: (p) =>
      p.startsWith("/you") ||
      p.startsWith("/settings") ||
      p.startsWith("/billing") ||
      p.startsWith("/clarity-plus") ||
      p.startsWith("/about") ||
      p.startsWith("/help") ||
      p.startsWith("/safety"),
  },
];

const HIDDEN_PREFIXES = [
  "/auth",
  "/onboarding",
  "/share/",
  "/s/",
  "/two-person/invite/",
];

function shouldHide(pathname: string): boolean {
  return HIDDEN_PREFIXES.some((p) => pathname === p || pathname.startsWith(p));
}

export function BottomNav() {
  const { pathname } = useLocation();
  const { isAuthed, loading } = useAuthSession();
  const { surface } = useFTUEController();

  if (!isGlobalPassEnabled()) return null;
  if (loading || !isAuthed) return null;
  if (surface !== "none") return null;
  if (shouldHide(pathname)) return null;

  return (
    <nav
      aria-label="Primary"
      className="fixed inset-x-0 bottom-0 z-30 border-t border-border/60 bg-background/90 backdrop-blur-md pb-[env(safe-area-inset-bottom)]"
    >
      <ul className="mx-auto flex h-16 max-w-content-wide items-stretch justify-around px-2">
        {TABS.map(({ to, label, Icon, match }) => {
          const active = match(pathname);
          return (
            <li key={to} className="flex-1">
              <NavLink
                to={to}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex h-full flex-col items-center justify-center gap-1 rounded-md text-[11px] transition-colors",
                  active
                    ? "text-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <Icon
                  className={cn(
                    "h-5 w-5 transition-transform",
                    active && "scale-110",
                  )}
                  aria-hidden
                />
                <span className="font-medium">{label}</span>
              </NavLink>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

/** Public helper so layouts know whether to reserve bottom space. */
export function useBottomNavVisible(): boolean {
  const { pathname } = useLocation();
  const { isAuthed, loading } = useAuthSession();
  const { surface } = useFTUEController();
  if (!isGlobalPassEnabled()) return false;
  if (loading || !isAuthed) return false;
  if (surface !== "none") return false;
  if (shouldHide(pathname)) return false;
  return true;
}
