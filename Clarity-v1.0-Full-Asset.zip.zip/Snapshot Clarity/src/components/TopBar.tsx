import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X, LogOut } from "lucide-react";
import { BackButton } from "@/components/nav/BackButton";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useAuthSession } from "@/hooks/useAuthSession";
import { supabase } from "@/integrations/supabase/client";

/**
 * Unified TopBar — single navigation system for mobile + desktop.
 * Logo on the left, hamburger on the right that opens a slide-out left menu.
 *
 * Signed-out users see "Log in" and "Create account" CTAs in the header
 * for effortless return. Signed-in users see the menu with a Sign out row.
 */

type MenuItem = { label: string; to: string };
type MenuSection = { title: string; items: MenuItem[] };

const SECTIONS: MenuSection[] = [
  { title: "Home", items: [{ label: "Home", to: "/home" }] },
  {
    title: "Questions",
    items: [
      { label: "Questions", to: "/reflect" },
      { label: "Fast Clarity", to: "/questions/fast" },
    ],
  },
  { title: "Daily Insights", items: [{ label: "Daily Insights", to: "/insights" }] },
  { title: "Patterns", items: [{ label: "Patterns", to: "/patterns" }] },
  { title: "Your Story", items: [{ label: "Your Story", to: "/story" }] },
  { title: "You", items: [{ label: "You", to: "/you" }] },
  { title: "Safety Resources", items: [{ label: "Safety Resources", to: "/safety/resources" }] },
  { title: "Shared Clarity", items: [{ label: "Shared Clarity", to: "/shared" }] },
  { title: "Clarity+", items: [{ label: "Clarity+", to: "/clarity-plus" }] },
  { title: "Info", items: [{ label: "Info", to: "/about" }] },
];

export const TopBar = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthed, loading } = useAuthSession();

  const go = (to: string) => {
    setOpen(false);
    navigate(to);
  };

  const signOut = async () => {
    setOpen(false);
    await supabase.auth.signOut();
    navigate("/home");
  };

  const next = encodeURIComponent(location.pathname + location.search);

  return (
    <header className="sticky top-0 z-30 h-14 border-b border-border/60 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-full max-w-content-wide items-center justify-between px-4 sm:px-6">
        <div className="flex items-center gap-1">
          <BackButton />
          <Link
            to="/home"
            aria-label="Clarity home"
            className="font-display text-lg font-semibold tracking-tight"
          >
            Clarity
          </Link>
        </div>

        <div className="flex items-center gap-2">
          {!loading && !isAuthed && (
            <>
              <Button asChild variant="ghost" size="sm" className="h-9 rounded-full px-3 text-sm">
                <Link to={`/auth?next=${next}`}>Log in</Link>
              </Button>
              <Button asChild size="sm" className="h-9 rounded-full px-3 text-sm">
                <Link to={`/auth?next=${next}&mode=signup`}>Create account</Link>
              </Button>
            </>
          )}

          {isAuthed && (
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger
                aria-label="Open menu"
                className="inline-flex h-11 w-11 items-center justify-center rounded-md text-foreground hover:bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <Menu className="h-6 w-6" aria-hidden="true" />
              </SheetTrigger>
              <SheetContent
                side="left"
                className="flex w-[88%] max-w-sm flex-col gap-0 overflow-y-auto p-0"
              >
                <div className="flex items-center justify-between border-b border-border/60 px-4 py-3">
                  <span className="font-display text-base font-semibold">Menu</span>
                  <SheetClose
                    aria-label="Close menu"
                    className="inline-flex h-11 w-11 items-center justify-center rounded-md hover:bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <X className="h-5 w-5" aria-hidden="true" />
                  </SheetClose>
                </div>

                <nav aria-label="Primary" className="flex-1 px-2 py-2">
                  {SECTIONS.map((section) => (
                    <div key={section.title} className="mb-4">
                      <div className="px-3 pb-1 pt-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                        {section.title}
                      </div>
                      <ul>
                        {section.items.map((item) => (
                          <li key={`${section.title}-${item.label}`}>
                            <button
                              type="button"
                              onClick={() => go(item.to)}
                              className="flex min-h-12 w-full items-center rounded-md px-3 text-left text-base text-foreground hover:bg-muted/60 focus:outline-none focus:ring-2 focus:ring-ring"
                            >
                              {item.label}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}

                  <div className="mb-2 mt-2 border-t border-border/60 pt-2">
                    <button
                      type="button"
                      onClick={signOut}
                      className="flex min-h-12 w-full items-center gap-2 rounded-md px-3 text-left text-base text-foreground hover:bg-muted/60 focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      <LogOut className="h-4 w-4" aria-hidden />
                      Sign out
                    </button>
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          )}
        </div>
      </div>
    </header>
  );
};
