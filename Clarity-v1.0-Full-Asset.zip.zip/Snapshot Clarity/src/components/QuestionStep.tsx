import { useEffect, useState, KeyboardEvent } from "react";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ProgressBar } from "./ProgressBar";
import { FIRST_QUESTION_PLACEHOLDER, QuestionType } from "@/lib/types";

interface Props {
  step: number;
  /** Soft target used to show ~progress; the real flow may go further. */
  target: number;
  question: string;
  questionType?: QuestionType;
  minChars?: number;
  initial?: string;
  isLast?: boolean;
  onBack?: () => void;
  onNext: (value: string) => Promise<void> | void;
  /** Optional regenerate handler. When provided, shows a "Regenerate Question" button. */
  onRegenerate?: () => Promise<void> | void;
  /** When true, regeneration is in flight; disables the regenerate button. */
  regenerating?: boolean;
  /** Optional async nudge generator for too-short answers. */
  getNudge?: (currentQuestion: string, answer: string) => Promise<string>;
}

const HARD_MAX = 1000;
const BRIEF_FLOOR = 25; // QIL: support brief-answer users.

export const QuestionStep = ({
  step,
  target,
  question,
  questionType = "open",
  minChars = 0,
  initial = "",
  isLast,
  onBack,
  onNext,
  onRegenerate,
  regenerating = false,
  getNudge,
}: Props) => {
  const [value, setValue] = useState(initial);
  const [submitting, setSubmitting] = useState(false);
  const [nudge, setNudge] = useState<string | null>(null);
  const [nudgeLoading, setNudgeLoading] = useState(false);

  useEffect(() => {
    setValue(initial);
    setNudge(null);
  }, [initial, step, question]);

  const trimmed = value.trim();
  // Effective minimum: lower of the LLM's per-question min and our brief floor,
  // but never less than the brief floor. This supports brief-answer users
  // while preserving question-specific guidance.
  const effectiveMin = questionType === "yesno" ? 0 : Math.min(minChars, BRIEF_FLOOR) || 0;
  const meetsMin = questionType === "yesno" ? true : trimmed.length >= effectiveMin;

  const submitOpen = async () => {
    if (submitting) return;
    if (!meetsMin) {
      // Generate a contextual nudge instead of a generic error.
      if (getNudge) {
        setNudgeLoading(true);
        try {
          const n = await getNudge(question, trimmed);
          setNudge(n);
        } finally {
          setNudgeLoading(false);
        }
      } else {
        setNudge("Could you add a bit more detail so I can understand this better?");
      }
      return;
    }
    setSubmitting(true);
    try {
      await onNext(trimmed);
    } finally {
      setSubmitting(false);
    }
  };

  const submitYesNo = async (val: "Yes" | "No") => {
    if (submitting) return;
    setSubmitting(true);
    try {
      await onNext(val);
    } finally {
      setSubmitting(false);
    }
  };

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") submitOpen();
  };

  return (
    <div className="space-y-6 animate-fade-in-up">
      <ProgressBar current={step} total={target} />
      <div className="space-y-3">
        <h2 className="font-display text-2xl font-medium leading-snug tracking-tight sm:text-[26px]">
          {question}
        </h2>
        {onRegenerate && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => onRegenerate()}
            disabled={regenerating || submitting}
            aria-label="Regenerate this question"
            className="h-7 gap-1.5 px-2 text-xs text-muted-foreground hover:text-foreground"
          >
            <RefreshCw className={`h-3 w-3 ${regenerating ? "animate-spin" : ""}`} aria-hidden />
            {regenerating ? "Rethinking…" : "Regenerate question"}
          </Button>
        )}
      </div>

      {questionType === "yesno" ? (
        <div className="grid grid-cols-2 gap-3 pt-2">
          <Button
            size="lg"
            variant="outline"
            className="h-20 rounded-xl bg-card text-lg font-medium shadow-card transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-elevated active:translate-y-0"
            disabled={submitting || regenerating}
            onClick={() => submitYesNo("Yes")}
          >
            Yes
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="h-20 rounded-xl bg-card text-lg font-medium shadow-card transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-elevated active:translate-y-0"
            disabled={submitting || regenerating}
            onClick={() => submitYesNo("No")}
          >
            No
          </Button>
        </div>
      ) : (
        <div>
          <Textarea
            rows={step === 1 ? 8 : 6}
            value={value}
            maxLength={HARD_MAX}
            onChange={(e) => {
              setValue(e.target.value.slice(0, HARD_MAX));
              if (nudge) setNudge(null);
            }}
            onKeyDown={onKey}
            placeholder={
              step === 1
                ? FIRST_QUESTION_PLACEHOLDER
                : "Take your time — type your answer here…"
            }
            disabled={regenerating}
            className="resize-none rounded-xl border-border bg-background/60 p-4 text-base leading-relaxed shadow-inner transition-shadow focus-visible:bg-background focus-visible:shadow-card disabled:opacity-60"
          />
          <div className="mt-2 min-h-5 text-xs text-muted-foreground">
            {nudgeLoading ? (
              <span className="italic">Thinking of a gentle prompt…</span>
            ) : nudge ? (
              <span className="text-foreground/80">{nudge}</span>
            ) : (
              "\u00A0"
            )}
          </div>
        </div>
      )}

      {questionType === "open" && (
        <div className="flex items-center justify-between pt-2">
          <Button variant="ghost" onClick={onBack} disabled={!onBack || submitting || regenerating} className="rounded-full">
            Back
          </Button>
          <Button
            onClick={submitOpen}
            disabled={submitting || regenerating}
            size="lg"
            className="min-w-32 rounded-full px-6 shadow-card transition-shadow hover:shadow-elevated"
          >
            {submitting ? "Saving…" : isLast ? "Generate snapshot" : "Continue"}
          </Button>
        </div>
      )}
      {questionType === "yesno" && (
        <div className="flex items-center justify-start pt-2">
          <Button variant="ghost" onClick={onBack} disabled={!onBack || submitting || regenerating} className="rounded-full">
            Back
          </Button>
        </div>
      )}
    </div>
  );
};
