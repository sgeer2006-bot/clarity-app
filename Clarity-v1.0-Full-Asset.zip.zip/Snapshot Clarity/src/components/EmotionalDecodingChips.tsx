import { useEffect, useState } from "react";
import { Heart } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  sessionId: string;
}

/**
 * Shows the emotions captured in the session's ContextModel as colored chips.
 * Falls back silently if the engine v2 context model isn't populated.
 */
export const EmotionalDecodingChips = ({ sessionId }: Props) => {
  const [emotions, setEmotions] = useState<string[]>([]);
  const [needs, setNeeds] = useState<string[]>([]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("session_context_models")
        .select("emotions, unspoken_needs")
        .eq("session_id", sessionId)
        .maybeSingle();
      if (cancelled || !data) return;
      const norm = (v: unknown): string[] =>
        Array.isArray(v)
          ? (v as unknown[])
              .map((x) =>
                typeof x === "string"
                  ? x
                  : x && typeof x === "object" && "value" in (x as any)
                  ? String((x as any).value)
                  : "",
              )
              .filter(Boolean)
              .slice(0, 6)
          : [];
      setEmotions(norm((data as any).emotions));
      setNeeds(norm((data as any).unspoken_needs));
    })();
    return () => { cancelled = true; };
  }, [sessionId]);

  if (emotions.length === 0 && needs.length === 0) return null;

  return (
    <section className="rounded-xl border border-primary/20 bg-primary/5 p-5">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-primary/10 p-2 text-primary">
          <Heart className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="text-base font-semibold leading-tight">Emotional decoding</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            What seems to be moving underneath the words you shared.
          </p>

          {emotions.length > 0 && (
            <div className="mt-4">
              <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                Feelings
              </p>
              <ul className="mt-1.5 flex flex-wrap gap-1.5">
                {emotions.map((e, i) => (
                  <li
                    key={i}
                    className="rounded-full border border-primary/30 bg-background/70 px-2.5 py-1 text-xs text-foreground"
                  >
                    {e}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {needs.length > 0 && (
            <div className="mt-3">
              <p className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                Possibly unspoken needs
              </p>
              <ul className="mt-1.5 flex flex-wrap gap-1.5">
                {needs.map((e, i) => (
                  <li
                    key={i}
                    className="rounded-full border border-accent/40 bg-accent/10 px-2.5 py-1 text-xs text-foreground"
                  >
                    {e}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
