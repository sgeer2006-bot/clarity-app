import { useEffect, useState } from "react";
import { History as HistoryIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import type { SnapshotJson } from "@/lib/types";

interface VersionRow {
  id: string;
  version_number: number;
  summary: string;
  observations: unknown;
  possible_paths: unknown;
  recommended_next_steps: unknown;
  common_misunderstandings: unknown;
  how_to_communicate: unknown;
  disclaimer: string;
  created_at: string;
}

interface Props {
  sessionId: string;
  /** Current/latest version number, used to label the "current" entry. */
  currentVersion?: number;
  /**
   * Called when the user picks a version. `null` means "go back to current".
   * The page is responsible for re-rendering the SnapshotView with this
   * snapshot data; this component does not mutate the database.
   */
  onSelect: (snapshot: SnapshotJson | null, versionNumber: number | null) => void;
  /** What's currently being viewed (null = current/latest). */
  selectedVersion: number | null;
}

function fmt(iso: string) {
  return new Date(iso).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function toStringArray(v: unknown): string[] {
  if (!Array.isArray(v)) return [];
  return v.filter((x): x is string => typeof x === "string");
}

/**
 * Lets the user browse prior snapshot versions for a session. Hidden when
 * there is only one version (nothing to compare).
 */
export const SnapshotVersionPicker = ({
  sessionId,
  currentVersion,
  onSelect,
  selectedVersion,
}: Props) => {
  const [versions, setVersions] = useState<VersionRow[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("snapshot_versions")
        .select("id, version_number, summary, observations, possible_paths, recommended_next_steps, common_misunderstandings, how_to_communicate, disclaimer, created_at")
        .eq("session_id", sessionId)
        .order("version_number", { ascending: false });
      if (!cancelled) setVersions((data as VersionRow[]) || []);
    })();
    return () => { cancelled = true; };
  }, [sessionId]);

  if (!versions || versions.length < 2) return null;

  const handlePick = (v: VersionRow) => {
    if (currentVersion && v.version_number === currentVersion) {
      onSelect(null, null);
      return;
    }
    onSelect(
      {
        summary: v.summary,
        observations: toStringArray(v.observations),
        possible_paths: toStringArray(v.possible_paths),
        recommended_next_steps: toStringArray(v.recommended_next_steps),
        common_misunderstandings: toStringArray(v.common_misunderstandings),
        how_to_communicate: toStringArray(v.how_to_communicate),
        disclaimer: v.disclaimer,
      },
      v.version_number,
    );
  };

  const label =
    selectedVersion == null
      ? `Current${currentVersion ? ` (v${currentVersion})` : ""}`
      : `Viewing v${selectedVersion}`;

  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border bg-muted/30 px-4 py-2 text-sm">
      <div className="flex items-center gap-2 text-muted-foreground">
        <HistoryIcon className="h-4 w-4" />
        <span>
          {versions.length} versions of this snapshot ·{" "}
          <span className="font-medium text-foreground">{label}</span>
        </span>
      </div>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm">
            {selectedVersion == null ? "View an earlier version" : "Switch version"}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel className="text-xs">Snapshot versions</DropdownMenuLabel>
          {selectedVersion != null && (
            <>
              <DropdownMenuItem onClick={() => onSelect(null, null)}>
                Back to current{currentVersion ? ` (v${currentVersion})` : ""}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
            </>
          )}
          {versions.map((v) => {
            const isCurrent = currentVersion === v.version_number;
            const isViewing = selectedVersion === v.version_number;
            return (
              <DropdownMenuItem
                key={v.id}
                onClick={() => handlePick(v)}
                disabled={isViewing || (isCurrent && selectedVersion == null)}
                className="flex items-center justify-between gap-3"
              >
                <span>
                  v{v.version_number}
                  {isCurrent ? " · current" : ""}
                </span>
                <span className="text-xs text-muted-foreground">{fmt(v.created_at)}</span>
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};
