import { useEffect, useState } from "react";
import { canUse } from "@/lib/featureGate";

/**
 * Phase 2 — Premium calm layer. A subtle breathing/orb motion overlay above
 * the base CalmCanvas. Respects prefers-reduced-motion and is gated by the
 * `premium_calm_layer` feature.
 *
 * Toggle persisted under localStorage key 'clarity.flags.premiumCalm'.
 * Non-premium users see a static preview when forced (preview mode).
 */

const FLAG_KEY = "clarity.flags.premiumCalm";

export function readPremiumCalm(): boolean {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(FLAG_KEY) === "true";
}

export function writePremiumCalm(on: boolean) {
  localStorage.setItem(FLAG_KEY, String(on));
  window.dispatchEvent(new CustomEvent("clarity:visual-flags"));
}

function reduced(): boolean {
  if (typeof window === "undefined" || !window.matchMedia) return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

interface Props {
  /** Force-render even without premium (used for static preview). */
  preview?: boolean;
}

export function PremiumCalmLayer({ preview = false }: Props) {
  const [on, setOn] = useState<boolean>(readPremiumCalm);
  const [isReduced, setIsReduced] = useState<boolean>(reduced);

  useEffect(() => {
    const onFlag = () => setOn(readPremiumCalm());
    window.addEventListener("clarity:visual-flags", onFlag as EventListener);
    window.addEventListener("storage", onFlag);
    return () => {
      window.removeEventListener("clarity:visual-flags", onFlag as EventListener);
      window.removeEventListener("storage", onFlag);
    };
  }, []);

  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (!mq) return;
    const h = () => setIsReduced(mq.matches);
    mq.addEventListener?.("change", h);
    return () => mq.removeEventListener?.("change", h);
  }, []);

  const allowed = canUse("premium_calm_layer");
  const visible = preview || (on && allowed);
  if (!visible) return null;

  const animate = !isReduced && !preview;

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-[5] overflow-hidden"
    >
      <div
        className={animate ? "absolute -left-1/4 top-1/4 h-[50vh] w-[50vh] rounded-full opacity-40 calm-breath" : "absolute -left-1/4 top-1/4 h-[50vh] w-[50vh] rounded-full opacity-30"}
        style={{
          background:
            "radial-gradient(circle, hsl(162 40% 80% / 0.45), hsl(162 28% 90% / 0) 70%)",
          filter: "blur(40px)",
        }}
      />
      <div
        className={animate ? "absolute right-0 bottom-0 h-[60vh] w-[60vh] rounded-full opacity-40 calm-breath" : "absolute right-0 bottom-0 h-[60vh] w-[60vh] rounded-full opacity-30"}
        style={{
          background:
            "radial-gradient(circle, hsl(22 60% 88% / 0.5), hsl(22 60% 90% / 0) 70%)",
          filter: "blur(50px)",
          animationDelay: "1.5s",
        }}
      />
    </div>
  );
}
