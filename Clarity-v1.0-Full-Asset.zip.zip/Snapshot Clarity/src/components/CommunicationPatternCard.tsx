import { useEffect, useState } from "react";
import { TrendingUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  userId: string;
  /** Exclude the current snapshot from the count so the user doesn't see "1 time". */
  excludeSessionId?: string;
}

interface RecurringPattern {
  name: string;
  short_description: string;
  count: number;
}

/**
 * Shows the user's recurring pattern identities across past completed sessions.
 * Renders nothing if the user has fewer than 2 completed snapshots with identities.
 */
export const CommunicationPatternCard = ({ userId, excludeSessionId }: Props) => {
  const [items, setItems] = useState<RecurringPattern[]>([]);
  const [totalSessions, setTotalSessions] = useState(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("reflection_sessions")
        .select("id, pattern_identity_id, pattern_identities(name, short_description)")
        .eq("user_id", userId)
        .eq("status", "complete")
        .is("deleted_at", null)
        .not("pattern_identity_id", "is", null);

      if (cancelled || !data) return;

      const filtered = excludeSessionId
        ? data.filter((r: any) => r.id !== excludeSessionId)
        : data;
      setTotalSessions(filtered.length);

      const counts = new Map<string, RecurringPattern>();
      for (const r of filtered as any[]) {
        const pi = r.pattern_identities;
        if (!pi?.name) continue;
        const existing = counts.get(pi.name);
        if (existing) {
          existing.count += 1;
        } else {
          counts.set(pi.name, {
            name: pi.name,
            short_description: pi.short_description ?? "",
            count: 1,
          });
        }
      }

      const sorted = Array.from(counts.values())
        .filter((c) => c.count >= 2)
        .sort((a, b) => b.count - a.count)
        .slice(0, 3);

      setItems(sorted);
    })();
    return () => { cancelled = true; };
  }, [userId, excludeSessionId]);

  if (items.length === 0) return null;

  return (
    <section className="rounded-xl border border-border bg-muted/30 p-5">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-foreground/10 p-2 text-foreground">
          <TrendingUp className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="text-base font-semibold leading-tight">Your recurring pattern</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            What's been showing up across your past {totalSessions} reflection
            {totalSessions === 1 ? "" : "s"}.
          </p>
          <ul className="mt-3 space-y-2">
            {items.map((p) => (
              <li
                key={p.name}
                className="flex items-start justify-between gap-3 rounded-lg border border-border bg-background/60 px-3 py-2"
              >
                <div className="min-w-0">
                  <p className="text-sm font-medium">{p.name}</p>
                  {p.short_description && (
                    <p className="mt-0.5 truncate text-xs text-muted-foreground">
                      {p.short_description}
                    </p>
                  )}
                </div>
                <span className="shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-[10px] font-medium text-foreground">
                  {p.count}× this season
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
};
