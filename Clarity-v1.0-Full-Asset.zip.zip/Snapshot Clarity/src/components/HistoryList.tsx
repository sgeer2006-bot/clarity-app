import { Link } from "react-router-dom";

interface Item {
  id: string;
  title: string;
  created_at: string;
}

function formatTs(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export const HistoryList = ({ items }: { items: Item[] }) => {
  return (
    <ul className="rounded-xl border border-border bg-card">
      {items.map((it, i) => (
        <li key={it.id} className={i > 0 ? "border-t border-border" : ""}>
          <Link
            to={`/snapshot/${it.id}`}
            className="flex h-14 items-center justify-between px-4 hover:bg-muted/50"
          >
            <span className="truncate pr-4 text-base">{it.title}</span>
            <span className="shrink-0 text-sm text-muted-foreground">
              {formatTs(it.created_at)}
            </span>
          </Link>
        </li>
      ))}
    </ul>
  );
};
