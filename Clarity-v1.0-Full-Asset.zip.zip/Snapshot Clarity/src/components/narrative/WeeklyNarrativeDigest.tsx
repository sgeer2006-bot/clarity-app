import { useEffect, useState } from "react";
import { ActivityPoint, UserPatternCount } from "@/lib/analytics";
import { getState, getTimeline } from "@/lib/identity";
import { DIMENSION_LABEL } from "@/lib/identity/dimensions";
import type { Dimension } from "@/lib/identity/types";
import { Link } from "react-router-dom";
import { ArrowRight, Sparkles } from "lucide-react";

interface Props {
  activity: ActivityPoint[];
  topPattern?: UserPatternCount;
  streak: number;
}

/**
 * Phase 7 — Weekly narrative digest.
 * Non-therapeutic, identity-based. Composes:
 *   • Top pattern  • Surprising insight  • Identity shift
 *   • Relational signal  • Continuation nudge  • Return-to-meaning suggestion
 */
export function WeeklyNarrativeDigest({ activity, topPattern, streak }: Props) {
  const [identityShift, setIdentityShift] = useState<string>("");
  const [relationalSignal, setRelationalSignal] = useState<string>("");
  const [surprise, setSurprise] = useState<string>("");

  useEffect(() => {
    const compute = () => {
      const tl = getTimeline("30d");
      const now = Date.now();
      const SEVEN = 7 * 24 * 60 * 60 * 1000;
      const recent = new Map<Dimension, number>();
      const prior = new Map<Dimension, number>();
      for (const e of tl) {
        const t = new Date(e.ts).getTime();
        const m = now - t <= SEVEN ? recent : prior;
        m.set(e.dimension, (m.get(e.dimension) ?? 0) + Math.abs(e.delta));
      }
      let topShiftDim: Dimension | null = null;
      let topShift = 0;
      for (const d of recent.keys()) {
        const delta = (recent.get(d) ?? 0) - (prior.get(d) ?? 0);
        if (Math.abs(delta) > Math.abs(topShift)) {
          topShift = delta;
          topShiftDim = d;
        }
      }
      if (topShiftDim && topShift !== 0) {
        setIdentityShift(
          `${DIMENSION_LABEL[topShiftDim]} ${topShift > 0 ? "felt more present" : "stayed quieter"} this week.`
        );
      } else {
        setIdentityShift("Your identity dimensions held a steady rhythm this week.");
      }

      const s = getState();
      const rels = Object.entries(s.relationships)
        .sort((a, b) => b[1].count - a[1].count)
        .slice(0, 1);
      if (rels.length) {
        setRelationalSignal(`${rels[0][0]} appeared in your reflections most often.`);
      } else {
        setRelationalSignal("Your reflections stayed close to your own inner world.");
      }

      // Surprise: smallest non-zero recent dim that wasn't there before
      const surprises: Dimension[] = [];
      for (const d of recent.keys()) {
        if (!prior.has(d) && (recent.get(d) ?? 0) > 0) surprises.push(d);
      }
      if (surprises[0]) {
        setSurprise(`${DIMENSION_LABEL[surprises[0]]} surfaced in a way they hadn't lately.`);
      } else {
        setSurprise("Nothing dramatic — just continued attention to what's familiar.");
      }
    };
    compute();
  }, [activity]);

  const last7Total = activity.slice(-7).reduce((s, d) => s + Number(d.session_count), 0);

  return (
    <article className="card-elevated p7-bloom relative overflow-hidden p-6 sm:p-8">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full bg-primary/15 blur-3xl"
      />
      <div className="relative space-y-5">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" aria-hidden />
          <span className="label-eyebrow">A weekly story</span>
        </div>
        <h2 className="font-display text-2xl font-semibold leading-tight tracking-tight sm:text-3xl">
          {last7Total === 0
            ? "A quieter week — space is its own kind of clarity."
            : `${last7Total} ${last7Total === 1 ? "reflection" : "reflections"} this week.`}
        </h2>

        <ul className="grid gap-3 sm:grid-cols-2">
          {topPattern && (
            <NarrativeRow label="Top pattern" body={topPattern.name} />
          )}
          <NarrativeRow label="Identity shift" body={identityShift} />
          <NarrativeRow label="Relational signal" body={relationalSignal} />
          <NarrativeRow label="Something new" body={surprise} />
          {streak > 0 && (
            <NarrativeRow
              label="Continuity"
              body={`A ${streak}-day rhythm of returning.`}
            />
          )}
        </ul>

        <div className="flex flex-wrap items-center gap-3 pt-1 text-sm">
          <Link
            to="/reflect"
            className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-primary-foreground shadow-card transition hover:shadow-elevated"
          >
            Continue your reflection
            <ArrowRight className="h-3.5 w-3.5" aria-hidden />
          </Link>
          <Link
            to="/insights"
            className="text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
          >
            Return to what was meaningful
          </Link>
        </div>
      </div>
    </article>
  );
}

function NarrativeRow({ label, body }: { label: string; body: string }) {
  return (
    <li className="rounded-xl border border-border/60 bg-background/50 p-3.5">
      <div className="label-eyebrow text-[10px]">{label}</div>
      <p className="mt-1 text-sm leading-relaxed text-foreground/90">{body}</p>
    </li>
  );
}
