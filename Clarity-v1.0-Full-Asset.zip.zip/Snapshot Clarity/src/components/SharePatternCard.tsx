import { forwardRef } from "react";
import { Sparkles } from "lucide-react";

interface Props {
  name: string;
  shortDescription: string;
  emotionalMeaning: string;
  otherPersonTip: string;
  statLine?: string | null;
}

/**
 * Branded shareable card for a single pattern. Matches snapshot card style.
 * Fixed at 1080x1080 (square only — patterns share well in square format).
 */
export const SharePatternCard = forwardRef<HTMLDivElement, Props>(
  ({ name, shortDescription, emotionalMeaning, otherPersonTip, statLine }, ref) => {
    return (
      <div
        ref={ref}
        style={{
          width: "1080px",
          height: "1080px",
          background:
            "linear-gradient(135deg, hsl(36, 38%, 96%) 0%, hsl(36, 30%, 92%) 50%, hsl(28, 35%, 90%) 100%)",
          fontFamily:
            "'Inter', system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
          color: "hsl(25, 20%, 18%)",
          padding: "80px",
          display: "flex",
          flexDirection: "column",
          position: "relative",
          overflow: "hidden",
          boxSizing: "border-box",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: "-200px",
            right: "-200px",
            width: "600px",
            height: "600px",
            borderRadius: "50%",
            background:
              "radial-gradient(circle, hsla(28, 60%, 70%, 0.35) 0%, transparent 70%)",
          }}
        />
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "16px",
            marginBottom: "48px",
            position: "relative",
          }}
        >
          <div
            style={{
              width: "56px",
              height: "56px",
              borderRadius: "16px",
              background:
                "linear-gradient(135deg, hsl(28, 70%, 55%) 0%, hsl(20, 65%, 50%) 100%)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "white",
            }}
          >
            <Sparkles size={28} strokeWidth={2.4} />
          </div>
          <span
            style={{
              fontFamily: "'Fraunces', Georgia, serif",
              fontSize: "32px",
              fontWeight: 600,
              color: "hsl(25, 30%, 20%)",
            }}
          >
            Clarity · Pattern
          </span>
        </div>

        <h1
          style={{
            fontFamily: "'Fraunces', Georgia, serif",
            fontSize: "72px",
            fontWeight: 600,
            lineHeight: 1.05,
            letterSpacing: "-0.02em",
            margin: 0,
            marginBottom: "24px",
            color: "hsl(25, 30%, 18%)",
            position: "relative",
          }}
        >
          {name}
        </h1>
        <p
          style={{
            fontSize: "30px",
            lineHeight: 1.4,
            margin: 0,
            marginBottom: "40px",
            color: "hsl(25, 20%, 28%)",
            position: "relative",
          }}
        >
          {shortDescription}
        </p>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "24px",
            position: "relative",
            flex: 1,
          }}
        >
          <Box label="What it often means" body={emotionalMeaning} />
          <Box label="With the other person" body={otherPersonTip} />
        </div>

        {statLine && (
          <div
            style={{
              marginTop: "32px",
              padding: "20px 24px",
              borderRadius: "16px",
              background: "hsla(28, 50%, 55%, 0.12)",
              border: "1px solid hsla(28, 50%, 55%, 0.25)",
              fontSize: "22px",
              color: "hsl(25, 30%, 25%)",
              position: "relative",
            }}
          >
            {statLine}
          </div>
        )}

        <div
          style={{
            marginTop: "32px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            position: "relative",
            paddingTop: "24px",
            borderTop: "1px solid hsla(25, 20%, 50%, 0.15)",
          }}
        >
          <span style={{ fontSize: "20px", fontWeight: 500, color: "hsl(25, 25%, 30%)" }}>
            clarity.app
          </span>
          <span style={{ fontSize: "16px", color: "hsl(25, 15%, 50%)", fontStyle: "italic" }}>
            Not advice — just perspective.
          </span>
        </div>
      </div>
    );
  },
);
SharePatternCard.displayName = "SharePatternCard";

function Box({ label, body }: { label: string; body: string }) {
  return (
    <div
      style={{
        background: "hsla(0, 0%, 100%, 0.5)",
        border: "1px solid hsla(25, 20%, 50%, 0.12)",
        borderRadius: "20px",
        padding: "28px",
        display: "flex",
        flexDirection: "column",
        gap: "14px",
      }}
    >
      <div
        style={{
          fontSize: "13px",
          fontWeight: 600,
          letterSpacing: "0.14em",
          textTransform: "uppercase",
          color: "hsl(28, 50%, 40%)",
        }}
      >
        {label}
      </div>
      <p
        style={{
          fontSize: "22px",
          lineHeight: 1.45,
          margin: 0,
          color: "hsl(25, 20%, 25%)",
        }}
      >
        {body}
      </p>
    </div>
  );
}
