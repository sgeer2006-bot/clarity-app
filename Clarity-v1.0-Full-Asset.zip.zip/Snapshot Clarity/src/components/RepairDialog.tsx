import { useEffect, useState } from "react";
import { HelpCircle, Loader2, Sparkles } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import {
  explainQuestion,
  submitClarification,
  trackEvent,
  type ClarifyExplanation,
} from "@/lib/engineV2";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sessionId: string;
  questionIndex: number;
  questionText: string;
  /** Called after a successful clarification so the parent can refetch the next question. */
  onResolved: () => void;
}

export const RepairDialog = ({
  open,
  onOpenChange,
  sessionId,
  questionIndex,
  questionText,
  onResolved,
}: Props) => {
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [explanation, setExplanation] = useState<ClarifyExplanation | null>(null);
  const [clarification, setClarification] = useState("");

  useEffect(() => {
    if (!open) {
      setExplanation(null);
      setClarification("");
      return;
    }
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        trackEvent("misunderstanding_repair_triggered", { sessionId, questionIndex });
        const ex = await explainQuestion(sessionId, questionIndex, questionText);
        if (!cancelled) setExplanation(ex);
      } catch (e: any) {
        if (!cancelled) {
          toast({
            title: "Couldn't open the repair flow",
            description: e?.message ?? "Please try again.",
            variant: "destructive",
          });
          onOpenChange(false);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [open, sessionId, questionIndex, questionText, onOpenChange]);

  const pickInterpretation = (text: string) => {
    setClarification((prev) => (prev.trim() ? prev : text));
  };

  const submit = async () => {
    if (!clarification.trim()) {
      toast({ title: "Add a sentence to clarify", description: "Even a few words help." });
      return;
    }
    setSubmitting(true);
    try {
      const res = await submitClarification(
        sessionId,
        questionIndex,
        questionText,
        clarification.trim(),
        explanation?.repair_id ?? null,
      );
      trackEvent("misunderstanding_repair_completed", {
        sessionId,
        questionIndex,
        saturation: res.saturation_score,
      });
      toast({ title: "Thanks — got it.", description: res.ack });
      onOpenChange(false);
      onResolved();
    } catch (e: any) {
      toast({
        title: "Couldn't save your clarification",
        description: e?.message ?? "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-primary" aria-hidden />
            I need your help understanding something…
          </DialogTitle>
          <DialogDescription>
            Walk me through what you actually meant. I'll update what I think and ask a better question.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
            Reading what I asked…
          </div>
        ) : explanation ? (
          <div className="space-y-4">
            <section className="rounded-lg border border-border bg-muted/40 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                What I'm confused about
              </p>
              <p className="mt-1 text-sm">{explanation.confused_about}</p>
            </section>

            <section className="rounded-lg border border-accent/40 bg-accent/10 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                What I think you meant
              </p>
              <p className="mt-1 text-sm italic">{explanation.hypothesis}</p>
            </section>

            {explanation.interpretations.length > 0 && (
              <section>
                <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Quick replies
                </p>
                <div className="flex flex-wrap gap-2">
                  {explanation.interpretations.map((t, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => pickInterpretation(t)}
                      className="rounded-full border border-border bg-background px-3 py-1.5 text-xs transition-colors hover:border-primary/40 hover:bg-primary/5"
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </section>
            )}

            <section>
              <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Here's what I actually meant
              </label>
              <Textarea
                value={clarification}
                onChange={(e) => setClarification(e.target.value)}
                placeholder="In your own words…"
                rows={4}
                className="mt-2 resize-none rounded-lg"
              />
            </section>
          </div>
        ) : null}

        <DialogFooter className="gap-2 sm:gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={submitting}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={loading || submitting || !clarification.trim()}>
            {submitting ? (
              <><Loader2 className="mr-1 h-4 w-4 animate-spin" /> Updating…</>
            ) : (
              <><Sparkles className="mr-1 h-4 w-4" /> That's closer</>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
