import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sparkles, Crown, Compass, Heart } from "lucide-react";
import { canUse } from "@/lib/featureGate";

/**
 * Phase 2 — Premium onboarding demo (multi-step, observational copy only).
 * Uses static demo data. Gated via canUse('premium_onboarding'); when not
 * available, a soft preview is shown instead.
 */

const ADVICE_RE = /\b(should|must|need to|have to|ought to|don't|please)\b/i;
const obs = (s: string) => (ADVICE_RE.test(s) ? s.replace(ADVICE_RE, "").replace(/\s+/g, " ").trim() : s);

interface Step {
  icon: typeof Heart;
  eyebrow: string;
  title: string;
  body: string;
}

const STEPS: Step[] = [
  {
    icon: Sparkles,
    eyebrow: "What you'll see",
    title: "A calm space for noticing",
    body: obs("Clarity gathers small observations across conversations. Nothing is prescribed — patterns simply surface."),
  },
  {
    icon: Heart,
    eyebrow: "Identity",
    title: "Who you tend to be",
    body: obs("A living portrait forms from your reflections — strengths, recurring themes, and gentle blind spots."),
  },
  {
    icon: Compass,
    eyebrow: "Continuation",
    title: "A thread that returns",
    body: obs("When something feels unresolved, Clarity offers a quiet way back to it later — only when it might help."),
  },
  {
    icon: Crown,
    eyebrow: "Premium",
    title: "Deeper narrative",
    body: obs("Week-over-week trend shifts, cluster intelligence, and a longer narrative summary — opt in anytime."),
  },
];

export function PremiumOnboarding({ onDone }: { onDone?: () => void }) {
  const [i, setI] = useState(0);
  const allowed = canUse("premium_onboarding");
  const step = STEPS[i];
  const Icon = step.icon;
  const last = i === STEPS.length - 1;

  if (!allowed) {
    return (
      <div className="card-soft p-6 text-sm text-muted-foreground">
        <div className="mb-2 inline-flex items-center gap-2 text-foreground">
          <Crown className="h-4 w-4 text-primary" aria-hidden /> Premium preview
        </div>
        <p>{obs("A guided walkthrough opens once Premium is active — a quiet tour of identity, continuation, and the deeper narrative layer.")}</p>
      </div>
    );
  }

  return (
    <div className="card-soft space-y-6 p-6 sm:p-8">
      <div className="flex items-center gap-2 text-xs uppercase tracking-wide text-muted-foreground">
        <Icon className="h-3.5 w-3.5 text-primary" aria-hidden />
        <span>{step.eyebrow}</span>
        <span className="ml-auto">{i + 1} / {STEPS.length}</span>
      </div>
      <div>
        <h2 className="font-display text-xl text-foreground">{step.title}</h2>
        <p className="mt-2 text-sm leading-relaxed text-foreground/80">{step.body}</p>
      </div>
      <div className="flex items-center justify-between gap-2">
        <Button variant="ghost" onClick={() => (onDone ? onDone() : null)}>
          Skip
        </Button>
        <div className="flex gap-2">
          {i > 0 && (
            <Button variant="outline" onClick={() => setI((n) => Math.max(0, n - 1))}>
              Back
            </Button>
          )}
          <Button onClick={() => (last ? onDone?.() : setI((n) => n + 1))}>
            {last ? "Begin" : "Continue"}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default PremiumOnboarding;
