import { useState } from "react";
import { ChevronDown, ChevronRight, Compass, MessageCircleQuestion, MessagesSquare } from "lucide-react";
import type { ReflectionSessionRow, ReflectionAnswerRow } from "@/lib/types";
import { SNAPSHOT_DISCLAIMER } from "@/lib/types";

interface Props {
  session: ReflectionSessionRow;
  answers?: ReflectionAnswerRow[];
  showResponsesCollapsible?: boolean;
}

function formatTs(iso: string) {
  const d = new Date(iso);
  return d
    .toLocaleString(undefined, {
      month: "long",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
    })
    .replace(",", " ·");
}

interface ExtendedSectionProps {
  icon: React.ReactNode;
  title: string;
  caption: string;
  items: string[];
  accent: "primary" | "accent" | "muted";
}

const accentStyles: Record<ExtendedSectionProps["accent"], string> = {
  primary: "border-primary/30 bg-primary/5",
  accent: "border-accent/40 bg-accent/10",
  muted: "border-border bg-muted/40",
};

const ExtendedSection = ({ icon, title, caption, items, accent }: ExtendedSectionProps) => {
  if (!items || items.length === 0) return null;
  return (
    <section className={`mt-6 rounded-lg border p-5 ${accentStyles[accent]}`}>
      <div className="flex items-start gap-3">
        <div className="mt-0.5 shrink-0 text-foreground/80" aria-hidden>
          {icon}
        </div>
        <div className="flex-1">
          <h2 className="text-base font-semibold leading-tight">{title}</h2>
          <p className="mt-1 text-xs text-muted-foreground">{caption}</p>
          <ul className="mt-3 list-disc space-y-2 pl-5 text-sm">
            {items.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
};

export const SnapshotView = ({
  session,
  answers,
  showResponsesCollapsible = true,
}: Props) => {
  const [open, setOpen] = useState(false);
  const snap = session.snapshot_json;

  return (
    <article className="card-elevated p-6 sm:p-8 p7-bloom">
      <h1 className="font-display text-3xl font-semibold leading-tight tracking-tight sm:text-4xl">
        {session.title}
      </h1>
      <p className="mt-2 text-sm text-muted-foreground">
        {formatTs(session.completed_at ?? session.created_at)}
      </p>
      <hr className="my-6 border-border" />

      {snap ? (
        <>
          <div className="rounded-lg border border-accent/40 bg-accent/10 p-4">
            <p className="text-sm">
              {snap.disclaimer || SNAPSHOT_DISCLAIMER}
            </p>
          </div>

          <h2 className="label-eyebrow mt-8">Situation Summary</h2>
          <p className="mt-2 text-base">{snap.summary}</p>

          <h2 className="label-eyebrow mt-8">Things to consider</h2>
          <ul className="mt-2 list-disc space-y-2 pl-5">
            {snap.observations.map((s, i) => (
              <li key={i} className="text-base">
                {s}
              </li>
            ))}
          </ul>

          <h2 className="label-eyebrow mt-8">Possible Paths</h2>
          <ul className="mt-2 list-disc space-y-2 pl-5">
            {snap.possible_paths.map((s, i) => (
              <li key={i} className="text-base">
                {s}
              </li>
            ))}
          </ul>

          <ExtendedSection
            icon={<Compass className="h-5 w-5" />}
            title="Recommended next steps"
            caption="Gentle ideas to consider — not advice. You decide what fits."
            items={snap.recommended_next_steps ?? []}
            accent="primary"
          />

          <ExtendedSection
            icon={<MessageCircleQuestion className="h-5 w-5" />}
            title="Common misunderstandings"
            caption="Where wires often get crossed in situations like this."
            items={snap.common_misunderstandings ?? []}
            accent="accent"
          />

          <ExtendedSection
            icon={<MessagesSquare className="h-5 w-5" />}
            title="How to communicate"
            caption="Phrasing ideas you can adapt — use your own words."
            items={snap.how_to_communicate ?? []}
            accent="muted"
          />

          <div className="mt-8 rounded-lg border border-border bg-muted/40 p-4">
            <p className="text-sm text-muted-foreground">
              {snap.disclaimer || SNAPSHOT_DISCLAIMER}
            </p>
          </div>
        </>
      ) : (
        <p className="text-sm text-muted-foreground">Snapshot is not available.</p>
      )}

      {showResponsesCollapsible && answers && answers.length > 0 && (
        <div className="mt-8 border-t border-border pt-4">
          <button
            onClick={() => setOpen((o) => !o)}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
          >
            {open ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
            Your answers
          </button>
          {open && (
            <div className="mt-4 space-y-4">
              {answers.map((r) => (
                <div key={r.id}>
                  <p className="text-sm text-muted-foreground">{r.question_text}</p>
                  <p className="mt-1 border-l-2 border-accent pl-3 text-base">
                    {r.answer_text}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </article>
  );
};
