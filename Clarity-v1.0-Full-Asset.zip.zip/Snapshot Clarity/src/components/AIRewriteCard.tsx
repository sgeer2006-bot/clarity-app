import { useState } from "react";
import { Copy, Loader2, Sparkles, RefreshCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Props {
  sessionId: string;
}

type Tone = "warm" | "direct" | "soft";

export const AIRewriteCard = ({ sessionId }: Props) => {
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [tone, setTone] = useState<Tone>("warm");

  const generate = async (selectedTone: Tone = tone) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("rewrite-message", {
        body: { sessionId, tone: selectedTone },
      });
      if (error) throw error;
      const msg = (data as { message?: string })?.message;
      if (!msg) throw new Error("Empty result");
      setMessage(msg);
    } catch (e) {
      console.error(e);
      toast({
        title: "Couldn't write a message",
        description: "Please try again in a moment.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const copy = async () => {
    if (!message) return;
    try {
      await navigator.clipboard.writeText(message);
      toast({ title: "Copied to clipboard" });
    } catch {
      toast({ title: "Couldn't copy", description: "Select the text and copy manually." });
    }
  };

  return (
    <section className="rounded-xl border border-accent/30 bg-gradient-to-br from-accent/5 via-card to-card p-5">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-accent/15 p-2 text-accent">
          <Sparkles className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="text-base font-semibold leading-tight">Write this for me</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            One short message you could adapt and send. Always your words to keep or change.
          </p>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            {(["warm", "direct", "soft"] as Tone[]).map((t) => (
              <button
                key={t}
                onClick={() => {
                  setTone(t);
                  generate(t);
                }}
                disabled={loading}
                className={`rounded-full border px-3 py-1 text-xs capitalize transition-colors ${
                  tone === t
                    ? "border-accent bg-accent/20 text-foreground"
                    : "border-border bg-background hover:bg-muted"
                }`}
              >
                {t}
              </button>
            ))}
            {!message && (
              <Button size="sm" onClick={() => generate()} disabled={loading} className="ml-auto">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Writing…
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Generate
                  </>
                )}
              </Button>
            )}
          </div>

          {message && (
            <div className="mt-4 rounded-lg border border-border bg-background/70 p-4">
              <p className="whitespace-pre-wrap text-sm leading-relaxed">{message}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={copy}>
                  <Copy className="mr-2 h-3.5 w-3.5" /> Copy
                </Button>
                <Button size="sm" variant="ghost" onClick={() => generate()} disabled={loading}>
                  {loading ? (
                    <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <RefreshCcw className="mr-2 h-3.5 w-3.5" />
                  )}
                  Try another
                </Button>
              </div>
              <p className="mt-3 text-[10px] text-muted-foreground">
                A starting point — edit freely before sending.
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
