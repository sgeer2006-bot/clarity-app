import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface PageHeaderProps {
  eyebrow?: ReactNode;
  title: ReactNode;
  lead?: ReactNode;
  align?: "left" | "center";
  className?: string;
  children?: ReactNode;
}

/**
 * Phase 7 — universal page header.
 * eyebrow → Fraunces display title → lead paragraph.
 * Use everywhere headers appear for a single visual rhythm.
 */
export function PageHeader({
  eyebrow,
  title,
  lead,
  align = "left",
  className,
  children,
}: PageHeaderProps) {
  return (
    <header
      className={cn(
        "mb-10 space-y-3 animate-fade-in-up",
        align === "center" && "text-center",
        className
      )}
    >
      {eyebrow ? (
        <span className="label-eyebrow inline-flex items-center gap-1.5">
          {eyebrow}
        </span>
      ) : null}
      <h1 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
        {title}
      </h1>
      {lead ? (
        <p
          className={cn(
            "max-w-prose text-sm leading-relaxed text-muted-foreground sm:text-base",
            align === "center" && "mx-auto"
          )}
        >
          {lead}
        </p>
      ) : null}
      {children}
    </header>
  );
}

interface SectionBlockProps {
  title?: ReactNode;
  description?: ReactNode;
  action?: ReactNode;
  className?: string;
  children: ReactNode;
}

/** Phase 7 — grouped section with calm spacing rhythm. */
export function SectionBlock({
  title,
  description,
  action,
  className,
  children,
}: SectionBlockProps) {
  return (
    <section className={cn("space-y-4", className)}>
      {(title || action) && (
        <div className="flex items-baseline justify-between gap-3">
          <div>
            {title ? (
              <h2 className="font-display text-lg font-semibold tracking-tight sm:text-xl">
                {title}
              </h2>
            ) : null}
            {description ? (
              <p className="mt-1 text-sm text-muted-foreground">{description}</p>
            ) : null}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}
