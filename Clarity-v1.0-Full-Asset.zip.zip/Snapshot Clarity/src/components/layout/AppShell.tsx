import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { TopBar } from "@/components/TopBar";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { PremiumCalmLayer } from "@/components/calm/PremiumCalmLayer";
import { canUse } from "@/lib/featureGate";
import { useBottomNavVisible } from "@/components/nav/BottomNav";

interface AppShellProps {
  children: ReactNode;
  /** wide = 1100px (dashboards, two-col); content = 680px (single-column reading) */
  width?: "content" | "wide";
  /** Hide the TopBar (e.g. for auth/onboarding) */
  bare?: boolean;
  className?: string;
}

/**
 * Phase 7.5 — universal app shell.
 *
 * Provides:
 *  - TopBar (unless bare)
 *  - MicroCalm route fade
 *  - Reserved calm background lane (does not clip CalmCanvas)
 *  - Consistent container width, padding, vertical rhythm
 *  - Subtle premium gradient backdrop behind content
 */
export function AppShell({ children, width = "wide", bare = false, className }: AppShellProps) {
  const navVisible = useBottomNavVisible();
  return (
    <div className="relative min-h-screen bg-background">
      {/* Reserved calm lane: does not interfere with CalmCanvas (which is fixed at -z-10) */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 -z-[5] h-[420px] bg-gradient-to-b from-primary/[0.04] via-transparent to-transparent p7-breath"
      />
      {!bare && <TopBar />}
      <MicroCalm>
        <main
          className={cn(
            "mx-auto px-page-x py-page-y sm:px-6",
            width === "wide" ? "max-w-content-wide" : "max-w-content",
            navVisible && "pb-[calc(env(safe-area-inset-bottom)+5rem)]",
            className
          )}
        >
          {canUse("premium_calm_layer") ? (
            <PremiumCalmLayer>{children}</PremiumCalmLayer>
          ) : (
            children
          )}
        </main>
      </MicroCalm>
    </div>
  );
}

