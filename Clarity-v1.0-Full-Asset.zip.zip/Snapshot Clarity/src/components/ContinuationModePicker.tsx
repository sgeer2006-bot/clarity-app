import { Telescope, Eye, Plus } from "lucide-react";
import type { ContinuationMode } from "@/lib/continuation";
import { MODE_LABELS, MODE_DESCRIPTIONS } from "@/lib/continuation";

interface Props {
  onSelect: (mode: ContinuationMode) => void;
}

const MODES: { key: ContinuationMode; icon: typeof Telescope }[] = [
  { key: "explore", icon: Telescope },
  { key: "angle", icon: Eye },
  { key: "context", icon: Plus },
];

export const ContinuationModePicker = ({ onSelect }: Props) => (
  <div className="space-y-4">
    <div>
      <h2 className="text-lg font-medium">Continue this conversation</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Pick one. We'll ask up to 5 focused questions, then build a small follow-up snapshot.
      </p>
    </div>
    <div className="grid gap-3">
      {MODES.map(({ key, icon: Icon }) => (
        <button
          key={key}
          onClick={() => onSelect(key)}
          className="flex items-start gap-4 rounded-xl border border-border bg-card p-5 text-left transition-colors hover:border-accent hover:bg-accent/5"
        >
          <Icon className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
          <div>
            <p className="font-medium">{MODE_LABELS[key]}</p>
            <p className="mt-1 text-sm text-muted-foreground">{MODE_DESCRIPTIONS[key]}</p>
          </div>
        </button>
      ))}
    </div>
  </div>
);
