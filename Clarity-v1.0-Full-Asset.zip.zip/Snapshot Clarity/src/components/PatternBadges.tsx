import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export interface SessionPatternMatch {
  pattern_id: string;
  confidence: number;
  reason: string | null;
  pattern: {
    id: string;
    slug: string;
    name: string;
    short_description: string;
  };
}

interface Props {
  sessionId: string;
}

/**
 * Renders the patterns matched for a session as clickable chips.
 * Silently renders nothing if no matches exist or detection hasn't run.
 */
export const PatternBadges = ({ sessionId }: Props) => {
  const [matches, setMatches] = useState<SessionPatternMatch[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from("session_patterns")
        .select(
          "pattern_id, confidence, reason, pattern:patterns(id, slug, name, short_description)",
        )
        .eq("session_id", sessionId)
        .order("confidence", { ascending: false });
      if (cancelled) return;
      if (!error && data) {
        setMatches(
          (data as any[]).filter((d) => d.pattern) as SessionPatternMatch[],
        );
      }
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [sessionId]);

  if (loading || matches.length === 0) return null;

  return (
    <section className="card-soft p-5 sm:p-6 animate-fade-in-up">
      <h2 className="label-eyebrow flex items-center gap-2">
        <Sparkles className="h-3.5 w-3.5" />
        Patterns we noticed
      </h2>
      <ul className="mt-3 flex flex-wrap gap-2">
        {matches.map((m) => (
          <li key={m.pattern_id}>
            <Link
              to={`/p/${m.pattern.slug}?session=${sessionId}`}
              className="group inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-3 py-1.5 text-sm transition-colors hover:bg-accent/20"
              title={m.reason ?? undefined}
            >
              <span className="font-medium">{m.pattern.name}</span>
              <span className="text-xs text-muted-foreground group-hover:text-foreground">
                · {m.confidence}%
              </span>
            </Link>
          </li>
        ))}
      </ul>
      {matches[0]?.reason && (
        <p className="mt-3 text-sm text-muted-foreground">
          <span className="font-medium text-foreground">Why:</span>{" "}
          {matches[0].reason}
        </p>
      )}
    </section>
  );
};
