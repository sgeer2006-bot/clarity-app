import { useState, type ReactNode } from "react";
import { ChevronDown, ChevronRight, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import type { QuestionType } from "@/lib/types";

export interface EditableAnswer {
  id: string;
  question_index: number;
  question_text: string;
  answer_text: string;
  question_type: QuestionType;
  min_chars: number;
}

interface Props {
  answers: EditableAnswer[];
  /**
   * Called when user saves an edit. Implementer is responsible for
   * persisting and (optionally) marking downstream answers as stale.
   */
  onSaveEdit: (
    answer: EditableAnswer,
    newValue: string,
  ) => Promise<void> | void;
  /** Title shown above the list. */
  title?: string;
  /** Whether to start expanded. */
  defaultOpen?: boolean;
  /** Show a small "may invalidate later questions" hint. */
  warnDownstream?: boolean;
  /** Optional render slot for extra actions per answer (e.g. Analyze pattern). */
  renderAnswerActions?: (answer: EditableAnswer) => ReactNode;
}

export const PriorAnswersPanel = ({
  answers,
  onSaveEdit,
  title = "Your previous answers",
  defaultOpen = false,
  warnDownstream = true,
  renderAnswerActions,
}: Props) => {
  const [open, setOpen] = useState(defaultOpen);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [saving, setSaving] = useState(false);

  if (answers.length === 0) return null;

  const startEdit = (a: EditableAnswer) => {
    setEditingId(a.id);
    setDraft(a.answer_text);
  };

  const cancel = () => {
    setEditingId(null);
    setDraft("");
  };

  const save = async (a: EditableAnswer, value: string) => {
    if (saving) return;
    if (a.question_type === "open") {
      const trimmed = value.trim();
      if (trimmed.length < Math.max(1, a.min_chars)) return;
    }
    setSaving(true);
    try {
      await onSaveEdit(a, value);
      setEditingId(null);
      setDraft("");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="rounded-xl border border-border bg-card/60 p-4">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
      >
        {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        {title} ({answers.length})
      </button>

      {open && (
        <div className="mt-4 space-y-4">
          {answers.map((a) => {
            const isEditing = editingId === a.id;
            return (
              <div
                key={a.id}
                className="rounded-lg border border-border bg-background p-4"
              >
                <p className="text-sm text-muted-foreground">{a.question_text}</p>

                {!isEditing ? (
                  <>
                    <div className="mt-2 flex items-start justify-between gap-3">
                      <p className="border-l-2 border-accent pl-3 text-base">
                        {a.answer_text}
                      </p>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="shrink-0"
                        onClick={() => startEdit(a)}
                      >
                        <Pencil className="mr-1 h-3.5 w-3.5" />
                        Edit
                      </Button>
                    </div>
                    {renderAnswerActions && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {renderAnswerActions(a)}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="mt-3 space-y-3">
                    {a.question_type === "yesno" ? (
                      <div className="grid grid-cols-2 gap-2">
                        <Button
                          variant={draft === "Yes" ? "default" : "outline"}
                          onClick={() => save(a, "Yes")}
                          disabled={saving}
                        >
                          Yes
                        </Button>
                        <Button
                          variant={draft === "No" ? "default" : "outline"}
                          onClick={() => save(a, "No")}
                          disabled={saving}
                        >
                          No
                        </Button>
                      </div>
                    ) : (
                      <>
                        <Textarea
                          rows={4}
                          value={draft}
                          onChange={(e) => setDraft(e.target.value)}
                          className="resize-none"
                        />
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={cancel}
                            disabled={saving}
                          >
                            Cancel
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => save(a, draft)}
                            disabled={saving}
                          >
                            {saving ? "Saving…" : "Save change"}
                          </Button>
                        </div>
                      </>
                    )}
                    {warnDownstream && (
                      <p className="text-xs text-muted-foreground">
                        Editing this may change what comes after it.
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
