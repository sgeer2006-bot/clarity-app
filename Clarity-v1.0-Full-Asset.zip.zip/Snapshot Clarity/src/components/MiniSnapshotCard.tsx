import { Sparkles, ArrowRight, BadgeCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { MiniSnapshot, ContinuationMode } from "@/lib/continuation";
import { MODE_LABELS } from "@/lib/continuation";

interface Props {
  mode: ContinuationMode;
  miniSnapshot: MiniSnapshot;
  snapshotPatched: boolean;
  exitReason?: "max_questions_reached" | "no_new_ground" | "fields_saturated";
  onBackToSnapshot: () => void;
  onStartAnother: () => void;
}

const EXIT_LABEL: Record<string, string> = {
  no_new_ground: "We were starting to circle the same ground, so we wrapped up here.",
  fields_saturated: "We had covered the relevant areas, so we wrapped up here.",
  max_questions_reached: "We reached the 5-question limit for this continuation.",
};

export const MiniSnapshotCard = ({
  mode,
  miniSnapshot,
  snapshotPatched,
  exitReason,
  onBackToSnapshot,
  onStartAnother,
}: Props) => {
  const changedKeys = Object.keys(miniSnapshot.changed_sections || {});
  return (
    <div className="space-y-5 rounded-xl border border-border bg-card p-6">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-accent/10 p-2 text-accent">
          <Sparkles className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-lg font-medium">{miniSnapshot.title}</h3>
            <Badge variant="secondary" className="text-xs">{MODE_LABELS[mode]}</Badge>
            {snapshotPatched && (
              <Badge className="bg-accent/15 text-accent hover:bg-accent/15 text-xs">
                <BadgeCheck className="mr-1 h-3 w-3" /> Snapshot updated
              </Badge>
            )}
          </div>
          {miniSnapshot.summary && (
            <p className="mt-2 text-sm text-muted-foreground">{miniSnapshot.summary}</p>
          )}
        </div>
      </div>

      {miniSnapshot.insights.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            What surfaced
          </p>
          <ul className="space-y-2">
            {miniSnapshot.insights.map((ins, i) => (
              <li key={i} className="flex gap-3 text-sm">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                <span>{ins}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {snapshotPatched && changedKeys.length > 0 && (
        <div className="rounded-lg border border-accent/30 bg-accent/5 p-3 text-xs text-muted-foreground">
          Updated snapshot sections: {changedKeys.map((k) => k.replace(/_/g, " ")).join(", ")}.
        </div>
      )}

      {exitReason && (
        <p className="rounded-lg bg-muted/40 p-3 text-xs text-muted-foreground">
          {EXIT_LABEL[exitReason]}
        </p>
      )}

      <div className="flex flex-col gap-2 sm:flex-row">
        <Button onClick={onBackToSnapshot} className="flex-1">
          Back to snapshot <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
        <Button variant="outline" onClick={onStartAnother} className="flex-1">
          Try another mode
        </Button>
      </div>
    </div>
  );
};
