import type { ReactNode } from "react";

interface Props {
  children: ReactNode;
}

/**
 * Soft warm wash transition between heavy screens. Respects reduced-motion.
 * Phase 7: layered with route-fade for a calmer arrival on every page.
 */
export function MicroCalm({ children }: Props) {
  return <div className="micro-calm-fade p7-route-fade">{children}</div>;
}

