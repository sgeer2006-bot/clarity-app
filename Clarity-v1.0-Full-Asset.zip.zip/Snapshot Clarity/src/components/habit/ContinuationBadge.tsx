import { Compass } from "lucide-react";
import { getFlag } from "@/lib/flags";

interface Props {
  /** When the continuation engine signals a return to this item. */
  active?: boolean;
  label?: string;
}

/**
 * Phase 2 — Small badge displayed on timeline items when the continuation
 * engine flags a likely return. Observational language only.
 */
export function ContinuationBadge({ active = false, label = "thread continues" }: Props) {
  if (!active) return null;
  if (!getFlag("continuationBadge")) return null;
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-border/60 bg-background/60 px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted-foreground">
      <Compass className="h-3 w-3 text-primary" aria-hidden />
      {label}
    </span>
  );
}

export default ContinuationBadge;
