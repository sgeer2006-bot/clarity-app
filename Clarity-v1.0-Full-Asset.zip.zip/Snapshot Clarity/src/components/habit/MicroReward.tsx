import { Sparkles } from "lucide-react";

interface Props {
  message?: string;
}

/** Small calm chip shown after a save/complete. ≤ 1 line. */
export function MicroReward({ message = "Saved. One small step taken." }: Props) {
  return (
    <div
      role="status"
      className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary-soft px-3 py-1.5 text-xs text-foreground"
    >
      <Sparkles className="h-3.5 w-3.5 text-primary" aria-hidden />
      <span>{message}</span>
    </div>
  );
}
