import { useEffect } from "react";

const KEY = "clarity.habit.lastSeen";

/**
 * Schedules a subtle in-app return cue. Local only — no push, no email.
 * Records lastSeen on mount; consumers can read it to render WelcomeBack.
 */
export function MicroReturnTrigger() {
  useEffect(() => {
    try {
      localStorage.setItem(KEY, new Date().toISOString());
    } catch {
      /* noop */
    }
  }, []);
  return null;
}

export function readLastSeen(): Date | null {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;
  const d = new Date(raw);
  return isNaN(d.getTime()) ? null : d;
}
