import { useEffect, useState } from "react";
import { getInsights } from "@/lib/identity";

/** "What this means" — pulls a single deterministic insight from the Identity Model. */
export function MicroMeaning() {
  const [text, setText] = useState<string>("");

  useEffect(() => {
    const refresh = () => {
      const insights = getInsights("all");
      setText(insights[0]?.text ?? "");
    };
    refresh();
    window.addEventListener("clarity:identity-updated", refresh);
    return () => window.removeEventListener("clarity:identity-updated", refresh);
  }, []);

  if (!text) return null;
  return (
    <div className="rounded-2xl border border-border bg-card p-4 text-sm text-foreground">
      <div className="label-eyebrow mb-1">What this means</div>
      <p className="text-foreground/90">{text}</p>
    </div>
  );
}
