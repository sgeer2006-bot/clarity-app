import { Sparkles } from "lucide-react";
import { getFlag } from "@/lib/flags";

const ADVICE_RE = /\b(should|must|need to|have to|ought to|don't|please)\b/i;
const obs = (s: string) => (ADVICE_RE.test(s) ? s.replace(ADVICE_RE, "").replace(/\s+/g, " ").trim() : s);

interface Props {
  message?: string;
  /** When false, nothing renders. */
  visible?: boolean;
}

/** Phase 2 — Tiny chip shown after a save/entry. Observational copy only. */
export function SuccessChip({ message = "Noted. A small piece of clarity gathered.", visible = true }: Props) {
  if (!visible) return null;
  if (!getFlag("successChip")) return null;
  return (
    <div
      role="status"
      className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary-soft px-3 py-1.5 text-xs text-foreground animate-fade-in"
    >
      <Sparkles className="h-3.5 w-3.5 text-primary" aria-hidden />
      <span>{obs(message)}</span>
    </div>
  );
}

export default SuccessChip;
