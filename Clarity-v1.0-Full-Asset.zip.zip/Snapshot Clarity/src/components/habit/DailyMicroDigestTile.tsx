import { Sparkles } from "lucide-react";
import { getFlag } from "@/lib/flags";

const ADVICE_RE = /\b(should|must|need to|have to|ought to|don't|please)\b/i;
const obs = (s: string) => (ADVICE_RE.test(s) ? s.replace(ADVICE_RE, "").replace(/\s+/g, " ").trim() : s);

interface Props {
  body?: string;
}

/**
 * Phase 2 — A small daily tile that surfaces one observation. Hidden by
 * default; opt-in via the `dailyMicroDigest` flag.
 */
export function DailyMicroDigestTile({
  body = "One small thing surfaced today — a quieter return to a familiar feeling.",
}: Props) {
  if (!getFlag("dailyMicroDigest")) return null;
  return (
    <aside className="card-soft flex items-start gap-3 p-4 text-sm">
      <span className="mt-0.5 inline-flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-primary">
        <Sparkles className="h-3.5 w-3.5" aria-hidden />
      </span>
      <div>
        <div className="text-xs uppercase tracking-wide text-muted-foreground">Today</div>
        <p className="mt-0.5 text-foreground/85">{obs(body)}</p>
      </div>
    </aside>
  );
}

export default DailyMicroDigestTile;
