import { useMemo } from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { getNextStep } from "@/lib/continuation/engine";
import type { ContinuationContext } from "@/lib/continuation/types";

interface Props {
  ctx: ContinuationContext;
}

export function MicroContinuation({ ctx }: Props) {
  const step = useMemo(() => getNextStep(ctx), [ctx]);
  return (
    <article className="card-soft p-5">
      <div className="label-eyebrow mb-1">
        {step.kind === "upsell" ? "Go deeper with Clarity+" : "A small next step"}
      </div>
      <h3 className="font-display text-lg text-foreground">{step.title}</h3>
      <p className="mt-1.5 text-sm text-muted-foreground">{step.body}</p>
      {step.kind === "next_step" && step.curiosity && (
        <p className="mt-2 text-xs italic text-foreground/70">{step.curiosity}</p>
      )}
      <Link
        to={step.cta.href}
        className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-primary"
      >
        {step.cta.label}
        <ArrowRight className="h-3.5 w-3.5" aria-hidden />
      </Link>
    </article>
  );
}
