import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { SuccessChip } from "@/components/habit/SuccessChip";
import { Crown, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { getFlag } from "@/lib/flags";

/**
 * Phase 2 — Expanded FTUE.
 *
 * Multi-step, dismissible at every step, non-blocking. Demonstrates a
 * micro-reward, surfaces a subtle premium tease, and collects ONE optional
 * preference (cadence). All copy filtered through ADVICE_RE.
 *
 * Shown once per browser. Storage key changed from minimal.v1 → expanded.v1
 * so users who saw the older minimal flow are not re-prompted (we set both
 * keys on completion to prevent any double-show).
 */

const STORAGE_KEY = "clarity.ftue.expanded.v1";
const LEGACY_KEY = "clarity.ftue.minimal.v1";
const ADVICE_RE = /\b(should|must|need to|have to|ought to|don't|please)\b/i;
const obs = (s: string) => (ADVICE_RE.test(s) ? s.replace(ADVICE_RE, "").replace(/\s+/g, " ").trim() : s);

type Step = "ask" | "reflect" | "preference" | "tease";

export function MinimalFTUE() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<Step>("ask");
  const [answer, setAnswer] = useState("");
  const [cadence, setCadence] = useState<"daily" | "weekly" | "no-preference" | null>(null);

  useEffect(() => {
    try {
      const seen = localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_KEY);
      if (!seen) {
        const t = setTimeout(() => setOpen(true), 600);
        return () => clearTimeout(t);
      }
    } catch {
      /* ignore */
    }
  }, []);

  const dismiss = () => {
    try {
      const payload = JSON.stringify({ at: Date.now(), step, cadence });
      localStorage.setItem(STORAGE_KEY, payload);
      localStorage.setItem(LEGACY_KEY, payload);
      if (cadence) localStorage.setItem("clarity.pref.cadence", cadence);
    } catch {
      /* ignore */
    }
    setOpen(false);
  };

  const reflection = (() => {
    const t = obs(answer.trim());
    if (!t) return obs("A quiet starting point is enough — observations gather as you write more.");
    return obs(`One thing surfaced: you put words to “${t.slice(0, 80)}”. That's a small piece of clarity.`);
  })();

  return (
    <Dialog open={open} onOpenChange={(v) => (v ? setOpen(true) : dismiss())}>
      <DialogContent className="sm:max-w-md">
        {step === "ask" && (
          <>
            <DialogHeader>
              <DialogTitle className="font-display">Welcome to Clarity</DialogTitle>
              <DialogDescription>
                {obs("One short question — answer in a few words, or skip.")}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <p className="text-sm text-foreground/85">{obs("What's one thing on your mind right now?")}</p>
              <Textarea
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="A few words is enough…"
                rows={3}
              />
            </div>
            <DialogFooter className="gap-2 sm:gap-2">
              <Button variant="ghost" onClick={dismiss}>Skip</Button>
              <Button onClick={() => setStep("reflect")}>Continue</Button>
            </DialogFooter>
          </>
        )}
        {step === "reflect" && (
          <>
            <DialogHeader>
              <DialogTitle className="font-display">A small reflection</DialogTitle>
              <DialogDescription>{obs("Take what feels useful and leave the rest.")}</DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <p className="rounded-xl border border-border/50 bg-muted/30 p-4 text-sm leading-relaxed text-foreground/85">
                {reflection}
              </p>
              <SuccessChip message="Noted. A small piece of clarity gathered." />
            </div>
            <DialogFooter className="gap-2 sm:gap-2">
              <Button variant="ghost" onClick={dismiss}>Skip</Button>
              <Button onClick={() => setStep("preference")}>Continue</Button>
            </DialogFooter>
          </>
        )}
        {step === "preference" && (
          <>
            <DialogHeader>
              <DialogTitle className="font-display">A gentle rhythm (optional)</DialogTitle>
              <DialogDescription>{obs("How often a quiet check-in feels right — change anytime.")}</DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-3 gap-2">
              {(["daily", "weekly", "no-preference"] as const).map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCadence(c)}
                  className={[
                    "rounded-xl border px-3 py-3 text-xs capitalize transition-colors",
                    cadence === c
                      ? "border-primary bg-primary/10 text-foreground"
                      : "border-border/60 bg-background/60 text-muted-foreground hover:text-foreground",
                  ].join(" ")}
                >
                  {c.replace("-", " ")}
                </button>
              ))}
            </div>
            <DialogFooter className="gap-2 sm:gap-2">
              <Button variant="ghost" onClick={dismiss}>Skip</Button>
              <Button onClick={() => setStep("tease")}>Continue</Button>
            </DialogFooter>
          </>
        )}
        {step === "tease" && (
          <>
            <DialogHeader>
              <DialogTitle className="font-display flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" aria-hidden /> You're set
              </DialogTitle>
              <DialogDescription>{obs("Free forever for daily reflections. A deeper layer is available when it feels right.")}</DialogDescription>
            </DialogHeader>
            {getFlag("premiumOnboardingTease") && (
              <div className="rounded-xl border border-primary/20 bg-primary-soft/40 p-4 text-sm">
                <div className="mb-1 inline-flex items-center gap-1.5 text-foreground">
                  <Crown className="h-3.5 w-3.5 text-primary" aria-hidden /> Premium adds
                </div>
                <p className="text-foreground/80">
                  {obs("A longer narrative summary, week-over-week trend shifts, and clusters of related observations.")}
                </p>
                <Link
                  to="/clarity-plus"
                  onClick={dismiss}
                  className="mt-2 inline-block text-xs text-primary underline-offset-2 hover:underline"
                >
                  See what's inside Clarity+
                </Link>
              </div>
            )}
            <DialogFooter>
              <Button onClick={dismiss}>Begin</Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default MinimalFTUE;
