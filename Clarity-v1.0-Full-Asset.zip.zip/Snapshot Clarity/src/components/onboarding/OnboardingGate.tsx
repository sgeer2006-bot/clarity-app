import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { getUserProfile } from "@/lib/profile/userProfile";
import { useAuthSession } from "@/hooks/useAuthSession";

/**
 * Light onboarding entry gate.
 *
 * On any client navigation, if light onboarding is not yet complete and the
 * user is not already inside an exempt route (auth, the onboarding flow
 * itself, the legacy onboarding page, or shared/public surfaces), redirect
 * to /onboarding/light.
 *
 * Deep onboarding is never enforced here — it is opt-in.
 */

const EXEMPT_PREFIXES = [
  "/onboarding", // covers /onboarding, /onboarding/light, /onboarding/deep, /onboarding/deep/intro
  "/auth",
  "/share/",
  "/s/",
  "/two-person/invite/",
  "/safety/resources",
];

function isExempt(path: string): boolean {
  return EXEMPT_PREFIXES.some((p) => path === p || path.startsWith(p + "/") || path.startsWith(p));
}

export function OnboardingGate() {
  const location = useLocation();
  const navigate = useNavigate();
  const { isAuthed, loading } = useAuthSession();

  useEffect(() => {
    if (loading) return;
    // Signed-out users see the app's signed-out shell (Home with Log in /
    // Create account in the header). Onboarding is only enforced for
    // authenticated users so returning is effortless.
    if (!isAuthed) return;
    const { onboardingStatus } = getUserProfile();
    if (onboardingStatus.lightCompleted) return;
    if (isExempt(location.pathname)) return;
    navigate("/onboarding/light", { replace: true });
  }, [location.pathname, navigate, isAuthed, loading]);

  return null;
}
