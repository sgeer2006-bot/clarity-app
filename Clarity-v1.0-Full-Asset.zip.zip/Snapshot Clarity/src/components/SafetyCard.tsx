import { useState } from "react";
import { LifeBuoy, X, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  categoryLabel,
  hotlinesFor,
  type SafetyCategory,
} from "@/lib/safety";

interface Props {
  category: SafetyCategory;
  onDismiss?: () => void;
  /** Compact = collapsed by default, expandable. Full = expanded. */
  variant?: "compact" | "full";
}

/**
 * SafetyCard: a calm, non-blocking module that surfaces relevant hotlines.
 * It never replaces the flow — it simply offers help alongside it.
 */
export function SafetyCard({ category, onDismiss, variant = "compact" }: Props) {
  const [open, setOpen] = useState(variant === "full");
  const hotlines = hotlinesFor(category);

  return (
    <section
      role="complementary"
      aria-label="Support resources"
      className="rounded-lg border border-accent/40 bg-accent/10 p-4"
    >
      <div className="flex items-start gap-3">
        <LifeBuoy className="mt-0.5 h-5 w-5 shrink-0 text-accent-foreground" aria-hidden />
        <div className="flex-1 space-y-1">
          <h3 className="text-sm font-semibold">{categoryLabel(category)}</h3>
          <p className="text-sm text-muted-foreground">
            You don't have to figure this out alone. These free, confidential lines
            are available any time — they won't judge you, and you can hang up whenever you want.
          </p>
        </div>
        {onDismiss && (
          <button
            type="button"
            onClick={onDismiss}
            aria-label="Dismiss support resources"
            className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {open ? (
        <ul className="mt-3 space-y-2">
          {hotlines.map((h) => (
            <li key={h.name} className="rounded-md border border-border bg-background/60 p-3">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="text-sm font-medium">{h.name}</p>
                {h.href ? (
                  <a
                    href={h.href}
                    className="text-sm font-medium text-primary underline-offset-4 hover:underline"
                  >
                    {h.contact}
                  </a>
                ) : (
                  <span className="text-sm font-medium">{h.contact}</span>
                )}
              </div>
              {h.detail && (
                <p className="mt-1 text-xs text-muted-foreground">{h.detail}</p>
              )}
            </li>
          ))}
        </ul>
      ) : null}

      {variant === "compact" && (
        <div className="mt-3">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setOpen((v) => !v)}
            className="h-8 px-2 text-xs"
          >
            {open ? (
              <>
                <ChevronUp className="mr-1 h-3.5 w-3.5" /> Hide resources
              </>
            ) : (
              <>
                <ChevronDown className="mr-1 h-3.5 w-3.5" /> Show resources
              </>
            )}
          </Button>
        </div>
      )}

      <p className="mt-3 text-[11px] text-muted-foreground">
        You can keep using this tool — this is just here in case it helps.
      </p>
    </section>
  );
}
