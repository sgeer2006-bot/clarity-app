import { useEffect, useState } from "react";
import { Sparkles, Users } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";

export interface PatternIdentity {
  id: string;
  slug: string;
  name: string;
  short_description: string;
  long_description?: string;
  emotional_signature?: string;
  communication_tendency?: string;
  growth_edge?: string;
}

interface Props {
  identity: PatternIdentity;
  showCount?: boolean;
}

export const PatternIdentityCard = ({ identity, showCount = true }: Props) => {
  const [count, setCount] = useState<number | null>(null);

  useEffect(() => {
    if (!showCount) return;
    let cancelled = false;
    (async () => {
      const { data } = await supabase.rpc("get_pattern_identity_stats", {
        _identity_id: identity.id,
      });
      const row = (data as { identity_count: number; total_count: number }[] | null)?.[0];
      if (!cancelled && row) setCount(row.identity_count);
    })();
    return () => { cancelled = true; };
  }, [identity.id, showCount]);

  return (
    <div className="rounded-xl border border-accent/30 bg-gradient-to-br from-accent/5 via-card to-card p-5">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-accent/15 p-2 text-accent">
          <Sparkles className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Your pattern in this moment
            </p>
            {showCount && count !== null && count > 0 && (
              <Badge variant="secondary" className="gap-1 text-xs">
                <Users className="h-3 w-3" />
                {count.toLocaleString()} {count === 1 ? "person shares this" : "people share this"}
              </Badge>
            )}
          </div>
          <h3 className="mt-1 text-lg font-medium">{identity.name}</h3>
          <p className="mt-2 text-sm text-foreground/80">{identity.short_description}</p>

          {(identity.emotional_signature || identity.communication_tendency || identity.growth_edge) && (
            <dl className="mt-4 grid gap-3 sm:grid-cols-3">
              {identity.emotional_signature && (
                <div>
                  <dt className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                    Emotional signature
                  </dt>
                  <dd className="mt-0.5 text-xs text-foreground/80">{identity.emotional_signature}</dd>
                </div>
              )}
              {identity.communication_tendency && (
                <div>
                  <dt className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                    How it sounds
                  </dt>
                  <dd className="mt-0.5 text-xs text-foreground/80">{identity.communication_tendency}</dd>
                </div>
              )}
              {identity.growth_edge && (
                <div>
                  <dt className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                    Growth edge
                  </dt>
                  <dd className="mt-0.5 text-xs text-foreground/80">{identity.growth_edge}</dd>
                </div>
              )}
            </dl>
          )}
        </div>
      </div>
    </div>
  );
};
