import { useEffect, useRef, useState } from "react";
import { getState } from "@/lib/identity";
import { DIMENSIONS, DIMENSION_LABEL } from "@/lib/identity/dimensions";
import type { Dimension } from "@/lib/identity/types";

interface Row {
  dim: Dimension;
  total: number;
}

/**
 * Compact, read-only summary of the user's top identity dimensions.
 * Pure client-side; reads from the local Identity Model.
 * Phase 7: chip micro-pulse on identity event arrival.
 */
export function IdentityChips({ limit = 3, title = "Your evolving identity" }: { limit?: number; title?: string }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [pulseKey, setPulseKey] = useState(0);
  const firstRender = useRef(true);

  useEffect(() => {
    const compute = () => {
      const s = getState();
      const all: Row[] = DIMENSIONS.map((dim) => {
        let total = 0;
        for (const v of Object.values(s.dimensions[dim].counts)) total += v;
        return { dim, total };
      })
        .filter((r) => r.total > 0)
        .sort((a, b) => b.total - a.total)
        .slice(0, limit);
      setRows(all);
      if (!firstRender.current) setPulseKey((k) => k + 1);
      firstRender.current = false;
    };
    compute();
    const handler = () => compute();
    window.addEventListener("storage", handler);
    window.addEventListener("clarity:identity", handler);
    return () => {
      window.removeEventListener("storage", handler);
      window.removeEventListener("clarity:identity", handler);
    };
  }, [limit]);

  if (rows.length === 0) return null;

  return (
    <article className="card-soft p-5 p7-breath">
      <div className="label-eyebrow mb-2">{title}</div>
      <ul className="flex flex-wrap gap-2">
        {rows.map((r) => (
          <li
            key={`${r.dim}-${pulseKey}`}
            className="p7-chip-pulse rounded-full border border-border bg-muted/40 px-3 py-1 text-xs text-foreground"
          >
            {DIMENSION_LABEL[r.dim]}
            <span className="ml-1.5 text-muted-foreground">· {r.total}</span>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs text-muted-foreground">
        A gentle reflection of where your patterns have shown up most.
      </p>
    </article>
  );
}

