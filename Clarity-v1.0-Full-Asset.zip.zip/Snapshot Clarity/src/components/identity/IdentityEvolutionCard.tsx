import { useEffect, useState } from "react";
import { getState, getTimeline } from "@/lib/identity";
import { DIMENSION_LABEL } from "@/lib/identity/dimensions";
import type { Dimension } from "@/lib/identity/types";

interface Trend {
  dim: Dimension;
  recent: number;
  prior: number;
}

/**
 * Phase 7 — Identity Evolution narrative card.
 * Reflective, non-clinical. Surfaces 7d vs prior-7d trends per dimension.
 * Pure client-side; reads only from the local identity store.
 */
export function IdentityEvolutionCard() {
  const [trends, setTrends] = useState<Trend[]>([]);
  const [headline, setHeadline] = useState<string>("");

  useEffect(() => {
    const compute = () => {
      const tl = getTimeline("30d");
      const now = Date.now();
      const SEVEN = 7 * 24 * 60 * 60 * 1000;
      const recentMap = new Map<Dimension, number>();
      const priorMap = new Map<Dimension, number>();
      for (const e of tl) {
        const t = new Date(e.ts).getTime();
        const map = now - t <= SEVEN ? recentMap : priorMap;
        map.set(e.dimension, (map.get(e.dimension) ?? 0) + Math.abs(e.delta));
      }
      const dims = new Set<Dimension>([...recentMap.keys(), ...priorMap.keys()]);
      const ts: Trend[] = [];
      for (const d of dims) {
        const recent = recentMap.get(d) ?? 0;
        const prior = priorMap.get(d) ?? 0;
        if (recent + prior === 0) continue;
        ts.push({ dim: d, recent, prior });
      }
      ts.sort((a, b) => Math.abs(b.recent - b.prior) - Math.abs(a.recent - a.prior));
      setTrends(ts.slice(0, 4));

      // Headline from totals
      const s = getState();
      let topDim: Dimension | null = null;
      let topTotal = 0;
      for (const d of Object.keys(s.dimensions) as Dimension[]) {
        const total = Object.values(s.dimensions[d].counts).reduce((a, b) => a + b, 0);
        if (total > topTotal) {
          topTotal = total;
          topDim = d;
        }
      }
      if (topDim) {
        setHeadline(`Your ${DIMENSION_LABEL[topDim].toLowerCase()} have shown up most lately.`);
      } else {
        setHeadline("Your identity story is just beginning to take shape.");
      }
    };
    compute();
    const h = () => compute();
    window.addEventListener("clarity:identity", h);
    window.addEventListener("storage", h);
    return () => {
      window.removeEventListener("clarity:identity", h);
      window.removeEventListener("storage", h);
    };
  }, []);

  return (
    <article className="card-soft p-6 p7-route-fade">
      <div className="label-eyebrow mb-2">Identity evolution</div>
      <h3 className="font-display text-xl font-semibold tracking-tight text-foreground">
        {headline}
      </h3>
      {trends.length === 0 ? (
        <p className="mt-2 text-sm text-muted-foreground">
          As more reflections gather, shifts in what you notice will appear here.
        </p>
      ) : (
        <ul className="mt-4 space-y-2.5">
          {trends.map((t) => {
            const delta = t.recent - t.prior;
            const direction =
              delta > 0
                ? "more present this week"
                : delta < 0
                ? "quieter this week"
                : "steady this week";
            return (
              <li
                key={t.dim}
                className="flex items-center justify-between gap-3 rounded-xl border border-border/60 bg-background/40 px-3.5 py-2.5"
              >
                <span className="text-sm text-foreground">{DIMENSION_LABEL[t.dim]}</span>
                <span className="text-xs text-muted-foreground">{direction}</span>
              </li>
            );
          })}
        </ul>
      )}
      <p className="mt-4 text-xs leading-relaxed text-muted-foreground/90">
        A reflective view — not a verdict. Identity moves in seasons.
      </p>
    </article>
  );
}
