import { Progress } from "@/components/ui/progress";
import type { CoverageMap, CoverageState } from "@/lib/engineV2";

interface Props {
  slot: number;
  hardCap: number;
  saturation?: number;
  coverage?: CoverageMap;
}

const STATE_DOT: Record<CoverageState, string> = {
  empty: "bg-muted",
  partial: "bg-accent",
  filled: "bg-primary",
};

const FIELD_LABEL: Record<string, string> = {
  situation: "Situation",
  emotions: "Emotions",
  intentions: "Intent",
  triggers: "Triggers",
  expectations: "Expectations",
  fears: "Fears",
  desired_outcome: "Outcome",
  relationships: "Relationships",
  history: "History",
  unspoken_needs: "Unspoken",
};

export const CoverageProgress = ({ slot, hardCap, saturation = 0, coverage }: Props) => {
  return (
    <div className="space-y-2">
      <div className="flex items-baseline justify-between gap-2">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Question {slot} of up to {hardCap} — building your clarity map
        </p>
        <span className="text-xs tabular-nums text-muted-foreground">{Math.round(saturation)}%</span>
      </div>
      <Progress value={Math.max(8, saturation)} className="h-2" />
      {coverage && (
        <ul className="flex flex-wrap gap-x-3 gap-y-1.5 pt-1" aria-label="Context coverage">
          {Object.entries(coverage).map(([field, state]) => (
            <li key={field} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <span
                className={`inline-block h-1.5 w-1.5 rounded-full ${STATE_DOT[state as CoverageState]}`}
                aria-hidden
              />
              {FIELD_LABEL[field] ?? field}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
