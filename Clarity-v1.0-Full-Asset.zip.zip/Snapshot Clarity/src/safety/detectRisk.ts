import type { RiskCategory } from "./riskCategories";

export const RISK_KEYWORDS: Record<RiskCategory, string[]> = {
  self_harm: [
    "self harm", "self-harm", "hurt myself", "harming myself", "cut myself",
    "cutting myself", "burn myself", "burning myself",
  ],
  suicidal_ideation: [
    "suicide", "suicidal", "kill myself", "end my life", "want to die",
    "don't want to live", "do not want to live", "take my own life",
    "better off dead", "no reason to live",
  ],
  harm_to_others: [
    "kill him", "kill her", "kill them", "hurt him", "hurt her", "hurt them",
    "want to hurt someone", "want to kill someone",
  ],
  domestic_violence: [
    "he hits me", "she hits me", "they hit me", "hits me", "beats me",
    "abuses me", "abusing me", "afraid of my partner", "threatens me",
    "chokes me", "strangles me", "domestic violence", "abusive relationship",
    "controlling partner",
  ],
  child_abuse: [
    "child abuse", "abused as a child", "hits my child", "hurts my child",
    "abuses my child",
  ],
  gambling_addiction: [
    "gambling problem", "can't stop gambling", "cannot stop gambling",
    "lost everything gambling",
  ],
  substance_abuse: [
    "drinking too much", "can't stop drinking", "cannot stop drinking",
    "addicted to", "using again", "relapsed", "overdose", "withdrawal",
  ],
  medical_emergency: [
    "chest pain", "can't breathe", "cannot breathe", "passing out",
    "bleeding heavily", "stroke symptoms",
  ],
};

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function detectRisk(text: string): RiskCategory[] {
  if (!text) return [];
  const lower = text.toLowerCase();
  const found = new Set<RiskCategory>();
  for (const [cat, terms] of Object.entries(RISK_KEYWORDS) as [RiskCategory, string[]][]) {
    for (const term of terms) {
      const re = new RegExp(`(^|[^a-z])${escapeRegex(term)}([^a-z]|$)`, "i");
      if (re.test(lower)) {
        found.add(cat);
        break;
      }
    }
  }
  return Array.from(found);
}
