export const RISK_CATEGORIES = {
  self_harm:          { label: "Self-Harm",         resourceCategory: "Suicide & Crisis Support", slug: "suicide-crisis-support" },
  suicidal_ideation:  { label: "Suicidal Ideation", resourceCategory: "Suicide & Crisis Support", slug: "suicide-crisis-support" },
  harm_to_others:     { label: "Harm to Others",    resourceCategory: "Emergency Medical Support", slug: "emergency-medical-support" },
  domestic_violence:  { label: "Domestic Violence", resourceCategory: "Domestic Violence Support", slug: "domestic-violence-support" },
  child_abuse:        { label: "Child Safety",      resourceCategory: "Emergency Medical Support", slug: "emergency-medical-support" },
  gambling_addiction: { label: "Gambling",          resourceCategory: "Gambling Addiction Support", slug: "gambling-addiction-support" },
  substance_abuse:    { label: "Substance Use",     resourceCategory: "Substance Abuse Support",   slug: "substance-abuse-support" },
  medical_emergency:  { label: "Medical Emergency", resourceCategory: "Emergency Medical Support", slug: "emergency-medical-support" },
} as const;

export type RiskCategory = keyof typeof RISK_CATEGORIES;
