import { useEffect, useState } from "react";
import { detectRisk } from "./detectRisk";
import type { RiskCategory } from "./riskCategories";

export function useSafetyScan(text: string, debounceMs = 300) {
  const [categories, setCategories] = useState<RiskCategory[]>([]);
  useEffect(() => {
    const t = setTimeout(() => setCategories(detectRisk(text)), debounceMs);
    return () => clearTimeout(t);
  }, [text, debounceMs]);
  return { categories, hasRisk: categories.length > 0 };
}
