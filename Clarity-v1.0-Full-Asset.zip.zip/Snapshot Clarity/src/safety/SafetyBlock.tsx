import { useState } from "react";
import { ChevronDown, Heart } from "lucide-react";
import { Link } from "react-router-dom";
import { RISK_CATEGORIES, type RiskCategory } from "./riskCategories";

interface Props {
  categories: RiskCategory[];
  defaultOpen?: boolean;
}

export function SafetyBlock({ categories, defaultOpen = false }: Props) {
  const [open, setOpen] = useState(defaultOpen);
  if (!categories || categories.length === 0) return null;

  // Unique resource categories
  const seen = new Set<string>();
  const chips = categories
    .map((c) => RISK_CATEGORIES[c])
    .filter((r) => {
      if (seen.has(r.slug)) return false;
      seen.add(r.slug);
      return true;
    });

  return (
    <aside
      className="my-3 rounded-[14px] border-l-4 p-4"
      style={{
        background: "#F4ECE0",
        borderLeftColor: "#8FA88F",
        boxShadow: "0 2px 8px rgba(60,50,40,0.06)",
        color: "#2A2520",
      }}
    >
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between gap-3 text-left"
        aria-expanded={open}
      >
        <span className="flex items-center gap-2 text-sm font-medium">
          <Heart className="h-4 w-4" style={{ color: "#5E7A60" }} aria-hidden />
          A note before continuing
        </span>
        <ChevronDown className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`} style={{ color: "#5A524A" }} />
      </button>
      {open ? (
        <div className="mt-3 space-y-3">
          <p className="text-sm leading-relaxed" style={{ color: "#5A524A" }}>
            If something you wrote sounds urgent or unsafe, please consider contacting local emergency services or a trusted person nearby. Clarity is a reflective journaling tool. It is not a crisis service, does not monitor messages, and does not replace professional support.
          </p>
          <div className="flex flex-wrap gap-1.5">
            {chips.map((c) => (
              <Link
                key={c.slug}
                to={`/safety/resources#${c.slug}`}
                className="rounded-full border px-2.5 py-0.5 text-xs"
                style={{ borderColor: "#A8BBA1", color: "#5E7A60" }}
              >
                {c.resourceCategory}
              </Link>
            ))}
          </div>
          <Link to="/safety/resources" className="inline-block text-xs underline" style={{ color: "#5E7A60" }}>
            Open the safety resources page →
          </Link>
        </div>
      ) : null}
    </aside>
  );
}
