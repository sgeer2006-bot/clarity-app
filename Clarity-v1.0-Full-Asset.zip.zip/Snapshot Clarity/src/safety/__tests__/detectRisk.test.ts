import { describe, it, expect } from "vitest";
import { detectRisk } from "../detectRisk";

describe("detectRisk", () => {
  it("returns [] for empty / benign text", () => {
    expect(detectRisk("")).toEqual([]);
    expect(detectRisk("Today was a calm day.")).toEqual([]);
  });

  it("detects suicidal ideation", () => {
    expect(detectRisk("sometimes I want to die")).toContain("suicidal_ideation");
  });

  it("detects domestic violence", () => {
    expect(detectRisk("he hits me when angry")).toContain("domestic_violence");
  });

  it("matches whole words only", () => {
    expect(detectRisk("supersuicidal")).toEqual([]);
  });

  it("returns unique categories", () => {
    const r = detectRisk("suicidal and want to die");
    expect(r.filter((x) => x === "suicidal_ideation").length).toBe(1);
  });
});
