// Client-side AES-GCM encryption derived from a shared perspective token.
// Server never sees plaintext.

const SALT = new TextEncoder().encode("clarity.two_person.v1");

async function deriveKey(token: string): Promise<CryptoKey> {
  const baseKey = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(token),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt: SALT, iterations: 100_000, hash: "SHA-256" },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

function toB64(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}

function fromB64(s: string): Uint8Array {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export interface Envelope {
  v: 1;
  mode: "two_person";
  iv: string;
  ct: string;
  perspective: "A" | "B";
}

export async function encryptEnvelope(
  text: string,
  token: string,
  perspective: "A" | "B"
): Promise<Envelope> {
  const key = await deriveKey(token);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv as BufferSource },
    key,
    new TextEncoder().encode(text) as BufferSource
  );
  return { v: 1, mode: "two_person", iv: toB64(iv), ct: toB64(ct), perspective };
}

export async function decryptEnvelope(env: Envelope, token: string): Promise<string> {
  const key = await deriveKey(token);
  const pt = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: fromB64(env.iv) as BufferSource },
    key,
    fromB64(env.ct) as BufferSource
  );
  return new TextDecoder().decode(pt);
}

const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

export function generatePerspectiveToken(length = 22): string {
  const bytes = crypto.getRandomValues(new Uint8Array(length));
  let s = "";
  for (let i = 0; i < length; i++) s += ALPHABET[bytes[i] % ALPHABET.length];
  return s;
}
