import { useEffect, useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useTwoPersonRoom, persistPerspective, readPerspective, type RoomMessage } from "./useTwoPersonRoom";
import { useSafetyScan } from "@/safety/useSafetyScan";
import { SafetyBlock } from "@/safety/SafetyBlock";
import { recordEvent } from "@/lib/identity";

interface Props {
  token: string;
  initialPerspective: "A" | "B";
  onLeave: () => void;
}

const A_COLOR = "#8FA88F";
const B_COLOR = "#C9A689";

function deriveSimpleInsights(messages: RoomMessage[]): string[] {
  if (!messages.length) return [];
  const out: string[] = [];
  const aCount = messages.filter((m) => m.perspective === "A").length;
  const bCount = messages.length - aCount;
  if (aCount && bCount) {
    const ratio = Math.max(aCount, bCount) / Math.min(aCount, bCount);
    if (ratio >= 1.6) {
      out.push(`One side has been speaking more so far (${aCount} vs ${bCount}).`);
    } else {
      out.push(`Both sides are contributing at a similar rate (${aCount} vs ${bCount}).`);
    }
  }
  const apologies = messages.filter((m) => /\b(sorry|my fault|i apolog)/i.test(m.text)).length;
  if (apologies >= 2) out.push(`Apology language has appeared ${apologies} times.`);
  const questions = messages.filter((m) => /\?/.test(m.text)).length;
  if (questions >= 2) out.push(`Questions are being used to keep things open (${questions} so far).`);
  return out;
}

export function TwoPersonRoom({ token, initialPerspective, onLeave }: Props) {
  const [perspective, setPerspective] = useState<"A" | "B">(
    () => readPerspective(token) ?? initialPerspective
  );
  const { messages, send } = useTwoPersonRoom(token);
  const [draft, setDraft] = useState("");
  const { categories } = useSafetyScan(draft);

  useEffect(() => { persistPerspective(token, perspective); }, [token, perspective]);

  const insights = useMemo(() => deriveSimpleInsights(messages), [messages]);

  const submit = async () => {
    if (!draft.trim()) return;
    await send(draft, perspective);
    try {
      recordEvent({
        source: "two_person",
        tags: { relational: ["two_person_message"], communication: [perspective === "A" ? "voice_a" : "voice_b"] },
        text: draft,
      });
    } catch {
      /* ignore */
    }
    setDraft("");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 text-sm">
        <div className="flex items-center gap-2">
          <span className="rounded-full px-2 py-0.5 text-xs" style={{ background: A_COLOR, color: "#FAF5EC" }}>Person A</span>
          <span className="rounded-full px-2 py-0.5 text-xs" style={{ background: B_COLOR, color: "#FAF5EC" }}>Person B</span>
          <span className="ml-2 text-xs text-muted-foreground">Room: {token.slice(0, 6)}…</span>
        </div>
        <Button variant="ghost" size="sm" onClick={onLeave}>Leave room</Button>
      </div>

      {/* Split panes */}
      <div className="grid min-h-[40dvh] gap-4 md:grid-cols-2">
        {(["A", "B"] as const).map((p) => (
          <div key={p}
            className="rounded-[14px] p-4"
            style={{
              background: "#FAF5EC",
              borderTop: `3px solid ${p === "A" ? A_COLOR : B_COLOR}`,
              boxShadow: "0 2px 8px rgba(60,50,40,0.06)",
            }}>
            <div className="mb-3 text-xs uppercase tracking-[0.18em]" style={{ color: p === "A" ? A_COLOR : B_COLOR }}>
              Person {p}
            </div>
            <div className="space-y-2">
              {messages.filter((m) => m.perspective === p).map((m) => (
                <div key={m.id} className="rounded-xl px-3 py-2 text-sm" style={{ background: "#F4ECE0", color: "#2A2520" }}>
                  {m.text}
                </div>
              ))}
              {messages.filter((m) => m.perspective === p).length === 0 ? (
                <p className="text-xs italic" style={{ color: "#5A524A" }}>Nothing here yet.</p>
              ) : null}
            </div>
          </div>
        ))}
      </div>

      {/* Shared timeline */}
      <section>
        <h3 className="mb-2 text-xs uppercase tracking-[0.18em]" style={{ color: "#5E7A60" }}>Shared timeline</h3>
        <div className="rounded-[14px] p-4" style={{ background: "#F4ECE0" }}>
          {messages.length === 0 ? (
            <p className="text-sm italic" style={{ color: "#5A524A" }}>No messages yet.</p>
          ) : (
            <ol className="space-y-2">
              {messages.map((m) => (
                <li key={m.id} className="flex items-start gap-2 text-sm">
                  <span
                    className="mt-1 inline-block h-2 w-2 shrink-0 rounded-full"
                    style={{ background: m.perspective === "A" ? A_COLOR : B_COLOR }}
                  />
                  <span style={{ color: "#2A2520" }}>{m.text}</span>
                </li>
              ))}
            </ol>
          )}
        </div>
      </section>

      {/* Shared insights */}
      <section>
        <h3 className="mb-2 text-xs uppercase tracking-[0.18em]" style={{ color: "#5E7A60" }}>Shared insights</h3>
        <div className="rounded-[14px] p-4" style={{ background: "#FAF5EC", border: "1px solid #EBDFCB" }}>
          {insights.length === 0 ? (
            <p className="text-sm italic" style={{ color: "#5A524A" }}>Insights will appear as the conversation grows.</p>
          ) : (
            <ul className="space-y-1 text-sm" style={{ color: "#2A2520" }}>
              {insights.map((i, idx) => <li key={idx}>• {i}</li>)}
            </ul>
          )}
        </div>
      </section>

      {/* Composer */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs">
          <span style={{ color: "#5A524A" }}>Sending as:</span>
          {(["A", "B"] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPerspective(p)}
              className="rounded-full px-3 py-1"
              style={{
                background: perspective === p ? (p === "A" ? A_COLOR : B_COLOR) : "transparent",
                color: perspective === p ? "#FAF5EC" : "#5A524A",
                border: "1px solid #A8BBA1",
              }}
            >
              Person {p}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <Input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); } }}
            placeholder="Write a message…"
          />
          <Button onClick={submit} style={{ background: "#8FA88F", color: "#FAF5EC" }}>Send</Button>
        </div>
        <SafetyBlock categories={categories} />
      </div>
    </div>
  );
}
