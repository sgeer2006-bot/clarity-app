import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { generatePerspectiveToken } from "./crypto";

interface Props {
  onEnter: (token: string, perspective: "A" | "B") => void;
}

export function JoinRoom({ onEnter }: Props) {
  const [token, setToken] = useState("");
  const [perspective, setPerspective] = useState<"A" | "B">("A");

  return (
    <div className="mx-auto max-w-md space-y-5 rounded-[14px] p-6"
      style={{ background: "#F4ECE0", boxShadow: "0 2px 8px rgba(60,50,40,0.06)", color: "#2A2520" }}>
      <h2 className="text-lg font-semibold">Two-Person Room</h2>
      <p className="text-sm" style={{ color: "#5A524A" }}>
        Paste a shared room token. Both people use the same one. The token never leaves your device unencrypted.
      </p>
      <Input
        placeholder="Room token"
        value={token}
        onChange={(e) => setToken(e.target.value.trim())}
      />
      <div className="flex items-center gap-2 text-sm">
        <span style={{ color: "#5A524A" }}>I am:</span>
        {(["A", "B"] as const).map((p) => (
          <button
            key={p}
            onClick={() => setPerspective(p)}
            className="rounded-full px-3 py-1 text-xs"
            style={{
              background: perspective === p ? (p === "A" ? "#8FA88F" : "#C9A689") : "transparent",
              color: perspective === p ? "#FAF5EC" : "#5A524A",
              border: "1px solid #A8BBA1",
            }}
          >
            Person {p}
          </button>
        ))}
      </div>
      <div className="flex gap-2">
        <Button
          onClick={() => token && onEnter(token, perspective)}
          disabled={!token}
          className="flex-1"
          style={{ background: "#8FA88F", color: "#FAF5EC" }}
        >
          Enter room
        </Button>
        <Button
          variant="outline"
          onClick={() => setToken(generatePerspectiveToken())}
        >
          Generate
        </Button>
      </div>
    </div>
  );
}
