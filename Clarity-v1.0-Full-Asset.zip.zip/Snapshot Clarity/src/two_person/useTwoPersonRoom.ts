import { useEffect, useMemo, useState } from "react";
import { decryptEnvelope, encryptEnvelope, type Envelope } from "./crypto";

export interface RoomMessage {
  id: string;
  perspective: "A" | "B";
  text: string;
  at: number;
}

const STORAGE_KEY = (token: string) => `clarity.tp.${token}.messages`;
const PERSPECTIVE_KEY = (token: string) => `clarity.tp.${token}.perspective`;

export function persistPerspective(token: string, perspective: "A" | "B") {
  localStorage.setItem(PERSPECTIVE_KEY(token), perspective);
}
export function readPerspective(token: string): "A" | "B" | null {
  const v = localStorage.getItem(PERSPECTIVE_KEY(token));
  return v === "A" || v === "B" ? v : null;
}

/**
 * Local-first room. Encrypts before any persistence; decrypts on read.
 * No backend changes — this stores encrypted envelopes in localStorage so
 * the same device can demonstrate decrypt-on-read. Future server sync would
 * write the same `Envelope` shape into existing conversation payloads.
 */
export function useTwoPersonRoom(token: string) {
  const [messages, setMessages] = useState<RoomMessage[]>([]);
  const storageKey = useMemo(() => STORAGE_KEY(token), [token]);

  // Load + decrypt
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const raw = localStorage.getItem(storageKey);
      if (!raw) {
        setMessages([]);
        return;
      }
      try {
        const envs: (Envelope & { id: string; at: number })[] = JSON.parse(raw);
        const out: RoomMessage[] = [];
        for (const env of envs) {
          try {
            const text = await decryptEnvelope(env, token);
            out.push({ id: env.id, perspective: env.perspective, text, at: env.at });
          } catch {
            /* skip undecryptable */
          }
        }
        if (!cancelled) setMessages(out.sort((a, b) => a.at - b.at));
      } catch {
        if (!cancelled) setMessages([]);
      }
    })();
    return () => { cancelled = true; };
  }, [storageKey, token]);

  const send = async (text: string, perspective: "A" | "B") => {
    if (!text.trim()) return;
    const env = await encryptEnvelope(text, token, perspective);
    const id = crypto.randomUUID();
    const at = Date.now();
    const raw = localStorage.getItem(storageKey);
    const list = raw ? JSON.parse(raw) : [];
    list.push({ ...env, id, at });
    localStorage.setItem(storageKey, JSON.stringify(list));
    setMessages((prev) => [...prev, { id, perspective, text, at }]);
  };

  return { messages, send };
}
