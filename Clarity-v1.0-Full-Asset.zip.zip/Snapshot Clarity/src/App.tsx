import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "./pages/NotFound.tsx";
import Auth from "./pages/Auth.tsx";
import NewSession from "./pages/NewSession.tsx";
import QuestionFlow from "./pages/QuestionFlow.tsx";
import Loading from "./pages/Loading.tsx";
import SnapshotPage from "./pages/SnapshotPage.tsx";

import TimelinePage from "./pages/TimelinePage.tsx";
import Analytics from "./pages/Analytics.tsx";
import SharePage from "./pages/SharePage.tsx";
import SharedSnapshotPage from "./pages/SharedSnapshotPage.tsx";
import PatternPage from "./pages/PatternPage.tsx";
import FollowUpFlow from "./pages/FollowUpFlow.tsx";
import CorrectionFlow from "./pages/CorrectionFlow.tsx";
import TwoPersonHub from "./pages/TwoPersonHub.tsx";
import TwoPersonSession from "./pages/TwoPersonSession.tsx";
import TwoPersonInvite from "./pages/TwoPersonInvite.tsx";
import PatternSnapshotPage from "./pages/PatternSnapshotPage.tsx";
import SafetyResourcesPage from "./pages/SafetyResourcesPage.tsx";
import SettingsVisualPage from "./pages/SettingsVisualPage.tsx";
// SettingsBillingPage removed from routes — /billing surfaces now redirect to /clarity-plus/pricing.
import TwoPersonRoomPage from "./pages/TwoPersonRoomPage.tsx";
import OnboardingPage from "./pages/OnboardingPage.tsx";
import ComposerPage from "./pages/ComposerPage.tsx";
import InsightsPage from "./pages/insights/PremiumInsightsPage.tsx";
import Home from "./pages/Home.tsx";
import FastClarity from "./pages/FastClarity.tsx";
import PatternsPage from "./pages/PatternsPage.tsx";
import StoryPage from "./pages/StoryPage.tsx";
import SettingsIndexPage from "./pages/SettingsIndexPage.tsx";
import { ClarityPlusPage, PricingPage as ClarityPlusPricingPage } from "./premium/clarityPlus";
import ClarityPlusSuccessPage from "./pages/clarityPlus/ClarityPlusSuccess.tsx";
import ClarityPlusCancelPage from "./pages/clarityPlus/ClarityPlusCancel.tsx";
import AboutPage from "./pages/AboutPage.tsx";
import HelpPage from "./pages/HelpPage.tsx";
import { AmbientBackground } from "./visual/AmbientBackground.tsx";
import { CalmCanvas } from "./components/calm/CalmCanvas.tsx";
import { PremiumCalmLayer } from "./components/ui/CalmLayer";
import { MinimalFTUE } from "./components/onboarding/MinimalFTUE.tsx";
import { OnboardingGate } from "./components/onboarding/OnboardingGate.tsx";
import { runPhase6ResetOnce } from "./lib/reset/runReset.ts";
import { FTUEHost } from "./ftue/FTUEHost";
import { BottomNav } from "./components/nav/BottomNav";

// One-time local data refresh (preserves subscription + onboarding).
runPhase6ResetOnce();

const queryClient = new QueryClient();

function App() {
  return (
  <HelmetProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <AmbientBackground />
        <CalmCanvas />
        <PremiumCalmLayer />
        <MinimalFTUE />
        <BrowserRouter>
          <OnboardingGate />
          <FTUEHost />
          <BottomNav />
          <Routes>
            {/* Phase 4 structural reset: 4-tab nav (Today, Questions, Insights, You).
                Tools tab removed. Onboarding consolidated to a single /onboarding route.
                Insights consolidated to /insights. Timeline replaces History+Folders under You. */}
            <Route path="/" element={<Navigate to="/home" replace />} />
            <Route path="/home" element={<Home />} />

            {/* Primary tab aliases */}
            <Route path="/insights" element={<InsightsPage />} />
            <Route path="/you" element={<SettingsIndexPage />} />

            {/* Questions section: entry points */}
            <Route path="/reflect" element={<NewSession />} />
            <Route path="/fast-clarity" element={<FastClarity />} />
            <Route path="/questions/fast" element={<FastClarity />} />
            <Route path="/compose" element={<ComposerPage />} />

            {/* Auth + flows */}
            <Route path="/auth" element={<Auth />} />
            <Route path="/new/:sessionId/:step" element={<QuestionFlow />} />
            <Route path="/loading/:sessionId" element={<Loading />} />
            <Route path="/snapshot/:snapshotId" element={<SnapshotPage mode="history" />} />
            <Route path="/follow-up/:sessionId" element={<FollowUpFlow />} />
            <Route path="/correct/:sessionId" element={<CorrectionFlow />} />

            {/* Insights / patterns */}
            <Route path="/dashboard" element={<Analytics />} />
            <Route path="/patterns" element={<PatternsPage />} />
            <Route path="/story" element={<StoryPage />} />
            <Route path="/p/:slug" element={<PatternPage />} />
            <Route path="/pattern/answer/:answerId" element={<PatternSnapshotPage />} />

            {/* Timeline (canonical) — merged History + Folders under You */}
            <Route path="/you/timeline" element={<TimelinePage />} />

            {/* Shared Clarity (canonical + functional sub-routes) */}
            <Route path="/shared" element={<TwoPersonHub />} />
            <Route path="/two-person/:sessionId" element={<TwoPersonSession />} />
            <Route path="/two-person/invite/:token" element={<TwoPersonInvite />} />
            <Route path="/two-person-room" element={<TwoPersonRoomPage />} />

            {/* Sharing */}
            <Route path="/share/:token" element={<SharePage />} />
            <Route path="/s/:token" element={<SharedSnapshotPage />} />

            {/* Calm — single entry from the menu, routes to SafetyResources */}
            <Route path="/safety/resources" element={<SafetyResourcesPage />} />

            {/* Settings + Appearance (canonical) — /settings redirects to /you */}
            <Route path="/settings" element={<Navigate to="/you" replace />} />
            <Route path="/settings/visual" element={<SettingsVisualPage />} />
            {/* Billing routes redirect to canonical Clarity+ pricing surface */}
            <Route path="/billing" element={<Navigate to="/clarity-plus/pricing" replace />} />
            <Route path="/settings/billing" element={<Navigate to="/clarity-plus/pricing" replace />} />

            {/* Onboarding — single canonical entry */}
            <Route path="/onboarding" element={<OnboardingPage />} />

            {/* Clarity+ (subscription) — page + pricing checkout flow */}
            <Route path="/clarity-plus" element={<ClarityPlusPage />} />
            <Route path="/clarity-plus/pricing" element={<ClarityPlusPricingPage />} />
            <Route path="/clarity-plus/success" element={<ClarityPlusSuccessPage />} />
            <Route path="/clarity-plus/cancel" element={<ClarityPlusCancelPage />} />

            {/* About / Help */}
            <Route path="/about" element={<AboutPage />} />
            <Route path="/help" element={<HelpPage />} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </HelmetProvider>
  );
}

export default App;
