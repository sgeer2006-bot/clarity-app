import { useEffect, useState } from "react";
import { useVisualFlags } from "./useVisualFlags";

const CLOUDS = [
  { d: "M40,40 Q20,10 60,18 Q90,5 110,28 Q150,20 140,55 Q130,80 90,72 Q50,80 40,55 Z", duration: 140, top: "8%",  left: "-20%", scale: 1.6, fill: "#F4ECE0" },
  { d: "M30,50 Q10,25 55,30 Q85,10 105,35 Q140,30 130,60 Q115,85 75,75 Q40,82 30,60 Z",  duration: 180, top: "30%", left: "-25%", scale: 2.0, fill: "#EBDFCB" },
  { d: "M50,45 Q30,20 70,22 Q100,5 120,30 Q160,25 145,60 Q135,85 95,77 Q55,82 50,60 Z", duration: 110, top: "55%", left: "-30%", scale: 1.4, fill: "#A8BBA1" },
  { d: "M35,40 Q15,15 55,20 Q85,5 110,28 Q145,22 135,55 Q125,80 85,72 Q45,78 35,55 Z",  duration: 160, top: "75%", left: "-20%", scale: 1.8, fill: "#8FA88F" },
  { d: "M40,45 Q25,20 65,25 Q95,8 115,32 Q150,27 140,58 Q128,82 90,75 Q50,80 40,58 Z",  duration: 90,  top: "18%", left: "-15%", scale: 1.2, fill: "#F4ECE0" },
];

export function AmbientBackground() {
  const { visualMotion, reducedMotion, themeIntensity } = useVisualFlags();
  const [prefersReduced, setPrefersReduced] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setPrefersReduced(mq.matches);
    update();
    mq.addEventListener?.("change", update);
    return () => mq.removeEventListener?.("change", update);
  }, []);

  if (!visualMotion) return null;

  const animate = !(reducedMotion || prefersReduced);
  const maxAlpha = 0.18;
  const alpha = Math.max(0, Math.min(100, themeIntensity)) / 100 * maxAlpha;

  return (
    <>
      <style>{`
        @keyframes clarity-cloud-drift {
          from { transform: translate3d(0,0,0); }
          to   { transform: translate3d(160vw,0,0); }
        }
      `}</style>
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 overflow-hidden"
        style={{ zIndex: -1 }}
      >
        {CLOUDS.map((c, i) => (
          <svg
            key={i}
            viewBox="0 0 180 100"
            width={220 * c.scale}
            height={120 * c.scale}
            style={{
              position: "absolute",
              top: c.top,
              left: c.left,
              opacity: alpha,
              animation: animate ? `clarity-cloud-drift ${c.duration}s linear infinite` : undefined,
              willChange: animate ? "transform" : undefined,
            }}
          >
            <path d={c.d} fill={c.fill} />
          </svg>
        ))}
      </div>
    </>
  );
}
