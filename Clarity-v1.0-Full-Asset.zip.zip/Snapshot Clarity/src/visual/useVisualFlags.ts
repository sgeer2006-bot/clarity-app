import { useEffect, useState } from "react";

const KEYS = {
  motion: "clarity.flags.visualMotion",
  reduced: "clarity.flags.reducedMotion",
  intensity: "clarity.flags.themeIntensity",
} as const;

export interface VisualFlags {
  visualMotion: boolean;
  reducedMotion: boolean;
  themeIntensity: number;
}

function read(): VisualFlags {
  if (typeof window === "undefined") {
    return { visualMotion: true, reducedMotion: false, themeIntensity: 60 };
  }
  return {
    visualMotion: localStorage.getItem(KEYS.motion) !== "false",
    reducedMotion: localStorage.getItem(KEYS.reduced) === "true",
    themeIntensity: Number(localStorage.getItem(KEYS.intensity) ?? 60),
  };
}

export function useVisualFlags(): VisualFlags & {
  set: (patch: Partial<VisualFlags>) => void;
} {
  const [flags, setFlags] = useState<VisualFlags>(read);

  useEffect(() => {
    const onStorage = () => setFlags(read());
    window.addEventListener("storage", onStorage);
    window.addEventListener("clarity:visual-flags", onStorage as EventListener);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("clarity:visual-flags", onStorage as EventListener);
    };
  }, []);

  const set = (patch: Partial<VisualFlags>) => {
    if (patch.visualMotion !== undefined) localStorage.setItem(KEYS.motion, String(patch.visualMotion));
    if (patch.reducedMotion !== undefined) localStorage.setItem(KEYS.reduced, String(patch.reducedMotion));
    if (patch.themeIntensity !== undefined) localStorage.setItem(KEYS.intensity, String(patch.themeIntensity));
    setFlags(read());
    window.dispatchEvent(new Event("clarity:visual-flags"));
  };

  return { ...flags, set };
}
