import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>About Clarity — Your deeper clarity starts here</title>
        <meta
          name="description"
          content="Clarity is a calm, private space for reflection. Clarity+ goes deeper. Your reflections stay yours."
        />
        <link rel="canonical" href="/about" />
      </Helmet>
      <TopBar />
      <main className="mx-auto w-full max-w-2xl px-5 py-12 sm:py-16">
        <p className="text-sm text-primary">Clarity+</p>
        <h1 className="mt-1 font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
          Your deeper clarity starts here.
        </h1>
        <p className="mt-3 text-base text-muted-foreground">
          A short, honest read on what Clarity is, how it works, and how we look after your reflections.
        </p>

        <section className="mt-10">
          <h2 className="font-display text-xl font-semibold">What Clarity is</h2>
          <p className="mt-3 text-base leading-relaxed text-foreground/85">
            Clarity is a quiet space to reflect. You write what&apos;s on your mind. We listen back, gently — naming the patterns and feelings that keep showing up, in plain words. No advice, no judgment, no noise.
          </p>
        </section>

        <section className="mt-10">
          <h2 className="font-display text-xl font-semibold">What Clarity+ is</h2>
          <p className="mt-3 text-base leading-relaxed text-foreground/85">
            Clarity+ is the deeper layer. The same calm reflections, read more closely, with the through-lines you might miss alone. It&apos;s not "more features." It&apos;s a longer, gentler look at the person you&apos;re quietly becoming.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <Button asChild className="h-11 rounded-full px-5">
              <Link to="/clarity-plus">Unlock Clarity+</Link>
            </Button>
            <Button asChild variant="outline" className="h-11 rounded-full px-5">
              <Link to="/clarity-plus/pricing">See what&apos;s inside</Link>
            </Button>
          </div>
        </section>

        <section id="how" className="mt-10">
          <h2 className="font-display text-xl font-semibold">How it works</h2>
          <p className="mt-3 text-base leading-relaxed text-foreground/85">
            Every time you reflect, Clarity reads what you wrote and looks for shapes — feelings that come back, situations that repeat, words you reach for again and again. It pieces those shapes together into small, plain-language insights, so that what was foggy becomes a little clearer. It&apos;s not magic, and it&apos;s not a therapist. Think of it as a calm, attentive friend who notices the threads you&apos;re too close to see.
          </p>
        </section>

        <section id="privacy" className="mt-10">
          <h2 className="font-display text-xl font-semibold">Your privacy</h2>
          <p className="mt-3 text-base leading-relaxed text-foreground/85">
            Your reflections are yours. We treat them with the same care you do — kept private, never sold, never shared for advertising. You can delete your data any time from Settings. Nothing about Clarity works without your trust, and we don&apos;t take it lightly.
          </p>
        </section>

        <p className="mt-12 text-center text-sm text-muted-foreground">
          Whenever you&apos;re ready, we&apos;re here. <Link to="/home" className="underline-offset-4 hover:underline">Back home →</Link>
        </p>
        <p className="mt-3 text-center text-xs text-primary/80">Clarity+ — Your deeper clarity starts here.</p>
      </main>
    </div>
  );
}
