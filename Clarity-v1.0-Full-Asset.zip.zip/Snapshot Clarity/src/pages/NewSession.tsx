import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TopBar } from "@/components/TopBar";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { CreditMeterBanner, TierGate } from "@/premium/TierGate";
import { canPerform, recordAction } from "@/premium/limits";
import { currentTier } from "@/premium/tier";

const NewSession = () => {
  const navigate = useNavigate();
  const [resumeId, setResumeId] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    document.title = "Reflect — Clarity";
    (async () => {
      const { data: sess } = await supabase.auth.getSession();
      if (!sess.session) {
        navigate("/auth", { replace: true });
        return;
      }
      const { data } = await supabase
        .from("reflection_sessions")
        .select("id")
        .eq("user_id", sess.session.user.id)
        .eq("status", "in_progress")
        .is("deleted_at", null)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (data?.id) {
        setResumeId(data.id);
        setChecking(false);
      } else {
        // No in-progress session — go straight to question 1
        await createAndGo();
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const createAndGo = async () => {
    const tier = currentTier();
    if (!canPerform("reflection", tier)) {
      setChecking(false);
      setCreating(false);
      return;
    }
    setCreating(true);
    const { data: userRes } = await supabase.auth.getUser();
    const uid = userRes.user?.id;
    if (!uid) {
      navigate("/auth");
      return;
    }
    const { data, error } = await supabase
      .from("reflection_sessions")
      .insert({ user_id: uid, status: "in_progress" })
      .select("id")
      .single();
    if (error || !data) {
      setCreating(false);
      toast({
        title: "Couldn't start your reflection",
        description: error?.message ?? "Give it another try in a moment.",
        variant: "destructive",
      });
      return;
    }
    recordAction("reflection");
    navigate(`/new/${data.id}/1`, { replace: true });
  };

  const startOver = async () => {
    if (!resumeId) return;
    await supabase
      .from("reflection_sessions")
      .update({ status: "abandoned" })
      .eq("id", resumeId);
    setResumeId(null);
    await createAndGo();
  };

  return (
    <>
      <TopBar />
      <MicroCalm>
      <main className="mx-auto max-w-content px-4 py-12">
        <header className="mb-8">
          <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
            Questions
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            A guided conversation to understand what's happening inside.
          </p>
        </header>
        <div className="mb-6"><CreditMeterBanner /></div>
        <TierGate action="reflection" requires="free"><div /></TierGate>
        {checking || creating ? (
          <div className="flex flex-col items-center gap-4 py-16">
            <Loader2 className="h-6 w-6 animate-spin text-accent" />
            <p className="text-base text-muted-foreground">
              {creating ? "Setting your space up…" : "Just a moment…"}
            </p>
          </div>
        ) : resumeId ? (
          <div className="rounded-xl border border-border bg-card p-6">
            <h1 className="text-xl font-semibold">Pick up where you left off?</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              You have a reflection in progress. We saved your place.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button onClick={() => navigate(`/new/${resumeId}/1`)}>
                Continue where I was
              </Button>
              <Button variant="outline" onClick={startOver}>
                Start fresh
              </Button>
              <Button variant="outline" onClick={() => navigate("/fast-clarity")}>
                Get grounded fast
              </Button>
            </div>
          </div>
        ) : null}

        <div className="mt-10">
        </div>
      </main>
      </MicroCalm>
    </>
  );
};

export default NewSession;
