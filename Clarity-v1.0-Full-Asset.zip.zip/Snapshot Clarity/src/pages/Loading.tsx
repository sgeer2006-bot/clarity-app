import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { detectPatterns, FriendlyError, generateSnapshot } from "@/lib/api";
import { supabase } from "@/integrations/supabase/client";

const PHRASES = [
  "Reading what you wrote…",
  "Putting the pieces together…",
  "Looking at this carefully…",
  "Considering what's missing…",
  "Almost ready…",
];

const Loading = () => {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [running, setRunning] = useState(true);
  const [phraseIdx, setPhraseIdx] = useState(0);

  const run = async () => {
    if (!sessionId) return;
    setRunning(true);
    setError(null);
    try {
      await generateSnapshot(sessionId);
      // Fire-and-forget pattern detection — never blocks navigation.
      detectPatterns(sessionId);
      navigate(`/snapshot/${sessionId}`, { replace: true });
    } catch (e) {
      const fe = e instanceof FriendlyError ? e : null;
      if (fe?.kind === "auth") { navigate("/auth", { replace: true }); return; }
      setError(fe?.message || "Something went wrong. Please try again.");
      setRunning(false);
    }
  };

  useEffect(() => {
    document.title = "Putting it together — Clarity";
    run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId]);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setPhraseIdx((i) => (i + 1) % PHRASES.length), 2500);
    return () => clearInterval(id);
  }, [running]);

  const goBack = async () => {
    if (!sessionId) { navigate("/new"); return; }
    const { count } = await supabase
      .from("reflection_answers")
      .select("id", { count: "exact", head: true })
      .eq("session_id", sessionId);
    const last = Math.max(1, count ?? 1);
    navigate(`/new/${sessionId}/${last}`);
  };

  return (
    <>
      <TopBar />
      <MicroCalm>
      <main className="mx-auto flex max-w-content flex-col items-center px-4 py-24">
        {running ? (
          <div className="flex flex-col items-center gap-6 animate-fade-in-up">
            <div className="relative flex h-20 w-20 items-center justify-center">
              <span aria-hidden className="absolute inset-0 rounded-full bg-primary/10 breathe-dot" />
              <span aria-hidden className="absolute inset-3 rounded-full bg-primary/20 breathe-dot" style={{ animationDelay: "0.4s" }} />
              <span aria-hidden className="relative h-3 w-3 rounded-full bg-primary breathe-dot" style={{ animationDelay: "0.8s" }} />
            </div>
            <p className="text-base text-muted-foreground transition-opacity duration-500">
              {PHRASES[phraseIdx]}
            </p>
            <p className="max-w-xs text-center text-xs text-muted-foreground/80">
              Take a breath. This usually takes a few seconds.
            </p>
          </div>
        ) : (
          <div className="card-soft w-full max-w-md p-8 text-center animate-fade-in-up">
            <p className="text-base">{error}</p>
            <div className="mt-6 flex justify-center gap-3">
              <Button variant="outline" onClick={goBack}>Back</Button>
              <Button onClick={run}>Try Again</Button>
            </div>
          </div>
        )}
      </main>
      </MicroCalm>
    </>
  );
};

export default Loading;
