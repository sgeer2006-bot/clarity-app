import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  BarChart3,
  Calendar,
  Compass,
  FileText,
  Share2,
  Sparkles,
} from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import {
  ActivityPoint,
  RecentSnapshot,
  SharedSnapshot,
  UserPatternCount,
  UserSummaryStats,
  fetchActivityTimeline,
  fetchPatternCounts,
  fetchRecentSnapshots,
  fetchSharedSnapshots,
  fetchSummaryStats,
} from "@/lib/analytics";
import { StatCard } from "@/components/analytics/StatCard";
import { ActivityChart } from "@/components/analytics/ActivityChart";
import { PatternBreakdown } from "@/components/analytics/PatternBreakdown";
import { SnapshotsGallery } from "@/components/analytics/SnapshotsGallery";
import { WeeklyNarrativeDigest } from "@/components/narrative/WeeklyNarrativeDigest";
import { HistoryList } from "@/components/HistoryList";
import { IdentityChips } from "@/components/identity/IdentityChips";
import { IdentityEvolutionCard } from "@/components/identity/IdentityEvolutionCard";
import { MicroContinuation } from "@/components/habit/MicroContinuation";
import { PageHeader } from "@/components/layout/PageHeader";
import { CalmSurface } from "@/components/calm/CalmPrimitives";
import { CalmSectionHeader } from "@/components/calm/CalmSectionHeader";

import { PremiumCalmLayer } from "@/components/calm/PremiumCalmLayer";
import { canUse } from "@/lib/featureGate";

const Analytics = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<UserSummaryStats | null>(null);
  const [patterns, setPatterns] = useState<UserPatternCount[]>([]);
  const [activity, setActivity] = useState<ActivityPoint[]>([]);
  const [recent, setRecent] = useState<RecentSnapshot[]>([]);
  const [shared, setShared] = useState<SharedSnapshot[]>([]);

  useEffect(() => {
    document.title = "Your dashboard — Clarity";
    const desc = "A living view of your reflections, patterns, and shared snapshots.";
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      (meta as HTMLMetaElement).name = "description";
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", desc);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user.id;
      if (!userId) {
        navigate("/auth");
        return;
      }
      const [s, p, a, r, sh] = await Promise.all([
        fetchSummaryStats(userId),
        fetchPatternCounts(userId),
        fetchActivityTimeline(userId, 30),
        fetchRecentSnapshots(8),
        fetchSharedSnapshots(6),
      ]);
      if (cancelled) return;
      setSummary(s);
      setPatterns(p);
      setActivity(a);
      setRecent(r);
      setShared(sh);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [navigate]);

  const empty =
    !loading &&
    summary?.completed_sessions === 0 &&
    patterns.length === 0 &&
    shared.length === 0;

  return (
    <AppShell width="wide">
      <PageHeader
        eyebrow={<><BarChart3 className="h-3 w-3" aria-hidden /> Your dashboard</>}
        title="How your thinking is unfolding"
        lead="A living view of your reflections, the patterns we've spotted, and what you've shared."
      />

        {loading ? (
          <SkeletonState />
        ) : empty ? (
          <EmptyState />
        ) : (
          <div className="space-y-12">
            {canUse("premium_calm_layer") ? (
              <PremiumCalmLayer delay={40}>
                <section
                  aria-label="Summary"
                  className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4"
                >
                  <StatCard
                    label="Reflections"
                    value={summary?.completed_sessions ?? 0}
                    hint={`${summary?.total_sessions ?? 0} total started`}
                    icon={FileText}
                  />
                  <StatCard
                    label="Patterns"
                    value={summary?.unique_patterns ?? 0}
                    hint={`${summary?.total_patterns_matched ?? 0} matches`}
                    icon={Compass}
                    accent="accent"
                  />
                  <StatCard
                    label="Shared"
                    value={summary?.total_shared ?? 0}
                    hint="snapshots"
                    icon={Share2}
                  />
                  <StatCard
                    label="Streak"
                    value={summary?.current_streak_days ?? 0}
                    hint="days in a row"
                    icon={Calendar}
                    accent="accent"
                  />
                </section>
              </PremiumCalmLayer>
            ) : (
              <section
                aria-label="Summary"
                className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4"
              >
                <StatCard
                  label="Reflections"
                  value={summary?.completed_sessions ?? 0}
                  hint={`${summary?.total_sessions ?? 0} total started`}
                  icon={FileText}
                />
                <StatCard
                  label="Patterns"
                  value={summary?.unique_patterns ?? 0}
                  hint={`${summary?.total_patterns_matched ?? 0} matches`}
                  icon={Compass}
                  accent="accent"
                />
                <StatCard
                  label="Shared"
                  value={summary?.total_shared ?? 0}
                  hint="snapshots"
                  icon={Share2}
                />
                <StatCard
                  label="Streak"
                  value={summary?.current_streak_days ?? 0}
                  hint="days in a row"
                  icon={Calendar}
                  accent="accent"
                />
              </section>
            )}

            <CalmSurface padding="24" radius="lg" shadow="sm" aria-label="This week, as a story">
              <CalmSectionHeader>This week, as a story</CalmSectionHeader>
              <WeeklyNarrativeDigest
                activity={activity}
                topPattern={patterns[0]}
                streak={summary?.current_streak_days ?? 0}
              />
            </CalmSurface>

            <section aria-label="Your evolving identity" className="grid gap-4 lg:grid-cols-2">
              <IdentityEvolutionCard />
              <div className="space-y-4">
                <IdentityChips />
                <MicroContinuation ctx={{ lastActionType: "insight_viewed" }} />
              </div>
            </section>

            <section
              aria-label="Activity and patterns"
              className="grid gap-6 lg:grid-cols-5"
            >
              <div className="lg:col-span-3">
                <ActivityChart data={activity} />
              </div>
              <div className="lg:col-span-2">
                <PatternBreakdown patterns={patterns} />
              </div>
            </section>

            <section aria-label="Shared snapshots">
              <SnapshotsGallery shares={shared} />
            </section>

            <section aria-label="Recent reflections">
              <div className="mb-3 flex items-baseline justify-between">
                <h2 className="font-display text-lg font-semibold">Recent reflections</h2>
                <Link
                  to="/you/timeline"
                  className="text-xs text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
                >
                  View all
                </Link>
              </div>
              {recent.length > 0 ? (
                <HistoryList
                  items={recent.map((r) => ({
                    id: r.id,
                    title: r.title,
                    created_at: r.completed_at,
                  }))}
                />
              ) : (
                <p className="rounded-xl border border-dashed border-border/70 bg-muted/30 p-6 text-center text-sm text-muted-foreground">
                  No completed reflections yet.
                </p>
              )}
            </section>
          </div>
        )}
        <div className="mt-8">
        </div>
    </AppShell>
  );
};

const SkeletonState = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Skeleton key={i} className="h-28 rounded-2xl" />
      ))}
    </div>
    <Skeleton className="h-32 rounded-2xl" />
    <div className="grid gap-6 lg:grid-cols-5">
      <Skeleton className="h-72 rounded-2xl lg:col-span-3" />
      <Skeleton className="h-72 rounded-2xl lg:col-span-2" />
    </div>
    <Skeleton className="h-56 rounded-2xl" />
  </div>
);

const EmptyState = () => (
  <div className="rounded-2xl border border-dashed border-border/70 bg-card/60 p-10 text-center">
    <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
      <Sparkles className="h-5 w-5 text-primary" aria-hidden />
    </div>
    <h2 className="font-display text-xl font-semibold">Your dashboard begins with one reflection</h2>
    <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
      Once you complete a reflection, you'll see your activity, the patterns we spot, and any
      snapshots you share — all in one place.
    </p>
    <Button asChild className="mt-6 rounded-full">
      <Link to="/reflect">Start a reflection</Link>
    </Button>
  </div>
);

export default Analytics;
