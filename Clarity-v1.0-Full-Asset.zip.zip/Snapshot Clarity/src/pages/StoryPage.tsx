/**
 * /story — canonical "Your Story" surface.
 *
 * Wrapper around StorySection. Reachable from the Menu and Insights.
 */
import { Helmet } from "react-helmet-async";
import { TopBar } from "@/components/TopBar";
import { AppShell } from "@/components/layout/AppShell";
import { StorySection } from "@/pages/insights/sections/StorySection";

export default function StoryPage() {
  return (
    <>
      <Helmet>
        <title>Your Story — Clarity</title>
        <meta
          name="description"
          content="Your story, reflected back with precision."
        />
        <link rel="canonical" href="/story" />
      </Helmet>
      <TopBar />
      <AppShell width="content">
        <header className="mb-6">
          <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
            Your Story
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Your story, reflected back with precision.
          </p>
        </header>
        <StorySection />
      </AppShell>
    </>
  );
}
