import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Loader2, Send, RefreshCw } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { SnapshotView } from "@/components/SnapshotView";
import { supabase } from "@/integrations/supabase/client";
import { generateCorrectionQuestion, regenerateSnapshot, FriendlyError } from "@/lib/api";
import type { ReflectionSessionRow, SnapshotJson } from "@/lib/types";
import { toast } from "@/hooks/use-toast";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { recordEvent } from "@/lib/identity";

interface Msg {
  role: "user" | "ai";
  content: string;
}

const CorrectionFlow = () => {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  const [session, setSession] = useState<ReflectionSessionRow | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [generating, setGenerating] = useState(false);
  const [regenerating, setRegenerating] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showUpdated, setShowUpdated] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data: sess } = await supabase.auth.getSession();
      if (!sess.session) { navigate("/auth"); return; }

      const { data } = await supabase
        .from("reflection_sessions")
        .select("*")
        .eq("id", sessionId!)
        .maybeSingle();

      if (cancelled) return;
      if (!data) { navigate("/you/timeline", { replace: true }); return; }

      setSession({
        ...data,
        status: data.status as ReflectionSessionRow["status"],
        snapshot_json: (data.snapshot_json as unknown as SnapshotJson | null) ?? null,
      });
      setLoading(false);

      // Generate first correction question
      setGenerating(true);
      try {
        const q = await generateCorrectionQuestion(sessionId!, []);
        if (!cancelled) setMessages([{ role: "ai", content: q }]);
      } catch (e) {
        if (e instanceof FriendlyError && e.kind === "auth") navigate("/auth");
        else toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
      } finally {
        if (!cancelled) setGenerating(false);
      }
    })();
    return () => { cancelled = true; };
  }, [sessionId, navigate]);

  const handleSend = async () => {
    const trimmed = input.trim();
    if (!trimmed || !sessionId) return;
    const userMsg: Msg = { role: "user", content: trimmed };
    const updated = [...messages, userMsg];
    setMessages(updated);
    setInput("");

    // Ask another correction question
    setGenerating(true);
    try {
      const q = await generateCorrectionQuestion(sessionId, updated);
      setMessages((prev) => [...prev, { role: "ai", content: q }]);
    } catch (e) {
      if (e instanceof FriendlyError && e.kind === "auth") navigate("/auth");
      else toast({ title: "Error", description: (e as Error).message, variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const handleRegenerate = async () => {
    if (!sessionId) return;
    setRegenerating(true);
    try {
      const { snapshot, version } = await regenerateSnapshot(sessionId, messages);
      setSession((prev) =>
        prev ? { ...prev, snapshot_json: snapshot } : prev,
      );
      setShowUpdated(true);
      toast({ title: `Snapshot updated (version ${version})` });
      recordEvent({
        source: "snapshot",
        tags: { cognitive: ["snapshot_corrected"] },
      });
    } catch (e) {
      toast({ title: "Could not regenerate", description: (e as Error).message, variant: "destructive" });
    } finally {
      setRegenerating(false);
    }
  };

  if (loading || !session) {
    return (
      <>
        <TopBar />
        <main className="mx-auto max-w-content px-4 py-12">
          <p className="text-sm text-muted-foreground">Loading…</p>
        </main>
      </>
    );
  }

  if (showUpdated) {
    return (
      <>
        <TopBar />
        <main className="mx-auto max-w-content space-y-6 px-4 py-12">
          <div className="rounded-lg border border-accent/40 bg-accent/10 p-3 text-center text-sm">
            ✓ Your snapshot has been updated based on your corrections.
          </div>
          <SnapshotView session={session} showResponsesCollapsible={false} />
          <Button onClick={() => navigate(`/snapshot/${sessionId}`)} className="w-full">
            Back to Snapshot
          </Button>
        </main>
      </>
    );
  }

  return (
    <>
      <TopBar />
      <MicroCalm>
      <main className="mx-auto max-w-content space-y-6 px-4 py-12">
        <div className="rounded-xl border border-border bg-card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium">Correct your snapshot</h2>
            <Button variant="ghost" size="sm" onClick={() => navigate(`/snapshot/${sessionId}`)}>
              Cancel
            </Button>
          </div>

          <p className="text-sm text-muted-foreground">
            Tell us what feels wrong or missing. We'll update your snapshot.
          </p>

          <div className="space-y-3 max-h-[350px] overflow-y-auto rounded-lg border border-border bg-muted/20 p-4">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm ${
                  m.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-card border border-border"
                }`}>
                  {m.content}
                </div>
              </div>
            ))}
            {generating && (
              <div className="flex justify-start">
                <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" /> Thinking…
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Describe what's wrong or missing…"
              rows={2}
              className="resize-none"
              disabled={generating || regenerating}
              onKeyDown={(e) => {
                if ((e.metaKey || e.ctrlKey) && e.key === "Enter") handleSend();
              }}
            />
            <Button onClick={handleSend} disabled={!input.trim() || generating || regenerating} size="icon" className="shrink-0">
              <Send className="h-4 w-4" />
            </Button>
          </div>

          {messages.filter((m) => m.role === "user").length >= 1 && (
            <Button
              onClick={handleRegenerate}
              disabled={regenerating}
              className="w-full"
              variant="default"
            >
              {regenerating ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Regenerating…</>
              ) : (
                <><RefreshCw className="mr-2 h-4 w-4" /> Regenerate Snapshot</>
              )}
            </Button>
          )}
        </div>
      </main>
      </MicroCalm>
    </>
  );
};

export default CorrectionFlow;
