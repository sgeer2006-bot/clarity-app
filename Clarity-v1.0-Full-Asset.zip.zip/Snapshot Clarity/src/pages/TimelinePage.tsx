/**
 * Timeline — canonical page under "You".
 *
 * Primary data: Analytical Engine v1 via the read-only Data Adapter
 * (getTimelinePageEngineData). Legacy History (snapshots + folders) remains
 * the fallback path when the engine returns nothing useful, and is rendered
 * unchanged via the existing History component.
 */
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import History from "./History";
import { TopBar } from "@/components/TopBar";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { useAuthSession } from "@/hooks/useAuthSession";
import { getTimelinePageEngineData } from "@/lib/analyticalEngine/dataAdapter";

type EngineTimeline = Awaited<ReturnType<typeof getTimelinePageEngineData>>;

function formatDate(iso?: string) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

export default function TimelinePage() {
  const { session } = useAuthSession();
  const userId = session?.user?.id ?? null;
  const [engine, setEngine] = useState<EngineTimeline | null>(null);
  const [engineLoading, setEngineLoading] = useState(false);
  const [engineError, setEngineError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    if (!userId) {
      setEngine(null);
      return;
    }
    setEngineLoading(true);
    setEngineError(false);
    (async () => {
      try {
        const result = await getTimelinePageEngineData(userId);
        if (!cancelled) setEngine(result ?? null);
      } catch {
        if (!cancelled) {
          setEngine(null);
          setEngineError(true);
        }
      } finally {
        if (!cancelled) setEngineLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [userId]);

  // Permissive view: read every listed engine field defensively so any
  // future adapter expansion lights up without page changes.
  const view = (engine ?? null) as null | (EngineTimeline & {
    groupedReflections?: Array<{
      key: string;
      items: Array<{ id: string; title: string; summary?: string; ts?: string }>;
    }>;
    emotionalTags?: Array<{ id?: string; label: string; confidenceScore?: number }>;
    identityEvolution?: Array<{ id?: string; label?: string; description?: string; ts?: string }>;
    weeklyArcs?: Array<{ id?: string; label?: string; description?: string }>;
  });

  const groupedReflections = view?.groupedReflections ?? [];
  const emotionalTags = view?.emotionalTags ?? [];
  const patternEvolution = engine?.patternEvolution ?? [];
  const identityEvolution = view?.identityEvolution ?? [];
  const turningPoints = engine?.turningPoints ?? [];
  const weeklyArcs = view?.weeklyArcs ?? [];

  const useEngine =
    groupedReflections.length > 0 ||
    emotionalTags.length > 0 ||
    patternEvolution.length > 0 ||
    identityEvolution.length > 0 ||
    turningPoints.length > 0 ||
    weeklyArcs.length > 0;

  if (!useEngine) {
    // Fallback path: render the legacy History UI exactly as before.
    return (
      <>
        {engineLoading ? (
          <p className="mx-auto max-w-content px-5 pt-4 text-sm text-muted-foreground sm:px-6">
            Loading…
          </p>
        ) : engineError ? (
          <p className="mx-auto max-w-content px-5 pt-4 text-sm text-muted-foreground sm:px-6">
            Something went wrong — showing your saved version instead.
          </p>
        ) : null}
        <History />
      </>
    );
  }

  return (
    <>
      <TopBar />
      <MicroCalm>
        <main className="mx-auto max-w-content space-y-6 px-5 py-12 sm:px-6 sm:py-16">
          <header>
            <h1 className="text-2xl font-semibold tracking-tight">How things have been shifting</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              A gentle look at what's been improving, what's getting heavier, and what's been steady for you.
            </p>
            {engineLoading ? (
              <p className="mt-2 text-sm text-muted-foreground">Loading…</p>
            ) : engineError ? (
              <p className="mt-2 text-sm text-muted-foreground">
                Something went wrong — showing your saved version instead.
              </p>
            ) : null}
          </header>

          <div className="grid gap-6 md:grid-cols-[240px_1fr]">
            {/* Rail slot — emotional tag rail (engine equivalent of folder rail). */}
            <aside className="space-y-3">
              <nav className="rounded-xl border border-border bg-card p-2">
                {emotionalTags.length === 0 ? (
                  <p className="px-2 py-1.5 text-xs text-muted-foreground">Feelings will start showing up here as you reflect.</p>
                ) : (
                  emotionalTags.map((t, i) => (
                    <div
                      key={t.id ?? `${t.label}-${i}`}
                      className="flex items-center justify-between rounded px-2 py-1.5 text-sm"
                    >
                      <span className="truncate text-foreground/90">{t.label}</span>
                      {typeof t.confidenceScore === "number" ? (
                        <span className="shrink-0 text-xs text-muted-foreground">
                          {(t.confidenceScore * 100).toFixed(0)}%
                        </span>
                      ) : null}
                    </div>
                  ))
                )}
              </nav>
            </aside>

            {/* Main slot — grouped reflections (engine equivalent of snapshot list). */}
            <section className="space-y-6">
              {groupedReflections.length > 0 ? (
                groupedReflections.map((g) => (
                  <div key={g.key}>
                    <h3 className="mb-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground/80">
                      {g.key}
                    </h3>
                    <ul className="divide-y divide-border rounded-xl border border-border bg-card">
                      {g.items.map((it) => (
                        <li key={it.id} className="flex items-center gap-2 px-3 py-2">
                          <Link
                            to={`/snapshot/${it.id}`}
                            className="flex flex-1 items-center justify-between rounded px-2 py-2 hover:bg-muted/50"
                          >
                            <span className="truncate pr-4 text-base">{it.title}</span>
                            <span className="shrink-0 text-sm text-muted-foreground">
                              {formatDate(it.ts)}
                            </span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))
              ) : (
                <div className="rounded-xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">
                  Once you've had a few conversations, your reflections will start grouping here.
                </div>
              )}

              {turningPoints.length > 0 ? (
                <div>
                  <h3 className="mb-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground/80">
                    Moments that mattered
                  </h3>
                  <ul className="divide-y divide-border rounded-xl border border-border bg-card">
                    {turningPoints.map((tp) => (
                      <li key={tp.id} className="px-3 py-2">
                        <div className="text-base text-foreground/90">{tp.label}</div>
                        <div className="text-sm text-muted-foreground">{tp.description}</div>
                        {tp.ts ? (
                          <div className="mt-1 text-xs text-muted-foreground/70">
                            {formatDate(tp.ts)}
                          </div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}

              {patternEvolution.length > 0 ? (
                <div>
                  <h3 className="mb-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground/80">
                    What's been shifting for you
                  </h3>
                  <ul className="divide-y divide-border rounded-xl border border-border bg-card">
                    {patternEvolution.map((p, i) => (
                      <li key={`${p.what}-${i}`} className="flex items-center justify-between px-3 py-2">
                        <span className="text-base text-foreground/90">{p.what}</span>
                        <span className="text-sm text-muted-foreground">{p.direction}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}

              {identityEvolution.length > 0 ? (
                <div>
                  <h3 className="mb-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground/80">
                    How you're changing over time
                  </h3>
                  <ul className="divide-y divide-border rounded-xl border border-border bg-card">
                    {identityEvolution.map((e, i) => (
                      <li key={e.id ?? `${e.label}-${i}`} className="px-3 py-2">
                        <div className="text-base text-foreground/90">{e.label ?? "—"}</div>
                        {e.description ? (
                          <div className="text-sm text-muted-foreground">{e.description}</div>
                        ) : null}
                        {e.ts ? (
                          <div className="mt-1 text-xs text-muted-foreground/70">
                            {formatDate(e.ts)}
                          </div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}

              {weeklyArcs.length > 0 ? (
                <div>
                  <h3 className="mb-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground/80">
                    How your weeks have been going
                  </h3>
                  <ul className="divide-y divide-border rounded-xl border border-border bg-card">
                    {weeklyArcs.map((w, i) => (
                      <li key={w.id ?? `${w.label}-${i}`} className="px-3 py-2">
                        <div className="text-base text-foreground/90">{w.label ?? "—"}</div>
                        {w.description ? (
                          <div className="text-sm text-muted-foreground">{w.description}</div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </section>
          </div>
        </main>
      </MicroCalm>
    </>
  );
}
