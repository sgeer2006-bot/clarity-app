import { useParams, useNavigate } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { ChevronLeft, Sparkles, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { usePatternSnapshot } from "@/hooks/usePatternSnapshot";
import { PatternCard } from "@/components/pattern/PatternCard";
import { LoopRing } from "@/components/pattern/LoopRing";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { IdentityChips } from "@/components/identity/IdentityChips";
import { MicroContinuation } from "@/components/habit/MicroContinuation";

export default function PatternSnapshotPage() {
  const { answerId } = useParams<{ answerId: string }>();
  const navigate = useNavigate();
  const { data, loading, error, analyze } = usePatternSnapshot(answerId);

  const sections = data?.sections;

  return (
    <div className="min-h-screen" style={{ background: "var(--gradient-hero)" }}>
      <Helmet>
        <title>Pattern Snapshot — Clarity</title>
        <meta name="description" content="A psychological read-back of your reflection: patterns, loops, and possibilities." />
      </Helmet>

      <header className="px-4 pt-4 pb-2 flex items-center justify-between max-w-2xl mx-auto">
        <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
          <ChevronLeft className="h-4 w-4 mr-1" /> Back
        </Button>
        <Button variant="ghost" size="sm" onClick={() => analyze(true)} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Re-read
        </Button>
      </header>

      <MicroCalm>
      <main className="max-w-2xl mx-auto px-4 pb-16 space-y-5">
        {loading && !data && (
          <div className="space-y-4 pt-6">
            <Skeleton className="h-40 w-full rounded-xl" />
            <Skeleton className="h-24 w-full rounded-xl" />
            <Skeleton className="h-24 w-full rounded-xl" />
          </div>
        )}

        {error && (
          <Card className="p-4 border-destructive/30 bg-destructive/5">
            <p className="text-sm text-destructive">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={() => analyze(true)}>Try again</Button>
          </Card>
        )}

        {sections && (
          <>
            {/* Hero / primary pattern */}
            <Card
              className="p-6 border-primary/10 overflow-hidden relative"
              style={{ background: "var(--gradient-card)" }}
            >
              <div className="absolute -top-20 -right-20 h-64 w-64 rounded-full opacity-20"
                   style={{ background: "radial-gradient(circle, hsl(var(--primary)) 0%, transparent 70%)" }} />
              <div className="relative">
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground mb-2">
                  <Sparkles className="h-3 w-3" /> Primary pattern
                </div>
                <h1 className="font-serif text-3xl leading-tight text-foreground mb-3">
                  {sections.primaryPattern.label}
                </h1>
                <p className="text-base text-foreground/80 leading-relaxed">
                  {sections.primaryPattern.summary}
                </p>
              </div>
            </Card>

            {/* Secondary patterns */}
            {sections.secondaryPatterns?.length > 0 && (
              <section>
                <h2 className="text-xs uppercase tracking-wider text-muted-foreground mb-2 px-1">Also surfacing</h2>
                <div className="space-y-2">
                  {sections.secondaryPatterns.map((p) => (
                    <PatternCard
                      key={p.id}
                      label={p.label}
                      category={p.id.split(".")[0]}
                      intensity={0.55}
                      summary={p.summary}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Emotional loop */}
            {sections.emotionalLoop && (
              <Card className="p-6 flex justify-center">
                <LoopRing loop={sections.emotionalLoop} />
              </Card>
            )}

            {/* Communication + Behavioral */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {sections.communicationStyle?.label && (
                <Card className="p-4">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1">Communication</div>
                  <div className="font-medium mb-1">{sections.communicationStyle.label}</div>
                  <p className="text-sm text-muted-foreground leading-snug">{sections.communicationStyle.notes}</p>
                </Card>
              )}
              {sections.behavioralTendencies?.length > 0 && (
                <Card className="p-4">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1">Behavioral notes</div>
                  <ul className="space-y-2 mt-1">
                    {sections.behavioralTendencies.map((b, i) => (
                      <li key={i} className="text-sm">
                        <div className="font-medium">{b.label}</div>
                        <div className="text-muted-foreground">{b.notes}</div>
                      </li>
                    ))}
                  </ul>
                </Card>
              )}
            </div>

            {/* Meaning / Why / How — accordion */}
            <Accordion type="multiple" className="space-y-2">
              <AccordionItem value="meaning" className="border rounded-xl bg-card px-4">
                <AccordionTrigger className="text-sm font-medium">What this pattern usually means</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed">{sections.meaning}</AccordionContent>
              </AccordionItem>
              <AccordionItem value="why" className="border rounded-xl bg-card px-4">
                <AccordionTrigger className="text-sm font-medium">Why this might be showing up</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed">{sections.why}</AccordionContent>
              </AccordionItem>
              <AccordionItem value="how" className="border rounded-xl bg-card px-4">
                <AccordionTrigger className="text-sm font-medium">How it shows up in your life</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed">{sections.howItShowsUp}</AccordionContent>
              </AccordionItem>
            </Accordion>

            {/* What the AI notices */}
            {sections.whatAINotices?.length > 0 && (
              <section>
                <h2 className="text-xs uppercase tracking-wider text-muted-foreground mb-2 px-1">What I keep noticing</h2>
                <div className="space-y-2">
                  {sections.whatAINotices.map((q, i) => (
                    <Card key={i} className="p-4 border-l-4 border-l-primary/40">
                      <p className="text-sm italic text-foreground/90">"{q}"</p>
                    </Card>
                  ))}
                </div>
              </section>
            )}

            {/* Paths forward */}
            {sections.pathsForward?.length > 0 && (
              <section>
                <h2 className="text-xs uppercase tracking-wider text-muted-foreground mb-2 px-1">Possible paths forward</h2>
                <div className="space-y-2">
                  {sections.pathsForward.map((p, i) => (
                    <Card key={i} className="p-4 hover:border-primary/40 transition-colors">
                      <p className="text-sm leading-relaxed">{p}</p>
                    </Card>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground/70 mt-3 text-center px-4">
                  These are openings, not instructions. This tool does not give advice.
                </p>
              </section>
            )}
          </>
        )}

        {sections && (
          <div className="grid gap-4 pt-2 sm:grid-cols-2">
            <IdentityChips />
            <MicroContinuation ctx={{ lastActionType: "insight_viewed" }} />
          </div>
        )}
      </main>
      </MicroCalm>
    </div>
  );
}
