import { Helmet } from "react-helmet-async";
import { TopBar } from "@/components/TopBar";
import { MicroCalm } from "@/components/habit/MicroCalm";

const SECTIONS = [
  {
    slug: "suicide-crisis-support",
    title: "Suicide & Crisis Support",
    body: "If you are having thoughts of suicide or self-harm, you are not alone. Many regions have free, confidential crisis lines staffed around the clock by trained listeners.",
  },
  {
    slug: "domestic-violence-support",
    title: "Domestic Violence Support",
    body: "If you feel unsafe with someone close to you, support is available. Local organisations can offer confidential guidance, safety planning, and shelter referrals.",
  },
  {
    slug: "substance-abuse-support",
    title: "Substance Abuse Support",
    body: "If substances are part of what's hard right now, treatment referral lines and peer support groups exist in most regions and are often free and confidential.",
  },
  {
    slug: "gambling-addiction-support",
    title: "Gambling Addiction Support",
    body: "If gambling is causing harm, free helplines and peer-support communities exist in many regions to help you talk through what's happening at your own pace.",
  },
  {
    slug: "emergency-medical-support",
    title: "Emergency Medical Support",
    body: "If you are experiencing a medical emergency or feel someone is in immediate physical danger, please contact your local emergency services right away.",
  },
];

const COMMON = [
  "Please seek local emergency services if you are in immediate danger.",
  "This app is not a crisis tool.",
  "We do not store or monitor your messages for emergencies.",
];

export default function SafetyResourcesPage() {
  return (
    <div className="min-h-screen" style={{ background: "#FAF5EC", color: "#2A2520" }}>
      <Helmet>
        <title>Safety Resources — Clarity</title>
        <meta name="description" content="Support when things feel overwhelming." />
        <link rel="canonical" href="/safety/resources" />
      </Helmet>
      <TopBar />
      <MicroCalm>
      <main className="mx-auto w-full max-w-2xl px-6 py-12">
        <h1 className="mb-2 text-2xl font-semibold tracking-tight">Safety Resources</h1>
        <p className="mb-6 text-sm" style={{ color: "#5A524A" }}>Support when things feel overwhelming.</p>
        <section className="mb-8">
          <h2 className="mb-2 text-xs uppercase tracking-[0.18em]" style={{ color: "#5E7A60" }}>
            About this page
          </h2>
          <p className="text-sm leading-relaxed" style={{ color: "#5A524A" }}>
            This page provides general, non-directive guidance about where people commonly look for support. It is not a crisis service. Clarity does not monitor your messages, does not contact anyone on your behalf, and does not replace professional or emergency services.
          </p>
        </section>

        <div className="space-y-8">
          {SECTIONS.map((s) => (
            <section key={s.slug} id={s.slug} className="scroll-mt-24">
              <h2 className="text-base font-medium">{s.title}</h2>
              <p className="mt-2 text-sm leading-relaxed" style={{ color: "#5A524A" }}>
                {s.body}
              </p>
              <ul className="mt-3 space-y-1 text-sm" style={{ color: "#5A524A" }}>
                {COMMON.map((c) => (
                  <li key={c}>• {c}</li>
                ))}
              </ul>
            </section>
          ))}
        </div>

        <aside
          className="mt-12 rounded-[14px] p-5 text-sm leading-relaxed"
          style={{ background: "#EBDFCB", borderLeft: "4px solid #8FA88F", color: "#2A2520" }}
        >
          Clarity provides reflective journaling features only. It is not medical, psychological, legal, or emergency advice.
        </aside>
      </main>
      </MicroCalm>
    </div>
  );
}
