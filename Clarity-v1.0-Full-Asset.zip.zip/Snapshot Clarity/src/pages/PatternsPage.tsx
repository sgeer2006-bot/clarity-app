/**
 * /patterns — canonical Patterns surface.
 *
 * Restored route. Renders the existing PatternsSection (no engine or
 * component changes). Reachable from Insights and the Menu.
 */
import { Helmet } from "react-helmet-async";
import { TopBar } from "@/components/TopBar";
import { AppShell } from "@/components/layout/AppShell";
import { PatternsSection } from "@/pages/insights/sections/PatternsSection";

export default function PatternsPage() {
  return (
    <>
      <Helmet>
        <title>Patterns — Clarity</title>
        <meta
          name="description"
          content="Frequency, heatmap, and clusters at a glance — the shapes that keep showing up."
        />
        <link rel="canonical" href="/patterns" />
      </Helmet>
      <TopBar />
      <AppShell width="content">
        <PatternsSection />
      </AppShell>
    </>
  );
}
