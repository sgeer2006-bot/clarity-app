/**
 * Story — timeline + identity narrative.
 *
 * Primary data: Analytical Engine v1 via the read-only Data Adapter
 * (getYourStoryPageEngineData). Legacy hooks and helpers
 * (useTimeline / useIdentity / useIdentityHistory / deriveTimelineInsights /
 * deriveIdentityInsights) remain untouched and serve as the fallback path.
 */
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { CalmCard } from "@/components/patterns/CalmPrimitives";
import { CalmSurface, QuietLead } from "@/components/calm/CalmPrimitives";
import { CalmSectionHeader } from "@/components/calm/CalmSectionHeader";
import { CalmText } from "@/components/calm/CalmText";
import { TimelineEventCard } from "@/components/patterns/TimelineEventCard";
import { IdentityNarrativeCard } from "@/components/patterns/IdentityNarrativeCard";
import { EmptyState } from "@/components/patterns/EmptyState";
import { InsightNarrativeBlock, InsightList } from "@/components/patterns/insights";
import { CollapsibleSection } from "@/components/patterns/CollapsibleSection";
import { IdentityTimeline } from "@/interaction/IdentityTimeline";
import {
  useTimeline,
  useIdentity,
  useIdentityHistory,
  type TimelineRow,
} from "@/hooks/usePatternData";
import { deriveTimelineInsights, deriveIdentityInsights } from "@/lib/insights";
import { getYourStoryPageEngineData } from "@/lib/analyticalEngine/dataAdapter";
import { useAuthSession } from "@/hooks/useAuthSession";

type Grouping = "week" | "month";
type EngineStory = Awaited<ReturnType<typeof getYourStoryPageEngineData>>;

function groupKey(iso: string, grouping: Grouping) {
  const d = new Date(iso);
  if (grouping === "month") {
    return d.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  }
  const onejan = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil((((d.getTime() - onejan.getTime()) / 86400000) + onejan.getDay() + 1) / 7);
  return `Week ${week}, ${d.getFullYear()}`;
}

function asArray(v: unknown): string[] {
  if (Array.isArray(v)) return v.filter((x) => typeof x === "string");
  return [];
}

/**
 * Render structured detail without raw JSON. Accepts either an engine-derived
 * string (preferred), an object of key/value pairs, or nothing.
 */
function DetailBlock({ detail }: { detail: unknown }) {
  if (typeof detail === "string" && detail.trim().length > 0) {
    return <p className="text-xs text-muted-foreground">{detail}</p>;
  }
  if (detail && typeof detail === "object" && Object.keys(detail as Record<string, unknown>).length > 0) {
    const entries = Object.entries(detail as Record<string, unknown>).filter(
      ([, v]) => v !== null && v !== undefined && v !== "",
    );
    if (entries.length === 0) {
      return <p className="italic text-muted-foreground/70">Nothing more to add here.</p>;
    }
    return (
      <ul className="space-y-1 text-xs text-muted-foreground">
        {entries.map(([k, v]) => (
          <li key={k}>
            <span className="uppercase tracking-wider text-muted-foreground/70">
              {k.replace(/_/g, " ")}
            </span>
            : {Array.isArray(v) ? v.map(String).join(", ") : String(v)}
          </li>
        ))}
      </ul>
    );
  }
  return <p className="italic text-muted-foreground/70">Nothing more to add here.</p>;
}

export function StorySection() {
  // Legacy hooks — preserved as fallback path. Untouched.
  const timeline = useTimeline();
  const identity = useIdentity();
  const history = useIdentityHistory();
  const [grouping, setGrouping] = useState<Grouping>("week");

  // Engine-backed data (primary path).
  const { session } = useAuthSession();
  const userId = session?.user?.id ?? null;
  const [engineStory, setEngineStory] = useState<EngineStory | null>(null);
  const [engineLoading, setEngineLoading] = useState(false);
  const [engineError, setEngineError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    if (!userId) {
      setEngineStory(null);
      return;
    }
    setEngineLoading(true);
    setEngineError(false);
    (async () => {
      try {
        const result = await getYourStoryPageEngineData(userId);
        if (!cancelled) setEngineStory(result ?? null);
      } catch {
        if (!cancelled) {
          setEngineStory(null);
          setEngineError(true);
        }
      } finally {
        if (!cancelled) setEngineLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [userId]);

  // Defensive permissive view so engine fields not present on v1
  // YourStoryPageData (narrativeArcs / strengths / vulnerabilities /
  // blindSpots / triggers / emotionalArcs / identityEvolution) light up
  // automatically when the adapter expands.
  const engineExtra = (engineStory ?? null) as null | (EngineStory & {
    narrativeArcs?: Array<{ id?: string; title?: string; description?: string }>;
    strengths?: string[];
    vulnerabilities?: string[];
    blindSpots?: string[];
    triggers?: string[];
    emotionalArcs?: Array<{ id?: string; label?: string; description?: string; ts?: string }>;
    identityEvolution?: Array<{ id?: string; label?: string; description?: string; ts?: string }>;
  });

  const identityThemes = engineStory?.identityThemes ?? [];
  const turningPoints = engineStory?.turningPoints ?? [];
  const narrativeArcs = engineExtra?.narrativeArcs ?? [];
  const engineStrengths = engineExtra?.strengths ?? [];
  const engineVulnerabilities = engineExtra?.vulnerabilities ?? [];
  const engineBlindSpots = engineExtra?.blindSpots ?? [];
  const engineTriggers = engineExtra?.triggers ?? [];
  const emotionalArcs = engineExtra?.emotionalArcs ?? [];
  const identityEvolution = engineExtra?.identityEvolution ?? [];

  const useEngine =
    identityThemes.length > 0 ||
    narrativeArcs.length > 0 ||
    engineStrengths.length > 0 ||
    engineVulnerabilities.length > 0 ||
    engineBlindSpots.length > 0 ||
    engineTriggers.length > 0 ||
    emotionalArcs.length > 0 ||
    identityEvolution.length > 0;

  // --- Legacy derived (fallback) ---
  const groups = useMemo(() => {
    const data = timeline.data ?? [];
    const map = new Map<string, TimelineRow[]>();
    for (const r of data) {
      const k = groupKey(r.event_date, grouping);
      const arr = map.get(k) ?? [];
      arr.push(r);
      map.set(k, arr);
    }
    return Array.from(map.entries()).slice(0, 3).map(([key, rows]) => ({ key, rows }));
  }, [timeline.data, grouping]);

  const timelineInsights = useMemo(
    () => deriveTimelineInsights({ rows: timeline.data ?? [] }),
    [timeline.data]
  );
  const identityInsights = useMemo(
    () => deriveIdentityInsights({ identity: identity.data ?? null }),
    [identity.data]
  );

  const id = identity.data;
  const legacyIdentitySections = id
    ? [
        { heading: "What you carry well", bullets: asArray(id.strengths) },
        { heading: "What you've been carrying", bullets: asArray(id.vulnerabilities) },
        { heading: "Easy to miss in yourself", bullets: asArray(id.blind_spots) },
        { heading: "What tends to set things off", bullets: asArray(id.recurring_triggers) },
      ].filter((s) => s.bullets.length > 0)
    : [];

  // --- Engine-driven timeline groups (replaces useTimeline output) ---
  const engineGroups = useMemo(() => {
    const arcs = [...emotionalArcs, ...identityEvolution].filter((a) => a && a.ts);
    if (arcs.length === 0 && turningPoints.length === 0) return [];
    const rows = [
      ...turningPoints.map((tp) => ({
        id: tp.id,
        event_date: tp.ts ?? new Date().toISOString(),
        title: tp.label,
        summary: tp.description,
        detail: { confidence: (tp.confidenceScore ?? 0).toFixed(2) } as Record<string, unknown>,
      })),
      ...arcs.map((a, i) => ({
        id: a.id ?? `arc-${i}`,
        event_date: a.ts ?? new Date().toISOString(),
        title: a.label ?? "Arc",
        summary: a.description ?? "",
        detail: a.description as unknown,
      })),
    ];
    const map = new Map<string, typeof rows>();
    for (const r of rows) {
      const k = groupKey(r.event_date, grouping);
      const arr = map.get(k) ?? [];
      arr.push(r);
      map.set(k, arr);
    }
    return Array.from(map.entries()).slice(0, 3).map(([key, rs]) => ({ key, rows: rs }));
  }, [emotionalArcs, identityEvolution, turningPoints, grouping]);

  const engineIdentitySections = [
    { heading: "What you carry well", bullets: engineStrengths },
    { heading: "What you've been carrying", bullets: engineVulnerabilities },
    { heading: "Easy to miss in yourself", bullets: engineBlindSpots },
    { heading: "What tends to set things off", bullets: engineTriggers },
  ].filter((s) => s.bullets.length > 0);

  const engineNarrativeText = useMemo(() => {
    if (narrativeArcs.length === 0 && identityThemes.length === 0) return "";
    const arcText = narrativeArcs.map((a) => a.description ?? a.title ?? "").filter(Boolean).join(" ");
    const themeText = identityThemes.map((t) => t.description ?? t.title).filter(Boolean).join(" ");
    return [arcText, themeText].filter(Boolean).join(" ");
  }, [narrativeArcs, identityThemes]);

  const engineDerivedInsights = useMemo(() => {
    if (!useEngine) return [];
    const out: Array<{ id: string; title: string; body: string; confidence: "low" | "medium" | "high"; tags: string[]; source: string }> = [];
    identityThemes.slice(0, 3).forEach((t) =>
      out.push({
        id: `theme-${t.id}`,
        title: t.title,
        body: t.description,
        confidence: (t.confidenceScore ?? 0) >= 0.7 ? "high" : (t.confidenceScore ?? 0) >= 0.4 ? "medium" : "low",
        tags: ["identity"],
        source: "engine",
      })
    );
    turningPoints.slice(0, 3).forEach((tp) =>
      out.push({
        id: `tp-${tp.id}`,
        title: tp.label,
        body: tp.description,
        confidence: (tp.confidenceScore ?? 0) >= 0.7 ? "high" : (tp.confidenceScore ?? 0) >= 0.4 ? "medium" : "low",
        tags: ["timeline"],
        source: "engine",
      })
    );
    return out;
  }, [useEngine, identityThemes, turningPoints]);

  const groupsToRender = useEngine ? engineGroups : groups;
  const isTimelineLoading = !useEngine && timeline.isLoading;
  const identitySections = useEngine ? engineIdentitySections : legacyIdentitySections;
  const narrativeText = useEngine ? engineNarrativeText : (id?.narrative_md ?? "");
  const historyCount = history.data?.length ?? 0;

  return (
    <section id="story" aria-labelledby="story-heading">
      <CalmSurface padding="24" radius="lg" shadow="sm">
        <header style={{ marginBottom: "var(--calm-space-16)" }}>
          <CalmText size="xs" soft style={{ textTransform: "uppercase", letterSpacing: "0.18em" }}>
            Your story so far
          </CalmText>
          <CalmSectionHeader id="story-heading" style={{ marginTop: "var(--calm-space-8)" }}>
            What you've been carrying, and what keeps coming up
          </CalmSectionHeader>
          <QuietLead>A quiet read of how things have been moving for you — and how they're changing.</QuietLead>
        </header>

        {engineLoading ? (
          <p className="text-sm text-muted-foreground" style={{ marginTop: "var(--calm-space-16)" }}>
            Loading…
          </p>
        ) : engineError ? (
          <p className="text-sm text-muted-foreground" style={{ marginTop: "var(--calm-space-16)" }}>
            Something went wrong — showing your saved version instead.
          </p>
        ) : null}

        <div
          style={{ marginTop: "var(--calm-space-24)", marginBottom: "var(--calm-space-24)" }}
          className="flex items-center justify-end"
        >
          <div className="inline-flex rounded-full border border-border/60 bg-card/40 p-0.5 text-xs">
            {(["week", "month"] as const).map((g) => (
              <button
                key={g}
                onClick={() => setGrouping(g)}
                className={`rounded-full px-3 py-1 transition-colors ${
                  grouping === g ? "bg-primary/10 text-foreground" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {g === "week" ? "By week" : "By month"}
              </button>
            ))}
          </div>
        </div>

        {isTimelineLoading ? (
          <CalmCard><p className="text-sm text-muted-foreground">Loading…</p></CalmCard>
        ) : groupsToRender.length === 0 ? (
          <EmptyState headline="Nothing here yet." subtext="Once you've had a few conversations, the bigger story will start to show up here." />
        ) : (
          <div className="space-y-10">
            {groupsToRender.map((g) => (
              <div key={g.key}>
                <h3 className="mb-4 text-[11px] uppercase tracking-[0.18em] text-muted-foreground/80">{g.key}</h3>
                <div>
                  {g.rows.map((r) => {
                    const isLegacy = (r as TimelineRow).event_type !== undefined;
                    const date = new Date(r.event_date).toLocaleDateString(undefined, { month: "short", day: "numeric" });
                    const title = isLegacy
                      ? ((r as TimelineRow).short_label || (r as TimelineRow).event_type.replace(/_/g, " "))
                      : (r as { title: string }).title;
                    const summary = isLegacy ? (r as TimelineRow).summary : (r as { summary: string }).summary;
                    const detail = isLegacy ? (r as TimelineRow).detail : (r as { detail: unknown }).detail;
                    return (
                      <TimelineEventCard
                        key={(r as { id: string }).id}
                        date={date}
                        title={title}
                        summary={summary}
                      >
                        <DetailBlock detail={detail} />
                      </TimelineEventCard>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}

        {narrativeText ? (
          <div style={{ marginTop: "var(--calm-space-40)" }}>
            <h3 className="mb-3 text-xs uppercase tracking-[0.18em] text-muted-foreground/80">
              Your story so far
            </h3>
            <CalmCard>
              <p className="text-base leading-relaxed text-foreground/85">{narrativeText}</p>
              {!useEngine && historyCount > 0 ? (
                <p className="mt-4 text-[11px] text-muted-foreground/60">
                  {historyCount} version{historyCount === 1 ? "" : "s"} of your story saved.
                </p>
              ) : null}
            </CalmCard>
          </div>
        ) : null}

        {identitySections.length > 0 ? (
          <div style={{ marginTop: "var(--calm-space-24)" }} className="space-y-3">
            {identitySections.map((s) => (
              <IdentityNarrativeCard key={s.heading} heading={s.heading} bullets={s.bullets} />
            ))}
          </div>
        ) : null}

        <InsightNarrativeBlock title="How things are changing for you">
          <InsightList
            insights={useEngine ? (engineDerivedInsights as never) : [...timelineInsights, ...identityInsights]}
            emptyLabel="Nothing big to point to yet — and that's okay."
          />
        </InsightNarrativeBlock>

        <CollapsibleSection title="How you're changing over time">
          <IdentityTimeline />
        </CollapsibleSection>

        <div style={{ marginTop: "var(--calm-space-32)" }} className="flex flex-wrap gap-3 text-xs text-muted-foreground/80">
          <Link to="/you/timeline" className="underline-offset-4 hover:underline">See how things have been shifting →</Link>
          <Link to="/story" className="underline-offset-4 hover:underline">How you're changing over time →</Link>
        </div>
      </CalmSurface>
    </section>
  );
}
