/**
 * Premium Preview — read-only teaser that respects existing gating.
 * Uses canUse() from the central feature gate. When the user already has
 * access, this becomes a quiet shortcut block instead of an upsell.
 */
import { Link } from "react-router-dom";
import { QuietHeader, CalmCard } from "@/components/patterns/CalmPrimitives";
import { canUse } from "@/lib/featureGate";

const PREMIUM_LINKS: { to: string; title: string; blurb: string }[] = [
  { to: "/insights", title: "A deeper read of you", blurb: "Longer narrative insights and richer pattern reads." },
  { to: "/dashboard", title: "Trends, taken further", blurb: "Soft week-over-week shifts and richer breakdowns." },
  { to: "/shared", title: "Shared Clarity", blurb: "A shared, calm space to reflect together." },
  { to: "/clarity-plus", title: "See what Clarity+ unlocks", blurb: "A short walk-through of everything inside." },
];

export function PremiumPreviewSection() {
  const hasFullInsights = canUse("insights_full");

  return (
    <section id="premium" aria-labelledby="premium-heading">
      <QuietHeader
        eyebrow={hasFullInsights ? "Your Clarity+ surfaces" : "A peek at Clarity+"}
        title={hasFullInsights ? "Where to go a little deeper" : "What opens with Clarity+"}
        lead={
          hasFullInsights
            ? "Quick links to the deeper layers you've unlocked."
            : "A short look at what Clarity+ adds to the work you're already doing here."
        }
      />
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        {PREMIUM_LINKS.map((p) => (
          <Link key={p.to} to={p.to} className="block">
            <CalmCard className="p-4 transition-colors hover:bg-card/60">
              <p className="text-base font-medium text-foreground/90">{p.title}</p>
              <p className="mt-1 text-sm text-muted-foreground">{p.blurb}</p>
            </CalmCard>
          </Link>
        ))}
      </div>
      {!hasFullInsights ? (
        <div className="mt-4 text-xs text-muted-foreground/80">
          <Link to="/clarity-plus" className="underline-offset-4 hover:underline">
            Unlock Clarity+ →
          </Link>
        </div>
      ) : null}
    </section>
  );
}
