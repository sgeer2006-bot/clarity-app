/**
 * Patterns — frequency, heatmap, clusters at a glance.
 *
 * Primary data: Analytical Engine v1 via the read-only Data Adapter
 * (getPatternsPageEngineData). Legacy hooks (useFrequency / useClusters /
 * useMacroPatterns) remain untouched and provide the fallback path when the
 * engine call errors or returns empty/missing data.
 */
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { CalmCard } from "@/components/patterns/CalmPrimitives";
import { getPatternsPageEngineData } from "@/lib/analyticalEngine/dataAdapter";
import { useAuthSession } from "@/hooks/useAuthSession";
import { CalmSurface, QuietLead } from "@/components/calm/CalmPrimitives";
import { CalmSectionHeader } from "@/components/calm/CalmSectionHeader";
import { CalmText } from "@/components/calm/CalmText";
import { PatternCard } from "@/components/patterns/PatternCard";
import { PatternClusterCard } from "@/components/patterns/PatternClusterCard";
import { EmptyState } from "@/components/patterns/EmptyState";
import { InsightNarrativeBlock, InsightList } from "@/components/patterns/insights";
import {
  useFrequency,
  useClusters,
  useMacroPatterns,
} from "@/hooks/usePatternData";
import { deriveFrequencyInsights, deriveClusterInsights } from "@/lib/insights";

type EnginePatterns = Awaited<ReturnType<typeof getPatternsPageEngineData>>;

export function PatternsSection() {
  // Legacy hooks — preserved as the fallback path. Untouched.
  const freq = useFrequency();
  const clusters = useClusters();
  const macros = useMacroPatterns();

  // Engine-backed data (primary path).
  const { session } = useAuthSession();
  const userId = session?.user?.id ?? null;
  const [enginePatterns, setEnginePatterns] = useState<EnginePatterns | null>(null);
  const [engineLoading, setEngineLoading] = useState(false);
  const [engineError, setEngineError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    if (!userId) {
      setEnginePatterns(null);
      return;
    }
    setEngineLoading(true);
    setEngineError(false);
    (async () => {
      try {
        const result = await getPatternsPageEngineData(userId);
        if (!cancelled) setEnginePatterns(result ?? null);
      } catch {
        if (!cancelled) {
          setEnginePatterns(null);
          setEngineError(true);
        }
      } finally {
        if (!cancelled) setEngineLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [userId]);

  // Read the six listed engine fields defensively. Fields not present on
  // PatternsPageData in v1 (topPatterns / patternEvolution / confidenceScores)
  // are read via a permissive shape so future adapter expansion lights up
  // automatically without further page changes.
  const engineExtra = (enginePatterns ?? null) as null | (EnginePatterns & {
    topPatterns?: Array<{ id?: string; description?: string; type?: string; frequency?: number; confidenceScore?: number }>;
    patternEvolution?: Array<{ what: string; direction: string; confidenceScore?: number }>;
    confidenceScores?: Record<string, number>;
  });

  const emotionalPatterns = enginePatterns?.emotionalPatterns ?? [];
  const behavioralPatterns = enginePatterns?.behavioralPatterns ?? [];
  const emotionalSignatures = enginePatterns?.emotionalSignatures ?? [];
  const triggers = enginePatterns?.triggerTypes ?? [];
  const loops = enginePatterns?.emotionalLoops ?? [];
  const topPatternsRaw = engineExtra?.topPatterns ?? [];
  const patternEvolution = engineExtra?.patternEvolution ?? [];
  const confidenceScores = engineExtra?.confidenceScores ?? {};

  const useEngine =
    topPatternsRaw.length > 0 ||
    emotionalSignatures.length > 0 ||
    triggers.length > 0 ||
    loops.length > 0 ||
    patternEvolution.length > 0 ||
    Object.keys(confidenceScores).length > 0 ||
    emotionalPatterns.length > 0 ||
    behavioralPatterns.length > 0;

  // --- Legacy derived (fallback) ---
  const labelById = useMemo(() => {
    const m = new Map<string, string>();
    (macros.data ?? []).forEach((p) => m.set(p.id, p.pattern_label));
    return m;
  }, [macros.data]);

  const freqInsights = useMemo(
    () => deriveFrequencyInsights({ rows: freq.data ?? [] }),
    [freq.data]
  );
  const clusterInsights = useMemo(
    () => deriveClusterInsights({ rows: clusters.data ?? [] }),
    [clusters.data]
  );

  const legacyTop = (freq.data ?? []).slice(0, 5);

  // --- Engine-derived "top" + "clusters" view ---
  const engineTop = useMemo(() => {
    if (topPatternsRaw.length > 0) {
      return topPatternsRaw.slice(0, 5).map((p) => ({
        key: p.id ?? `${p.type ?? "pattern"}-${p.description ?? ""}`,
        title: p.description ?? "Pattern",
        summary: `Showing up often — seen ${p.frequency ?? 0} time${(p.frequency ?? 0) === 1 ? "" : "s"} recently.`,
      }));
    }
    const combined = [...emotionalPatterns, ...behavioralPatterns]
      .slice()
      .sort((a, b) => (b.frequency ?? 0) - (a.frequency ?? 0))
      .slice(0, 5);
    return combined.map((p) => {
      return {
        key: p.id,
        title: p.description,
        summary: `Showing up often — seen ${p.frequency ?? 0} time${(p.frequency ?? 0) === 1 ? "" : "s"} recently.`,
      };
    });
  }, [topPatternsRaw, emotionalPatterns, behavioralPatterns, confidenceScores]);

  const engineClusters = useMemo(() => {
    // Engine maps "clusters" slot to emotional loops, enriched with triggers
    // and signatures. Same UI component, same slot.
    return loops.slice(0, 6).map((l) => {
      const related = [
        ...(l.triggerTypes ?? []),
        ...(l.dominantEmotions ?? []),
      ].filter(Boolean);
      const examples = [
        ...(l.typicalBehaviors ?? []),
        ...(l.typicalConsequences ?? []),
      ].filter(Boolean);
      return {
        key: l.id,
        name: (l.dominantEmotions?.[0] ?? l.triggerTypes?.[0] ?? "Loop"),
        cohesion: l.confidenceScore ?? 0,
        related,
        examples,
      };
    });
  }, [loops]);

  // Patterns-worth-noticing block: feed engine signals when in engine mode.
  const engineDerivedInsights = useMemo(() => {
    if (!useEngine) return [];
    const out: Array<{ id: string; title: string; body: string; confidence: "low" | "medium" | "high"; tags: string[]; source: string }> = [];
    triggers.slice(0, 3).forEach((t) =>
      out.push({
        id: `trigger-${t.id}`,
        title: `When this tends to come up: ${t.label}`,
        body: `You've noticed this around you ${t.frequency ?? 0} time${(t.frequency ?? 0) === 1 ? "" : "s"} lately.`,
        confidence: (t.confidenceScore ?? 0) >= 0.7 ? "high" : (t.confidenceScore ?? 0) >= 0.4 ? "medium" : "low",
        tags: ["trigger"],
        source: "engine",
      })
    );
    emotionalSignatures.slice(0, 3).forEach((s) =>
      out.push({
        id: `signature-${s.id}`,
        title: `A feeling that keeps surfacing: ${s.label}`,
        body: `Mostly showing up as: ${(s.dominantEmotions ?? []).join(", ") || "something hard to name yet"}.`,
        confidence: (s.confidenceScore ?? 0) >= 0.7 ? "high" : (s.confidenceScore ?? 0) >= 0.4 ? "medium" : "low",
        tags: ["signature"],
        source: "engine",
      })
    );
    patternEvolution.slice(0, 3).forEach((e, i) =>
      out.push({
        id: `evolution-${i}`,
        title: `What's been shifting: ${e.what}`,
        body: `Lately, this seems to be ${e.direction}.`,
        confidence: (e.confidenceScore ?? 0) >= 0.7 ? "high" : (e.confidenceScore ?? 0) >= 0.4 ? "medium" : "low",
        tags: ["evolution"],
        source: "engine",
      })
    );
    return out;
  }, [useEngine, triggers, emotionalSignatures, patternEvolution]);

  return (
    <section id="patterns" aria-labelledby="patterns-heading">
      <CalmSurface padding="24" radius="lg" shadow="sm">
        <header style={{ marginBottom: "var(--calm-space-16)" }}>
          <CalmText size="xs" soft style={{ textTransform: "uppercase", letterSpacing: "0.18em" }}>
            Patterns you tend to fall into
          </CalmText>
          <CalmSectionHeader id="patterns-heading" style={{ marginTop: "var(--calm-space-8)" }}>
            The quiet shapes that keep coming back
          </CalmSectionHeader>
          <QuietLead>
            What you tend to do, when it shows up, and how it tends to affect you.
          </QuietLead>
        </header>

        {engineLoading ? (
          <p className="text-sm text-muted-foreground" style={{ marginTop: "var(--calm-space-16)" }}>
            Loading…
          </p>
        ) : engineError ? (
          <p className="text-sm text-muted-foreground" style={{ marginTop: "var(--calm-space-16)" }}>
            Something went wrong — showing your saved version instead.
          </p>
        ) : null}

        <div style={{ marginTop: "var(--calm-space-24)" }} className="space-y-10">
          <div>
            <h3 className="mb-3 text-xs uppercase tracking-[0.18em] text-muted-foreground/80">
              What you tend to do
            </h3>
            {useEngine ? (
              engineTop.length === 0 ? (
                <EmptyState headline="Once you've had a few conversations, I'll start noticing what keeps coming back for you." />
              ) : (
                <div className="space-y-2">
                  {engineTop.map((r) => (
                    <PatternCard key={r.key} title={r.title} summary={r.summary} />
                  ))}
                </div>
              )
            ) : legacyTop.length === 0 ? (
              <EmptyState headline="Once you've had a few conversations, I'll start noticing what keeps coming back for you." />
            ) : (
              <div className="space-y-2">
                {legacyTop.map((r) => (
                  <PatternCard
                    key={`${r.pattern_type}-${r.pattern_label}`}
                    title={r.pattern_label}
                    summary={`Showing up often — seen ${r.raw_count} time${r.raw_count === 1 ? "" : "s"} recently.`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Heat map (Energy Map) removed in structural cleanup. */}

          <div>
            <h3 className="mb-3 text-xs uppercase tracking-[0.18em] text-muted-foreground/80">
              Themes you keep coming back to
            </h3>
            {useEngine ? (
              engineClusters.length === 0 ? (
                <EmptyState headline="No clear themes yet — give it a little more time and they'll start to take shape." />
              ) : (
                <div className="grid gap-4 sm:grid-cols-2">
                  {engineClusters.map((c) => (
                    <PatternClusterCard
                      key={c.key}
                      name={c.name}
                      cohesion={c.cohesion}
                      related={c.related}
                      examples={c.examples}
                    />
                  ))}
                </div>
              )
            ) : clusters.isLoading ? (
              <CalmCard><p className="text-sm text-muted-foreground">Loading…</p></CalmCard>
            ) : (clusters.data ?? []).length === 0 ? (
              <EmptyState headline="No clear themes yet — give it a little more time and they'll start to take shape." />
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                {clusters.data!.map((c) => (
                  <PatternClusterCard
                    key={c.id}
                    name={c.cluster_label}
                    cohesion={c.cohesion_score}
                    related={(c.member_pattern_ids ?? [])
                      .map((id) => labelById.get(id) ?? "—")
                      .filter((s) => s !== "—")}
                    examples={c.cluster_summary ? [c.cluster_summary] : []}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        <InsightNarrativeBlock title="Why this matters for you">
          <InsightList
            insights={useEngine ? (engineDerivedInsights as never) : [...freqInsights, ...clusterInsights]}
            emptyLabel="Nothing big to point to yet — and that's okay."
          />
        </InsightNarrativeBlock>

        <div style={{ marginTop: "var(--calm-space-32)" }} className="flex flex-wrap gap-3 text-xs text-muted-foreground/80">
          <Link to="/insights" className="underline-offset-4 hover:underline">See today's read →</Link>
          <Link to="/insights" className="underline-offset-4 hover:underline">A closer look at your themes →</Link>
        </div>
      </CalmSurface>
    </section>
  );
}
