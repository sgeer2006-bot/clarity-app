/**
 * Mind Today — concise read of what's currently surfacing.
 * Reuses Phase-2 pattern hooks and the existing weekly-digest insight engine.
 * No engine logic is duplicated here.
 */
import { useMemo } from "react";
import { CalmCard } from "@/components/patterns/CalmPrimitives";
import { CalmSurface, QuietLead } from "@/components/calm/CalmPrimitives";
import { CalmSectionHeader } from "@/components/calm/CalmSectionHeader";
import { CalmText } from "@/components/calm/CalmText";
import { InsightNarrativeBlock, InsightList } from "@/components/patterns/insights";
import { IdentityChips } from "@/components/identity/IdentityChips";
import { MicroContinuation } from "@/components/habit/MicroContinuation";
import {
  useFrequency,
  useIdentity,
  useMacroPatterns,
  useTimeline,
  useClusters,
} from "@/hooks/usePatternData";
import { buildWeeklyDigest } from "@/lib/insights";

export function MindTodaySection() {
  const freq = useFrequency();
  const identity = useIdentity();
  const macros = useMacroPatterns();
  const timeline = useTimeline();
  const clusters = useClusters();

  const ctx = useMemo(
    () => ({
      frequency: freq.data ?? [],
      timeline: timeline.data ?? [],
      clusters: clusters.data ?? [],
      identity: identity.data ?? null,
    }),
    [freq.data, timeline.data, clusters.data, identity.data]
  );
  const digest = useMemo(() => buildWeeklyDigest(ctx, new Date()), [ctx]);

  const macroCount = macros.data?.length ?? 0;
  const activeLoops = (freq.data ?? []).filter((f) => f.pattern_type === "emotional_loop").length;
  const dominantTheme = (freq.data ?? [])[0]?.pattern_label ?? null;
  const recentEvent = timeline.data?.[0]?.short_label ?? null;
  

  const summaryCards = [
    { label: "Patterns tracked", value: String(macroCount) },
    { label: "Active loops", value: String(activeLoops) },
    { label: "Dominant theme", value: dominantTheme ?? "—" },
    { label: "Recent shift", value: recentEvent ?? "—" },
  ];

  return (
    <section id="mind-today" aria-labelledby="mind-today-heading">
      <CalmSurface padding="24" radius="lg" shadow="sm">
        <header style={{ marginBottom: "var(--calm-space-16)" }}>
          <CalmText size="xs" soft style={{ textTransform: "uppercase", letterSpacing: "0.18em" }}>
            Mind today
          </CalmText>
          <CalmSectionHeader id="mind-today-heading" style={{ marginTop: "var(--calm-space-8)" }}>
            A quiet read of where you are
          </CalmSectionHeader>
          <QuietLead>What's currently surfacing across your reflections.</QuietLead>
        </header>

        <div style={{ marginTop: "var(--calm-space-24)" }} className="grid gap-4 sm:grid-cols-2">
          <IdentityChips />
          <MicroContinuation ctx={{ lastActionType: "insight_viewed" }} />
        </div>

        <div style={{ marginTop: "var(--calm-space-32)" }} className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {summaryCards.map((c) => (
            <CalmCard key={c.label} className="p-4">
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground/70">{c.label}</p>
              <p className="mt-2 truncate text-base font-medium text-foreground/90">{c.value}</p>
            </CalmCard>
          ))}
        </div>

        <InsightNarrativeBlock title="This week" narrative={`${digest.summary}\n\n${digest.trendShift}`}>
          <InsightList insights={digest.insights} emptyLabel="No weekly observations yet." />
        </InsightNarrativeBlock>
      </CalmSurface>
    </section>
  );
}
