/**
 * Tools — quick links to the reflective surfaces (Reflect, Composer,
 * Two-Person, Folders, Safety). Reuses existing routes; no logic moved.
 */
import { Link } from "react-router-dom";
import { CalmCard } from "@/components/patterns/CalmPrimitives";
import { CalmSurface, QuietLead } from "@/components/calm/CalmPrimitives";
import { CalmSectionHeader } from "@/components/calm/CalmSectionHeader";
import { CalmText } from "@/components/calm/CalmText";

const TOOLS: { to: string; title: string; blurb: string }[] = [
  { to: "/reflect", title: "Your Thoughts", blurb: "Start or resume a reflection." },
  { to: "/compose", title: "Composer", blurb: "Draft, soften, or rewrite a message." },
  { to: "/you/timeline", title: "Timeline", blurb: "Browse past sessions and snapshots." },
  { to: "/shared", title: "Shared Clarity", blurb: "Reflect together, privately." },
  { to: "/safety/resources", title: "Grounding", blurb: "Soft resources if things feel heavy." },
];

export function ToolsSection() {
  return (
    <section id="tools" aria-labelledby="tools-heading">
      <CalmSurface padding="24" radius="lg" shadow="sm">
        <header style={{ marginBottom: "var(--calm-space-16)" }}>
          <CalmText size="xs" soft style={{ textTransform: "uppercase", letterSpacing: "0.18em" }}>
            Helpful Tools
          </CalmText>
          <CalmSectionHeader id="tools-heading" style={{ marginTop: "var(--calm-space-8)" }}>
            What you can do from here
          </CalmSectionHeader>
          <QuietLead>Gentle surfaces for reflection, drafting, and grounding.</QuietLead>
        </header>
        <div style={{ marginTop: "var(--calm-space-24)" }} className="grid gap-3 sm:grid-cols-2">
          {TOOLS.map((t) => (
            <Link key={t.to} to={t.to} className="block">
              <CalmCard className="p-4 transition-colors hover:bg-card/60">
                <p className="text-base font-medium text-foreground/90">{t.title}</p>
                <p className="mt-1 text-sm text-muted-foreground">{t.blurb}</p>
              </CalmCard>
            </Link>
          ))}
        </div>
      </CalmSurface>
    </section>
  );
}
