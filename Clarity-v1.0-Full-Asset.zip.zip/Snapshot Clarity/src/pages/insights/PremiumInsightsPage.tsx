/**
 * PremiumInsightsPage — UI-only surface that consumes:
 *   - ProfileInsightsEngine (Module #10): generateInsights
 *   - ClarityPlusGating (Module #12): getClarityPlusGating
 *   - ProfileAwareFraming (Module #11): getProfileAwareFraming
 *
 * No engine changes, no logic changes, no new data fetching, no mutations,
 * no analytics, no navigation. Mounts at the existing /insights route.
 */
import { useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { AppShell } from "@/components/layout/AppShell";
import { useAuthSession } from "@/hooks/useAuthSession";
import {
  generateInsights,
  type PsychologicalProfileLike,
  type ProfileEntryLike,
  type SnapshotLike,
} from "@/lib/insights/ProfileInsightsEngine";
import { getClarityPlusGating } from "@/lib/premium/ClarityPlusGating";
import { getProfileAwareFraming } from "@/lib/insights/ProfileAwareFraming";
import { TopInsightCard } from "@/components/insights/TopInsightCard";
import { IdentityInsightsSection } from "@/components/insights/IdentityInsightsSection";
import { SituationInsightsSection } from "@/components/insights/SituationInsightsSection";
import { TrendInsightsSection } from "@/components/insights/TrendInsightsSection";
import { UpgradePromptCard } from "@/components/insights/UpgradePromptCard";
import { getInsightsPageEngineData } from "@/lib/analyticalEngine/dataAdapter";

const EMPTY_PROFILE: PsychologicalProfileLike = {};
const EMPTY_SNAPSHOTS: SnapshotLike[] = [];

function confidenceBand(score: number | undefined): "emerging" | "recurring" | "consistent" {
  const s = typeof score === "number" ? score : 0;
  if (s >= 0.7) return "consistent";
  if (s >= 0.4) return "recurring";
  return "emerging";
}

export default function PremiumInsightsPage() {
  // Read user via the existing auth pattern (read-only).
  const { session } = useAuthSession();
  const user = session?.user ?? null;
  const userId = user?.id ?? "";

  // Engine-backed inputs. We default to empty placeholders (legacy behavior)
  // and replace with mapped engine output when the adapter resolves with
  // non-empty data. Any error or empty result keeps the placeholder path.
  const [profile, setProfile] = useState<PsychologicalProfileLike>(EMPTY_PROFILE);
  const [recentSnapshots, setRecentSnapshots] = useState<SnapshotLike[]>(EMPTY_SNAPSHOTS);
  const [engineLoading, setEngineLoading] = useState(false);
  const [engineError, setEngineError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    if (!userId) {
      setProfile(EMPTY_PROFILE);
      setRecentSnapshots(EMPTY_SNAPSHOTS);
      return () => { cancelled = true; };
    }
    setEngineLoading(true);
    setEngineError(false);
    (async () => {
      try {
        const data = await getInsightsPageEngineData(userId);
        if (cancelled || !data) return;

        const coreThemes = data.coreThemes ?? [];
        const identitySignals = data.identitySignals ?? [];
        const weeklyShifts = data.weekOverWeekShifts ?? [];
        const highConfidencePatterns = data.highConfidencePatterns ?? [];
        // emotionalLoops is not part of InsightsPageData in v1; read
        // defensively if the adapter ever surfaces it.
        const emotionalLoops = ((data as unknown) as { emotionalLoops?: Array<{ triggerTypes?: string[]; dominantEmotions?: string[]; typicalBehaviors?: string[]; confidenceScore?: number }> }).emotionalLoops ?? [];

        const allEmpty =
          coreThemes.length === 0 &&
          identitySignals.length === 0 &&
          weeklyShifts.length === 0 &&
          highConfidencePatterns.length === 0 &&
          emotionalLoops.length === 0;

        if (allEmpty) {
          setProfile(EMPTY_PROFILE);
          setRecentSnapshots(EMPTY_SNAPSHOTS);
          return;
        }

        // Map engine output into the legacy profile/snapshot input shapes
        // consumed by generateInsights. Same UI slots; no structural change.
        const emotionalEntries: ProfileEntryLike[] = [
          ...coreThemes.map((t) => ({
            key: t.id,
            label: t.title,
            confidence: confidenceBand(t.confidenceScore),
            notes: t.description ? [t.description] : [],
          })),
          ...highConfidencePatterns
            .filter((p) => p.type === "emotional")
            .map((p) => ({
              key: p.id,
              label: p.description,
              confidence: confidenceBand(p.confidenceScore),
            })),
        ];

        const behaviorEntries: ProfileEntryLike[] = highConfidencePatterns
          .filter((p) => p.type === "behavioral")
          .map((p) => ({
            key: p.id,
            label: p.description,
            confidence: confidenceBand(p.confidenceScore),
          }));

        const selfNarrativeEntries: ProfileEntryLike[] = identitySignals.map((s) => ({
          key: s.id,
          label: s.label,
          confidence: confidenceBand(s.confidenceScore),
        }));

        const mappedProfile: PsychologicalProfileLike = {
          emotionalPatterns: emotionalEntries,
          behaviorPatterns: behaviorEntries,
          selfNarrativeThemes: selfNarrativeEntries,
        };

        const observations = [
          ...weeklyShifts.map((w) => `${w.what} is ${w.direction}`),
          ...emotionalLoops.map((l) =>
            `${(l.triggerTypes ?? []).join(", ")} → ${(l.dominantEmotions ?? []).join(", ")}`,
          ),
        ].filter(Boolean);

        const themes = coreThemes.map((t) => t.title);
        const patterns = highConfidencePatterns.map((p) => p.description);

        const snapshot: SnapshotLike = {
          observations,
          themes,
          patterns,
          createdAt: new Date().toISOString(),
        };

        setProfile(mappedProfile);
        setRecentSnapshots([snapshot]);
      } catch (err) {
        // Fall back to legacy placeholder behavior on any error.
        console.warn("[PremiumInsightsPage] engine fetch failed; using placeholders", err);
        if (!cancelled) {
          setProfile(EMPTY_PROFILE);
          setRecentSnapshots(EMPTY_SNAPSHOTS);
          setEngineError(true);
        }
      } finally {
        if (!cancelled) setEngineLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [userId]);

  const gating = useMemo(() => getClarityPlusGating(user), [user]);
  const insights = useMemo(
    () => generateInsights(profile, recentSnapshots),
    [profile, recentSnapshots],
  );
  const framing = useMemo(
    () => getProfileAwareFraming(profile, insights),
    [profile, insights],
  );

  return (
    <>
      <Helmet>
        <title>Today's read — Clarity</title>
        <meta
          name="description"
          content="A warm, human read of what's showing up for you today."
        />
        <link rel="canonical" href="/insights" />
      </Helmet>

      <AppShell width="content">
        <div className="mx-auto w-full max-w-3xl">
          <header className="mx-auto w-full max-w-2xl px-4 pt-10">
            <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
              What's showing up for you
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              A gentle read of what's been on your mind, and what seems to be shifting lately.
            </p>
          </header>

          {engineLoading ? (
            <p className="mx-auto w-full max-w-2xl px-4 pt-6 text-center text-sm leading-relaxed text-muted-foreground">
              Loading…
            </p>
          ) : engineError ? (
            <p className="mx-auto w-full max-w-2xl px-4 pt-6 text-center text-sm leading-relaxed text-muted-foreground">
              Something went wrong — showing your saved version instead.
            </p>
          ) : framing.framing ? (
            <p className="mx-auto w-full max-w-2xl px-4 pt-6 text-center text-sm leading-relaxed text-muted-foreground">
              {framing.framing.text}
            </p>
          ) : null}

          <TopInsightCard
            topInsight={insights.topInsight}
            blurInsights={gating.blurInsights}
          />

          <IdentityInsightsSection
            identityInsights={insights.identityInsights}
            blurInsights={gating.blurInsights}
          />

          <SituationInsightsSection
            situationInsights={insights.situationInsights}
            blurInsights={gating.blurInsights}
          />

          <TrendInsightsSection
            trendInsights={insights.trendInsights}
            showTrends={gating.showTrends}
            upgradePrompt={gating.upgradePrompt}
          />

          <UpgradePromptCard upgradePrompt={gating.upgradePrompt} />

          <div className="mx-auto mt-8 w-full max-w-2xl px-4">
            <a
              href="/patterns"
              className="block rounded-lg border border-border/60 bg-card/40 p-4 transition-colors hover:bg-card/60"
            >
              <div className="text-sm font-medium text-foreground">Patterns you tend to fall into</div>
              <p className="mt-1 text-sm text-muted-foreground">
                The quiet shapes that keep coming back — and what they tend to mean for you.
              </p>
            </a>
          </div>
        </div>
      </AppShell>
    </>
  );
}
