import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Folder, FolderOpen, Inbox, Plus, MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { MicroContinuation } from "@/components/habit/MicroContinuation";
import { IdentityChips } from "@/components/identity/IdentityChips";
import { recordEvent } from "@/lib/identity";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface Snapshot {
  id: string;
  title: string;
  created_at: string;
  folder_id: string | null;
}

interface FolderRow {
  id: string;
  name: string;
}

const STARTER_FOLDERS = ["Work", "Family", "Roommates", "Money", "Friends", "Health"];
const UNCATEGORIZED = "__uncat__" as const;
type SelectedFolder = string | typeof UNCATEGORIZED | "all";

function formatTs(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

const History = () => {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [folders, setFolders] = useState<FolderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<SelectedFolder>("all");
  const [newFolderName, setNewFolderName] = useState("");
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [deleteFolderId, setDeleteFolderId] = useState<string | null>(null);
  const [deleteSnapshotId, setDeleteSnapshotId] = useState<string | null>(null);

  useEffect(() => {
    document.title = "Timeline — Clarity";
    (async () => {
      const { data: sess } = await supabase.auth.getSession();
      if (!sess.session) {
        navigate("/auth");
        return;
      }
      setUserId(sess.session.user.id);
      await Promise.all([loadSnapshots(), loadFolders(sess.session.user.id)]);
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigate]);

  const loadSnapshots = async () => {
    const { data } = await supabase
      .from("reflection_sessions")
      .select("id, title, created_at, folder_id")
      .eq("status", "complete")
      .is("deleted_at", null)
      .order("created_at", { ascending: false });
    setSnapshots((data as Snapshot[]) || []);
  };

  const loadFolders = async (uid: string) => {
    const { data } = await supabase
      .from("folders")
      .select("id, name")
      .eq("user_id", uid)
      .order("name", { ascending: true });
    setFolders((data as FolderRow[]) || []);
  };

  const folderCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    let uncat = 0;
    for (const s of snapshots) {
      if (!s.folder_id) uncat++;
      else counts[s.folder_id] = (counts[s.folder_id] || 0) + 1;
    }
    return { counts, uncat, total: snapshots.length };
  }, [snapshots]);

  const visibleSnapshots = useMemo(() => {
    if (selected === "all") return snapshots;
    if (selected === UNCATEGORIZED) return snapshots.filter((s) => !s.folder_id);
    return snapshots.filter((s) => s.folder_id === selected);
  }, [snapshots, selected]);

  const createFolder = async (name: string) => {
    if (!userId) return;
    const trimmed = name.trim();
    if (!trimmed) return;
    // Prevent duplicates client-side (DB has a unique index too).
    if (folders.some((f) => f.name.toLowerCase() === trimmed.toLowerCase())) {
      toast({ title: "That folder already exists" });
      return;
    }
    const { data, error } = await supabase
      .from("folders")
      .insert({ user_id: userId, name: trimmed })
      .select("id, name")
      .maybeSingle();
    if (error || !data) {
      toast({
        title: "Could not create folder",
        description: error?.message,
        variant: "destructive",
      });
      return;
    }
    setFolders((prev) => [...prev, data].sort((a, b) => a.name.localeCompare(b.name)));
    setNewFolderName("");
    setShowNewFolder(false);
    setSelected(data.id);
  };

  const moveSnapshot = async (snapshotId: string, folderId: string | null) => {
    const { error } = await supabase
      .from("reflection_sessions")
      .update({ folder_id: folderId })
      .eq("id", snapshotId);
    if (error) {
      toast({
        title: "Could not move snapshot",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    setSnapshots((prev) =>
      prev.map((s) => (s.id === snapshotId ? { ...s, folder_id: folderId } : s)),
    );
  };

  const renameFolder = async (id: string, name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const { error } = await supabase
      .from("folders")
      .update({ name: trimmed })
      .eq("id", id);
    if (error) {
      toast({
        title: "Could not rename",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    setFolders((prev) =>
      prev
        .map((f) => (f.id === id ? { ...f, name: trimmed } : f))
        .sort((a, b) => a.name.localeCompare(b.name)),
    );
    setRenamingId(null);
    setRenameValue("");
  };

  const deleteFolder = async (id: string, moveToUncategorized: boolean) => {
    if (!moveToUncategorized) {
      // Soft-delete the snapshots in this folder (same pattern as the rest of the app).
      const ids = snapshots.filter((s) => s.folder_id === id).map((s) => s.id);
      if (ids.length > 0) {
        await supabase
          .from("reflection_sessions")
          .update({ deleted_at: new Date().toISOString() })
          .in("id", ids);
      }
    }
    // Deleting the folder cascades folder_id -> NULL on remaining snapshots
    // (per the foreign-key ON DELETE SET NULL).
    const { error } = await supabase.from("folders").delete().eq("id", id);
    if (error) {
      toast({
        title: "Could not delete folder",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    setFolders((prev) => prev.filter((f) => f.id !== id));
    if (selected === id) setSelected("all");
    setDeleteFolderId(null);
    await loadSnapshots();
  };

  const deleteSnapshot = async (id: string) => {
    const { error } = await supabase
      .from("reflection_sessions")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", id);
    if (error) {
      toast({
        title: "Could not delete",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    setSnapshots((prev) => prev.filter((s) => s.id !== id));
    setDeleteSnapshotId(null);
  };

  const folderToDelete = folders.find((f) => f.id === deleteFolderId);
  const snapshotToDelete = snapshots.find((s) => s.id === deleteSnapshotId);
  const starterChips = STARTER_FOLDERS.filter(
    (s) => !folders.some((f) => f.name.toLowerCase() === s.toLowerCase()),
  );

  return (
    <>
      <TopBar />
      <MicroCalm>
      <main className="mx-auto max-w-content space-y-6 px-4 py-12">
        <header>
          <h1 className="text-2xl font-semibold tracking-tight">Timeline</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Your past conversations, organized with meaning.
          </p>
        </header>
        <div className="grid gap-4 sm:grid-cols-2">
          <IdentityChips />
          <MicroContinuation
            ctx={{ lastActionType: snapshots.length > 0 ? "snapshot_saved" : "idle" }}
          />
        </div>

        {loading ? (
          <p className="text-sm text-muted-foreground">Loading…</p>
        ) : snapshots.length === 0 && folders.length === 0 ? (
          <div className="rounded-xl border border-border bg-card p-8 text-center">
            <p className="text-base">Your timeline will grow as you reflect.</p>
            <Link
              to="/reflect"
              className="mt-4 inline-block text-sm text-accent hover:underline"
            >
              Start your first conversation
            </Link>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-[240px_1fr]">
            {/* Folder rail */}
            <aside className="space-y-3">
              <nav className="rounded-xl border border-border bg-card p-2">
                <FolderRailItem
                  icon={<Inbox className="h-4 w-4" />}
                  label="All"
                  count={folderCounts.total}
                  active={selected === "all"}
                  onClick={() => setSelected("all")}
                />
                <FolderRailItem
                  icon={<Folder className="h-4 w-4" />}
                  label="Uncategorized"
                  count={folderCounts.uncat}
                  active={selected === UNCATEGORIZED}
                  onClick={() => setSelected(UNCATEGORIZED)}
                />
                {folders.length > 0 && (
                  <div className="my-2 border-t border-border" />
                )}
                {folders.map((f) => (
                  <div key={f.id} className="group relative">
                    {renamingId === f.id ? (
                      <div className="flex items-center gap-1 px-2 py-1.5">
                        <Input
                          autoFocus
                          value={renameValue}
                          onChange={(e) => setRenameValue(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") renameFolder(f.id, renameValue);
                            if (e.key === "Escape") {
                              setRenamingId(null);
                              setRenameValue("");
                            }
                          }}
                          className="h-7 text-sm"
                        />
                      </div>
                    ) : (
                      <FolderRailItem
                        icon={
                          selected === f.id ? (
                            <FolderOpen className="h-4 w-4" />
                          ) : (
                            <Folder className="h-4 w-4" />
                          )
                        }
                        label={f.name}
                        count={folderCounts.counts[f.id] || 0}
                        active={selected === f.id}
                        onClick={() => setSelected(f.id)}
                        rightSlot={
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <button
                                onClick={(e) => e.stopPropagation()}
                                className="rounded p-1 opacity-0 hover:bg-muted group-hover:opacity-100"
                                aria-label={`Folder options for ${f.name}`}
                              >
                                <MoreHorizontal className="h-3.5 w-3.5" />
                              </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setRenamingId(f.id);
                                  setRenameValue(f.name);
                                }}
                              >
                                <Pencil className="mr-2 h-3.5 w-3.5" />
                                Rename
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-destructive focus:text-destructive"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setDeleteFolderId(f.id);
                                }}
                              >
                                <Trash2 className="mr-2 h-3.5 w-3.5" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        }
                      />
                    )}
                  </div>
                ))}
              </nav>

              {/* New folder controls */}
              <div className="rounded-xl border border-border bg-card p-3">
                {showNewFolder ? (
                  <div className="space-y-2">
                    <Input
                      autoFocus
                      value={newFolderName}
                      onChange={(e) => setNewFolderName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") createFolder(newFolderName);
                        if (e.key === "Escape") {
                          setShowNewFolder(false);
                          setNewFolderName("");
                        }
                      }}
                      placeholder="Folder name"
                      className="h-8 text-sm"
                    />
                    <div className="flex justify-end gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setShowNewFolder(false);
                          setNewFolderName("");
                        }}
                      >
                        Cancel
                      </Button>
                      <Button size="sm" onClick={() => createFolder(newFolderName)}>
                        Create
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => setShowNewFolder(true)}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    New folder
                  </Button>
                )}
                {starterChips.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {starterChips.map((s) => (
                      <button
                        key={s}
                        onClick={() => createFolder(s)}
                        className="rounded-full border border-border px-2 py-0.5 text-xs text-muted-foreground hover:bg-muted hover:text-foreground"
                      >
                        + {s}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </aside>

            {/* Snapshot list */}
            <section>
              {visibleSnapshots.length === 0 ? (
                <div className="rounded-xl border border-border bg-card p-8 text-center text-sm text-muted-foreground">
                  No snapshots in this folder yet.
                </div>
              ) : (
                <ul className="divide-y divide-border rounded-xl border border-border bg-card">
                  {visibleSnapshots.map((s) => (
                    <li key={s.id} className="flex items-center gap-2 px-3 py-2">
                      <Link
                        to={`/snapshot/${s.id}`}
                        onClick={() =>
                          recordEvent({
                            source: "snapshot",
                            tags: { cognitive: ["revisit"] },
                          })
                        }
                        className="flex flex-1 items-center justify-between rounded px-2 py-2 hover:bg-muted/50"
                      >
                        <span className="truncate pr-4 text-base">{s.title}</span>
                        <span className="shrink-0 text-sm text-muted-foreground">
                          {formatTs(s.created_at)}
                        </span>
                      </Link>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button
                            className="rounded p-1 hover:bg-muted"
                            aria-label="Snapshot options"
                          >
                            <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel className="text-xs">Move to</DropdownMenuLabel>
                          <DropdownMenuItem
                            onClick={() => moveSnapshot(s.id, null)}
                            disabled={!s.folder_id}
                          >
                            <Folder className="mr-2 h-3.5 w-3.5" />
                            Uncategorized
                          </DropdownMenuItem>
                          {folders.map((f) => (
                            <DropdownMenuItem
                              key={f.id}
                              onClick={() => moveSnapshot(s.id, f.id)}
                              disabled={s.folder_id === f.id}
                            >
                              <Folder className="mr-2 h-3.5 w-3.5" />
                              {f.name}
                            </DropdownMenuItem>
                          ))}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => setDeleteSnapshotId(s.id)}
                          >
                            <Trash2 className="mr-2 h-3.5 w-3.5" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </div>
        )}
      </main>
      </MicroCalm>

      {/* Delete folder confirm */}
      <AlertDialog
        open={!!deleteFolderId}
        onOpenChange={(o) => !o && setDeleteFolderId(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete "{folderToDelete?.name}"?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Move snapshots in this folder to Uncategorized, or delete them too?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col gap-2 sm:flex-row">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <Button
              variant="outline"
              onClick={() => deleteFolderId && deleteFolder(deleteFolderId, true)}
            >
              Move to Uncategorized
            </Button>
            <AlertDialogAction
              onClick={() => deleteFolderId && deleteFolder(deleteFolderId, false)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete snapshots too
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete snapshot confirm */}
      <AlertDialog
        open={!!deleteSnapshotId}
        onOpenChange={(o) => !o && setDeleteSnapshotId(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this snapshot?</AlertDialogTitle>
            <AlertDialogDescription>
              "{snapshotToDelete?.title}" will be removed. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteSnapshotId && deleteSnapshot(deleteSnapshotId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

interface RailItemProps {
  icon: React.ReactNode;
  label: string;
  count: number;
  active: boolean;
  onClick: () => void;
  rightSlot?: React.ReactNode;
}

const FolderRailItem = ({
  icon,
  label,
  count,
  active,
  onClick,
  rightSlot,
}: RailItemProps) => (
  <button
    onClick={onClick}
    className={`flex w-full items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-left text-sm transition-colors ${
      active
        ? "bg-muted font-medium text-foreground"
        : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"
    }`}
  >
    <span className="flex min-w-0 items-center gap-2">
      {icon}
      <span className="truncate">{label}</span>
    </span>
    <span className="flex shrink-0 items-center gap-1">
      <span className="text-xs text-muted-foreground">{count}</span>
      {rightSlot}
    </span>
  </button>
);

export default History;
