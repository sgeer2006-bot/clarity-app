import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Sparkles, ExternalLink } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { usePremiumStatus } from "@/hooks/usePremiumStatus";
import { supabase } from "@/integrations/supabase/client";
import { getStripeEnvironment } from "@/lib/stripe/loadStripe";
import { toast } from "@/hooks/use-toast";
import {
  getPricing,
  getTierDescriptions,
} from "@/lib/premium/SubscriptionEngine";

/**
 * Clarity+ — pricing page (renamed surface, same /billing route).
 *
 * Static page chrome owned by Module 19. Tier titles and pricing values
 * are sourced from SubscriptionEngine (Module #14). The feature lists
 * below are the page-chrome lists owned by this module and intentionally
 * differ from the engine's locked-in bulletPointFeatures.
 */

const FREE_FEATURES = [
  "3 conversations/day",
  "Limited insights",
  "Limited timeline",
  "No premium patterns",
  "No deep identity modeling",
];

const BASIC_FEATURES = [
  "Unlimited conversations",
  "Full timeline",
  "Full history",
  "Full folders",
  "Basic weekly digest",
  "Basic analytics",
  "Access to Fast Clarity",
  "Access to Shared Clarity",
];

const PREMIUM_FEATURES = [
  "Everything in Basic",
  "Deep identity modeling",
  "Deep narrative summaries",
  "Week-over-week trend shifts",
  "Cluster intelligence",
  "Emotional loop detection",
  "Situational pattern detection",
  "Continuation engine",
  "Premium calm layer",
  "Premium visual themes",
  "Premium onboarding",
  "Premium insights page",
  "Premium digest",
  "Premium analytics dashboard",
  "Premium relationship insights",
];

function fmt(price: number) {
  return Number.isInteger(price) ? `$${price}` : `$${price.toFixed(2)}`;
}

export default function SettingsBillingPage() {
  const { isPremium } = usePremiumStatus();
  const [loadingPortal, setLoadingPortal] = useState(false);

  const pricing = getPricing();
  const tiers = getTierDescriptions();

  const openManage = async () => {
    setLoadingPortal(true);
    try {
      const { data, error } = await supabase.functions.invoke("clarity-plus-portal", {
        body: {
          environment: getStripeEnvironment(),
          returnUrl: `${window.location.origin}/billing`,
        },
      });
      if (error || !data?.url) throw new Error(error?.message ?? "Could not open portal");
      window.open(data.url as string, "_blank", "noopener,noreferrer");
    } catch (e: any) {
      toast({
        title: "We couldn't open your billing portal",
        description: e?.message ?? "Give it another try in a moment.",
        variant: "destructive",
      });
    } finally {
      setLoadingPortal(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Clarity+ — Clarity</title>
        <meta name="description" content="Built for people who want to understand themselves deeply." />
        <link rel="canonical" href="/billing" />
      </Helmet>
      <TopBar />
      <MicroCalm>
        <main className="mx-auto w-full max-w-3xl px-6 py-12">
          <header className="mb-8">
            <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
              Clarity+
            </h1>
            <p className="mt-2 text-base text-muted-foreground">
              Built for people who want to understand themselves deeply.
            </p>
          </header>

          <section className="mb-8 rounded-2xl border border-border/60 bg-card/40 p-5">
            <div className="flex items-start gap-3">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Sparkles className="h-4 w-4" aria-hidden />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-foreground/90">
                  Precision insights powered by your patterns.
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Your mind, decoded with clarity.
                </p>
                {isPremium ? (
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Button onClick={openManage} disabled={loadingPortal} className="h-10 rounded-full">
                      {loadingPortal ? "Opening your portal…" : "Manage subscription"}
                      <ExternalLink className="ml-1.5 h-3.5 w-3.5" aria-hidden />
                    </Button>
                  </div>
                ) : null}
              </div>
            </div>
          </section>

          <section className="grid gap-4 md:grid-cols-3">
            <TierCard
              title={tiers.free.title}
              label="Free"
              price="$0"
              per=""
              features={FREE_FEATURES}
            />
            <TierCard
              title={tiers.basic.title}
              label="Clarity+ Basic"
              price={`${fmt(pricing.basicMonthly)}`}
              per="/month"
              secondary={`or ${fmt(pricing.basicAnnual)}/year`}
              features={BASIC_FEATURES}
            />
            <TierCard
              title={tiers.premium.title}
              label="Clarity+ Premium"
              price={`${fmt(pricing.premiumMonthly)}`}
              per="/month"
              secondary={`or ${fmt(pricing.premiumAnnual)}/year`}
              features={PREMIUM_FEATURES}
              highlighted
            />
          </section>
        </main>
      </MicroCalm>
      
    </div>
  );
}

function TierCard({
  title,
  label,
  price,
  per,
  secondary,
  features,
  highlighted,
}: {
  title: string;
  label: string;
  price: string;
  per: string;
  secondary?: string;
  features: string[];
  highlighted?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl border p-5 ${
        highlighted ? "border-primary/50 bg-primary/5" : "border-border/60 bg-card/40"
      }`}
    >
      <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-2 text-base font-medium text-foreground/90">{title}</p>
      <p className="mt-3 text-2xl font-semibold tracking-tight text-foreground">
        {price}
        {per ? <span className="ml-1 text-sm font-normal text-muted-foreground">{per}</span> : null}
      </p>
      {secondary ? <p className="mt-0.5 text-xs text-muted-foreground">{secondary}</p> : null}
      <ul className="mt-4 space-y-1.5 text-sm text-foreground/85">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2">
            <span className="mt-1.5 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-primary/70" />
            <span>{f}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
