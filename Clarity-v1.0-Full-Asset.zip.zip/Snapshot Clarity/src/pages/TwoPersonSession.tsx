import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Check, Copy, Loader2, Sparkles, Users } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import {
  TwoPersonPerspectiveRow,
  TwoPersonSessionRow,
  generateCombinedInsight,
  getTwoPersonPerspectives,
  getTwoPersonSession,
  inviteUrl,
} from "@/lib/twoPerson";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { recordEvent } from "@/lib/identity";
import { MicroContinuation } from "@/components/habit/MicroContinuation";
import { IdentityChips } from "@/components/identity/IdentityChips";

const TwoPersonSession = () => {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  const [session, setSession] = useState<TwoPersonSessionRow | null>(null);
  const [perspectives, setPerspectives] = useState<TwoPersonPerspectiveRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    document.title = "Shared Clarity session — Clarity";
  }, []);

  const refresh = async () => {
    if (!sessionId) return;
    const [s, p] = await Promise.all([
      getTwoPersonSession(sessionId),
      getTwoPersonPerspectives(sessionId),
    ]);
    setSession(s);
    setPerspectives(p);
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) {
        navigate("/auth");
        return;
      }
      try {
        await refresh();
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId, navigate]);

  // Realtime: when invitee submits, refresh
  useEffect(() => {
    if (!sessionId) return;
    const channel = supabase
      .channel(`tp-${sessionId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "two_person_perspectives",
          filter: `session_id=eq.${sessionId}`,
        },
        () => refresh(),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId]);

  const owner = perspectives.find((p) => p.side === "owner");
  const invitee = perspectives.find((p) => p.side === "invitee");
  const bothIn = !!owner && !!invitee;
  const isComplete = session?.status === "complete" && !!session.combined_summary;

  const generate = async () => {
    if (!session) return;
    setGenerating(true);
    try {
      await generateCombinedInsight(session.id);
      await refresh();
      try {
        recordEvent({
          source: "manual",
          tags: { relational: ["two_person_combined_insight"] },
        });
      } catch { /* ignore */ }
      toast({ title: "Combined insight ready" });
    } catch (e) {
      console.error(e);
      toast({ title: "Couldn't generate insight", description: "Please try again." });
    } finally {
      setGenerating(false);
    }
  };

  const copyLink = () => {
    if (!session) return;
    navigator.clipboard.writeText(inviteUrl(session.invite_token));
    toast({ title: "Invite link copied" });
  };

  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <MicroCalm>
      <main className="mx-auto max-w-content px-4 py-8 sm:px-6 sm:py-12">
        <Link
          to="/shared"
          className="mb-6 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> All Shared Clarity sessions
        </Link>

        {loading ? (
          <div className="space-y-4">
            <Skeleton className="h-12 w-2/3 rounded-xl" />
            <Skeleton className="h-40 rounded-2xl" />
            <Skeleton className="h-40 rounded-2xl" />
          </div>
        ) : !session ? (
          <p className="rounded-xl border border-dashed border-border/70 bg-muted/30 p-6 text-center text-sm text-muted-foreground">
            Session not found.
          </p>
        ) : (
          <div className="space-y-6">
            <header className="space-y-2">
              <span className="label-eyebrow inline-flex items-center gap-1.5">
                <Users className="h-3 w-3" aria-hidden /> Shared Clarity
              </span>
              <h1 className="font-display text-3xl font-semibold tracking-tight">
                {session.topic}
              </h1>
            </header>

            {/* Invite */}
            {!isComplete && (
              <section className="rounded-2xl border border-border/70 bg-card/80 p-5 shadow-sm">
                <h2 className="font-display text-lg font-semibold">Invite the other person</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  They open this private link, write their own perspective, and submit. No account
                  needed.
                </p>
                <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                  <code className="flex-1 truncate rounded-lg border border-border bg-muted/40 px-3 py-2 text-xs">
                    {inviteUrl(session.invite_token)}
                  </code>
                  <Button onClick={copyLink} variant="secondary" className="rounded-full">
                    <Copy className="h-4 w-4" /> Copy link
                  </Button>
                </div>
                <ul className="mt-4 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2">
                  <li className="flex items-center gap-2">
                    <Check className={owner ? "h-4 w-4 text-primary" : "h-4 w-4 opacity-30"} />
                    Your perspective: {owner ? "received" : "missing"}
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className={invitee ? "h-4 w-4 text-primary" : "h-4 w-4 opacity-30"} />
                    Their perspective: {invitee ? "received" : "waiting"}
                  </li>
                </ul>
              </section>
            )}

            {/* Both perspectives, side by side (owner-only view) */}
            <section className="grid gap-4 md:grid-cols-2">
              <PerspectivePanel
                title={owner?.display_name?.trim() || "Your perspective"}
                text={owner?.perspective_text ?? null}
                rewrite={isComplete ? owner?.suggested_rewrite ?? null : null}
                emptyLabel="Your perspective is missing"
              />
              <PerspectivePanel
                title={invitee?.display_name?.trim() || "Their perspective"}
                text={invitee?.perspective_text ?? null}
                rewrite={isComplete ? invitee?.suggested_rewrite ?? null : null}
                emptyLabel="Waiting for their perspective"
              />
            </section>

            {/* Combine action / insight */}
            {bothIn && !isComplete && (
              <section className="rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 to-accent/10 p-5">
                <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h2 className="font-display text-lg font-semibold">Both sides are in</h2>
                    <p className="text-sm text-muted-foreground">
                      Generate a balanced combined insight and a kind opening message for each side.
                    </p>
                  </div>
                  <Button onClick={generate} disabled={generating} className="rounded-full">
                    {generating ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" /> Reading both sides…
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-4 w-4" /> Generate combined insight
                      </>
                    )}
                  </Button>
                </div>
              </section>
            )}

            {isComplete && session.combined_summary && (
              <section className="space-y-4 rounded-2xl border border-border/70 bg-card/80 p-5 shadow-sm">
                <div>
                  <h2 className="font-display text-lg font-semibold">Combined insight</h2>
                  <p className="mt-2 text-base leading-relaxed">{session.combined_summary}</p>
                </div>
                {session.shared_themes.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium">Shared themes</h3>
                    <ul className="mt-2 flex flex-wrap gap-1.5">
                      {session.shared_themes.map((t, i) => (
                        <li
                          key={i}
                          className="rounded-full border border-border bg-background/60 px-2.5 py-1 text-xs"
                        >
                          {t}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {session.misread_points.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium">Where each may be reading the other</h3>
                    <ul className="mt-2 space-y-2 text-sm leading-relaxed text-muted-foreground">
                      {session.misread_points.map((m, i) => (
                        <li key={i} className="border-l-2 border-primary/30 pl-3">
                          {m}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <p className="pt-2 text-xs text-muted-foreground">
                  Clarity does not give advice. These are general perspectives based on what you
                  both wrote.
                </p>
              </section>
            )}

            <div className="grid gap-4 sm:grid-cols-2">
              <IdentityChips title="Shared identity context" />
              <MicroContinuation ctx={{ lastActionType: "two_person_event" }} />
            </div>
          </div>
        )}
      </main>
      </MicroCalm>
    </div>
  );
};

const PerspectivePanel = ({
  title,
  text,
  rewrite,
  emptyLabel,
}: {
  title: string;
  text: string | null;
  rewrite: string | null;
  emptyLabel: string;
}) => (
  <div className="rounded-2xl border border-border/70 bg-card/80 p-5 shadow-sm">
    <h3 className="font-display text-base font-semibold">{title}</h3>
    {text ? (
      <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed">{text}</p>
    ) : (
      <p className="mt-3 rounded-lg border border-dashed border-border/70 bg-muted/30 p-4 text-center text-xs text-muted-foreground">
        {emptyLabel}
      </p>
    )}
    {rewrite && (
      <div className="mt-4 rounded-xl border border-accent/30 bg-accent/5 p-3">
        <div className="flex items-center justify-between gap-2">
          <p className="text-xs font-medium uppercase tracking-wider text-accent-foreground/70">
            Suggested opening
          </p>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 px-2 text-xs"
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(rewrite);
                toast({ title: "Copied" });
              } catch {
                toast({ title: "Couldn't copy" });
              }
            }}
          >
            <Copy className="mr-1.5 h-3 w-3" /> Copy
          </Button>
        </div>
        <p className="mt-1.5 text-sm leading-relaxed">{rewrite}</p>
      </div>
    )}
  </div>
);

export default TwoPersonSession;
