import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { TopBar } from "@/components/TopBar";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { QuestionStep } from "@/components/QuestionStep";
import { Button } from "@/components/ui/button";
import { PriorAnswersPanel, EditableAnswer } from "@/components/PriorAnswersPanel";
import { supabase } from "@/integrations/supabase/client";
import {
  FIRST_QUESTION,
  FIRST_QUESTION_MIN_CHARS,
  MAX_QUESTIONS,
  TARGET_QUESTIONS,
  QuestionType,
} from "@/lib/types";
import { FriendlyError, generateAnswerNudge, generateNextQuestion } from "@/lib/api";
import { toast } from "@/hooks/use-toast";
import { SafetyCard } from "@/components/SafetyCard";
import { detectSafety, type SafetyMatch } from "@/lib/safety";
import { Button as UIButton } from "@/components/ui/button";
import { HelpCircle } from "lucide-react";
import {
  generateNextQuestionV2,
  getSessionEngineVersion,
  pinSessionEngineVersion,
  trackEvent,
  type CoverageMap,
} from "@/lib/engineV2";
import { CoverageProgress } from "@/components/CoverageProgress";
import { RepairDialog } from "@/components/RepairDialog";
import { QuestionTransitionLayer } from "@/components/questions/QuestionTransitionLayer";
import { firePatternEnginePipeline } from "@/pattern-engine/client/dispatch";
import { recordEvent } from "@/lib/identity";

interface PriorAnswer {
  id: string;
  question_index: number;
  question_text: string;
  answer_text: string;
  question_type: QuestionType;
  min_chars: number;
}

const THINKING_PHRASES = [
  "Reading what you wrote…",
  "Figuring out what to ask next…",
  "Putting the pieces together…",
  "Looking at this carefully…",
  "Considering what's missing…",
];

const QuestionFlow = () => {
  const { sessionId, step } = useParams<{ sessionId: string; step: string }>();
  const navigate = useNavigate();
  const stepNum = Math.max(1, Math.min(MAX_QUESTIONS, parseInt(step || "1", 10) || 1));

  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [questionText, setQuestionText] = useState<string>(FIRST_QUESTION);
  const [questionType, setQuestionType] = useState<QuestionType>("open");
  const [minChars, setMinChars] = useState<number>(FIRST_QUESTION_MIN_CHARS);
  const [doneSignal, setDoneSignal] = useState<boolean>(false);
  const [initial, setInitial] = useState<string>("");
  const [priorAnswers, setPriorAnswers] = useState<PriorAnswer[]>([]);
  const [thinkingIdx, setThinkingIdx] = useState(0);
  const [safetyMatch, setSafetyMatch] = useState<SafetyMatch | null>(null);

  // v2 engine state
  const [engineVersion, setEngineVersion] = useState<"v1" | "v2">("v1");
  const [coverage, setCoverage] = useState<CoverageMap | undefined>(undefined);
  const [saturation, setSaturation] = useState<number>(0);
  const [hardCap, setHardCap] = useState<number>(MAX_QUESTIONS);
  const [repairOpen, setRepairOpen] = useState(false);
  const [refreshTick, setRefreshTick] = useState(0); // bump to refetch after repair

  useEffect(() => {
    document.title = `Your conversation — Clarity`;
  }, [stepNum]);

  // Rotate thinking phrases.
  useEffect(() => {
    if (!loading && !generating) return;
    const id = setInterval(() => setThinkingIdx((i) => (i + 1) % THINKING_PHRASES.length), 2500);
    return () => clearInterval(id);
  }, [loading, generating]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setGenError(null);
      setDoneSignal(false);
      const { data: sess } = await supabase.auth.getSession();
      if (!sess.session) { navigate("/auth"); return; }
      if (!sessionId) { navigate("/new"); return; }

      const { data: sessionRow } = await supabase
        .from("reflection_sessions")
        .select("id, status")
        .eq("id", sessionId)
        .is("deleted_at", null)
        .maybeSingle();

      if (!sessionRow) { navigate("/new", { replace: true }); return; }
      if (sessionRow.status === "complete") {
        navigate(`/snapshot/${sessionId}`, { replace: true });
        return;
      }

      const { data: answers } = await supabase
        .from("reflection_answers")
        .select("id, question_index, question_text, answer_text, question_type, min_chars")
        .eq("session_id", sessionId)
        .order("question_index", { ascending: true });

      const priors = ((answers ?? []) as any[]).map((a) => ({
        id: a.id,
        question_index: a.question_index,
        question_text: a.question_text,
        answer_text: a.answer_text,
        question_type: (a.question_type ?? "open") as QuestionType,
        min_chars: a.min_chars ?? 0,
      })) as PriorAnswer[];
      if (cancelled) return;
      setPriorAnswers(priors);

      // Determine engine version (pinned per-session, defaults to feature flag).
      // Pin on first interaction so we never flip mid-session.
      let version = await getSessionEngineVersion(sessionId);
      if (priors.length === 0 && stepNum === 1) {
        await pinSessionEngineVersion(sessionId, version);
        if (version === "v2") trackEvent("engine_v2_session_started", { sessionId });
      }
      if (cancelled) return;
      setEngineVersion(version);

      // Hydrate coverage from any existing ContextModel so progress shows immediately.
      if (version === "v2") {
        const { data: ctx } = await supabase
          .from("session_context_models" as any)
          .select("coverage_map, saturation_score")
          .eq("session_id", sessionId)
          .maybeSingle();
        if (!cancelled && ctx) {
          if ((ctx as any).coverage_map) setCoverage((ctx as any).coverage_map);
          if (typeof (ctx as any).saturation_score === "number") setSaturation((ctx as any).saturation_score);
        }
      }

      // Resume guard: if user lands ahead of progress, redirect to next unanswered.
      const nextIndex = priors.length + 1;
      if (stepNum > nextIndex) {
        navigate(`/new/${sessionId}/${nextIndex}`, { replace: true });
        return;
      }

      // Existing answer for this step?
      const existing = priors.find((p) => p.question_index === stepNum);
      if (existing) {
        setQuestionText(existing.question_text);
        setQuestionType(existing.question_type);
        setMinChars(existing.min_chars);
        setInitial(existing.answer_text);
        setLoading(false);
        return;
      }

      // No existing answer — Q1 is fixed.
      if (stepNum === 1) {
        setQuestionText(FIRST_QUESTION);
        setQuestionType("open");
        setMinChars(FIRST_QUESTION_MIN_CHARS);
        setInitial("");
        setLoading(false);
        return;
      }

      // Generate next question from priors.
      setQuestionText("");
      setInitial("");
      setLoading(false);
      setGenerating(true);

      // engineVersion already determined above; reuse it.

      try {
        if (engineVersion === "v2") {
          const next = await generateNextQuestionV2(
            sessionId,
            priors.map((p) => ({ question: p.question_text, answer: p.answer_text })),
          );
          if (cancelled) return;
          if (next.coverage_map) setCoverage(next.coverage_map);
          if (typeof next.saturation_score === "number") setSaturation(next.saturation_score);
          if (typeof next.hard_cap === "number") setHardCap(next.hard_cap);
          if (next.done) {
            trackEvent("engine_v2_done", { sessionId, slot: priors.length });
            navigate(`/loading/${sessionId}`, { replace: true });
            return;
          }
          setQuestionText(next.question ?? "");
          setQuestionType("open");
          setMinChars(25);
          setDoneSignal(false);
          trackEvent("question_shown", {
            sessionId,
            slot: next.slot,
            depth: next.depth,
            target_fields: next.target_fields,
          });
        } else {
          const next = await generateNextQuestion(
            sessionId,
            priors.map((p) => ({
              question: p.question_text,
              answer: p.answer_text,
              type: p.question_type,
            })),
          );
          if (cancelled) return;
          if (next.done && !next.question) {
            navigate(`/loading/${sessionId}`, { replace: true });
            return;
          }
          setQuestionText(next.question);
          setQuestionType(next.question_type);
          setMinChars(next.min_chars);
          setDoneSignal(next.done);
        }
      } catch (e) {
        if (cancelled) return;
        const fe = e instanceof FriendlyError ? e : null;
        if (fe?.kind === "auth") { navigate("/auth", { replace: true }); return; }
        setGenError((e as Error)?.message || "Something went wrong. Please try again.");
      } finally {
        if (!cancelled) setGenerating(false);
      }
    })();
    return () => { cancelled = true; };
  }, [sessionId, stepNum, navigate, refreshTick]);

  const saveAndAdvance = async (value: string) => {
    if (!sessionId) return;

    // Guard: recalculate the correct index from stored answers to prevent
    // gaps/desync after regeneration, edits, or stale URLs. The next valid
    // index is always (count of existing answers) + 1, unless we're updating
    // an existing answer at this exact step.
    const { data: existingRows } = await supabase
      .from("reflection_answers")
      .select("question_index")
      .eq("session_id", sessionId)
      .order("question_index", { ascending: true });

    const indices = (existingRows ?? []).map((r: any) => r.question_index as number);
    const hasThisStep = indices.includes(stepNum);
    const nextIndex = indices.length + 1;
    const safeIndex = hasThisStep ? stepNum : nextIndex;

    // If the URL was ahead of reality, redirect to the correct step instead
    // of silently writing to a wrong index.
    if (!hasThisStep && stepNum !== nextIndex) {
      navigate(`/new/${sessionId}/${nextIndex}`, { replace: true });
      return;
    }

    const { data: savedRow, error } = await supabase
      .from("reflection_answers")
      .upsert(
        {
          session_id: sessionId,
          question_index: safeIndex,
          question_text: questionText,
          answer_text: value,
          question_type: questionType,
          min_chars: minChars,
        },
        { onConflict: "session_id,question_index" },
      )
      .select("id")
      .maybeSingle();
    if (error) {
      toast({
        title: "Could not save your answer",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    // Phase 2 fire-and-forget: never blocks, never throws.
    firePatternEnginePipeline(savedRow?.id);
    if (stepNum === 1) {
      const autoTitle = value.trim().replace(/\s+/g, " ").slice(0, 60) || "Conversation";
      await supabase.from("reflection_sessions").update({ title: autoTitle }).eq("id", sessionId);
    }
    // Crisis detection on the just-submitted answer (open-text only).
    if (questionType === "open") {
      const match = detectSafety(value);
      if (match) {
        setSafetyMatch(match);
        const { data: sess } = await supabase.auth.getSession();
        const uid = sess.session?.user.id;
        if (uid) {
          // Privacy: we intentionally do NOT store the user's triggering text.
          // matched_terms captures the keyword(s) we already knew to look for;
          // the surrounding sentence is never persisted.
          await supabase.from("safety_events").insert({
            user_id: uid,
            session_id: sessionId,
            category: match.category,
            severity: match.severity,
            matched_terms: match.matchedTerms,
            source: "answer",
          });
        }
        // Pause auto-advance so the user sees the SafetyCard. They can dismiss
        // it and continue manually.
        return;
      }
    }
    trackEvent("question_answered", {
      sessionId,
      slot: safeIndex,
      length: value.length,
      engine: engineVersion,
    });
    recordEvent({
      source: "manual",
      tags: { cognitive: ["question_answered"] },
      text: questionType === "open" ? value : undefined,
    });
    // End conditions: AI signaled done OR we've hit the hard cap (use v2's hardCap when on v2).
    const cap = engineVersion === "v2" ? hardCap + 3 : MAX_QUESTIONS;
    if (doneSignal || safeIndex >= cap) {
      navigate(`/loading/${sessionId}`);
    } else {
      navigate(`/new/${sessionId}/${safeIndex + 1}`);
    }
  };

  const retryGenerate = async () => {
    if (!sessionId) return;
    setGenError(null);
    setGenerating(true);
    try {
      const next = await generateNextQuestion(
        sessionId,
        priorAnswers.map((p) => ({
          question: p.question_text,
          answer: p.answer_text,
          type: p.question_type,
        })),
      );
      if (next.done && !next.question) {
        navigate(`/loading/${sessionId}`, { replace: true });
        return;
      }
      setQuestionText(next.question);
      setQuestionType(next.question_type);
      setMinChars(next.min_chars);
      setDoneSignal(next.done);
    } catch (e) {
      const fe = e instanceof FriendlyError ? e : null;
      if (fe?.kind === "auth") { navigate("/auth", { replace: true }); return; }
      setGenError(fe?.message || "Something went wrong. Please try again.");
    } finally {
      setGenerating(false);
    }
  };

  // Regenerate the CURRENT question without losing prior answers or session state.
  const regenerateQuestion = async () => {
    if (!sessionId) return;
    if (stepNum === 1) return; // Q1 is fixed.
    setGenerating(true);
    try {
      const next = await generateNextQuestion(
        sessionId,
        priorAnswers
          .filter((p) => p.question_index < stepNum)
          .map((p) => ({
            question: p.question_text,
            answer: p.answer_text,
            type: p.question_type,
          })),
        { forceRegenerate: true },
      );
      if (next.done && !next.question) {
        navigate(`/loading/${sessionId}`, { replace: true });
        return;
      }
      setQuestionText(next.question);
      setQuestionType(next.question_type);
      setMinChars(next.min_chars);
      setDoneSignal(next.done);
      setInitial("");
    } catch (e) {
      const fe = e instanceof FriendlyError ? e : null;
      if (fe?.kind === "auth") { navigate("/auth", { replace: true }); return; }
      toast({
        title: "Couldn't regenerate just now",
        description: fe?.message || "Please try again in a moment.",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  const nudgeForAnswer = async (currentQuestion: string, answer: string) => {
    if (!sessionId) {
      return "Could you add a bit more detail so I can understand this better?";
    }
    return await generateAnswerNudge(sessionId, currentQuestion, answer);
  };

  const isLast = doneSignal || stepNum >= MAX_QUESTIONS;

  // Only show prior answers BEFORE the current step (the active question
  // is rendered separately and future questions don't exist yet).
  const editablePriors: EditableAnswer[] = priorAnswers
    .filter((p) => p.question_index < stepNum)
    .map((p) => ({
      id: p.id,
      question_index: p.question_index,
      question_text: p.question_text,
      answer_text: p.answer_text,
      question_type: p.question_type,
      min_chars: p.min_chars,
    }));

  const handleEditPrior = async (a: EditableAnswer, newValue: string) => {
    if (!sessionId) return;
    // 1) Update the edited row.
    const { error: updErr } = await supabase
      .from("reflection_answers")
      .update({ answer_text: newValue })
      .eq("id", a.id);
    if (updErr) {
      toast({
        title: "Could not save your edit",
        description: updErr.message,
        variant: "destructive",
      });
      return;
    }
    // 2) Mark downstream as stale: delete any answer with a higher index.
    //    The edited answer changes context, so later questions need to be
    //    regenerated against the new picture.
    const { error: delErr } = await supabase
      .from("reflection_answers")
      .delete()
      .eq("session_id", sessionId)
      .gt("question_index", a.question_index);
    if (delErr) {
      toast({
        title: "Edit saved, but could not refresh later questions",
        description: delErr.message,
        variant: "destructive",
      });
    }
    // 3) If it was Q1, refresh the auto-title.
    if (a.question_index === 1 && a.question_type === "open") {
      const autoTitle =
        newValue.trim().replace(/\s+/g, " ").slice(0, 60) || "Conversation";
      await supabase
        .from("reflection_sessions")
        .update({ title: autoTitle })
        .eq("id", sessionId);
    }
    toast({ title: "Updating based on your edit…" });
    // 4) Send the user to the question right after the edited one so the
    //    flow regenerates from there.
    navigate(`/new/${sessionId}/${a.question_index + 1}`, { replace: true });
  };

  return (
    <>
      <TopBar />
      <MicroCalm>
      <main className="mx-auto max-w-content space-y-4 px-4 py-12">
        {safetyMatch && (
          <div className="space-y-3">
            <SafetyCard
              category={safetyMatch.category}
              variant="full"
              onDismiss={async () => {
                const { data: sess } = await supabase.auth.getSession();
                const uid = sess.session?.user.id;
                if (uid && sessionId) {
                  await supabase
                    .from("safety_events")
                    .update({ acknowledged: true })
                    .eq("session_id", sessionId)
                    .eq("user_id", uid)
                    .eq("acknowledged", false);
                }
                setSafetyMatch(null);
                if (doneSignal || stepNum >= MAX_QUESTIONS) {
                  navigate(`/loading/${sessionId}`);
                } else {
                  navigate(`/new/${sessionId}/${stepNum + 1}`);
                }
              }}
            />
            <p className="text-center text-xs text-muted-foreground">
              Close this when you're ready and we'll keep going.
            </p>
          </div>
        )}
        {!loading && !generating && !genError && editablePriors.length > 0 && (
          <PriorAnswersPanel
            answers={editablePriors}
            onSaveEdit={handleEditPrior}
          />
        )}
        {engineVersion === "v2" && !loading && !genError && !safetyMatch && (
          <CoverageProgress
            slot={stepNum}
            hardCap={hardCap}
            saturation={saturation}
            coverage={coverage}
          />
        )}
        <QuestionTransitionLayer
          generating={generating}
          loading={loading}
          genError={genError}
        />
        <div className="card-soft p-6 sm:p-8">
          {loading || generating ? (
            <div className="flex flex-col items-center gap-5 py-12">
              <div className="relative flex h-16 w-16 items-center justify-center">
                <span aria-hidden className="absolute inset-0 rounded-full bg-primary/10 breathe-dot" />
                <span aria-hidden className="absolute inset-2 rounded-full bg-primary/20 breathe-dot" style={{ animationDelay: "0.4s" }} />
                <span aria-hidden className="relative h-2.5 w-2.5 rounded-full bg-primary breathe-dot" style={{ animationDelay: "0.8s" }} />
              </div>
              <p className="text-base text-muted-foreground transition-opacity">{THINKING_PHRASES[thinkingIdx]}</p>
            </div>
          ) : genError ? (
            <div className="text-center">
              <p className="text-base">{genError}</p>
              <div className="mt-6 flex justify-center gap-3">
                <Button
                  variant="outline"
                  onClick={() => navigate(`/new/${sessionId}/${Math.max(1, stepNum - 1)}`)}
                >
                  Back
                </Button>
                <Button onClick={retryGenerate}>Try Again</Button>
              </div>
            </div>
          ) : (
            <>
              <QuestionStep
                step={stepNum}
                target={engineVersion === "v2" ? hardCap : TARGET_QUESTIONS}
                question={questionText}
                questionType={questionType}
                minChars={minChars}
                initial={initial}
                isLast={isLast}
                onBack={
                  stepNum > 1
                    ? () => navigate(`/new/${sessionId}/${stepNum - 1}`)
                    : undefined
                }
                onNext={saveAndAdvance}
                onRegenerate={stepNum > 1 && !initial ? regenerateQuestion : undefined}
                regenerating={generating}
                getNudge={nudgeForAnswer}
              />
              {engineVersion === "v2" && stepNum > 1 && !initial && (
                <div className="mt-4 flex justify-center">
                  <UIButton
                    variant="ghost"
                    size="sm"
                    onClick={() => setRepairOpen(true)}
                    className="h-7 gap-1.5 px-2 text-xs text-muted-foreground hover:text-foreground"
                  >
                    <HelpCircle className="h-3.5 w-3.5" aria-hidden />
                    This question doesn't make sense
                  </UIButton>
                </div>
              )}
            </>
          )}
        </div>
        {engineVersion === "v2" && sessionId && (
          <RepairDialog
            open={repairOpen}
            onOpenChange={setRepairOpen}
            sessionId={sessionId}
            questionIndex={stepNum}
            questionText={questionText}
            onResolved={() => setRefreshTick((t) => t + 1)}
          />
        )}
      </main>
      </MicroCalm>
    </>
  );
};

export default QuestionFlow;
