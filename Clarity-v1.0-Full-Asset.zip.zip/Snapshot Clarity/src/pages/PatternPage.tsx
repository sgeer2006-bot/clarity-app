import { useEffect, useRef, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { ArrowLeft, Copy, Download, Loader2, Share2, Sparkles } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { SocialProofStat } from "@/components/SocialProofStat";
import { SharePatternCard } from "@/components/SharePatternCard";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { downloadBlob, renderCardToPng } from "@/lib/share";
import { toast } from "@/hooks/use-toast";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { recordEvent } from "@/lib/identity";
import { IdentityChips } from "@/components/identity/IdentityChips";
import { MicroContinuation } from "@/components/habit/MicroContinuation";

interface PatternRow {
  id: string;
  slug: string;
  name: string;
  short_description: string;
  emotional_meaning: string;
  other_person_tip: string;
}

const PatternPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const [params] = useSearchParams();
  const sessionId = params.get("session");

  const [pattern, setPattern] = useState<PatternRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [reason, setReason] = useState<string | null>(null);
  const [statLine, setStatLine] = useState<string | null>(null);

  const [shareOpen, setShareOpen] = useState(false);
  const [generating, setGenerating] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!slug) return;
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from("patterns")
        .select("id, slug, name, short_description, emotional_meaning, other_person_tip")
        .eq("slug", slug)
        .maybeSingle();
      if (cancelled) return;
      if (error || !data) {
        setPattern(null);
        setLoading(false);
        return;
      }
      setPattern(data as PatternRow);
      setLoading(false);

      // Pull stat for the share card (best-effort)
      const { data: stats } = await supabase.rpc("get_pattern_stats", {
        _pattern_id: data.id,
        _days: 30,
      });
      if (Array.isArray(stats) && stats[0]) {
        const s = stats[0] as any;
        const total = Number(s.total_count ?? 0);
        const pat = Number(s.pattern_count ?? 0);
        if (total >= 20) {
          const pct = total > 0 ? (pat / total) * 100 : 0;
          const pretty = pct >= 10 ? Math.round(pct) : pct.toFixed(1);
          setStatLine(`${pretty}% of recent reflections matched this pattern.`);
        }
      }

      // If we arrived from a session, fetch the LLM's reason for that match
      if (sessionId) {
        const { data: spm } = await supabase
          .from("session_patterns")
          .select("reason")
          .eq("session_id", sessionId)
          .eq("pattern_id", data.id)
          .maybeSingle();
        if (!cancelled && spm?.reason) setReason(spm.reason);
        recordEvent({
          source: "manual",
          tags: { communication: [`pattern_viewed:${data.slug}`] },
        });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [slug, sessionId]);

  const share = async (action: "download" | "copy") => {
    if (!cardRef.current) return;
    setGenerating(true);
    try {
      const blob = await renderCardToPng(cardRef.current);
      if (action === "download") {
        downloadBlob(blob, `clarity-pattern-${slug}.png`);
        toast({ title: "Image saved" });
      } else {
        await navigator.clipboard.writeText(`${window.location.origin}/p/${slug}`);
        toast({ title: "Link copied", description: "Anyone can view this pattern page." });
      }
    } catch (e: any) {
      toast({
        title: "Couldn't share",
        description: e?.message ?? "Please try again.",
        variant: "destructive",
      });
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <>
        <TopBar />
        <main className="mx-auto max-w-content px-4 py-12 text-sm text-muted-foreground">
          Loading…
        </main>
      </>
    );
  }

  if (!pattern) {
    return (
      <>
        <TopBar />
        <main className="mx-auto max-w-content px-4 py-24 text-center">
          <h1 className="font-display text-3xl">Pattern not found</h1>
          <Button asChild className="mt-6">
            <Link to="/">Go home</Link>
          </Button>
        </main>
      </>
    );
  }

  const canonical = `${window.location.origin}/p/${pattern.slug}`;

  return (
    <>
      <Helmet>
        <title>{pattern.name} — Clarity Pattern</title>
        <meta name="description" content={pattern.short_description} />
        <link rel="canonical" href={canonical} />
        <meta property="og:title" content={`${pattern.name} — Clarity`} />
        <meta property="og:description" content={pattern.short_description} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={canonical} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={`${pattern.name} — Clarity`} />
        <meta name="twitter:description" content={pattern.short_description} />
      </Helmet>

      <TopBar />
      <MicroCalm>
      <main className="mx-auto max-w-content space-y-6 px-4 py-12">
        {sessionId && (
          <Link
            to={`/snapshot/${sessionId}`}
            className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to your snapshot
          </Link>
        )}

        <article className="card-soft p-6 sm:p-8 animate-fade-in-up">
          <div className="label-eyebrow flex items-center gap-2">
            <Sparkles className="h-3.5 w-3.5" />
            Communication pattern
          </div>
          <h1 className="mt-2 font-display text-3xl font-semibold leading-tight tracking-tight sm:text-4xl">
            {pattern.name}
          </h1>
          <p className="mt-3 text-lg text-muted-foreground">{pattern.short_description}</p>

          <hr className="my-6 border-border" />

          {reason && (
            <div className="mb-6 rounded-lg border border-accent/40 bg-accent/10 p-4 text-sm">
              <span className="font-medium">Why we picked this for you:</span> {reason}
            </div>
          )}

          <h2 className="label-eyebrow">What it often means</h2>
          <p className="mt-2 text-base">{pattern.emotional_meaning}</p>

          <h2 className="label-eyebrow mt-8">With the other person</h2>
          <p className="mt-2 text-base">{pattern.other_person_tip}</p>

          <div className="mt-8">
            <SocialProofStat patternId={pattern.id} />
          </div>
        </article>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <Button variant="ghost" asChild>
            <Link to="/">Back to Home</Link>
          </Button>
          <Button onClick={() => setShareOpen(true)}>
            <Share2 className="mr-2 h-4 w-4" />
            Share this pattern
          </Button>
        </div>

        {sessionId && (
          <div className="grid gap-4 sm:grid-cols-2">
            <IdentityChips />
            <MicroContinuation ctx={{ lastActionType: "insight_viewed" }} />
          </div>
        )}
      </main>
      </MicroCalm>

      <Dialog open={shareOpen} onOpenChange={setShareOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Share this pattern</DialogTitle>
            <DialogDescription>Download an image or copy the public link.</DialogDescription>
          </DialogHeader>

          <div className="relative mx-auto overflow-hidden rounded-lg border border-border bg-muted/30">
            <div
              className="origin-top-left"
              style={{ transform: "scale(0.28)", width: 1080 * 0.28, height: 1080 * 0.28 }}
            >
              <SharePatternCard
                ref={cardRef}
                name={pattern.name}
                shortDescription={pattern.short_description}
                emotionalMeaning={pattern.emotional_meaning}
                otherPersonTip={pattern.other_person_tip}
                statLine={statLine}
              />
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => share("copy")} disabled={generating}>
              <Copy className="mr-2 h-4 w-4" />
              Copy link
            </Button>
            <Button onClick={() => share("download")} disabled={generating}>
              {generating ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Download className="mr-2 h-4 w-4" />
              )}
              Download PNG
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default PatternPage;
