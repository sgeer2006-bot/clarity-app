import { Helmet } from "react-helmet-async";
import { useNavigate } from "react-router-dom";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";

export default function ClarityPlusCancelPage() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Clarity+ — Whenever you&apos;re ready</title>
        <meta name="description" content="No worries — Clarity+ will be here whenever you're ready." />
      </Helmet>
      <TopBar />
      <main className="mx-auto w-full max-w-xl px-5 py-16">
        <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
          All good. Nothing changed.
        </h1>
        <p className="mt-3 text-base leading-relaxed text-muted-foreground">
          You can take your time. Clarity+ will be here whenever you&apos;re ready — your deeper clarity starts here.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button
            size="lg"
            className="h-12 rounded-full px-6 text-base"
            onClick={() => {
              if (window.history.length > 1) navigate(-1);
              else navigate("/clarity-plus");
            }}
          >
            Back to where I was
          </Button>
        </div>
      </main>
    </div>
  );
}
