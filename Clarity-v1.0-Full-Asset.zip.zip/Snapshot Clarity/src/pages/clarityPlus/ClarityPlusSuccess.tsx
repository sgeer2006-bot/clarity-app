import { useEffect, useRef, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Sparkles } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { usePremiumStatus } from "@/hooks/usePremiumStatus";

export default function ClarityPlusSuccessPage() {
  const { isPremium, refresh } = usePremiumStatus();
  const [waiting, setWaiting] = useState(true);
  const tries = useRef(0);

  useEffect(() => {
    let cancelled = false;
    const tick = async () => {
      if (cancelled) return;
      const now = await refresh();
      tries.current += 1;
      if (now || tries.current >= 15) {
        setWaiting(false);
        return;
      }
      setTimeout(tick, 1000);
    };
    void tick();
    return () => {
      cancelled = true;
    };
  }, [refresh]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Welcome to Clarity+</title>
        <meta name="description" content="Your Clarity+ access is active. Your deeper clarity starts here." />
      </Helmet>
      <TopBar />
      <main className="mx-auto w-full max-w-xl px-5 py-16">
        <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 text-xs text-primary">
          <Sparkles className="h-3 w-3" aria-hidden /> Clarity+
        </span>
        <h1 className="mt-4 font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
          {isPremium ? "You're in. Welcome to Clarity+." : "Just a moment — finishing up…"}
        </h1>
        <p className="mt-3 text-base leading-relaxed text-muted-foreground">
          {isPremium
            ? "Take a breath. There's nothing else you need to do. Clarity+ will quietly deepen what you're already doing here."
            : waiting
              ? "Your payment went through. We're getting your access ready — this usually takes a few seconds."
              : "Your payment was received. If access doesn't appear in a moment, refresh this page or pop into Settings → Billing."}
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button asChild size="lg" className="h-12 rounded-full px-6 text-base">
            <Link to="/home">Take me home</Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="h-12 rounded-full px-6 text-base">
            <Link to="/clarity-plus/pricing">Manage subscription</Link>
          </Button>
        </div>
      </main>
    </div>
  );
}
