import { Helmet } from "react-helmet-async";
import { useEffect, useState } from "react";
import { TopBar } from "@/components/TopBar";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { useVisualFlags } from "@/visual/useVisualFlags";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { PageHeader } from "@/components/layout/PageHeader";
import { Sparkles, Crown } from "lucide-react";
import { canUse } from "@/lib/featureGate";
import { PremiumCalmLayer, readPremiumCalm, writePremiumCalm } from "@/components/ui/CalmLayer";

// Phase 7 decision: KEEP this page. It controls the calm/ambient layer
// (drift intensity, motion toggle, reduced-motion respect) and is the only
// surface where users can tune the visual atmosphere.
export default function SettingsVisualPage() {
  const { visualMotion, reducedMotion, themeIntensity, set } = useVisualFlags();
  const [premiumCalm, setPremiumCalm] = useState<boolean>(() => readPremiumCalm());
  const premiumAllowed = canUse("premium_calm_layer");
  useEffect(() => { writePremiumCalm(premiumCalm); }, [premiumCalm]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Visual Calm — Clarity</title>
        <meta name="description" content="Adjust ambient background motion and intensity." />
        <link rel="canonical" href="/settings/visual" />
      </Helmet>
      <TopBar />
      <MicroCalm>
        <main className="mx-auto w-full max-w-2xl px-6 py-12 sm:py-16">
          <PageHeader
            eyebrow={<><Sparkles className="h-3 w-3" aria-hidden /> Calm</>}
            title="Visual atmosphere"
            lead="Tune the ambient layer behind your reflections. These settings stay on this device."
          />

          <div className="card-soft grid gap-8 p-6 sm:grid-cols-[1fr_180px] sm:p-8">
            <div className="space-y-7">
              <label className="flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-medium text-foreground">Background motion</div>
                  <div className="mt-0.5 text-xs text-muted-foreground">Soft drifting shapes behind the app.</div>
                </div>
                <Switch checked={visualMotion} onCheckedChange={(v) => set({ visualMotion: v })} />
              </label>

              <label className="flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-medium text-foreground">Reduced motion</div>
                  <div className="mt-0.5 text-xs text-muted-foreground">Keep shapes static even when motion is on.</div>
                </div>
                <Switch checked={reducedMotion} onCheckedChange={(v) => set({ reducedMotion: v })} />
              </label>

              <div>
                <div className="mb-3 flex items-center justify-between">
                  <div className="text-sm font-medium text-foreground">Theme intensity</div>
                  <span className="text-xs text-muted-foreground">{themeIntensity}</span>
                </div>
                <Slider
                  value={[themeIntensity]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={(v) => set({ themeIntensity: v[0] ?? 0 })}
                />
              </div>

              <div className="border-t border-border/40 pt-5">
                <label className="flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-1.5 text-sm font-medium text-foreground">
                      <Crown className="h-3.5 w-3.5 text-primary" aria-hidden />
                      Premium calm layer
                    </div>
                    <div className="mt-0.5 text-xs text-muted-foreground">
                      {premiumAllowed
                        ? "Soft breathing orbs added behind the canvas."
                        : "A static preview is shown below — full motion opens with Premium."}
                    </div>
                  </div>
                  <Switch
                    checked={premiumCalm && premiumAllowed}
                    disabled={!premiumAllowed}
                    onCheckedChange={(v) => setPremiumCalm(v)}
                  />
                </label>
                {!premiumAllowed && (
                  <div className="relative mt-4 h-28 overflow-hidden rounded-xl border border-border/40">
                    <PremiumCalmLayer preview />
                  </div>
                )}
              </div>
            </div>

            <aside
              className="hidden h-40 rounded-2xl sm:block"
              style={{
                background: "linear-gradient(135deg, hsl(40 30% 92%), hsl(40 22% 86%) 60%, hsl(162 28% 70%))",
                opacity: 0.4 + (themeIntensity / 100) * 0.6,
                boxShadow: "var(--shadow-card)",
              }}
              aria-label="Live preview"
            />
          </div>
        </main>
      </MicroCalm>
    </div>
  );
}
