import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { useFolders } from "@/hooks/useFolders";
import { addEntry } from "@/lib/folders/store";
import { recordEvent } from "@/lib/identity";
import { useSafetyScan } from "@/safety/useSafetyScan";
import { SafetyBlock } from "@/safety/SafetyBlock";
import { MicroReward } from "@/components/habit/MicroReward";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { MicroContinuation } from "@/components/habit/MicroContinuation";

export default function ComposerPage() {
  const folders = useFolders();
  const [text, setText] = useState("");
  const [folderId, setFolderId] = useState<string>("");
  const [saved, setSaved] = useState(false);
  const { categories: risks } = useSafetyScan(text);

  const onSave = () => {
    const value = text.trim();
    if (!value) return;
    if (folderId) addEntry(folderId, value);
    try {
      recordEvent({
        source: "manual",
        text: value,
        tags: { behavioral: ["composed_reflection"] },
      });
    } catch { /* ignore */ }
    setText("");
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Compose — Clarity</title>
        <meta name="description" content="A calm space to write a single reflection." />
        <link rel="canonical" href="/compose" />
      </Helmet>
      <TopBar />
      <MicroCalm>
      <main className="mx-auto w-full max-w-2xl px-6 py-12 sm:py-16">
        <header className="mb-10 space-y-3 animate-fade-in-up">
          <span className="label-eyebrow">A quiet page</span>
          <h1 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            Write
          </h1>
          <p className="max-w-prose text-sm leading-relaxed text-muted-foreground">
            One quiet space. No prompts, no pressure — just a place to notice.
          </p>
        </header>

        <div className="card-soft p-2 p7-type-glow transition-shadow">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="What would you like to notice today?"
            rows={10}
            className="w-full resize-none rounded-xl bg-transparent px-5 py-4 text-base leading-relaxed text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-0"
          />
        </div>


        {risks.length > 0 && (
          <div className="mt-4">
            <SafetyBlock categories={risks} />
          </div>
        )}

        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          {folders.length > 0 ? (
            <label className="text-sm text-muted-foreground">
              Save to folder:{" "}
              <select
                value={folderId}
                onChange={(e) => setFolderId(e.target.value)}
                className="ml-1 rounded-md border border-input bg-background px-2 py-1 text-sm"
              >
                <option value="">(none)</option>
                {folders.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </label>
          ) : (
            <span className="text-xs text-muted-foreground/80">
              Tip: create a folder to keep entries together.
            </span>
          )}
          <Button onClick={onSave} disabled={!text.trim()}>
            Save reflection
          </Button>
        </div>

        {saved && (
          <>
            <div className="mt-4">
              <MicroReward message="Saved." />
            </div>
            <div className="mt-6">
              <MicroContinuation ctx={{ lastActionType: "reflection_saved" }} />
            </div>
          </>
        )}
      </main>
      </MicroCalm>
    </div>
  );
}
