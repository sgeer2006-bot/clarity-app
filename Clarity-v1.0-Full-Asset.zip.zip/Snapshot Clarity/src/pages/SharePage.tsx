import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Home, Sparkles } from "lucide-react";
import { SnapshotView } from "@/components/SnapshotView";
import { PatternIdentityCard, type PatternIdentity } from "@/components/PatternIdentityCard";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import type { ReflectionSessionRow, SnapshotJson } from "@/lib/types";
import { MicroCalm } from "@/components/habit/MicroCalm";

const SharePage = () => {
  const { token } = useParams<{ token: string }>();
  const [session, setSession] = useState<ReflectionSessionRow | null>(null);
  const [identity, setIdentity] = useState<PatternIdentity | null>(null);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    document.title = "Share Your Clarity — Clarity";
    (async () => {
      const { data, error } = await supabase
        .from("reflection_sessions")
        .select("*")
        .eq("share_token", token!)
        .is("deleted_at", null)
        .maybeSingle();
      if (error || !data) {
        setNotFound(true);
        return;
      }
      setSession({
        ...data,
        status: data.status as ReflectionSessionRow["status"],
        snapshot_json: (data.snapshot_json as unknown as SnapshotJson | null) ?? null,
      });

      const identityId = (data as any).pattern_identity_id as string | null;
      if (identityId) {
        const { data: cat } = await supabase
          .from("pattern_identities")
          .select("*")
          .eq("id", identityId)
          .maybeSingle();
        if (cat) setIdentity(cat as PatternIdentity);
      }
    })();
  }, [token]);

  return (
    <MicroCalm>
    <main className="mx-auto max-w-content space-y-6 px-4 py-12">
      <div>
        <Button asChild variant="outline" className="h-11 gap-1.5">
          <Link to="/" aria-label="Home">
            <Home className="h-4 w-4" aria-hidden="true" />
            <span>Home</span>
          </Link>
        </Button>
      </div>
      {notFound ? (
        <p className="text-sm text-muted-foreground">
          This reflection is not available.
        </p>
      ) : !session ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : (
        <>
          <SnapshotView session={session} showResponsesCollapsible={false} />
          {identity && <PatternIdentityCard identity={identity} />}
          <div className="rounded-xl border border-accent/30 bg-accent/5 p-5 text-center">
            <Sparkles className="mx-auto h-5 w-5 text-accent" />
            <p className="mt-2 text-sm font-medium">Get your own clarity map</p>
            <p className="mt-1 text-xs text-muted-foreground">
              See your communication pattern in any situation, free.
            </p>
            <Button asChild className="mt-3" size="sm">
              <Link to="/">Try Clarity</Link>
            </Button>
          </div>
          <p className="text-center text-xs text-muted-foreground">Generated with Clarity</p>
        </>
      )}
    </main>
    </MicroCalm>
  );
};

export default SharePage;
