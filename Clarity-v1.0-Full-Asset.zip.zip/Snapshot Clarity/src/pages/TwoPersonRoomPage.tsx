import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { TopBar } from "@/components/TopBar";
import { PremiumGate } from "@/premium/PremiumGate";
import { JoinRoom } from "@/two_person/JoinRoom";
import { TwoPersonRoom } from "@/two_person/TwoPersonRoom";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { MotionToggle } from "@/components/calm/MotionToggle";
import { IdentityChips } from "@/components/identity/IdentityChips";
import { MicroContinuation } from "@/components/habit/MicroContinuation";

export default function TwoPersonRoomPage() {
  const [token, setToken] = useState<string | null>(null);
  const [perspective, setPerspective] = useState<"A" | "B">("A");

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Shared Clarity Room — Clarity</title>
        <meta name="description" content="A private, client-encrypted shared reflection space." />
        <link rel="canonical" href="/two-person-room" />
      </Helmet>
      <TopBar />
      <main className="mx-auto w-full max-w-4xl px-6 py-10">
        <h1 className="mb-6 text-2xl font-semibold tracking-tight">Shared Clarity Room</h1>
        <PremiumGate feature="two_person">
          <MicroCalm>
            {token ? (
              <TwoPersonRoom
                token={token}
                initialPerspective={perspective}
                onLeave={() => setToken(null)}
              />
            ) : (
              <JoinRoom
                onEnter={(t, p) => {
                  setPerspective(p);
                  setToken(t);
                }}
              />
            )}
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <IdentityChips title="Shared identity context" />
              <MicroContinuation ctx={{ lastActionType: "two_person_event" }} />
            </div>
            <div className="mt-6">
              <MotionToggle />
            </div>
          </MicroCalm>
        </PremiumGate>
      </main>
    </div>
  );
}
