import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Loader2, Send } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { ContinuationModePicker } from "@/components/ContinuationModePicker";
import { MiniSnapshotCard } from "@/components/MiniSnapshotCard";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { FriendlyError } from "@/lib/api";
import {
  startContinuation,
  nextContinuation,
  finalizeContinuation,
  MAX_CONTINUATION_QUESTIONS,
  MODE_LABELS,
  type ContinuationMode,
  type MiniSnapshot,
} from "@/lib/continuation";
import { recordEvent } from "@/lib/identity";
import { toast } from "@/hooks/use-toast";

interface Msg {
  role: "user" | "ai";
  content: string;
}

const FollowUpFlow = () => {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<ContinuationMode | null>(null);
  const [continuationId, setContinuationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [generating, setGenerating] = useState(false);
  const [questionsAsked, setQuestionsAsked] = useState(0);
  const [done, setDone] = useState(false);
  const [exitReason, setExitReason] = useState<"max_questions_reached" | "no_new_ground" | "fields_saturated" | undefined>(undefined);
  const [finalizing, setFinalizing] = useState(false);
  const [miniSnapshot, setMiniSnapshot] = useState<MiniSnapshot | null>(null);
  const [snapshotPatched, setSnapshotPatched] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!data.session) { navigate("/auth"); return; }
      setLoading(false);
    })();
  }, [navigate]);

  const handleApiError = (e: unknown) => {
    if (e instanceof FriendlyError && e.kind === "auth") {
      navigate("/auth");
      return;
    }
    toast({
      title: "Something went wrong",
      description: (e as Error).message,
      variant: "destructive",
    });
  };

  const handleModeSelect = async (m: ContinuationMode) => {
    if (!sessionId) return;
    setMode(m);
    setGenerating(true);
    try {
      const r = await startContinuation(sessionId, m);
      setContinuationId(r.continuationId);
      setMessages([{ role: "ai", content: r.question }]);
      setQuestionsAsked(r.questionsAsked);
      setDone(r.done);
    } catch (e) {
      setMode(null);
      handleApiError(e);
    } finally {
      setGenerating(false);
    }
  };

  const handleSend = async () => {
    const trimmed = input.trim();
    if (!trimmed || !continuationId) return;
    setMessages((prev) => [...prev, { role: "user", content: trimmed }]);
    setInput("");
    setGenerating(true);
    try {
      const r = await nextContinuation(continuationId, trimmed);
      setQuestionsAsked(r.questionsAsked);
      if (r.done) {
        setDone(true);
        setExitReason(r.exitReason);
        if (r.question) {
          setMessages((prev) => [...prev, { role: "ai", content: r.question! }]);
        }
      } else if (r.question) {
        setMessages((prev) => [...prev, { role: "ai", content: r.question! }]);
      }
    } catch (e) {
      handleApiError(e);
    } finally {
      setGenerating(false);
    }
  };

  const handleFinalize = async () => {
    if (!continuationId) return;
    setFinalizing(true);
    try {
      const r = await finalizeContinuation(continuationId);
      setMiniSnapshot(r.miniSnapshot);
      setSnapshotPatched(r.snapshotPatched);
      recordEvent({
        source: "continuation",
        tags: { cognitive: [`followup_finalized:${mode ?? "unknown"}`] },
      });
    } catch (e) {
      handleApiError(e);
    } finally {
      setFinalizing(false);
    }
  };

  const handleStartAnother = () => {
    setMode(null);
    setContinuationId(null);
    setMessages([]);
    setQuestionsAsked(0);
    setDone(false);
    setExitReason(undefined);
    setMiniSnapshot(null);
    setSnapshotPatched(false);
    setInput("");
  };

  if (loading) {
    return (
      <>
        <TopBar />
        <main className="mx-auto max-w-content px-4 py-12">
          <p className="text-sm text-muted-foreground">Loading…</p>
        </main>
      </>
    );
  }

  // Mini-snapshot view (terminal state)
  if (miniSnapshot && mode) {
    return (
      <>
        <TopBar />
        <main className="mx-auto max-w-content space-y-6 px-4 py-12">
          <MiniSnapshotCard
            mode={mode}
            miniSnapshot={miniSnapshot}
            snapshotPatched={snapshotPatched}
            exitReason={exitReason}
            onBackToSnapshot={() => navigate(`/snapshot/${sessionId}`)}
            onStartAnother={handleStartAnother}
          />
        </main>
      </>
    );
  }

  return (
    <>
      <TopBar />
      <MicroCalm>
      <main className="mx-auto max-w-content space-y-6 px-4 py-12">
        <div className="rounded-xl border border-border bg-card p-6">
          {!mode ? (
            <ContinuationModePicker onSelect={handleModeSelect} />
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-lg font-medium">{MODE_LABELS[mode]}</h2>
                <Button variant="ghost" size="sm" onClick={() => navigate(`/snapshot/${sessionId}`)}>
                  Back to Snapshot
                </Button>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>
                    Question {Math.min(questionsAsked, MAX_CONTINUATION_QUESTIONS)} of up to {MAX_CONTINUATION_QUESTIONS}
                  </span>
                  {done && <span className="text-accent">Wrapped up</span>}
                </div>
                <Progress
                  value={(Math.min(questionsAsked, MAX_CONTINUATION_QUESTIONS) / MAX_CONTINUATION_QUESTIONS) * 100}
                  className="h-1.5"
                />
              </div>

              <div className="max-h-[400px] space-y-3 overflow-y-auto rounded-lg border border-border bg-muted/20 p-4">
                {messages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm ${
                        m.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-card border border-border"
                      }`}
                    >
                      {m.content}
                    </div>
                  </div>
                ))}
                {generating && (
                  <div className="flex justify-start">
                    <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm text-muted-foreground">
                      <Loader2 className="h-3 w-3 animate-spin" /> Thinking…
                    </div>
                  </div>
                )}
              </div>

              {!done ? (
                <div className="flex gap-2">
                  <Textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Type your response…"
                    rows={2}
                    className="resize-none"
                    disabled={generating}
                    onKeyDown={(e) => {
                      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") handleSend();
                    }}
                  />
                  <Button
                    onClick={handleSend}
                    disabled={!input.trim() || generating}
                    size="icon"
                    className="shrink-0"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="rounded-lg border border-accent/30 bg-accent/5 p-4 text-sm">
                  We've covered enough ground for this continuation. Build the follow-up snapshot when you're ready.
                </div>
              )}

              <div className="flex flex-col gap-2 sm:flex-row">
                <Button
                  onClick={handleFinalize}
                  disabled={finalizing || (questionsAsked < 1)}
                  className="flex-1"
                >
                  {finalizing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {done ? "Build follow-up snapshot" : "I'm done — build the snapshot"}
                </Button>
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => navigate(`/snapshot/${sessionId}`)}
                >
                  Back to snapshot
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
      </MicroCalm>
    </>
  );
};

export default FollowUpFlow;
