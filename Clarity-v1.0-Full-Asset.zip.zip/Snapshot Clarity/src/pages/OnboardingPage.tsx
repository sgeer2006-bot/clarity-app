import { Helmet } from "react-helmet-async";
import { useNavigate } from "react-router-dom";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { MeetYourMind } from "@/components/ftue/MeetYourMind";
import { recordEvent } from "@/lib/identity";

const KEY = "clarity.onboarding.done";

const STEPS_NOTE = "Phase 2 — Commit J: Meet Your Mind FTUE.";

export default function OnboardingPage() {
  const navigate = useNavigate();

  const finish = () => {
    try {
      localStorage.setItem(KEY, "1");
      recordEvent({
        source: "manual",
        tags: { stability: ["onboarded"] },
      });
    } catch {
      /* ignore */
    }
    navigate("/", { replace: true });
  };

  void STEPS_NOTE;

  return (
    <div className="relative min-h-screen overflow-hidden bg-background">
      <Helmet>
        <title>Welcome — Clarity</title>
        <meta name="description" content="A short, calm welcome to Clarity." />
        <link rel="canonical" href="/onboarding" />
      </Helmet>

      {/* Ambient drift orbs — same family as the home hero */}
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-16 -z-10 h-72 w-72 -translate-x-1/2 rounded-full bg-primary/10 blur-3xl calm-drift-slow"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute right-4 bottom-24 -z-10 h-56 w-56 rounded-full bg-accent/15 blur-3xl calm-drift-fast"
      />

      <MicroCalm>
        <main className="mx-auto flex min-h-screen w-full max-w-xl flex-col items-center justify-center px-6 py-12">
          <div className="w-full">
            <MeetYourMind onComplete={finish} />
            <div className="mt-6 text-center">
              <button
                onClick={finish}
                className="text-xs text-muted-foreground/70 underline-offset-4 hover:text-muted-foreground hover:underline"
              >
                Skip introduction
              </button>
            </div>
          </div>
        </main>
      </MicroCalm>
    </div>
  );
}

