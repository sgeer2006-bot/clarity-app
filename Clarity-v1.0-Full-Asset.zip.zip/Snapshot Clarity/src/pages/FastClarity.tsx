/**
 * /fast-clarity — additive, isolated quick reflection flow.
 *
 * Reuses existing insight generation (buildInsights) and the existing
 * continuation engine (getNextStep). No new logic, no new state shape,
 * no backend, no analytics. Local component state only.
 */
import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { buildInsights, type Insight } from "@/lib/insights";
import {
  useFrequency,
  useIdentity,
  useTimeline,
  useClusters,
} from "@/hooks/usePatternData";
import { getNextStep } from "@/lib/continuation/engine";
import { InsightCard } from "@/components/patterns/insights/InsightCard";
import { TierGate, CreditMeterBanner } from "@/premium/TierGate";
import { useTier } from "@/premium/tier";
import { canPerform, recordAction } from "@/premium/limits";
import { getFastClarityContext as getFastClarityEngineData } from "@/lib/analyticalEngine/dataAdapter";
import { useAuthSession } from "@/hooks/useAuthSession";

export default function FastClarity() {
  const navigate = useNavigate();
  const [a1, setA1] = useState("");
  const [a2, setA2] = useState("");
  const [a3, setA3] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const { tier } = useTier();
  const allowed = canPerform("fast_clarity", tier);

  const freq = useFrequency();
  const identity = useIdentity();
  const timeline = useTimeline();
  const clusters = useClusters();

  const insight: Insight | null = useMemo(() => {
    if (!submitted) return null;
    const all = buildInsights({
      frequency: freq.data ?? [],
      timeline: (timeline.data ?? []) as any,
      clusters: (clusters.data ?? []) as any,
      identity: (identity.data ?? null) as any,
    });
    return all[0] ?? null;
  }, [submitted, freq.data, identity.data, timeline.data, clusters.data]);

  const step = useMemo(() => {
    if (!submitted) return null;
    return getNextStep({ lastActionType: "reflection_saved" });
  }, [submitted]);

  // Analytical Engine wiring (Phase 2, Module 6).
  // After submission, fetch the Fast Clarity engine context and derive the
  // four conceptual fields the result UI consumes. Wrapped in try/catch via
  // the adapter (which never throws) plus a local guard. If the engine
  // returns nothing useful, we fall back to the existing placeholder
  // insight + suggestion below.
  const { session } = useAuthSession();
  const userId = session?.user?.id ?? "";
  const [engineFields, setEngineFields] = useState<{
    quickInsight: string;
    emotionalAnchor: string;
    groundingCue: string;
    suggestedNextStep: string;
  } | null>(null);
  const [engineLoading, setEngineLoading] = useState(false);
  const [engineError, setEngineError] = useState(false);

  useEffect(() => {
    if (!submitted || !userId) return;
    let cancelled = false;
    setEngineLoading(true);
    setEngineError(false);
    (async () => {
      try {
        const ctx = await getFastClarityEngineData(userId);
        if (cancelled || !ctx) return;
        const quickInsight = ctx.recentPatterns?.[0]?.description ?? "";
        const emotionalAnchor = ctx.recentEmotionalSignals?.[0]?.label ?? "";
        const groundingCue = ctx.recentSituationalSignals?.[0]?.label ?? "";
        const suggestedNextStep = ctx.recentPatterns?.[1]?.description ?? "";
        if (quickInsight || emotionalAnchor || groundingCue || suggestedNextStep) {
          setEngineFields({ quickInsight, emotionalAnchor, groundingCue, suggestedNextStep });
        }
      } catch {
        // Fall back to existing placeholder insight + suggestion.
        if (!cancelled) setEngineError(true);
      } finally {
        if (!cancelled) setEngineLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [submitted, userId]);

  const engineInsight: Insight | null = useMemo(() => {
    if (!engineFields) return null;
    const bodyParts = [
      engineFields.quickInsight,
      engineFields.emotionalAnchor && `Emotional anchor: ${engineFields.emotionalAnchor}`,
      engineFields.groundingCue && `Grounding cue: ${engineFields.groundingCue}`,
    ].filter(Boolean);
    if (bodyParts.length === 0) return null;
    return {
      id: "fast-clarity-engine",
      title: "Here's the heart of what you shared",
      body: bodyParts.join(" "),
      tags: [],
      confidence: "medium",
      source: "pattern_frequency",
    } as Insight;
  }, [engineFields]);

  const canSubmit = a1.trim().length > 0;

  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <main className="mx-auto w-full max-w-2xl px-5 py-12 sm:py-16">
        <div className="mb-6"><CreditMeterBanner /></div>
        {!allowed ? (
          <TierGate action="fast_clarity" requires="free"><div /></TierGate>
        ) : !submitted ? (
          <>
            <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
              Fast Clarity
            </h1>
            <p className="mt-3 text-base text-muted-foreground">
              A quick clarity boost when your mind feels loud.
            </p>

            <form
              className="mt-8 space-y-6"
              onSubmit={(e) => {
                e.preventDefault();
                if (canSubmit) {
                  recordAction("fast_clarity", tier);
                  setSubmitted(true);
                }
              }}
            >
              <div>
                <label className="text-sm font-medium text-foreground/90">
                  What&apos;s going on for you right now?
                </label>
                <Textarea
                  value={a1}
                  onChange={(e) => setA1(e.target.value)}
                  placeholder="One sentence is plenty."
                  className="mt-2"
                  required
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground/90">
                  What&apos;s the part that feels heaviest?
                  <span className="ml-1 text-xs text-muted-foreground">(optional)</span>
                </label>
                <Textarea
                  value={a2}
                  onChange={(e) => setA2(e.target.value)}
                  placeholder="Only if you want to say more."
                  className="mt-2"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground/90">
                  What would feel a little better right now?
                  <span className="ml-1 text-xs text-muted-foreground">(optional)</span>
                </label>
                <Textarea
                  value={a3}
                  onChange={(e) => setA3(e.target.value)}
                  placeholder="A word or two is enough."
                  className="mt-2"
                />
              </div>

              <Button
                type="submit"
                size="lg"
                disabled={!canSubmit}
                className="h-12 rounded-full px-6 text-base"
              >
                Show me what I just shared
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden />
              </Button>
            </form>
          </>
        ) : (
          <>
            <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
              Here's the heart of what you shared.
            </h1>
            <p className="mt-3 text-base text-muted-foreground">
              You showed up — and that counts for more than it might feel like.
            </p>

            {engineLoading ? (
              <p className="mt-4 text-sm text-muted-foreground">Loading…</p>
            ) : engineError ? (
              <p className="mt-4 text-sm text-muted-foreground">
                Something went wrong — showing your saved version instead.
              </p>
            ) : null}

            <div className="mt-8 space-y-4">
              {engineInsight ? (
                <InsightCard insight={engineInsight} />
              ) : insight ? (
                <InsightCard insight={insight} />
              ) : (
                <div className="rounded-xl border border-border/50 bg-muted/30 p-4">
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    Nothing big to point to yet — and that&apos;s okay. What you just shared still counts.
                  </p>
                </div>
              )}

              {engineFields?.suggestedNextStep ? (
                <div className="rounded-xl border border-border/50 bg-card/40 p-4">
                  <h3 className="text-sm font-medium text-foreground/90">
                    {step?.title ?? "Here's what this could mean for you"}
                  </h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {engineFields.suggestedNextStep}
                  </p>
                </div>
              ) : step ? (
                <div className="rounded-xl border border-border/50 bg-card/40 p-4">
                  <h3 className="text-sm font-medium text-foreground/90">
                    {step.title}
                  </h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {step.body}
                  </p>
                </div>
              ) : null}
            </div>

            <div className="mt-10">
              <Button
                asChild
                size="lg"
                className="h-12 rounded-full px-6 text-base"
                onClick={() => navigate("/home")}
              >
                <Link to="/home">I&apos;m good — back home</Link>
              </Button>
            </div>
          </>
        )}

        <div className="mt-12">
        </div>
      </main>
    </div>
  );
}
