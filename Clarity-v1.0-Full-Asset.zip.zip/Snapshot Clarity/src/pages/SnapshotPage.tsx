import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Folder } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { SnapshotView } from "@/components/SnapshotView";
import { SnapshotVersionPicker } from "@/components/SnapshotVersionPicker";
import { PriorAnswersPanel, EditableAnswer } from "@/components/PriorAnswersPanel";
import { ShareSnapshotDialog } from "@/components/ShareSnapshotDialog";
import { PatternBadges } from "@/components/PatternBadges";
import { Button } from "@/components/ui/button";
import { Share2, Sparkles } from "lucide-react";
// Note: LocalResourcesCard intentionally removed from the snapshot page — the
// new "Recommended next steps", "Common misunderstandings" and "How to
// communicate" sections in SnapshotView cover this need with safer, in-context
// guidance.
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import type {
  ReflectionSessionRow,
  ReflectionAnswerRow,
  SnapshotJson,
  QuestionType,
  FolderRow,
} from "@/lib/types";
import { makeShareToken, suggestFolder, assignPatternIdentity, type AssignedPatternIdentity } from "@/lib/api";
import { PatternIdentityCard } from "@/components/PatternIdentityCard";
import { EmotionalDecodingChips } from "@/components/EmotionalDecodingChips";
import { AIRewriteCard } from "@/components/AIRewriteCard";
import { CommunicationPatternCard } from "@/components/CommunicationPatternCard";
import { toast } from "@/hooks/use-toast";
import { IdentityChips } from "@/components/identity/IdentityChips";
import { MicroContinuation } from "@/components/habit/MicroContinuation";
import { recordEvent } from "@/lib/identity";

interface Props {
  mode: "owner" | "history";
}

const SnapshotPage = ({ mode }: Props) => {
  const { snapshotId } = useParams<{ snapshotId: string }>();
  const navigate = useNavigate();
  const [session, setSession] = useState<ReflectionSessionRow | null>(null);
  const [answers, setAnswers] = useState<ReflectionAnswerRow[]>([]);
  const [folders, setFolders] = useState<FolderRow[]>([]);
  const [folderName, setFolderName] = useState<string | null>(null);
  const [autoAssigned, setAutoAssigned] = useState(false);
  const [loading, setLoading] = useState(true);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [regenOpen, setRegenOpen] = useState(false);
  const [hasEdits, setHasEdits] = useState(false);
  const [latestVersion, setLatestVersion] = useState<number | undefined>();
  const [previewSnap, setPreviewSnap] = useState<SnapshotJson | null>(null);
  const [previewVersion, setPreviewVersion] = useState<number | null>(null);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [identity, setIdentity] = useState<AssignedPatternIdentity | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data: sess } = await supabase.auth.getSession();
      if (!sess.session) {
        navigate("/auth");
        return;
      }
      const { data, error } = await supabase
        .from("reflection_sessions")
        .select("*")
        .eq("id", snapshotId!)
        .is("deleted_at", null)
        .maybeSingle();
      if (cancelled) return;
      if (error || !data) {
        navigate("/you/timeline", { replace: true });
        return;
      }
      const row: ReflectionSessionRow = {
        ...data,
        status: data.status as ReflectionSessionRow["status"],
        snapshot_json: (data.snapshot_json as unknown as SnapshotJson | null) ?? null,
        folder_id: (data as any).folder_id ?? null,
      };
      setSession(row);
      document.title = `${row.title} — Clarity`;

      const [{ data: rs }, { data: fs }, { data: vs }] = await Promise.all([
        supabase
          .from("reflection_answers")
          .select("*")
          .eq("session_id", row.id)
          .order("question_index", { ascending: true }),
        supabase
          .from("folders")
          .select("id, user_id, name, created_at")
          .eq("user_id", sess.session.user.id)
          .order("name", { ascending: true }),
        supabase
          .from("snapshot_versions")
          .select("version_number")
          .eq("session_id", row.id)
          .order("version_number", { ascending: false })
          .limit(1),
      ]);

      if (cancelled) return;
      setAnswers((rs as ReflectionAnswerRow[]) || []);
      setFolders((fs as FolderRow[]) || []);
      setLatestVersion((vs as { version_number: number }[] | null)?.[0]?.version_number);

      if (row.folder_id) {
        const f = (fs as FolderRow[] | null)?.find((x) => x.id === row.folder_id);
        if (f) setFolderName(f.name);
      } else if (row.snapshot_json) {
        // Auto-suggest a folder for fresh, uncategorized snapshots.
        try {
          const result = await suggestFolder(row.id);
          if (cancelled) return;
          setFolderName(result.folder_name);
          setAutoAssigned(true);
          const [{ data: refreshedFolders }, { data: refreshedSession }] = await Promise.all([
            supabase
              .from("folders")
              .select("id, user_id, name, created_at")
              .eq("user_id", sess.session.user.id)
              .order("name", { ascending: true }),
            supabase
              .from("reflection_sessions")
              .select("folder_id")
              .eq("id", row.id)
              .maybeSingle(),
          ]);
          if (!cancelled) {
            setFolders((refreshedFolders as FolderRow[]) || []);
            setSession((s) =>
              s
                ? { ...s, folder_id: (refreshedSession as any)?.folder_id ?? result.folder_id }
                : s,
            );
          }
        } catch {
          // Auto-categorization is best-effort.
        }
      }

      // Best-effort: assign / fetch a pattern identity for this snapshot.
      if (row.snapshot_json) {
        (async () => {
          // First, see if one is already assigned (joined fetch).
          const { data: rsWithIdentity } = await supabase
            .from("reflection_sessions")
            .select("pattern_identity_id")
            .eq("id", row.id)
            .maybeSingle();
          const existingId = (rsWithIdentity as any)?.pattern_identity_id as string | null;
          if (existingId) {
            const { data: cat } = await supabase
              .from("pattern_identities")
              .select("*")
              .eq("id", existingId)
              .maybeSingle();
            if (!cancelled && cat) setIdentity(cat as AssignedPatternIdentity);
            return;
          }
          const assigned = await assignPatternIdentity(row.id);
          if (!cancelled && assigned) setIdentity(assigned);
        })();
      }

      // Record a local identity event (deterministic, client-only).
      if (row.snapshot_json) {
        try {
          recordEvent({ source: "snapshot", tags: { emotional: ["snapshot_viewed"] } });
        } catch {
          /* ignore */
        }
      }

      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [snapshotId, navigate]);

  const moveToFolder = async (folderId: string | null) => {
    if (!session) return;
    const { error } = await supabase
      .from("reflection_sessions")
      .update({ folder_id: folderId })
      .eq("id", session.id);
    if (error) {
      toast({
        title: "Could not move",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    const f = folders.find((x) => x.id === folderId);
    setSession({ ...session, folder_id: folderId });
    setFolderName(f?.name ?? null);
    setAutoAssigned(false);
  };

  const share = async () => {
    if (!session) return;
    let token = session.share_token;
    if (!token) {
      token = makeShareToken();
      const { error } = await supabase
        .from("reflection_sessions")
        .update({ share_token: token })
        .eq("id", session.id);
      if (error) {
        toast({
          title: "Could not create share link",
          description: error.message,
          variant: "destructive",
        });
        return;
      }
      setSession({ ...session, share_token: token });
    }
    const url = `${window.location.origin}/share/${token}`;
    try {
      await navigator.clipboard.writeText(url);
      toast({ title: "Share link copied" });
    } catch {
      toast({ title: "Share link", description: url });
    }
  };

  const remove = async () => {
    if (!session) return;
    const { error } = await supabase
      .from("reflection_sessions")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", session.id);
    if (error) {
      toast({
        title: "Could not delete",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    navigate("/you/timeline", { replace: true });
  };

  if (loading || !session) {
    return (
      <>
        <TopBar />
        <main className="mx-auto max-w-content px-4 py-12">
          <p className="text-sm text-muted-foreground">Loading…</p>
        </main>
      </>
    );
  }

  const editablePriors: EditableAnswer[] = answers.map((a) => ({
    id: a.id,
    question_index: a.question_index,
    question_text: a.question_text,
    answer_text: a.answer_text,
    question_type: ((a as any).question_type ?? "open") as QuestionType,
    min_chars: (a as any).min_chars ?? 0,
  }));

  const handleEditAnswer = async (a: EditableAnswer, newValue: string) => {
    const { error } = await supabase
      .from("reflection_answers")
      .update({ answer_text: newValue })
      .eq("id", a.id);
    if (error) {
      toast({
        title: "Could not save your edit",
        description: error.message,
        variant: "destructive",
      });
      return;
    }
    setAnswers((prev) =>
      prev.map((row) => (row.id === a.id ? { ...row, answer_text: newValue } : row)),
    );
    setHasEdits(true);
    setRegenOpen(true);
  };

  const regenerate = () => {
    if (!session) return;
    setRegenOpen(false);
    navigate(`/loading/${session.id}`);
  };

  // When previewing an older version, swap snapshot_json on a shallow copy of
  // the session so SnapshotView re-renders. Don't mutate state — the original
  // session row stays intact.
  const displaySession = previewSnap
    ? { ...session, snapshot_json: previewSnap }
    : session;

  return (
    <>
      <TopBar />
      <MicroCalm>
      <main className="mx-auto max-w-content space-y-8 px-4 py-10 sm:py-14">
        <header className="space-y-2 animate-fade-in-up">
          <span className="label-eyebrow">Your snapshot</span>
        </header>
        <SnapshotView session={displaySession} answers={answers} />

        {identity && <PatternIdentityCard identity={identity} />}

        <EmotionalDecodingChips sessionId={session.id} />

        <AIRewriteCard sessionId={session.id} />

        <CommunicationPatternCard userId={session.user_id} excludeSessionId={session.id} />

        <PatternBadges sessionId={session.id} />

        <IdentityChips />

        <MicroContinuation ctx={{ lastActionType: "snapshot_saved", lastActionTs: new Date().toISOString() }} />

        <SnapshotVersionPicker
          sessionId={session.id}
          currentVersion={latestVersion}
          selectedVersion={previewVersion}
          onSelect={(snap, ver) => {
            setPreviewSnap(snap);
            setPreviewVersion(ver);
          }}
        />

        {/* Folder location + change menu */}
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-border/70 bg-muted/30 px-4 py-2.5 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Folder className="h-4 w-4" />
            <span>
              {folderName
                ? autoAssigned
                  ? <>Saved to <span className="font-medium text-foreground">{folderName}</span></>
                  : <>In <span className="font-medium text-foreground">{folderName}</span></>
                : "Uncategorized"}
            </span>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm">Change folder</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel className="text-xs">Move to</DropdownMenuLabel>
              <DropdownMenuItem
                onClick={() => moveToFolder(null)}
                disabled={!session.folder_id}
              >
                <Folder className="mr-2 h-3.5 w-3.5" />
                Uncategorized
              </DropdownMenuItem>
              {folders.map((f) => (
                <DropdownMenuItem
                  key={f.id}
                  onClick={() => moveToFolder(f.id)}
                  disabled={session.folder_id === f.id}
                >
                  <Folder className="mr-2 h-3.5 w-3.5" />
                  {f.name}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {hasEdits && (
          <div className="rounded-lg border border-accent/40 bg-accent/10 p-4">
            <p className="text-sm">
              You changed an answer. Want a fresh snapshot built from your updates?
            </p>
            <div className="mt-3 flex gap-2">
              <Button size="sm" onClick={regenerate}>
                Regenerate snapshot
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setHasEdits(false)}>
                Not now
              </Button>
            </div>
          </div>
        )}

        <PriorAnswersPanel
          answers={editablePriors}
          onSaveEdit={handleEditAnswer}
          title="Edit your answers"
          warnDownstream={false}
          renderAnswerActions={(a) => (
            <Button
              size="sm"
              variant="outline"
              onClick={() => navigate(`/pattern/answer/${a.id}`)}
            >
              <Sparkles className="mr-1.5 h-3.5 w-3.5" />
              Analyze pattern
            </Button>
          )}
        />

        

        <div className="flex flex-col gap-3 sm:flex-row">
          <Button onClick={() => navigate(`/follow-up/${session.id}`)} className="flex-1">
            Continue this conversation
          </Button>
          <Button variant="outline" onClick={() => navigate(`/correct/${session.id}`)} className="flex-1">
            Something here is wrong or missing
          </Button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <Button variant="ghost" onClick={() => navigate("/")}>
            Back to Home
          </Button>
          <div className="flex flex-wrap items-center gap-2">
            <Button
              onClick={() => setShareDialogOpen(true)}
              disabled={!session.snapshot_json}
            >
              <Share2 className="mr-2 h-4 w-4" />
              Share Snapshot
            </Button>
            <Button variant="ghost" onClick={share}>
              Copy link
            </Button>
            {mode === "history" && (
              <button
                onClick={() => setConfirmOpen(true)}
                className="text-sm text-destructive underline-offset-4 hover:underline"
              >
                Delete
              </button>
            )}
          </div>
        </div>
      </main>
      </MicroCalm>

      {session.snapshot_json && (
        <ShareSnapshotDialog
          open={shareDialogOpen}
          onOpenChange={setShareDialogOpen}
          sessionId={session.id}
          title={session.title}
          snapshot={session.snapshot_json}
        />
      )}

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this snapshot?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={remove}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={regenOpen} onOpenChange={setRegenOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Regenerate your snapshot with these changes?</AlertDialogTitle>
            <AlertDialogDescription>
              Your previous snapshot will be saved as a version, and a new one
              will be generated from your updated answers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Not now</AlertDialogCancel>
            <AlertDialogAction onClick={regenerate}>Regenerate</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default SnapshotPage;
