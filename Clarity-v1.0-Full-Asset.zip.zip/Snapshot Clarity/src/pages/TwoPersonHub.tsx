import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Plus, Users, ArrowRight, Trash2 } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import {
  TwoPersonSessionRow,
  createTwoPersonSession,
  deleteTwoPersonSession,
  inviteUrl,
  listTwoPersonSessions,
} from "@/lib/twoPerson";
import { MicroCalm } from "@/components/habit/MicroCalm";
import { recordEvent } from "@/lib/identity";
import { TierGate } from "@/premium/TierGate";

const STATUS_LABEL: Record<string, string> = {
  awaiting_invitee: "Waiting for the other person",
  awaiting_owner: "Waiting on you",
  awaiting_other: "Waiting for both",
  ready: "Ready to combine",
  complete: "Combined insight ready",
};

const TwoPersonHub = () => {
  const navigate = useNavigate();
  const [userId, setUserId] = useState<string | null>(null);
  const [sessions, setSessions] = useState<TwoPersonSessionRow[]>([]);
  const [loading, setLoading] = useState(true);

  // create dialog
  const [open, setOpen] = useState(false);
  const [topic, setTopic] = useState("");
  const [name, setName] = useState("");
  const [perspective, setPerspective] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const [pendingDelete, setPendingDelete] = useState<TwoPersonSessionRow | null>(null);

  useEffect(() => {
    document.title = "Shared Clarity — Clarity";
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase.auth.getSession();
      const uid = data.session?.user.id;
      if (!uid) {
        navigate("/auth");
        return;
      }
      setUserId(uid);
      try {
        const list = await listTwoPersonSessions(uid);
        if (!cancelled) setSessions(list);
      } catch (e) {
        console.error(e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [navigate]);

  const create = async () => {
    if (!userId) return;
    if (topic.trim().length < 3) {
      toast({ title: "Add a short topic so you can find this later." });
      return;
    }
    if (perspective.trim().length < 40) {
      toast({
        title: "Tell us a bit more",
        description: "Aim for at least a couple of sentences from your side.",
      });
      return;
    }
    setSubmitting(true);
    try {
      const session = await createTwoPersonSession({
        ownerId: userId,
        topic,
        ownerDisplayName: name,
        ownerPerspective: perspective,
      });
      setSessions((s) => [session, ...s]);
      setOpen(false);
      setTopic("");
      setName("");
      setPerspective("");
      recordEvent({
        source: "two_person",
        tags: { relational: ["two_person_session_created"] },
      });
      navigate(`/two-person/${session.id}`);
    } catch (e) {
      console.error(e);
      toast({ title: "Couldn't create session", description: "Please try again." });
    } finally {
      setSubmitting(false);
    }
  };

  const confirmDelete = async () => {
    if (!pendingDelete) return;
    try {
      await deleteTwoPersonSession(pendingDelete.id);
      setSessions((s) => s.filter((x) => x.id !== pendingDelete.id));
      toast({ title: "Session deleted" });
    } catch (e) {
      console.error(e);
      toast({ title: "Couldn't delete" });
    } finally {
      setPendingDelete(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <MicroCalm>
      <main className="mx-auto max-w-content px-4 py-8 sm:px-6 sm:py-12">
        <TierGate requires="premium"><div /></TierGate>
        <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div className="space-y-2 animate-fade-in-up">
            <span className="label-eyebrow inline-flex items-center gap-1.5">
              <Users className="h-3 w-3" aria-hidden />
              Shared Clarity
            </span>
            <h1 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
              Shared Clarity
            </h1>
            <p className="max-w-prose text-sm text-muted-foreground">
              Reflect together with someone you trust.
            </p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-full">
                <Plus className="h-4 w-4" /> New session
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Start a Shared Clarity session</DialogTitle>
                <DialogDescription>
                  Your perspective stays private until you choose to share. The other person only
                  sees what you write here after the combined insight is generated.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium" htmlFor="tp-topic">
                    Topic
                  </label>
                  <Input
                    id="tp-topic"
                    placeholder="e.g. Last weekend's argument"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    maxLength={120}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium" htmlFor="tp-name">
                    Your name (optional)
                  </label>
                  <Input
                    id="tp-name"
                    placeholder="So they know who shared"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    maxLength={60}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium" htmlFor="tp-persp">
                    Your perspective
                  </label>
                  <Textarea
                    id="tp-persp"
                    placeholder="What happened from your side, and how it landed for you."
                    value={perspective}
                    onChange={(e) => setPerspective(e.target.value)}
                    rows={6}
                    maxLength={4000}
                  />
                  <p className="text-xs text-muted-foreground">
                    {perspective.trim().length}/40 characters minimum
                  </p>
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setOpen(false)} disabled={submitting}>
                  Cancel
                </Button>
                <Button onClick={create} disabled={submitting}>
                  {submitting ? "Creating…" : "Create & invite"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </header>

        {loading ? (
          <div className="space-y-3">
            <Skeleton className="h-20 rounded-2xl" />
            <Skeleton className="h-20 rounded-2xl" />
          </div>
        ) : sessions.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border/70 bg-card/60 p-10 text-center">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Users className="h-5 w-5 text-primary" aria-hidden />
            </div>
            <h2 className="font-display text-xl font-semibold">No Shared Clarity sessions yet</h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
              Start one when you and someone close are seeing a situation differently.
            </p>
          </div>
        ) : (
          <ul className="space-y-3">
            {sessions.map((s) => (
              <li key={s.id}>
                <div className="group flex items-center gap-2 rounded-2xl border border-border/70 bg-card/80 p-4 shadow-sm transition-all hover:border-primary/30">
                  <Link
                    to={`/two-person/${s.id}`}
                    className="min-w-0 flex-1"
                  >
                    <p className="truncate font-medium">{s.topic}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {STATUS_LABEL[s.status] ?? s.status} ·{" "}
                      {new Date(s.created_at).toLocaleDateString(undefined, {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </p>
                  </Link>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="rounded-full"
                    onClick={() => {
                      navigator.clipboard.writeText(inviteUrl(s.invite_token));
                      toast({ title: "Invite link copied" });
                    }}
                  >
                    Copy link
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Delete session"
                    onClick={() => setPendingDelete(s)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <Link
                    to={`/two-person/${s.id}`}
                    className="rounded-full p-2 text-muted-foreground hover:text-foreground"
                    aria-label="Open"
                  >
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
      </MicroCalm>

      <AlertDialog open={!!pendingDelete} onOpenChange={(v) => !v && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this session?</AlertDialogTitle>
            <AlertDialogDescription>
              Both perspectives and the combined insight will be removed. The invite link will stop
              working.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default TwoPersonHub;
