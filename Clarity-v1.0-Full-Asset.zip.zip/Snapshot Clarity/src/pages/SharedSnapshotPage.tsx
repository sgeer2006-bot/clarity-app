import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { SNAPSHOT_DISCLAIMER } from "@/lib/types";
import { MicroCalm } from "@/components/habit/MicroCalm";

interface SharedRow {
  id: string;
  token: string;
  variant: "square" | "vertical";
  title: string;
  summary: string;
  observations: string[];
  possible_paths: string[];
  image_path: string | null;
  created_at: string;
}

const SharedSnapshotPage = () => {
  const { token } = useParams<{ token: string }>();
  const [row, setRow] = useState<SharedRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from("shared_snapshots")
        .select(
          "id, token, variant, title, summary, observations, possible_paths, image_path, created_at",
        )
        .eq("token", token)
        .maybeSingle();
      if (cancelled) return;
      if (error || !data) {
        setRow(null);
        setLoading(false);
        return;
      }
      const r = {
        ...data,
        observations: (data.observations as string[]) ?? [],
        possible_paths: (data.possible_paths as string[]) ?? [],
      } as SharedRow;
      setRow(r);
      if (r.image_path) {
        const { data: pub } = supabase.storage
          .from("snapshot-shares")
          .getPublicUrl(r.image_path);
        setImageUrl(pub.publicUrl);
      }
      // Fire-and-forget view counter (best-effort; ignore failures)
      supabase
        .rpc as any; // no-op: keeping RPC-free; counter increment can be added later
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [token]);

  if (loading) {
    return (
      <main className="mx-auto max-w-2xl px-6 py-16 text-center text-muted-foreground">
        Loading…
      </main>
    );
  }

  if (!row) {
    return (
      <main className="mx-auto max-w-2xl px-6 py-24 text-center">
        <h1 className="font-display text-3xl">Snapshot not found</h1>
        <p className="mt-3 text-muted-foreground">
          This link may have expired or been removed.
        </p>
        <Button asChild className="mt-6">
          <Link to="/">Go home</Link>
        </Button>
      </main>
    );
  }

  const ogTitle = `${row.title} — Clarity`;
  const ogDesc = row.summary.slice(0, 180);
  const canonical = `${window.location.origin}/s/${row.token}`;

  return (
    <>
      <Helmet>
        <title>{ogTitle}</title>
        <meta name="description" content={ogDesc} />
        <link rel="canonical" href={canonical} />
        <meta property="og:title" content={ogTitle} />
        <meta property="og:description" content={ogDesc} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={canonical} />
        {imageUrl && <meta property="og:image" content={imageUrl} />}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={ogTitle} />
        <meta name="twitter:description" content={ogDesc} />
        {imageUrl && <meta name="twitter:image" content={imageUrl} />}
      </Helmet>

      <MicroCalm>
      <main className="min-h-screen bg-background px-4 py-10 sm:py-16">
        <div className="mx-auto flex max-w-2xl flex-col gap-8">
          <header className="flex items-center justify-between">
            <Link
              to="/"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
            >
              <span className="grid h-7 w-7 place-items-center rounded-md bg-primary text-primary-foreground">
                <Sparkles className="h-4 w-4" />
              </span>
              <span className="font-display text-base">Clarity</span>
            </Link>
            <Button asChild size="sm" variant="outline">
              <Link to="/">Try Clarity</Link>
            </Button>
          </header>

          <article className="card-soft animate-fade-in-up p-6 sm:p-8">
            <h1 className="font-display text-3xl font-semibold leading-tight tracking-tight sm:text-4xl">
              {row.title}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Shared via Clarity · {new Date(row.created_at).toLocaleDateString()}
            </p>
            <hr className="my-6 border-border" />

            <h2 className="label-eyebrow">Situation</h2>
            <p className="mt-2 text-base">{row.summary}</p>

            {row.observations.length > 0 && (
              <>
                <h2 className="label-eyebrow mt-8">Things to consider</h2>
                <ul className="mt-2 list-disc space-y-2 pl-5">
                  {row.observations.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ul>
              </>
            )}

            {row.possible_paths.length > 0 && (
              <>
                <h2 className="label-eyebrow mt-8">Possible paths</h2>
                <ul className="mt-2 list-disc space-y-2 pl-5">
                  {row.possible_paths.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ul>
              </>
            )}

            <div className="mt-8 rounded-lg border border-border bg-muted/40 p-4">
              <p className="text-sm text-muted-foreground">{SNAPSHOT_DISCLAIMER}</p>
            </div>
          </article>

          <div className="rounded-xl border border-border bg-accent/10 p-6 text-center">
            <p className="font-display text-xl">
              Want a snapshot like this for your own situation?
            </p>
            <Button asChild className="mt-4">
              <Link to="/">Try Clarity free</Link>
            </Button>
          </div>
        </div>
      </main>
      </MicroCalm>
    </>
  );
};

export default SharedSnapshotPage;
