/**
 * /home — calm landing for the app.
 *
 * UI-only. Reuses existing data hooks and components. No new endpoints,
 * no new state, no logic changes.
 *
 * TODO (wording rewrite, app-wide): the broader copy pass described in
 * the spec is intentionally scoped to this commit's touched files
 * (Home, PrimaryNav, More menu). A separate UI-only commit can sweep
 * the rest of the surfaces using the same voice rules.
 */
import { useMemo } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Lightbulb, Sparkles } from "lucide-react";
import { TopBar } from "@/components/TopBar";
import { IdentityChips } from "@/components/identity/IdentityChips";
import {
  useFrequency,
  useIdentity,
} from "@/hooks/usePatternData";
import { getNextStep } from "@/lib/continuation/engine";
import { Button } from "@/components/ui/button";
import { CreditMeterBanner } from "@/premium/TierGate";

function PatternTile({ title, body }: { title: string; body: string }) {
  return (
    <article className="rounded-2xl border border-border/60 bg-card/40 p-5 backdrop-blur-sm">
      <div className="mb-2 flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary">
        <Sparkles className="h-4 w-4" aria-hidden />
      </div>
      <h3 className="text-base font-medium text-foreground/90">{title}</h3>
      <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{body}</p>
    </article>
  );
}

export default function Home() {
  const freq = useFrequency();
  const identity = useIdentity();

  const step = useMemo(
    () => getNextStep({ lastActionType: "insight_viewed" }),
    []
  );

  const top3 = (freq.data ?? []).slice(0, 3);

  const story =
    identity.data?.narrative_md?.trim() ||
    "Your story is still gathering shape. Every reflection adds another quiet line.";

  const loading = freq.isLoading || identity.isLoading;

  return (
    <div className="min-h-screen bg-background">
      <TopBar />
      <main className="mx-auto w-full max-w-2xl px-5 py-12 sm:py-16">
        <div className="mb-6"><CreditMeterBanner /></div>

        {/* Section A — Today */}
        <section aria-labelledby="today-heading">
          <h1
            id="today-heading"
            className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl"
          >
            Welcome back. Here's where you are today.
          </h1>

          <div className="mt-6">
            <IdentityChips title="Where you've been showing up" />
          </div>

          <p className="mt-6 text-lg leading-relaxed text-foreground/85">
            {step.title}
            <span className="block text-base text-muted-foreground">{step.body}</span>
          </p>
        </section>

        {/* Section B — Patterns */}
        <section aria-labelledby="patterns-heading" className="mt-14">
          <h2
            id="patterns-heading"
            className="font-display text-2xl font-semibold tracking-tight text-foreground"
          >
            What keeps quietly coming up
          </h2>

          <div className="mt-5 grid gap-4 sm:grid-cols-3">
            {loading && top3.length === 0 ? (
              <p className="text-sm text-muted-foreground sm:col-span-3">
                One sec — pulling this together for you.
              </p>
            ) : top3.length === 0 ? (
              <p className="text-sm text-muted-foreground sm:col-span-3">
                Nothing to point at yet — keep going, and this will start to fill in.
              </p>
            ) : (
              top3.map((p) => (
                <PatternTile
                  key={`${p.pattern_type}-${p.pattern_label}`}
                  title={p.pattern_label}
                  body={`Showed up ${p.raw_count} ${p.raw_count === 1 ? "time" : "times"} lately.`}
                />
              ))
            )}
          </div>
        </section>

        {/* Section C — Story */}
        <section aria-labelledby="story-heading" className="mt-14">
          <h2
            id="story-heading"
            className="font-display text-2xl font-semibold tracking-tight text-foreground"
          >
            Your story, right now
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-foreground/85">{story}</p>
        </section>

        {/* Section D — Actions */}
        <section aria-label="Next steps" className="mt-14 flex flex-col gap-3 sm:flex-row">
          <Button asChild size="lg" className="h-12 rounded-full px-6 text-base">
            <Link to="/reflect">
              Start a reflection
              <ArrowRight className="ml-2 h-4 w-4" aria-hidden />
            </Link>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="h-12 rounded-full px-6 text-base"
          >
            <Link to="/insights">
              <Lightbulb className="mr-2 h-4 w-4" aria-hidden />
              See your Daily Insights
            </Link>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="h-12 rounded-full px-6 text-base"
          >
            <Link to="/fast-clarity">Get grounded fast</Link>
          </Button>
        </section>
      </main>
    </div>
  );
}
