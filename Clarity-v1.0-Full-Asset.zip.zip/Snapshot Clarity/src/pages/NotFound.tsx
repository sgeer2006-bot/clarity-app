import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MicroCalm } from "@/components/habit/MicroCalm";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <MicroCalm>
    <div className="flex min-h-screen items-center justify-center bg-muted px-4">
      <div className="text-center">
        <h1 className="mb-4 text-4xl font-bold">We can&apos;t find that page</h1>
        <p className="mb-6 text-xl text-muted-foreground">
          No worries — let&apos;s get you back somewhere calm.
        </p>
        <Button asChild className="h-11 gap-1.5">
          <Link to="/" aria-label="Home">
            <Home className="h-4 w-4" aria-hidden="true" />
            <span>Take me home</span>
          </Link>
        </Button>
      </div>
    </div>
    </MicroCalm>
  );
};

export default NotFound;
