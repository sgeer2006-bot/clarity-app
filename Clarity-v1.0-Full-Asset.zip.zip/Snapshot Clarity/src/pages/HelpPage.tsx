import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { TopBar } from "@/components/TopBar";

const FAQS: { q: string; a: string }[] = [
  {
    q: "How do I get started?",
    a: "Just start a reflection from Home. One sentence is plenty. Clarity will take it from there — no setup, no quizzes.",
  },
  {
    q: "How do reflections actually work?",
    a: "You write what's on your mind. Clarity reads it gently, looking for patterns in your feelings, situations, and language. Over time, those patterns become small, plain-language insights.",
  },
  {
    q: "How are insights generated?",
    a: "Insights come from the threads we notice across your reflections — feelings that recur, situations that repeat, words you reach for again and again. They're observations, never instructions.",
  },
  {
    q: "What does Clarity+ unlock?",
    a: "A deeper read of you. Longer insights, the patterns under the patterns, a soft timeline of how you're changing, and a weekly summary of what mattered most. Your deeper clarity starts here.",
  },
  {
    q: "How do I cancel or change my plan?",
    a: "Open Settings → Billing and tap Manage subscription. You can cancel, switch plans, or update your card any time. If you cancel, Clarity+ stays active until the end of your current period.",
  },
  {
    q: "Is my data private?",
    a: "Always. Your reflections are yours — never sold, never shared for advertising. We treat them with the same care you do.",
  },
  {
    q: "How do I delete my data?",
    a: "Go to Settings → Privacy & data. You can delete your reflections any time. Once deleted, they're gone — no copies kept.",
  },
  {
    q: "I'm having an account issue. What do I do?",
    a: "Sign out and back in first — that resolves most things. If something still feels off, write to us using the contact link below and we'll help.",
  },
];

const TROUBLES: { t: string; fix: string }[] = [
  {
    t: "Insights aren't appearing yet.",
    fix: "Insights need a few reflections to settle in. Try one or two more and they'll start to show.",
  },
  {
    t: "The page seems stuck or blank.",
    fix: "Refresh the page. If it stays blank, sign out and back in — that resets most things gently.",
  },
  {
    t: "My subscription didn't activate.",
    fix: "Give it a minute and refresh. If Clarity+ still hasn't appeared, open Settings → Billing — and write to us if anything looks off.",
  },
  {
    t: "I can't sign in.",
    fix: "Double-check the email address and try requesting a fresh sign-in. Still stuck? Reach out and we'll get you back in.",
  },
];

export default function HelpPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Help & FAQ — Clarity</title>
        <meta name="description" content="Common questions, calm fixes, and how to reach us." />
        <link rel="canonical" href="/help" />
      </Helmet>
      <TopBar />
      <main className="mx-auto w-full max-w-2xl px-5 py-12 sm:py-16">
        <h1 className="font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
          We&apos;re here to help.
        </h1>
        <p className="mt-3 text-base text-muted-foreground">
          A short answer to most things. If you don&apos;t find what you need, just write to us.
        </p>

        <section className="mt-10">
          <h2 className="font-display text-xl font-semibold">Common questions</h2>
          <dl className="mt-4 space-y-5 text-sm leading-relaxed">
            {FAQS.map((f) => (
              <div key={f.q} className="rounded-xl border border-border/50 bg-card/30 p-4">
                <dt className="font-medium text-foreground/90">{f.q}</dt>
                <dd className="mt-1 text-muted-foreground">{f.a}</dd>
              </div>
            ))}
          </dl>
        </section>

        <section id="troubleshooting" className="mt-10">
          <h2 className="font-display text-xl font-semibold">Troubleshooting</h2>
          <ul className="mt-4 space-y-3 text-sm leading-relaxed">
            {TROUBLES.map((t) => (
              <li key={t.t} className="rounded-xl border border-border/50 bg-card/30 p-4">
                <p className="font-medium text-foreground/90">{t.t}</p>
                <p className="mt-1 text-muted-foreground">{t.fix}</p>
              </li>
            ))}
          </ul>
        </section>

        <section id="contact" className="mt-10">
          <h2 className="font-display text-xl font-semibold">Contact us</h2>
          <p className="mt-3 text-base leading-relaxed text-foreground/85">
            Write to us at <a href="mailto:hello@clarity.app" className="underline-offset-4 hover:underline">hello@clarity.app</a>. We read every message and answer like a human, because we are one.
          </p>
        </section>

        <p className="mt-12 text-center text-sm text-muted-foreground">
          <Link to="/home" className="underline-offset-4 hover:underline">Back home →</Link>
        </p>
      </main>
    </div>
  );
}
