import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Check, Loader2, Users } from "lucide-react";
import { Helmet } from "react-helmet-async";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import {
  TwoPersonInviteSummary,
  getInviteSummary,
  submitInviteePerspective,
} from "@/lib/twoPerson";
import { MicroCalm } from "@/components/habit/MicroCalm";

const TwoPersonInvite = () => {
  const { token } = useParams<{ token: string }>();
  const [info, setInfo] = useState<TwoPersonInviteSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [text, setText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!token) return;
      const summary = await getInviteSummary(token);
      if (cancelled) return;
      setInfo(summary);
      setDone(!!summary?.has_invitee_perspective);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [token]);

  const submit = async () => {
    if (!token) return;
    if (text.trim().length < 20) {
      toast({
        title: "A little more, please",
        description: "Aim for at least a sentence or two so the insight makes sense.",
      });
      return;
    }
    setSubmitting(true);
    try {
      await submitInviteePerspective(token, name, text);
      setDone(true);
      toast({ title: "Thanks — your perspective has been shared." });
    } catch (e) {
      console.error(e);
      toast({ title: "Couldn't submit", description: "Please try again." });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>You've been invited — Clarity</title>
        <meta
          name="description"
          content="Someone you know wants to hear your side of a situation."
        />
        <meta name="robots" content="noindex" />
      </Helmet>

      <header className="border-b border-border/60 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-content items-center px-4">
          <span className="font-display text-lg font-semibold tracking-tight">Clarity</span>
        </div>
      </header>

      <MicroCalm>
      <main className="mx-auto max-w-prose px-4 py-10">
        {loading ? (
          <div className="text-center text-sm text-muted-foreground">Loading…</div>
        ) : !info ? (
          <div className="rounded-2xl border border-dashed border-border/70 bg-card/60 p-10 text-center">
            <h1 className="font-display text-2xl font-semibold">This invite isn't valid</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              The link may have expired or the session was deleted.
            </p>
          </div>
        ) : done ? (
          <div className="rounded-2xl border border-primary/30 bg-card/80 p-10 text-center">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Check className="h-5 w-5 text-primary" aria-hidden />
            </div>
            <h1 className="font-display text-2xl font-semibold">Thank you for sharing.</h1>
            <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground">
              The other person can now generate a combined insight that respects both sides. You
              don't need to do anything else.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            <header className="space-y-2 text-center">
              <span className="label-eyebrow inline-flex items-center gap-1.5">
                <Users className="h-3 w-3" aria-hidden /> Shared Clarity
              </span>
              <h1 className="font-display text-3xl font-semibold tracking-tight">
                Someone wants to hear your side.
              </h1>
              <p className="mx-auto max-w-md text-sm text-muted-foreground">
                Topic: <strong className="font-medium text-foreground">{info.topic}</strong>
              </p>
            </header>

            <div className="rounded-2xl border border-border/70 bg-card/80 p-5 shadow-sm">
              <p className="text-sm leading-relaxed text-muted-foreground">
                Write what happened from your side, and how it landed for you. Your words go only to
                the person who invited you. Clarity will then summarize what both of you actually
                share underneath the friction — without taking sides.
              </p>
              <div className="mt-5 space-y-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium" htmlFor="inv-name">
                    Your name (optional)
                  </label>
                  <Input
                    id="inv-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="So they know who replied"
                    maxLength={60}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium" htmlFor="inv-text">
                    Your perspective
                  </label>
                  <Textarea
                    id="inv-text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    rows={8}
                    maxLength={4000}
                    placeholder="What happened, and how it landed for you."
                  />
                  <p className="text-xs text-muted-foreground">
                    {text.trim().length}/20 minimum
                  </p>
                </div>
                <Button onClick={submit} disabled={submitting} className="w-full rounded-full">
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Sending…
                    </>
                  ) : (
                    "Share my perspective"
                  )}
                </Button>
                <p className="text-center text-xs text-muted-foreground">
                  Clarity does not give advice. Your words are used only to generate a balanced
                  summary for both of you.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>
      </MicroCalm>
    </div>
  );
};

export default TwoPersonInvite;
