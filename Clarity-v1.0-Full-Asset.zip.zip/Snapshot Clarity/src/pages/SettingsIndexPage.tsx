import { useEffect, useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link, useNavigate } from "react-router-dom";
import {
  
  Crown,
  ExternalLink,
  LogOut,
  Mail,
  ShieldAlert,
  Sparkles,
  User as UserIcon,
} from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { QuietHeader, CalmCard } from "@/components/patterns/CalmPrimitives";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuthSession } from "@/hooks/useAuthSession";
import { useTier } from "@/premium/tier";
import { useUsage, FREE_WEEKLY_CREDITS } from "@/premium/limits";
import { getStripeEnvironment } from "@/lib/stripe/loadStripe";
import { toast } from "@/hooks/use-toast";
import { isGlobalPassEnabled, setGlobalPassEnabled } from "@/lib/flags/globalPass";
import { patchProfile } from "@/lib/userProfile/store";

/**
 * Settings — consolidated.
 *
 * What this is: a small, intentional set of working controls.
 * What it helps you do: manage your account, plan, and privacy in one place.
 *
 * Sections kept (only when they have working content): Account, Subscription
 * & Billing, Data & Privacy (account deletion via support), and Sign out.
 * Notification settings are not yet wired and are intentionally hidden.
 */

function tierLabel(t: "free" | "basic" | "premium") {
  if (t === "premium") return "Clarity+";
  if (t === "basic") return "Clarity Basic";
  return "Clarity Free";
}

export default function SettingsIndexPage() {
  const navigate = useNavigate();
  const { session, isAuthed, loading } = useAuthSession();
  const { tier } = useTier();
  const usage = useUsage();
  const [openingPortal, setOpeningPortal] = useState(false);

  const email = session?.user?.email ?? null;
  const name =
    (session?.user?.user_metadata as { full_name?: string; name?: string } | undefined)?.full_name ??
    (session?.user?.user_metadata as { name?: string } | undefined)?.name ??
    null;

  useEffect(() => {
    if (!loading && !isAuthed) navigate("/auth?next=/you", { replace: true });
  }, [loading, isAuthed, navigate]);

  const signOut = async () => {
    await supabase.auth.signOut();
    navigate("/home");
  };

  const openPortal = async () => {
    setOpeningPortal(true);
    try {
      const { data, error } = await supabase.functions.invoke("clarity-plus-portal", {
        body: {
          environment: getStripeEnvironment(),
          returnUrl: `${window.location.origin}/you`,
        },
      });
      if (error || !data?.url) throw new Error(error?.message ?? "Could not open portal");
      window.open(data.url as string, "_blank", "noopener,noreferrer");
    } catch (e: any) {
      toast({
        title: "We couldn't open your billing portal",
        description: e?.message ?? "Give it another try in a moment.",
        variant: "destructive",
      });
    } finally {
      setOpeningPortal(false);
    }
  };

  const requestDeletion = () => {
    const subject = encodeURIComponent("Delete my Clarity account");
    const body = encodeURIComponent(
      `Hi,\n\nPlease permanently delete the account associated with ${email ?? "this email"}.\n\nThank you.`
    );
    window.location.href = `mailto:support@clarity.app?subject=${subject}&body=${body}`;
  };

  const balanceLine = useMemo(() => {
    if (tier === "free") {
      return `${usage.creditsRemaining}/${FREE_WEEKLY_CREDITS} weekly credits left · resets in ${usage.daysUntilReset} ${usage.daysUntilReset === 1 ? "day" : "days"}`;
    }
    if (tier === "basic") return "Unlimited reflections · 3 Fast Clarity sessions per day";
    return "Everything unlocked";
  }, [tier, usage]);

  return (
    <>
      <Helmet>
        <title>Settings — Clarity</title>
        <meta name="description" content="Account, plan and billing, privacy — gentle controls in one place." />
        <link rel="canonical" href="/you" />
      </Helmet>
      <AppShell width="content">
        <QuietHeader
          eyebrow="Settings"
          title="Your Clarity, your way"
          lead="A small, intentional set of controls — your account, your plan, your privacy."
        />

        {/* Timeline — entry point under You */}
        <section className="mt-6">
          <SectionHeading
            title="Timeline"
            what="Your past sessions and snapshots."
            help="Browse what you've reflected on, in order."
          />
          <Link to="/you/timeline" className="group block">
            <CalmCard>
              <div className="flex items-start gap-3">
                <Sparkles className="mt-0.5 h-5 w-5 text-muted-foreground" aria-hidden />
                <div>
                  <div className="text-sm font-medium text-foreground group-hover:underline underline-offset-4">
                    Open your timeline
                  </div>
                  <p className="mt-0.5 text-sm text-muted-foreground">All your reflections in one calm view.</p>
                </div>
              </div>
            </CalmCard>
          </Link>
        </section>

        {/* Account */}
        <section className="mt-8">
          <SectionHeading
            title="Account"
            what="Your sign-in details."
            help="See the email you signed in with and update your password."
          />
          <CalmCard>
            <div className="flex items-start gap-3">
              <UserIcon className="mt-0.5 h-5 w-5 text-muted-foreground" aria-hidden />
              <div className="min-w-0 flex-1">
                {name && <div className="text-sm font-medium text-foreground">{name}</div>}
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Mail className="h-3.5 w-3.5" aria-hidden />
                  <span className="truncate">{email ?? "—"}</span>
                </div>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="outline"
                className="h-9 rounded-full"
                onClick={async () => {
                  if (!email) return;
                  const { error } = await supabase.auth.resetPasswordForEmail(email, {
                    redirectTo: `${window.location.origin}/auth`,
                  });
                  if (error) {
                    toast({ title: "Couldn't send reset email", description: error.message, variant: "destructive" });
                  } else {
                    toast({ title: "Check your inbox", description: "We sent a password reset link." });
                  }
                }}
              >
                Send password reset email
              </Button>
            </div>
          </CalmCard>
        </section>

        {/* Subscription & Billing */}
        <section className="mt-8">
          <SectionHeading
            title="Subscription & Billing"
            what="Your current plan and what's included."
            help={tier === "free" ? "Upgrade to remove weekly limits." : "Manage your plan, payment method, and invoices."}
          />
          <CalmCard>
            <div className="flex items-start gap-3">
              <Crown className="mt-0.5 h-5 w-5 text-primary" aria-hidden />
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium text-foreground">{tierLabel(tier)}</div>
                <p className="mt-0.5 text-sm text-muted-foreground">{balanceLine}</p>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {tier === "free" && (
                <>
                  <Button asChild size="sm" className="h-9 rounded-full">
                    <Link to="/clarity-plus/pricing">Upgrade</Link>
                  </Button>
                  <Button asChild size="sm" variant="outline" className="h-9 rounded-full">
                    <Link to="/clarity-plus">See what you unlock</Link>
                  </Button>
                </>
              )}
              {tier === "basic" && (
                <>
                  <Button asChild size="sm" className="h-9 rounded-full">
                    <Link to="/clarity-plus/pricing">Upgrade to Clarity+</Link>
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-9 rounded-full"
                    onClick={openPortal}
                    disabled={openingPortal}
                  >
                    {openingPortal ? "Opening…" : "Manage plan"}
                    <ExternalLink className="ml-1.5 h-3.5 w-3.5" aria-hidden />
                  </Button>
                </>
              )}
              {tier === "premium" && (
                <>
                  <Button
                    size="sm"
                    className="h-9 rounded-full"
                    onClick={openPortal}
                    disabled={openingPortal}
                  >
                    {openingPortal ? "Opening…" : "Manage plan"}
                    <ExternalLink className="ml-1.5 h-3.5 w-3.5" aria-hidden />
                  </Button>
                  <span className="self-center text-xs text-muted-foreground">You're on Clarity+.</span>
                </>
              )}
            </div>
          </CalmCard>
        </section>

        {/* Appearance — kept because it controls a real visual layer */}
        <section className="mt-8">
          <SectionHeading
            title="Appearance"
            what="The ambient calm layer behind your reflections."
            help="Tune motion, intensity, and dark/light feel."
          />
          <Link to="/settings/visual" className="group block">
            <CalmCard>
              <div className="flex items-start gap-3">
                <Sparkles className="mt-0.5 h-5 w-5 text-muted-foreground" aria-hidden />
                <div>
                  <div className="text-sm font-medium text-foreground group-hover:underline underline-offset-4">
                    Visual atmosphere
                  </div>
                  <p className="mt-0.5 text-sm text-muted-foreground">Motion, intensity, and the calm layer.</p>
                </div>
              </div>
            </CalmCard>
          </Link>
        </section>

        {/* Data & Privacy */}
        <section className="mt-8">
          <SectionHeading
            title="Data & Privacy"
            what="Your reflections are yours."
            help="Request a permanent account deletion any time."
          />
          <CalmCard>
            <div className="flex items-start gap-3">
              <ShieldAlert className="mt-0.5 h-5 w-5 text-muted-foreground" aria-hidden />
              <div>
                <div className="text-sm font-medium text-foreground">Delete your account</div>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  This permanently removes your reflections and account data. We'll confirm by email.
                </p>
              </div>
            </div>
            <div className="mt-4">
              <Button size="sm" variant="outline" className="h-9 rounded-full" onClick={requestDeletion}>
                Request account deletion
              </Button>
            </div>
          </CalmCard>
        </section>

        {/* Preview new experience (dev toggle for clarity_global_pass_v1) */}
        <section className="mt-8">
          <SectionHeading
            title="Preview new experience"
            what="An early look at the warmer welcome flow and refreshed navigation."
            help="Turn it on to try the new first-time welcome. Turn it off any time to return to the current app."
          />
          <CalmCard>
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-sm font-medium text-foreground">Try the new welcome flow</div>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  {isGlobalPassEnabled() ? "On — you'll see the new flow." : "Off — the app behaves as usual."}
                </p>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="h-9 rounded-full"
                onClick={() => {
                  setGlobalPassEnabled(!isGlobalPassEnabled());
                  window.location.reload();
                }}
              >
                {isGlobalPassEnabled() ? "Turn off" : "Turn on"}
              </Button>
            </div>
            {isGlobalPassEnabled() && (
              <div className="mt-3">
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 text-xs"
                  onClick={async () => {
                    await patchProfile({
                      ftue_a_completed: false,
                      ftue_a_completed_at: null,
                      tour_completed: false,
                      tour_completed_at: null,
                    });
                    window.location.assign("/home");
                  }}
                >
                  Replay welcome flow
                </Button>
              </div>
            )}
          </CalmCard>
        </section>

        {/* Sign out */}
        <div className="mt-10">
          <Button variant="ghost" size="sm" onClick={signOut} className="gap-2">
            <LogOut className="h-4 w-4" aria-hidden />
            Sign out
          </Button>
        </div>
      </AppShell>
    </>
  );
}

function SectionHeading({ title, what, help }: { title: string; what: string; help: string }) {
  return (
    <div className="mb-3">
      <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h2>
      <p className="mt-1 text-sm text-foreground/85"><span className="font-medium">What this is:</span> {what}</p>
      <p className="text-sm text-muted-foreground"><span className="font-medium">What it helps you do:</span> {help}</p>
    </div>
  );
}
