# Migration Guide

This document explains how to stand up the database side of the project on your own Supabase instance after purchasing this codebase.

---

## What this package does and does not include

**This package does NOT include:**

- Any database dump (no `.sql` snapshot of seller data, no `pg_dump` output)
- Any secrets, API keys, service-role keys, or `.env` values
- Any production data, user records, or row-level content

**This package DOES include:**

- The `supabase/` folder with project configuration, edge functions, and any committed migration files
- The application code in `src/` that expects a specific Supabase schema
- A schema description in `README.md` (see the **Supabase Schema** section) that you can use to recreate the database by hand if needed

You — the buyer — are responsible for creating your own Supabase project and populating it with the schema before the app will work end to end.

---

## Step 1 — Create your own Supabase project

1. Go to [supabase.com](https://supabase.com), sign in, and click **New project**.
2. Choose a name, a strong database password (save it somewhere safe), and a region.
3. Wait for the project to finish provisioning.
4. From **Project Settings → API**, copy your **Project URL**, **anon/public key**, and **Project ref** into a local `.env` file (see `README_FOR_BUYER.md` step 4 for the exact variable names).

You now have an empty Supabase project. The next step is to give it a schema.

---

## Step 2 — Recreate the schema

You have two supported options. Pick whichever fits your workflow.

### Option 1 — Use the Supabase CLI with the included `supabase/` folder (recommended)

This option uses the migration files and config already shipped in this repo.

1. Install the [Supabase CLI](https://supabase.com/docs/guides/cli) if you don't already have it.
2. From the project root, sign in and link the repo to the new project you just created:

   ```bash
   supabase login
   supabase link --project-ref your-project-ref
   ```

3. Push the schema up to your new project:

   ```bash
   supabase db push
   ```

   This applies every migration in `supabase/migrations/` (if present) to your new database in order. Review the CLI output and confirm there are no errors.

4. Verify in the Supabase dashboard (**Table Editor**) that the expected tables now exist.

### Option 2 — Manually recreate the tables from `README.md`

If you would rather not use the CLI, or if the migration files do not suit your environment, you can recreate the schema by hand.

1. Open the main `README.md` in this project root.
2. Find the **Supabase Schema** section. It documents every table, column, type, and relationship the app expects.
3. In the Supabase dashboard, go to **SQL Editor** (or **Table Editor**) and recreate each table, column, foreign key, index, and row-level-security policy described there.
4. Once your schema matches the documented spec, the app will be able to read and write against it normally.

This option takes longer but gives you full visibility into every object being created.

---

## Step 3 — Deploy the edge functions

The application also depends on the serverless edge functions stored in `supabase/functions/`. They must be deployed to your new Supabase project before the relevant app features will work.

```bash
# (Assumes you already ran `supabase login` and `supabase link` in Step 2 Option 1.)
supabase functions deploy
```

This deploys every function inside `supabase/functions/` to your linked project. If you only want to deploy a single function, use:

```bash
supabase functions deploy <function-name>
```

Configure any per-function secrets via:

```bash
supabase secrets set KEY=value
```

See the [Supabase edge functions docs](https://supabase.com/docs/guides/functions) for details on logs, invocation, and secrets management.

---

## Step 4 — Smoke test

1. Make sure your local `.env` points at the new project (see `README_FOR_BUYER.md` step 4).
2. Run `bun run dev` (or `npm run dev`).
3. Exercise the parts of the app that read and write from Supabase, and confirm that:
   - Tables receive new rows where expected
   - Edge functions respond as documented
   - Authentication (if used) succeeds end to end

If anything misbehaves, double-check that every migration applied cleanly and that all edge functions in `supabase/functions/` were deployed.

---

## Summary

You bought the code. You bring the database. Either let the Supabase CLI replay the included migrations against your new project, or recreate the schema by hand from the documentation in `README.md`. Deploy the edge functions in `supabase/functions/` to the same project, point your `.env` at it, and you're live.
