// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SECTION_LABELS: Record<string, string> = {
  summary: "Situation Summary",
  consider: "Things to Consider",
  paths: "Possible Paths",
};

function buildSystemPrompt(section: string, snapshot: any, originalAnswers: any[]) {
  const sectionLabel = SECTION_LABELS[section] || section;
  const sectionContent =
    section === "summary"
      ? snapshot.summary
      : section === "consider"
        ? (snapshot.observations || []).join("\n- ")
        : (snapshot.possible_paths || []).join("\n- ");

  return `You are helping someone think more deeply about a specific part of their situation snapshot.

The user already answered questions and received a snapshot. They want to explore the "${sectionLabel}" section more.

Here is the snapshot section they want to discuss:
---
${sectionContent}
---

Here are the user's original answers:
${originalAnswers.map((a: any, i: number) => `Q${i + 1}: ${a.question_text}\nA: ${a.answer_text}`).join("\n\n")}

Your job:
- Ask ONE simple, concrete follow-up question about this section.
- Reference specific wording from the snapshot section when relevant.
- Use plain, everyday language. No jargon, no abstract terms.
- Focus on deepening understanding, NOT recommending actions.
- If prior follow-up messages exist, build on them — don't repeat.

Words you must NEVER use: reflection, reflective, dynamic, framework, pattern, lens, construct, narrative, journey, therapeutic.

Hard rules (legal safety):
- Never give advice or recommend actions.
- Never use "you should", "you need to", "I recommend", "the best thing", "try doing".
- Frame everything as curiosity and exploration.

Output: Return ONLY the question as a single sentence. No preamble, no numbering.`;
}

const FORBIDDEN = [
  "you should", "you need to", "you must", "i recommend",
  "the best thing", "the best option", "the right choice", "try doing",
];

function containsForbidden(s: string): boolean {
  const l = s.toLowerCase();
  return FORBIDDEN.some((p) => l.includes(p));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userToken = authHeader.replace("Bearer ", "");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userErr } = await supabase.auth.getUser(userToken);
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { sessionId, section, priorMessages } = await req.json();
    if (!sessionId || !section || !["summary", "consider", "paths"].includes(section)) {
      return new Response(JSON.stringify({ error: "Invalid input" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Load session + snapshot
    const { data: session } = await supabase
      .from("reflection_sessions")
      .select("id, user_id, snapshot_json")
      .eq("id", sessionId)
      .maybeSingle();

    if (!session || session.user_id !== userData.user.id) {
      return new Response(JSON.stringify({ error: "Session not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Load original answers
    const { data: answers } = await supabase
      .from("reflection_answers")
      .select("question_text, answer_text")
      .eq("session_id", sessionId)
      .order("question_index", { ascending: true });

    const systemPrompt = buildSystemPrompt(section, session.snapshot_json || {}, answers || []);

    const messages: any[] = [{ role: "system", content: systemPrompt }];
    if (Array.isArray(priorMessages)) {
      for (const m of priorMessages) {
        messages.push({ role: m.role, content: m.content });
      }
    }
    messages.push({ role: "user", content: "Ask the next follow-up question." });

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");

    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: "google/gemini-2.5-pro", temperature: 0.4, messages }),
    });

    if (!resp.ok) {
      const text = await resp.text();
      const status = resp.status === 429 ? 429 : resp.status === 402 ? 402 : 500;
      return new Response(JSON.stringify({ error: status === 429 ? "Rate limited" : status === 402 ? "Credits exhausted" : `AI error: ${text}` }), {
        status, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await resp.json();
    let question = (data?.choices?.[0]?.message?.content ?? "").trim().replace(/^["']|["']$/g, "");

    if (!question || containsForbidden(question)) {
      return new Response(JSON.stringify({ error: "Could not generate a valid question" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ question }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    console.error("generate-follow-up error:", e);
    return new Response(JSON.stringify({ error: e.message ?? "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
