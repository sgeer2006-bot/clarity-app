// Create a Stripe Embedded Checkout session for Clarity+.
// Returns { clientSecret } so the client can mount Embedded Checkout inline.

import { createClient } from "npm:@supabase/supabase-js@2";
import { type StripeEnv, createStripeClient } from "../_shared/stripe.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const ALLOWED_PRICE_IDS = new Set([
  "clarity_plus_monthly",
  "clarity_plus_yearly",
  "clarity_plus_yearly_v2",
  "clarity_basic_monthly",
  "clarity_basic_yearly",
]);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const priceId = String(body.priceId ?? "");
    const returnUrl = String(body.returnUrl ?? "");
    const environment: StripeEnv = body.environment === "live" ? "live" : "sandbox";

    if (!ALLOWED_PRICE_IDS.has(priceId)) {
      return new Response(JSON.stringify({ error: "Invalid priceId" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!/^https?:\/\//.test(returnUrl)) {
      return new Response(JSON.stringify({ error: "Invalid returnUrl" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Optional auth: link checkout to a user when one is signed in.
    let userId: string | undefined;
    let customerEmail: string | undefined;
    const authHeader = req.headers.get("Authorization");
    if (authHeader?.startsWith("Bearer ")) {
      try {
        const supabase = createClient(
          Deno.env.get("SUPABASE_URL")!,
          Deno.env.get("SUPABASE_ANON_KEY")!,
          { global: { headers: { Authorization: authHeader } } },
        );
        const { data } = await supabase.auth.getUser();
        if (data.user) {
          userId = data.user.id;
          customerEmail = data.user.email ?? undefined;
        }
      } catch {
        /* unauthenticated checkout is allowed */
      }
    }

    const stripe = createStripeClient(environment);

    // Resolve the human-readable priceId via lookup_keys.
    const prices = await stripe.prices.list({ lookup_keys: [priceId], limit: 1 });
    if (!prices.data.length) {
      return new Response(JSON.stringify({ error: "Price not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const stripePrice = prices.data[0];

    const session = await stripe.checkout.sessions.create({
      line_items: [{ price: stripePrice.id, quantity: 1 }],
      mode: "subscription",
      ui_mode: "embedded_page",
      return_url: returnUrl,
      ...(customerEmail && { customer_email: customerEmail }),
      ...(userId && {
        client_reference_id: userId,
        metadata: { userId, plan: priceId, product: "clarity_plus" },
        subscription_data: { metadata: { userId, plan: priceId, product: "clarity_plus" } },
      }),
      ...(!userId && {
        metadata: { plan: priceId, product: "clarity_plus" },
      }),
    });

    return new Response(JSON.stringify({ clientSecret: session.client_secret }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[clarity-plus-create-checkout] error:", err);
    const message = err instanceof Error ? err.message : "Unexpected error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
