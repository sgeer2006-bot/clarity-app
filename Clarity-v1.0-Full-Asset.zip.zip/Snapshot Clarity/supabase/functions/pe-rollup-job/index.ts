// pe-rollup-job
// Idempotent batch rollup. Decays weighted scores, then triggers downstream
// updates per user. Designed to be run on a schedule (not yet wired to cron).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const DECAY = 0.97; // gentle daily decay

async function dispatch(fn: string, body: Record<string, unknown>) {
  try {
    await fetch(`${SUPABASE_URL}/functions/v1/${fn}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE_KEY}`, apikey: SERVICE_KEY },
      body: JSON.stringify(body),
    });
  } catch {}
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  try {
    const { data: freq } = await admin
      .from("pe_macro_frequency")
      .select("id, user_id, weighted_score");

    const userIds = new Set<string>();
    for (const row of freq ?? []) {
      userIds.add(row.user_id);
      const decayed = Math.max(0, Number(row.weighted_score ?? 0) * DECAY);
      await admin
        .from("pe_macro_frequency")
        .update({ weighted_score: decayed, updated_at: new Date().toISOString() })
        .eq("id", row.id);
    }

    for (const uid of userIds) {
      dispatch("pe-update-identity", { userId: uid });
      dispatch("pe-cluster-patterns", { userId: uid });
    }

    await admin.from("pe_job_runs").insert({
      job_name: "pe_rollup_job",
      status: "success",
      triggered_by: "scheduled",
      details: { users: userIds.size, frequency_rows: freq?.length ?? 0 },
      completed_at: new Date().toISOString(),
    });

    return new Response(JSON.stringify({ ok: true, users: userIds.size }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: String(e) }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  }
});
