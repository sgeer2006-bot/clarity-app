// Shared Stripe gateway client for Lovable's built-in payments.
// All Stripe API calls from edge functions MUST go through this helper.
// It routes requests through the Lovable connector gateway instead of
// hitting api.stripe.com directly — the secret stored on the project
// (STRIPE_SANDBOX_API_KEY) is a gateway connection identifier, not a
// real Stripe secret key.

import Stripe from "https://esm.sh/stripe@17.7.0?target=denonext";

export type StripeEnv = "sandbox" | "live";

const GATEWAY_BASE = "https://connector-gateway.lovable.dev/stripe";

function getKeys(env: StripeEnv) {
  const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");
  const connectionKey =
    env === "live"
      ? Deno.env.get("STRIPE_LIVE_API_KEY") ?? Deno.env.get("STRIPE_SANDBOX_API_KEY")
      : Deno.env.get("STRIPE_SANDBOX_API_KEY");
  if (!lovableApiKey) throw new Error("Missing LOVABLE_API_KEY");
  if (!connectionKey) throw new Error("Missing Stripe connection key for env: " + env);
  return { lovableApiKey, connectionKey };
}

export function createStripeClient(env: StripeEnv): Stripe {
  const { lovableApiKey, connectionKey } = getKeys(env);

  // Custom fetch that prepends the gateway base and adds the gateway
  // auth headers, while preserving Stripe SDK's path + body + headers.
  const gatewayFetch: typeof fetch = (input, init) => {
    const url = typeof input === "string" ? input : (input as Request).url;
    const path = url.replace(/^https:\/\/api\.stripe\.com/, "");
    const target = `${GATEWAY_BASE}${path}`;

    const headers = new Headers(init?.headers ?? {});
    headers.set("Authorization", `Bearer ${lovableApiKey}`);
    headers.set("X-Connection-Api-Key", connectionKey);
    return fetch(target, { ...init, headers });
  };

  return new Stripe(connectionKey, {
    apiVersion: "2025-04-30.basil",
    httpClient: Stripe.createFetchHttpClient(gatewayFetch),
  });
}

export function getWebhookSecret(env: StripeEnv): string {
  const secret =
    env === "live"
      ? Deno.env.get("PAYMENTS_LIVE_WEBHOOK_SECRET") ??
        Deno.env.get("PAYMENTS_SANDBOX_WEBHOOK_SECRET")
      : Deno.env.get("PAYMENTS_SANDBOX_WEBHOOK_SECRET");
  if (!secret) throw new Error("Missing payments webhook secret for env: " + env);
  return secret;
}
