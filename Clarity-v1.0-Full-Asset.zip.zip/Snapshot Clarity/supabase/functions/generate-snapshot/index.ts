// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const DISCLAIMER =
  "This tool does not give advice. It generates general perspectives based solely on the information you provide. You are responsible for your own decisions.";

const SYSTEM_PROMPT = `You generate a neutral snapshot of a tricky situation someone shared with you.

Produce a snapshot containing:
1. "summary": a short, plain-language recap of the situation as the user described it. No interpretation, no labels, no diagnosis.
2. "observations": 3–5 short notes about things to consider — gaps, tensions, or unspoken pieces — framed as possibilities, NOT conclusions.
3. "possible_paths": 3–5 general perspectives that some people consider in situations like this. Each one must be framed as "some people…" or "one possibility is…" — NEVER as a recommendation.
4. "recommended_next_steps": 3–5 gentle, specific things the user could consider doing next. Always frame as "you could consider…", "one option is…", or "some people choose to…". Never directive. These must be concrete and grounded in what the user actually said — not generic advice.
5. "common_misunderstandings": 3–5 short notes on what the OTHER person involved might be misreading, missing, or interpreting differently. Frame neutrally — never blame either side. Use "they might be reading this as…" or "it's possible they understood…".
6. "how_to_communicate": 3–5 short phrasing ideas the user could adapt when they talk about this. Each item is ONE example sentence in quotes plus a brief note on when it might fit. Use first-person "I" statements that name a feeling and a need — never accusations. Example shape: "\\"I felt X when Y happened, and I'd like Z\\" — for when you want to be heard without putting them on the defensive."

Style rules:
- Use plain, everyday language. Roughly a 6th-grade reading level.
- Refer to what the user shared as "what you shared" or "the situation you described" — never "your reflection".
- Do not assign blame to anyone. Do not diagnose or label anyone's behavior.

Hard rules (legal safety):
- Never give advice.
- Never recommend actions.
- Never use phrases like "you should", "you need to", "I recommend", "the right choice", "the best option", "try doing", "the best thing", or any directive instruction.
- Frame everything as perspective or possibility.

Return strict JSON with this schema:
{
  "summary": string,
  "observations": string[3 to 5],
  "possible_paths": string[3 to 5],
  "recommended_next_steps": string[3 to 5],
  "common_misunderstandings": string[3 to 5],
  "how_to_communicate": string[3 to 5]
}
Return JSON only. No prose before or after.`;

const FORBIDDEN = [
  "you should",
  "you need to",
  "you must",
  "i recommend",
  "the right choice",
  "the best thing",
  "the best option",
  "try doing",
];

function containsForbidden(strs: string[]): boolean {
  const joined = strs.join(" ").toLowerCase();
  return FORBIDDEN.some((p) => joined.includes(p));
}

// Rewrite common directive phrases into permitted, perspective-framed equivalents.
// This is a best-effort softener so a single stray phrase doesn't kill the whole snapshot.
const SOFTENERS: Array<[RegExp, string]> = [
  [/\byou should consider\b/gi, "you could consider"],
  [/\byou should try\b/gi, "one option is to try"],
  [/\byou should\b/gi, "you could"],
  [/\byou need to\b/gi, "you might want to"],
  [/\byou must\b/gi, "you might"],
  [/\bi recommend\b/gi, "one possibility is"],
  [/\bthe right choice\b/gi, "one possible path"],
  [/\bthe best thing\b/gi, "one thing"],
  [/\bthe best option\b/gi, "one option"],
  [/\btry doing\b/gi, "one option is"],
];

function softenString(s: string): string {
  let out = s;
  for (const [re, repl] of SOFTENERS) out = out.replace(re, repl);
  return out;
}

function softenSnapshot(obj: any): any {
  return {
    ...obj,
    summary: softenString(obj.summary),
    observations: obj.observations.map(softenString),
    possible_paths: obj.possible_paths.map(softenString),
    recommended_next_steps: obj.recommended_next_steps.map(softenString),
    common_misunderstandings: obj.common_misunderstandings.map(softenString),
    how_to_communicate: obj.how_to_communicate.map(softenString),
  };
}

function isStringArrayInRange(v: any, min: number, max: number): boolean {
  return (
    Array.isArray(v) &&
    v.length >= min &&
    v.length <= max &&
    v.every((s: any) => typeof s === "string" && s.trim().length > 0)
  );
}

function validateShape(obj: any): obj is {
  summary: string;
  observations: string[];
  possible_paths: string[];
  recommended_next_steps: string[];
  common_misunderstandings: string[];
  how_to_communicate: string[];
} {
  if (!obj || typeof obj !== "object") return false;
  if (typeof obj.summary !== "string" || obj.summary.trim().length === 0) return false;
  if (!isStringArrayInRange(obj.observations, 3, 5)) return false;
  if (!isStringArrayInRange(obj.possible_paths, 3, 5)) return false;
  if (!isStringArrayInRange(obj.recommended_next_steps, 3, 5)) return false;
  if (!isStringArrayInRange(obj.common_misunderstandings, 3, 5)) return false;
  if (!isStringArrayInRange(obj.how_to_communicate, 3, 5)) return false;
  return true;
}

async function callLLM(userPayload: string, strict: boolean): Promise<any> {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");

  const messages: any[] = [{ role: "system", content: SYSTEM_PROMPT }];
  if (strict) {
    messages.push({
      role: "system",
      content: "The previous output violated rules. Regenerate strictly. Return JSON only.",
    });
  }
  messages.push({ role: "user", content: userPayload });

  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-pro",
      temperature: 0.3,
      response_format: { type: "json_object" },
      messages,
    }),
  });

  if (!resp.ok) {
    const text = await resp.text();
    if (resp.status === 429) throw new Error("RATE_LIMITED");
    if (resp.status === 402) throw new Error("PAYMENT_REQUIRED");
    throw new Error(`LLM error ${resp.status}: ${text}`);
  }

  const data = await resp.json();
  const content = data?.choices?.[0]?.message?.content ?? "";
  try {
    return JSON.parse(content);
  } catch {
    return null;
  }
}

function buildTextSnapshot(snap: {
  summary: string;
  observations: string[];
  possible_paths: string[];
  recommended_next_steps: string[];
  common_misunderstandings: string[];
  how_to_communicate: string[];
}) {
  const lines: string[] = [];
  lines.push("Situation Summary");
  lines.push(snap.summary);
  lines.push("");
  lines.push("Things to Consider");
  for (const o of snap.observations) lines.push(`- ${o}`);
  lines.push("");
  lines.push("Possible Paths");
  for (const p of snap.possible_paths) lines.push(`- ${p}`);
  lines.push("");
  lines.push("Recommended Next Steps");
  for (const p of snap.recommended_next_steps) lines.push(`- ${p}`);
  lines.push("");
  lines.push("Common Misunderstandings");
  for (const p of snap.common_misunderstandings) lines.push(`- ${p}`);
  lines.push("");
  lines.push("How to Communicate");
  for (const p of snap.how_to_communicate) lines.push(`- ${p}`);
  lines.push("");
  lines.push(DISCLAIMER);
  return lines.join("\n");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) {
      console.log("generate-snapshot: missing auth");
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userToken = authHeader.replace("Bearer ", "");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userErr } = await supabase.auth.getUser(userToken);
    if (userErr || !userData?.user) {
      console.log("generate-snapshot: getUser failed", userErr?.message);
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = userData.user.id;

    const { sessionId } = await req.json();
    if (!sessionId || typeof sessionId !== "string") {
      return new Response(JSON.stringify({ error: "Missing sessionId" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log("generate-snapshot: start", { sessionId, userId });

    const { data: session } = await supabase
      .from("reflection_sessions")
      .select("id, title, user_id, status")
      .eq("id", sessionId)
      .maybeSingle();
    if (!session || session.user_id !== userId) {
      return new Response(JSON.stringify({ error: "Session not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: answers } = await supabase
      .from("reflection_answers")
      .select("question_index, question_text, answer_text")
      .eq("session_id", sessionId)
      .order("question_index", { ascending: true });

    if (!answers || answers.length < 1) {
      return new Response(JSON.stringify({ error: "No answers found for this session." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userPayload = JSON.stringify({
      title: session.title,
      answers: answers.map((r: any) => ({ q: r.question_text, a: r.answer_text })),
    });

    let result: any = null;
    let attempt = 0;
    let lastErr: string | null = null;

    while (attempt < 3) {
      try {
        console.log("generate-snapshot: calling AI, attempt", attempt + 1);
        const out = await callLLM(userPayload, attempt > 0);
        if (out && validateShape(out)) {
          // Soften any directive phrasing the model slipped in.
          const softened = softenSnapshot(out);
          const allStrings = [
            softened.summary,
            ...softened.observations,
            ...softened.possible_paths,
            ...softened.recommended_next_steps,
            ...softened.common_misunderstandings,
            ...softened.how_to_communicate,
          ];
          if (!containsForbidden(allStrings)) {
            result = softened;
            break;
          } else {
            lastErr = "forbidden_phrase";
          }
        } else {
          lastErr = "shape_invalid";
        }
      } catch (e: any) {
        lastErr = e.message || "llm_error";
        if (lastErr === "RATE_LIMITED" || lastErr === "PAYMENT_REQUIRED") break;
      }
      attempt++;
    }

    if (!result) {
      console.log("generate-snapshot: failed", lastErr);
      await supabase
        .from("reflection_sessions")
        .update({ status: "in_progress" })
        .eq("id", sessionId);

      const status =
        lastErr === "RATE_LIMITED" ? 429 : lastErr === "PAYMENT_REQUIRED" ? 402 : 500;
      const message =
        lastErr === "RATE_LIMITED"
          ? "Rate limit exceeded. Please try again shortly."
          : lastErr === "PAYMENT_REQUIRED"
            ? "AI credits exhausted. Please add credits to your workspace."
            : "Could not generate a valid snapshot.";
      return new Response(JSON.stringify({ error: message }), {
        status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const snapshotJson = {
      summary: result.summary,
      observations: result.observations,
      possible_paths: result.possible_paths,
      recommended_next_steps: result.recommended_next_steps,
      common_misunderstandings: result.common_misunderstandings,
      how_to_communicate: result.how_to_communicate,
      disclaimer: DISCLAIMER,
    };
    const snapshotText = buildTextSnapshot(result);

    // ----- Title generator (two-stage) -----
    // Best-effort: never block snapshot save on title failure.
    let generatedTitle: string | null = null;
    try {
      generatedTitle = await generateSituationTitle(result.summary, userPayload);
    } catch (e) {
      console.log("title generation failed (non-fatal):", (e as any)?.message);
    }

    const updatePayload: any = {
      status: "complete",
      snapshot: snapshotText,
      snapshot_json: snapshotJson,
      completed_at: new Date().toISOString(),
    };
    if (generatedTitle) updatePayload.title = generatedTitle;

    const { error: updErr } = await supabase
      .from("reflection_sessions")
      .update(updatePayload)
      .eq("id", sessionId);

    if (updErr) {
      console.error("generate-snapshot: save failed", updErr);
      return new Response(JSON.stringify({ error: "Failed to save snapshot" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Save a version row so re-generations after edits are tracked.
    const { data: lastVer } = await supabase
      .from("snapshot_versions")
      .select("version_number")
      .eq("session_id", sessionId)
      .order("version_number", { ascending: false })
      .limit(1)
      .maybeSingle();
    const nextVersion = ((lastVer?.version_number as number | undefined) ?? 0) + 1;
    await supabase.from("snapshot_versions").insert({
      session_id: sessionId,
      version_number: nextVersion,
      summary: snapshotJson.summary,
      observations: snapshotJson.observations,
      possible_paths: snapshotJson.possible_paths,
      recommended_next_steps: snapshotJson.recommended_next_steps,
      common_misunderstandings: snapshotJson.common_misunderstandings,
      how_to_communicate: snapshotJson.how_to_communicate,
      disclaimer: DISCLAIMER,
    });

    console.log("generate-snapshot: success v" + nextVersion);
    return new Response(JSON.stringify({ snapshot: snapshotJson, version: nextVersion }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    console.error("generate-snapshot error:", e);
    return new Response(JSON.stringify({ error: e.message ?? "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

// ----------------- Two-stage situation title generator -----------------
const BANNED_TITLE_TOKENS = [
  "situation", "issue", "problem", "conversation", "talk", "discussion", "matter", "thing",
];

function isValidTitle(title: string): boolean {
  if (!title) return false;
  const wc = title.trim().split(/\s+/).filter(Boolean).length;
  if (wc < 4 || wc > 8) return false;
  const lower = title.toLowerCase();
  for (const t of BANNED_TITLE_TOKENS) {
    // Word-boundary match so e.g. "talk" doesn't reject "talking" — but the
    // banned list is a stop-list of generic nouns, so reject as substring with \b.
    const re = new RegExp(`\\b${t}\\b`, "i");
    if (re.test(lower)) return false;
  }
  return true;
}

async function callTitleLLM(prompt: string, temperature: number): Promise<string> {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");
  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      temperature,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (!resp.ok) throw new Error(`title LLM ${resp.status}`);
  const data = await resp.json();
  let text = String(data?.choices?.[0]?.message?.content ?? "").trim();
  // Strip surrounding quotes / trailing punctuation
  text = text.replace(/^["'`]+|["'`.!?]+$/g, "").trim();
  return text;
}

async function generateSituationTitle(summary: string, userPayload: string): Promise<string | null> {
  // Stage 1 — extract relationship + tension + emotion
  const stage1Prompt = `Read the following situation summary and the original Q&A. Output a single line of JSON with three fields:
{"relationship":"<one phrase, e.g. partner, mother, coworker, close friend>","tension":"<one short phrase capturing the core tension>","emotion":"<one word, the dominant emotion>"}

Summary: ${summary}

Original Q&A (JSON): ${userPayload.slice(0, 4000)}

Return JSON only.`;
  let cues: { relationship?: string; tension?: string; emotion?: string } = {};
  try {
    const raw = await callTitleLLM(stage1Prompt, 0.2);
    const m = raw.match(/\{[\s\S]*\}/);
    if (m) cues = JSON.parse(m[0]);
  } catch (_) { /* fall through */ }

  // Stage 2 — produce title with up to 3 retries on validation failure
  const oneLineSummary = summary.split(/[.!?]\s/)[0].slice(0, 200);
  const stage2 = (regenNote: string) => `Write a short, specific, emotionally accurate title (4–8 words) for this situation. The title MUST:
- name the relationship or context
- name the core tension
- carry the emotional tone
- AVOID these generic words entirely: situation, issue, problem, conversation, talk, discussion, matter, thing
- be human and conversational
${regenNote}

Input:
- relationship: ${cues.relationship ?? "(unknown)"}
- tension: ${cues.tension ?? "(unknown)"}
- emotion: ${cues.emotion ?? "(unknown)"}
- summary: ${oneLineSummary}

Output ONLY the title, no quotes, no punctuation at the end.`;

  for (let attempt = 0; attempt < 3; attempt++) {
    const note = attempt === 0
      ? ""
      : `Your previous attempt was rejected because it was either out of length (4-8 words) or contained a banned generic word. Try again with concrete, emotionally specific language.`;
    try {
      const t = await callTitleLLM(stage2(note), 0.55 + attempt * 0.1);
      if (isValidTitle(t)) return t;
    } catch (_) { /* try next */ }
  }
  return null;
}
