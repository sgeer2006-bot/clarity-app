// deno-lint-ignore-file no-explicit-any
// Engine v2 (corrected): ContextModel-driven question engine.
// Single LLM call with structured tool-calling extracts the updated ContextModel
// AND emits the next question (or a repair message). Persists ContextModel +
// question_history server-side. Enforces no-repeat (Jaccard 0.35 over last 6 +
// field-subset rejection), forbids targeting already-filled fields, requires
// 3-5 fields_targeted, repair triggers, minimal-user mode, no-delta exit,
// hard cap 10 (5 in minimal mode), early exit at 70% saturation or <3 under-
// filled fields remaining.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const HARD_CAP = 10;
const MINIMAL_CAP = 5;
const SATURATION_EXIT = 70; // /100 (== 0.70)
const MINIMAL_SATURATION_EXIT = 55;
const MIN_TARGET_FIELDS = 3;
const MAX_TARGET_FIELDS = 5;

const ALL_FIELDS = [
  "situation",
  "emotions",
  "intentions",
  "triggers",
  "expectations",
  "fears",
  "desired_outcome",
  "relationships",
  "history",
  "unspoken_needs",
] as const;
type FieldName = typeof ALL_FIELDS[number];

const PRIORITY_FIELDS: FieldName[] = [
  "situation", "emotions", "desired_outcome", "intentions",
  "triggers", "fears", "expectations", "unspoken_needs",
  "relationships", "history",
];

const BANNED_ELABORATION_PHRASES = [
  "can you tell me more",
  "could you elaborate",
  "please share more detail",
  "i need more information",
  "more detail",
  "elaborate",
];

const BANNED_CLINICAL_TERMS = [
  "dynamic", "framework", "lens", "construct", "narrative", "journey",
  "therapeutic", "reflection", "reflective",
];

// ---- Fix 3: safe fallback questions (used when sanity check exhausts retries) ----
const FALLBACK_QUESTIONS: { question: string; target_fields: FieldName[] }[] = [
  { question: "What feeling came up most strongly for you in this moment, and what did you most wish they understood?", target_fields: ["emotions", "unspoken_needs", "intentions"] },
  { question: "What outcome would actually feel okay to you here, and what's the part you're most afraid of?", target_fields: ["desired_outcome", "fears", "intentions"] },
  { question: "What were you hoping for going in, and where did things start to feel different than you expected?", target_fields: ["expectations", "situation", "emotions"] },
];

// ---- Fix 4: UI fallback shape ----
function makeUiFallback(message: string) {
  return { mode: "fallback_input", message, allow_freeform: true, retry_available: true };
}

// ---- Cross-cutting: tiny structured logger ----
function logEvent(eventName: string, payload: Record<string, unknown>) {
  try { console.info(`[engine-v2:${eventName}]`, JSON.stringify(payload)); } catch { /* noop */ }
}

// ---- Fix 1: Hard reset (adapted to current schema) ----
// Clears question_history, reflection_answers, and session_context_models for this session.
async function hardResetSession(supabase: any, sessionId: string, userId: string) {
  const reset_at = new Date().toISOString();
  // Verify ownership before destructive action
  const { data: own } = await supabase
    .from("reflection_sessions").select("id, user_id").eq("id", sessionId).maybeSingle();
  if (!own || own.user_id !== userId) throw new Error("reset_not_authorized");
  await Promise.all([
    supabase.from("question_history").delete().eq("session_id", sessionId),
    supabase.from("reflection_answers").delete().eq("session_id", sessionId),
    supabase.from("session_context_models").delete().eq("session_id", sessionId),
  ]);
  logEvent("hard_reset", { sessionId, reset_at });
  return { sessionId, session_reset_at: reset_at };
}

// ---- Fix 2: State mismatch detector + auto-repair (adapted) ----
// In this architecture, the client passes priorAnswers and the server stores
// reflection_answers + question_history. A mismatch means client and server
// disagree on how many turns have happened. We auto-repair by trimming
// priorAnswers down to the server's source-of-truth count rather than rejecting.
function detectStateMismatch(priorAnswers: any[], storedAnswerCount: number): boolean {
  return Array.isArray(priorAnswers) && priorAnswers.length !== storedAnswerCount;
}
function autoRepairPriorAnswers(priorAnswers: any[], storedAnswerCount: number) {
  const before = priorAnswers.length;
  const repaired = priorAnswers.slice(0, storedAnswerCount);
  logEvent("state_repaired", { before, after: repaired.length, stored: storedAnswerCount });
  return { repaired, state_repaired: true, before, after: repaired.length };
}

// ---- Fix 3: Question sanity-check ----
function sanityCheckQuestion(
  question: string,
  targets: string[],
  history: string[],
): { valid: boolean; reason: string | null } {
  if (typeof question !== "string") return { valid: false, reason: "not_string" };
  const q = question.trim();
  if (q.length < 10) return { valid: false, reason: "too_short" };
  if (q.length > 2000) return { valid: false, reason: "too_long" };
  const placeholders = ["{{", "}}", "undefined", "[object Object]", "TODO"];
  const lower = q.toLowerCase();
  for (const p of placeholders) {
    if (lower.includes(p.toLowerCase())) return { valid: false, reason: `placeholder:${p}` };
  }
  if (lower.includes(" null ") || lower.endsWith(" null") || lower.startsWith("null ")) {
    return { valid: false, reason: "placeholder:null" };
  }
  const norm = (s: string) => s.toLowerCase().trim().replace(/\s+/g, " ");
  const qn = norm(q);
  for (const h of history) {
    if (norm(String(h ?? "")) === qn) return { valid: false, reason: "duplicate_in_history" };
  }
  if (!Array.isArray(targets) || targets.length < 2) {
    return { valid: false, reason: "insufficient_targets" };
  }
  return { valid: true, reason: null };
}

// 12 therapy-style layered scaffolds. Each scaffold targets 3-5 fields.
const SCAFFOLDS: { template: string; fields: FieldName[] }[] = [
  { template: "When [trigger], what were you feeling underneath, and what did you wish they'd understood?", fields: ["triggers", "emotions", "unspoken_needs", "intentions"] },
  { template: "What would real resolution look like to you here, and what are you most afraid will happen instead?", fields: ["desired_outcome", "fears", "intentions"] },
  { template: "How do you usually handle moments like this with them, and what feels different this time?", fields: ["history", "relationships", "situation", "emotions"] },
  { template: "What did you most hope they'd say or do, and what did they actually do that landed differently?", fields: ["expectations", "situation", "emotions", "unspoken_needs"] },
  { template: "When this comes up, what's the deepest fear underneath it, and what would you need to feel safer?", fields: ["fears", "emotions", "desired_outcome", "unspoken_needs"] },
  { template: "What were you trying to communicate underneath the words, and what do you think they heard instead?", fields: ["intentions", "unspoken_needs", "situation"] },
  { template: "What's the relationship like between you two on a normal day, and how does this moment fit into that?", fields: ["relationships", "history", "situation"] },
  { template: "What part of this feels familiar from earlier in the relationship, and what feels new?", fields: ["history", "triggers", "emotions"] },
  { template: "If they could really see what's going on for you, what would you want them to understand first?", fields: ["unspoken_needs", "emotions", "intentions"] },
  { template: "What outcome would feel like 'good enough' here, and what would feel like a complete loss?", fields: ["desired_outcome", "fears", "expectations"] },
  { template: "What set this off for you in the moment, and what was the feeling that came up first?", fields: ["triggers", "emotions", "situation"] },
  { template: "What were you hoping for going into this, and where did the gap between hope and reality start to show?", fields: ["expectations", "desired_outcome", "situation", "emotions"] },
];

interface ContextModel {
  situation: string;
  emotions: string[];
  intentions: string[];
  triggers: string[];
  expectations: string[];
  fears: string[];
  desired_outcome: string;
  relationships: string[];
  history: string[];
  unspoken_needs: string[];
}

const EMPTY_MODEL: ContextModel = {
  situation: "", emotions: [], intentions: [], triggers: [], expectations: [],
  fears: [], desired_outcome: "", relationships: [], history: [], unspoken_needs: [],
};

function isEmpty(v: unknown): boolean {
  if (v == null) return true;
  if (typeof v === "string") return v.trim().length === 0;
  if (Array.isArray(v)) return v.length === 0;
  return false;
}

function computeCoverage(model: ContextModel) {
  const map: Record<string, "empty" | "partial" | "filled"> = {};
  let score = 0;
  for (const f of ALL_FIELDS) {
    const v = (model as any)[f];
    if (isEmpty(v)) map[f] = "empty";
    else if (typeof v === "string" && v.trim().length < 25) map[f] = "partial";
    else if (Array.isArray(v) && v.length === 1) map[f] = "partial";
    else map[f] = "filled";
    score += map[f] === "filled" ? 10 : map[f] === "partial" ? 5 : 0;
  }
  return { map, score };
}

function underFilledFields(map: Record<string, string>): FieldName[] {
  return ALL_FIELDS.filter((f) => map[f] !== "filled");
}

function tokenize(s: string): string[] {
  return s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((w) => w.length >= 4);
}

function jaccard(a: string, b: string): number {
  const sa = new Set(tokenize(a));
  const sb = new Set(tokenize(b));
  if (sa.size === 0 || sb.size === 0) return 0;
  let inter = 0;
  sa.forEach((w) => { if (sb.has(w)) inter++; });
  return inter / new Set([...sa, ...sb]).size;
}

function isSubsetOfAny(candidate: string[], priorSets: string[][]): boolean {
  if (candidate.length === 0) return false;
  const cs = new Set(candidate);
  return priorSets.some((p) => {
    if (p.length === 0) return false;
    const ps = new Set(p);
    for (const c of cs) if (!ps.has(c)) return false;
    return true; // candidate ⊆ p
  });
}

function isRepeat(q: string, history: string[]): boolean {
  if (!q.trim()) return true;
  return history.some((h) => h.trim().toLowerCase() === q.trim().toLowerCase() || jaccard(q, h) >= 0.35);
}

function containsBanned(text: string, list: string[]): boolean {
  const l = text.toLowerCase();
  return list.some((p) => l.includes(p));
}

function tokenCount(s: string): number {
  return s.trim().split(/\s+/).filter(Boolean).length;
}

// Section 12: Timeline question detection (history.* targeting)
const TIMELINE_KEYWORDS = [
  "what happened", "what happened next", "what happened after", "what happened because",
  "how did it end", "how did this end", "how it ended", "what came next",
  "after that", "before that", "what came before", "led up to",
  "the sequence", "timeline", "first, then", "what occurred",
];
function isTimelineQuestion(q: string, targets: string[]): boolean {
  if (targets.includes("history")) return true;
  const l = q.toLowerCase();
  return TIMELINE_KEYWORDS.some((k) => l.includes(k));
}

// Interpretation / meaning loop breaker — pattern-based detector.
// (Interpretation is not a separate ContextModel field; it's a question pattern
// that recurs across situation/expectations/intentions/unspoken_needs/emotions.)
const INTERPRETATION_KEYWORDS = [
  "why did you think",
  "why do you think",
  "what made you think",
  "what made you feel",
  "what made you believe",
  "why did it seem like",
  "why did it feel like",
  "what did they say that made you",
  "what did she say that made you",
  "what did he say that made you",
  "what made you feel she",
  "what made you feel he",
  "what made you feel they",
  "who do you think they meant",
  "who did they mean",
  "how did you know it was about you",
  "how did you know she meant",
  "how did you know he meant",
  "how did you know they meant",
  "what made it feel personal",
  "what convinced you",
];
function isInterpretationQuestion(q: string): boolean {
  const l = q.toLowerCase();
  return INTERPRETATION_KEYWORDS.some((k) => l.includes(k));
}

// Has the user already provided substantive interpretation content in any answer?
// Matches phrases like "she meant me", "looking right at me", "everyone knew", "the way she said it".
const INTERPRETATION_ANSWER_CUES = [
  "meant me", "meant us", "she meant", "he meant", "they meant",
  "about me", "about us", "directed at me", "aimed at me", "talking about me", "talking to me",
  "looking right at me", "looking at me", "stared at me", "glanced at me",
  "everyone knew", "obvious", "obviously", "clearly", "no doubt",
  "the way she said", "the way he said", "the way they said",
  "tone of voice", "her tone", "his tone", "their tone",
  "made it personal", "felt personal", "took it personally",
  "i thought she meant", "i thought he meant", "i thought they meant",
  "i felt targeted", "i felt singled out",
];
function answerHasInterpretationContent(answer: string): boolean {
  const l = (answer || "").toLowerCase();
  if (l.trim().length < 4) return false;
  return INTERPRETATION_ANSWER_CUES.some((k) => l.includes(k));
}

// ============================================================================
// IRRELEVANT DETAIL FILTER (IDF)
// Rejects questions about age/time/location/logistics/physical/numeric details
// UNLESS tied to safety / legality / emotional meaning / responsibility /
// fairness / risk.
// ============================================================================
const IRRELEVANT_DETAIL_PATTERNS = [
  "how old is", "how old are", "how old was", "what age", "what's their age",
  "what time", "what day", "what date", "what month", "what year",
  "where were you", "where was", "where did this happen", "what location",
  "what color", "what colour", "what were they wearing", "how tall", "how big",
  "how many", "how much", "what number", "how often per day", "how often per week",
  "what's the schedule", "what time of day", "what's their address", "what street",
];
const SAFETY_RISK_FAIRNESS_TIE = [
  "safe", "safety", "danger", "dangerous", "harm", "hurt", "violence", "violent",
  "abuse", "abusive", "threat", "threaten", "scared for", "afraid for",
  "legal", "law", "police", "court", "custody", "lawyer",
  "fair", "unfair", "fairness", "responsib", "blame", "fault",
  "risk", "risky", "consequence", "what's at stake",
];
function isIrrelevantDetailQuestion(q: string): boolean {
  const l = q.toLowerCase();
  const matchesIrrelevant = IRRELEVANT_DETAIL_PATTERNS.some((p) => l.includes(p));
  if (!matchesIrrelevant) return false;
  const tiedToMeaning = SAFETY_RISK_FAIRNESS_TIE.some((p) => l.includes(p));
  return !tiedToMeaning;
}

// ============================================================================
// USER REJECTION DETECTOR (URD)
// Detects when the user has signaled a field/topic doesn't matter.
// Returns the matched phrase (or null).
// ============================================================================
const REJECTION_PHRASES = [
  "it doesn't matter", "it does not matter", "doesnt matter", "doesn't matter",
  "that's not important", "thats not important", "not important",
  "that's irrelevant", "thats irrelevant", "irrelevant",
  "that's not the point", "thats not the point", "not the point",
  "stop asking that", "stop asking about", "quit asking",
  "i don't care about that", "i dont care about that",
  "why does that matter", "who cares",
  "move on", "let it go",
];
function detectUserRejection(answer: string): string | null {
  const l = (answer || "").toLowerCase();
  for (const p of REJECTION_PHRASES) if (l.includes(p)) return p;
  return null;
}

// ============================================================================
// REDUNDANCY SIGNAL DETECTOR — user explicitly says they already answered.
// ============================================================================
const REDUNDANCY_PHRASES = [
  "i already told you", "i already said", "i already answered",
  "i answered that", "i told you that", "i said that already",
  "that's the same question", "thats the same question", "same question",
  "you already asked", "asked that already",
  "it doesn't matter", "it does not matter",
];
function detectRedundancySignal(answer: string): boolean {
  const l = (answer || "").toLowerCase();
  return REDUNDANCY_PHRASES.some((p) => l.includes(p));
}

// ============================================================================
// EMOTIONAL PRIORITY BIAS (EPB)
// Lower index = higher priority. logistics-tied-to-safety only; irrelevant always reject.
// ============================================================================
const EPB_PRIORITY: FieldName[] = [
  "emotions",
  "expectations",
  "intentions",
  "unspoken_needs",
  "relationships",
  "fears",
  "desired_outcome",
  "triggers",
  "situation",
  "history",
];
function epbScore(targets: string[]): number {
  // Lower is better. Sum of priority indices for each targeted field.
  if (targets.length === 0) return 999;
  let s = 0;
  for (const t of targets) {
    const idx = EPB_PRIORITY.indexOf(t as FieldName);
    s += idx === -1 ? 99 : idx;
  }
  return s / targets.length;
}

// ============================================================================
// DEPTH ESCALATION LOGIC (DEL)
// After surface fields (situation/history/triggers/relationships) are filled,
// require planner to target deeper fields.
// ============================================================================
const SURFACE_FIELDS: FieldName[] = ["situation", "history", "triggers", "relationships"];
const DEEPER_FIELDS: FieldName[] = ["emotions", "expectations", "intentions", "unspoken_needs", "fears", "desired_outcome"];
function shouldEscalateDepth(coverageMap: Record<string, string>, askedSoFar: number): boolean {
  if (askedSoFar < 3) return false;
  const surfaceFilledCount = SURFACE_FIELDS.filter((f) => coverageMap[f] === "filled").length;
  return surfaceFilledCount >= 2;
}

// ============================================================================
// FIELD CLUSTER DETECTOR (FR2 supporting)
// Detects when the last 3 questions repeatedly target the same field.
// ============================================================================
function detectFieldCluster(lastThreeFieldSets: string[][]): string | null {
  if (lastThreeFieldSets.length < 3) return null;
  const counts: Record<string, number> = {};
  for (const set of lastThreeFieldSets) {
    for (const f of new Set(set)) counts[f] = (counts[f] || 0) + 1;
  }
  for (const [f, c] of Object.entries(counts)) {
    if (c >= 3) return f;
  }
  return null;
}

// Section 8: AlreadyProvidedGuardrail — LLM equivalence check.
// Returns the set of field names the candidate question is essentially asking about
// that are ALREADY answered in prior user answers. Best-effort, fail-open.
async function checkAlreadyProvided(
  candidateQuestion: string,
  candidateTargets: string[],
  recentAnswers: { question: string; answer: string }[],
): Promise<{ alreadyAnswered: boolean; coveredFields: string[] }> {
  if (recentAnswers.length === 0 || !candidateQuestion.trim()) {
    return { alreadyAnswered: false, coveredFields: [] };
  }
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) return { alreadyAnswered: false, coveredFields: [] };
  const lastThree = recentAnswers.slice(-3);
  const prompt = `You check whether a candidate question is asking about something the user has ALREADY explained in their recent answers.

Candidate question: ${JSON.stringify(candidateQuestion)}
Candidate target fields: ${JSON.stringify(candidateTargets)}

Recent user answers:
${lastThree.map((a, i) => `${i + 1}. Q: ${a.question}\n   A: ${a.answer}`).join("\n")}

Return a JSON object:
{ "already_answered": true|false, "covered_fields": ["field", ...], "reason": "<short>" }

Set already_answered=true if the candidate question's intent (what it tries to elicit) is >55% semantically equivalent to information the user has already provided in those answers.
covered_fields = subset of the candidate target fields that are already substantively answered.`;
  try {
    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-lite",
        temperature: 0.1,
        response_format: { type: "json_object" },
        messages: [{ role: "user", content: prompt }],
      }),
    });
    if (!resp.ok) return { alreadyAnswered: false, coveredFields: [] };
    const data = await resp.json();
    const txt = data?.choices?.[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(txt);
    const covered = Array.isArray(parsed?.covered_fields)
      ? parsed.covered_fields.filter((f: any) => (ALL_FIELDS as readonly string[]).includes(f))
      : [];
    return {
      alreadyAnswered: parsed?.already_answered === true,
      coveredFields: covered,
    };
  } catch (_) {
    return { alreadyAnswered: false, coveredFields: [] };
  }
}

const ENGINE_V2_SYSTEM_PROMPT = `You are a therapy-trained communication clarity engine. Your job is to help the user articulate a real-life interpersonal situation so that another person could understand it deeply.

CORE RULES (NON-NEGOTIABLE):

1. NEVER repeat a question, even rephrased. Before generating a question, scan the full transcript and the ContextModel coverage map. If any field is already filled, DO NOT ask about it again.

2. EVERY question must target 3–5 UNDER-FILLED ContextModel fields simultaneously. Questions must be layered, therapy-style, and combine situational + emotional + intention-based dimensions.

3. ADAPT to the user's input length. If the user gives one-word or short answers, you MUST:
   - infer what you can from those answers
   - ask broader, lower-friction questions next
   - never demand more detail
   - never re-ask
   - never loop
   - never scold or coach the user into writing more
   In minimal mode, banned phrases include: "Can you tell me more", "Could you elaborate", "Please share more detail", "I need more information".

4. TRIGGER MISUNDERSTANDING-REPAIR when ANY of the following is true:
   - the user's last answer is unclear or contradicts earlier context
   - you cannot fill any new field from the answer
   - you are uncertain what the user meant
   - the user gave almost no context across two turns
   When triggered, set "mode": "repair" and the question MUST start with the exact phrase:
   "I want to make sure I'm understanding you correctly. Here's what I think you're saying: [your interpretation]. Can you confirm or correct this: [the specific thing you need clarified]?"

5. RESPECT SATURATION. Exit early (set should_exit=true and complete=true) when ≥70% of priority ContextModel fields are filled OR when the last two turns produced no new field signal. Do not continue asking just to hit the cap.

6. HARD CAP: 10 questions total (5 in minimal mode). Most sessions should end at 4–7.

7. THERAPY-STYLE TONE: warm, curious, non-judgmental, never clinical, never robotic, never coachy.
   Banned clinical/coachy words: dynamic, framework, lens, construct, narrative, journey, therapeutic, reflection, reflective.
   Banned directive phrases: "you should", "you need to", "I recommend".

CONTEXT MODEL FIELDS:
situation, emotions, intentions, triggers, expectations, fears, desired_outcome, relationships, history, unspoken_needs.

QUESTION CONSTRUCTION:
Each question is a single conversational sentence that naturally probes 3–5 fields at once. Example shape:
"When [situation cue happened], what were you feeling underneath, and what were you hoping the other person would understand?"
NOT: "How did you feel?" (one field, shallow, BANNED).

You are also given a list of LAYERED_SCAFFOLDS. You may adapt one of them or generate your own — but the resulting question MUST target 3-5 currently UNDER-FILLED fields and MUST NOT semantically repeat any question in question_history.

ABSOLUTE TIMELINE RULE:
If forbidden_timeline_question=true OR history_locked=true OR locked_fields_never_target includes "history" → DO NOT ask any timeline / sequence / "what happened next" / "how did it end" / "what came after" / "what came before" question. The history field is permanently locked for this session. Rotate to emotions, intentions, fears, expectations, unspoken_needs, or desired_outcome instead.

ABSOLUTE INTERPRETATION RULE:
Interpretation/meaning questions ("why did you think they meant you", "what made you feel that way", "what did they say that made you think that", "who do you think they meant", "how did you know it was about you", etc.) lock after 1–2 valid answers. If forbidden_interpretation_question=true OR interpretation_locked=true → DO NOT ask any interpretation/meaning/inference question, even rephrased. Do NOT ask about who the other person meant, why the user thought it was about them, what made them feel targeted, what was said that made them think that, or what behavior indicated meaning. Rotate to a structurally different field (emotions BEYOND the targeting moment, fears, desired_outcome, unspoken_needs, intentions, relationships) and ask about something the user has NOT yet covered.

ALREADY-ANSWERED RULE:
Before emitting a question, scan prior_answers. If ANY prior answer already substantively contains the information you would extract from the candidate question, mark those fields as filled in updated_context and pick a DIFFERENT combination of under-filled fields. Never re-ask information the user has already provided. This applies on EVERY turn after turn 1, for every field — not just timeline.

FIELD ROTATION RULE:
Do NOT target the same field twice in a row unless the previous answer was invalid OR the field is still <40% filled OR the question is part of an explicit multi-field scaffold. Once a field is filled or locked, it is invisible — never target it. Every question MUST target 3–5 fields. Single-field questions are forbidden.

LOCKED FIELDS:
The locked_fields_never_target list contains fields that are permanently off-limits for this session. NEVER include any of them in target_fields. Pick from under_filled_fields only.

IRRELEVANT DETAIL RULE:
Do NOT ask irrelevant detail questions (age, time, location, scheduling minutiae, physical description, numeric details) UNLESS the detail is directly tied to safety, legality, emotional meaning, responsibility, fairness, or risk. Banned surface patterns: "How old is...", "What time...", "Where were you...", "What color...", "How many...", "What day...". If the detail is not tied to one of those meaning anchors, do not ask it.

USER REJECTION RULE:
If the user has signaled that a field/topic does not matter ("it doesn't matter", "that's not important", "stop asking that", "that's not the point", or any paraphrase), that field is permanently locked. NEVER target it again, even rephrased. Honor user_rejected_fields strictly.

EMOTIONAL PRIORITY BIAS:
Prioritize emotional relevance over factual detail. Order: emotions, expectations, intentions, fairness/resentment, unspoken_needs, relationships, conflict patterns, responsibility, consequences. Logistics is only valid when tied to safety or legality. Irrelevant details are always rejected.

DEPTH ESCALATION RULE:
After turn 3, do NOT ask shallow/logistical questions. Once surface fields (situation, history, triggers, relationships) are filled, escalate to deeper fields (emotions, expectations, intentions, unspoken_needs, fears, desired_outcome). Pair a deep field with a supporting field via multi-field scaffolds. If escalate_depth=true, your target_fields MUST include at least one of: emotions, expectations, intentions, unspoken_needs, fears, desired_outcome.

FIELD ROTATION RULE (STRICT):
Planner MUST NOT target the same field twice in a row. MUST NOT target any field answered in the last 2 turns (recent_targeted_fields). MUST always add ≥1 NEW field. Single-field questions are FORBIDDEN — every question must target ≥2 fields (3-5 strongly preferred). Prioritize fields with the LOWEST coverage. Avoid clusters: if a field appears in the last 3 turns' targets, do not include it again.

Output via the tool call exactly. No prose.`;

const TOOL_SCHEMA = {
  type: "function",
  function: {
    name: "emit_update_and_question",
    description: "Return the updated ContextModel and the next question (or a repair message).",
    parameters: {
      type: "object",
      properties: {
        updated_context: {
          type: "object",
          properties: {
            situation: { type: "string" },
            emotions: { type: "array", items: { type: "string" } },
            intentions: { type: "array", items: { type: "string" } },
            triggers: { type: "array", items: { type: "string" } },
            expectations: { type: "array", items: { type: "string" } },
            fears: { type: "array", items: { type: "string" } },
            desired_outcome: { type: "string" },
            relationships: { type: "array", items: { type: "string" } },
            history: { type: "array", items: { type: "string" } },
            unspoken_needs: { type: "array", items: { type: "string" } },
          },
          required: ["situation", "emotions", "intentions", "triggers", "expectations", "fears", "desired_outcome", "relationships", "history", "unspoken_needs"],
          additionalProperties: false,
        },
        mode: { type: "string", enum: ["question", "repair", "complete"] },
        question: { type: "string", description: "Single-sentence question OR repair message starting with 'I want to make sure I'm understanding you correctly.' OR empty if complete." },
        target_fields: { type: "array", items: { type: "string", enum: ALL_FIELDS as unknown as string[] } },
        depth: { type: "integer", enum: [1, 2, 3] },
        rationale: { type: "string" },
        confidence: { type: "number", description: "0-1 confidence in the field extraction from the latest answer." },
        contradiction_detected: { type: "boolean" },
        complete: { type: "boolean" },
      },
      required: ["updated_context", "mode", "question", "target_fields", "depth", "rationale", "confidence", "contradiction_detected", "complete"],
      additionalProperties: false,
    },
  },
} as const;

async function callEngine(payload: unknown) {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");
  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      temperature: 0.5,
      messages: [
        { role: "system", content: ENGINE_V2_SYSTEM_PROMPT },
        { role: "user", content: JSON.stringify(payload) },
      ],
      tools: [TOOL_SCHEMA],
      tool_choice: { type: "function", function: { name: "emit_update_and_question" } },
    }),
  });
  if (resp.status === 429) throw new Error("RATE_LIMITED");
  if (resp.status === 402) throw new Error("PAYMENT_REQUIRED");
  if (!resp.ok) throw new Error(`LLM error ${resp.status}: ${await resp.text()}`);
  const data = await resp.json();
  const call = data?.choices?.[0]?.message?.tool_calls?.[0];
  if (!call?.function?.arguments) throw new Error("No tool call in response");
  return JSON.parse(call.function.arguments);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization") || "";
    if (!auth.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const token = auth.replace("Bearer ", "");
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );
    const { data: userData } = await supabase.auth.getUser(token);
    const userId = userData?.user?.id;
    if (!userId) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const body = await req.json();
    const sessionId: string = body?.sessionId;
    if (!sessionId) return new Response(JSON.stringify({ error: "Missing sessionId" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { data: session } = await supabase
      .from("reflection_sessions").select("id, user_id").eq("id", sessionId).maybeSingle();
    if (!session || session.user_id !== userId) {
      return new Response(JSON.stringify({ error: "Session not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const priorAnswersRaw: { question: string; answer: string }[] = Array.isArray(body?.priorAnswers) ? body.priorAnswers : [];

    // ---- Fix 1: Hard reset path ----
    if (body?.force_reset === true) {
      try {
        const reset = await hardResetSession(supabase, sessionId, userId);
        return new Response(JSON.stringify({
          done: false,
          mode: "reset",
          reset: true,
          session_reset_at: reset.session_reset_at,
          next_action: "regenerate",
          ui_fallback: makeUiFallback("Session reset. Request a fresh question."),
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (resetErr: any) {
        logEvent("hard_reset_failed", { sessionId, error: resetErr?.message });
        return new Response(JSON.stringify({
          error: resetErr?.message || "reset_failed",
          next_action: "retry",
          ui_fallback: makeUiFallback("Couldn't reset the session. Try again."),
        }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
    }

    const [{ data: ctxRow }, { data: histRows }, { data: storedAnswers }] = await Promise.all([
      supabase.from("session_context_models").select("*").eq("session_id", sessionId).maybeSingle(),
      supabase.from("question_history").select("question_text, target_fields, question_index").eq("session_id", sessionId).order("question_index", { ascending: true }),
      supabase.from("reflection_answers").select("question_index").eq("session_id", sessionId),
    ]);

    // ---- Fix 2: detect + auto-repair state mismatch (no rejection) ----
    const storedAnswerCount = Array.isArray(storedAnswers) ? storedAnswers.length : 0;
    let stateRepaired = false;
    let priorAnswers = priorAnswersRaw;
    if (detectStateMismatch(priorAnswersRaw, storedAnswerCount)) {
      const repair = autoRepairPriorAnswers(priorAnswersRaw, storedAnswerCount);
      priorAnswers = repair.repaired;
      stateRepaired = true;
    }


    const currentModel: ContextModel = ctxRow ? {
      situation: ctxRow.situation ?? "",
      emotions: ctxRow.emotions ?? [],
      intentions: ctxRow.intentions ?? [],
      triggers: ctxRow.triggers ?? [],
      expectations: ctxRow.expectations ?? [],
      fears: ctxRow.fears ?? [],
      desired_outcome: ctxRow.desired_outcome ?? "",
      relationships: ctxRow.relationships ?? [],
      history: ctxRow.history ?? [],
      unspoken_needs: ctxRow.unspoken_needs ?? [],
    } : { ...EMPTY_MODEL };

    const allHistTexts = (histRows ?? []).map((r: any) => r.question_text as string);
    const allHistFieldSets = (histRows ?? []).map((r: any) => (r.target_fields as string[]) ?? []);
    // Compare against the last 6 questions for similarity guard
    const recentHistTexts = allHistTexts.slice(-6);
    const recentHistFieldSets = allHistFieldSets.slice(-6);

    const askedSoFar = priorAnswers.length;
    const slot = askedSoFar + 1;

    // Detect minimal-user mode: 2 of last 3 user answers < 6 tokens
    const lastThree = priorAnswers.slice(-3).map((p) => tokenCount(p.answer));
    const shortCount = lastThree.filter((n) => n < 6).length;
    const minimalMode = shortCount >= 2;
    const cap = minimalMode ? MINIMAL_CAP : HARD_CAP;
    const satExit = minimalMode ? MINIMAL_SATURATION_EXIT : SATURATION_EXIT;

    // Pre-call coverage
    const preCov = computeCoverage(currentModel);
    const underFilled = underFilledFields(preCov.map);
    const filledFields = ALL_FIELDS.filter((f) => preCov.map[f] === "filled");

    // Section 11/12: Timeline lock + field lock registry.
    const histRowsArr = (histRows ?? []) as any[];
    let timelineQuestionCount = 0;
    let timelineAnswersValid = 0;
    for (let i = 0; i < histRowsArr.length; i++) {
      const h = histRowsArr[i];
      const qText = String(h?.question_text ?? "");
      const tFields = (h?.target_fields as string[]) ?? [];
      if (isTimelineQuestion(qText, tFields)) {
        timelineQuestionCount++;
        const a = priorAnswers[i];
        if (a && a.answer && a.answer.trim().toLowerCase() !== "idk" && tokenCount(a.answer) >= 3) {
          timelineAnswersValid++;
        }
      }
    }
    const historyLocked =
      preCov.map.history === "filled" ||
      timelineAnswersValid >= 2 ||
      (timelineQuestionCount >= 2 && currentModel.history.length > 0);

    // Interpretation/meaning loop breaker.
    // Counts past interpretation-style questions and how many got valid answers,
    // OR detects that the user has already volunteered substantive interpretation
    // content in any prior answer (even if the question wasn't framed that way).
    let interpretationQuestionCount = 0;
    let interpretationAnswersValid = 0;
    for (let i = 0; i < histRowsArr.length; i++) {
      const qText = String(histRowsArr[i]?.question_text ?? "");
      if (isInterpretationQuestion(qText)) {
        interpretationQuestionCount++;
        const a = priorAnswers[i];
        if (a && a.answer && a.answer.trim().toLowerCase() !== "idk" && tokenCount(a.answer) >= 3) {
          interpretationAnswersValid++;
        }
      }
    }
    const userVolunteeredInterpretation = priorAnswers.some((a) => answerHasInterpretationContent(a.answer));
    const interpretationLocked =
      interpretationAnswersValid >= 2 ||
      (interpretationQuestionCount >= 1 && userVolunteeredInterpretation) ||
      (interpretationQuestionCount >= 2);

    // Field-rotation: the field set targeted by the immediately previous question.
    const lastTargetedFields: string[] = histRowsArr.length > 0
      ? ((histRowsArr[histRowsArr.length - 1]?.target_fields as string[]) ?? [])
      : [];
    // Recently-targeted: the LAST 2 questions' fields (FR2 — never re-target within 2 turns).
    const recentTargetedFieldSets: string[][] = histRowsArr.slice(-2).map((h: any) =>
      (h?.target_fields as string[]) ?? []
    );
    const recentTargetedFields: string[] = Array.from(
      new Set(recentTargetedFieldSets.flat())
    );
    const lastThreeFieldSets: string[][] = histRowsArr.slice(-3).map((h: any) =>
      (h?.target_fields as string[]) ?? []
    );
    const clusteredField = detectFieldCluster(lastThreeFieldSets);

    // ---- USER REJECTION DETECTOR (URD) ----
    // Scan every prior user answer; for each rejection signal, lock the field that
    // was targeted by the question immediately preceding that answer.
    const userRejectedFields: Set<FieldName> = new Set();
    const guardrailLogs: Array<Record<string, unknown>> = [];
    for (let i = 0; i < priorAnswers.length; i++) {
      const ans = priorAnswers[i]?.answer ?? "";
      const phrase = detectUserRejection(ans);
      if (phrase) {
        const fieldsAsked = (histRowsArr[i]?.target_fields as string[]) ?? [];
        for (const f of fieldsAsked) {
          if ((ALL_FIELDS as readonly string[]).includes(f)) {
            userRejectedFields.add(f as FieldName);
          }
        }
        guardrailLogs.push({ rule: "URD", turn: i + 1, phrase, locked_fields: fieldsAsked });
      }
      if (detectRedundancySignal(ans)) {
        const fieldsAsked = (histRowsArr[i]?.target_fields as string[]) ?? [];
        for (const f of fieldsAsked) {
          if ((ALL_FIELDS as readonly string[]).includes(f)) {
            userRejectedFields.add(f as FieldName);
          }
        }
        guardrailLogs.push({ rule: "RedundancySignal", turn: i + 1, locked_fields: fieldsAsked });
      }
    }

    const lockedFields: FieldName[] = [...filledFields];
    if (historyLocked && !lockedFields.includes("history")) lockedFields.push("history");
    for (const f of userRejectedFields) {
      if (!lockedFields.includes(f)) lockedFields.push(f);
    }

    // Section 4: EarlyExitEvaluator — runs BEFORE the planner.
    if (slot > cap) {
      return new Response(JSON.stringify({ done: true, reason: "hard_cap", coverage_map: preCov.map, saturation_score: preCov.score }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (preCov.score >= satExit && askedSoFar >= 3) {
      return new Response(JSON.stringify({ done: true, reason: "saturated", coverage_map: preCov.map, saturation_score: preCov.score }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const targetableUnderFilled = underFilled.filter((f) => !lockedFields.includes(f));
    if (targetableUnderFilled.length < MIN_TARGET_FIELDS && askedSoFar >= 2) {
      return new Response(JSON.stringify({ done: true, reason: "insufficient_underfilled", coverage_map: preCov.map, saturation_score: preCov.score }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // No-delta check: prior coverage from history
    const prevCovScore = (ctxRow as any)?.saturation_score ?? 0;
    const noDeltaTurns = Number((body?.noDeltaTurns ?? 0));
    if (noDeltaTurns >= 1 && preCov.score <= prevCovScore && askedSoFar >= 3) {
      return new Response(JSON.stringify({ done: true, reason: "no_delta_two_turns", coverage_map: preCov.map, saturation_score: preCov.score }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // DEL: depth escalation flag
    const escalateDepth = shouldEscalateDepth(preCov.map, askedSoFar);

    // Build payload for LLM
    const payload = {
      prior_answers: priorAnswers,
      current_context: currentModel,
      coverage_map: preCov.map,
      saturation_score: preCov.score,
      under_filled_fields: targetableUnderFilled,
      filled_fields_do_not_target: filledFields,
      locked_fields_never_target: lockedFields,
      user_rejected_fields: Array.from(userRejectedFields),
      history_locked: historyLocked,
      timeline_question_count: timelineQuestionCount,
      timeline_answers_valid: timelineAnswersValid,
      interpretation_locked: interpretationLocked,
      interpretation_question_count: interpretationQuestionCount,
      interpretation_answers_valid: interpretationAnswersValid,
      user_volunteered_interpretation: userVolunteeredInterpretation,
      previous_question_target_fields: lastTargetedFields,
      recent_targeted_fields: recentTargetedFields,
      clustered_field_to_avoid: clusteredField,
      escalate_depth: escalateDepth,
      deeper_fields: DEEPER_FIELDS,
      surface_fields: SURFACE_FIELDS,
      emotional_priority_order: EPB_PRIORITY,
      question_history: allHistTexts,
      question_history_field_sets: allHistFieldSets,
      slot,
      hard_cap: cap,
      saturation_exit_threshold: satExit,
      minimal_mode: minimalMode,
      layered_scaffolds: SCAFFOLDS,
      banned_elaboration_phrases: minimalMode ? BANNED_ELABORATION_PHRASES : [],
      banned_clinical_terms: BANNED_CLINICAL_TERMS,
      previous_saturation_score: prevCovScore,
      consecutive_no_delta_turns: noDeltaTurns,
      forbidden_timeline_question: historyLocked,
      forbidden_interpretation_question: interpretationLocked,
      irrelevant_detail_examples: IRRELEVANT_DETAIL_PATTERNS,
    };

    // Up to 3 attempts to satisfy guards
    let result: any | null = null;
    let lastReason = "";
    let lastQuestion = "";
    for (let attempt = 0; attempt < 3; attempt++) {
      const out = await callEngine({
        ...payload,
        ...(attempt > 0 ? { regenerate_reason: lastReason, previous_attempt: lastQuestion } : {}),
      });
      const q = String(out?.question ?? "").trim();
      const mode = String(out?.mode ?? "question");
      const targets: string[] = Array.isArray(out?.target_fields) ? out.target_fields.filter((f: any) => (ALL_FIELDS as readonly string[]).includes(f)) : [];

      // Repair mode: skip most guards but require the standardized opener
      if (mode === "repair") {
        if (!q.toLowerCase().startsWith("i want to make sure i'm understanding you correctly")) {
          lastReason = "Repair messages MUST start with the exact phrase 'I want to make sure I'm understanding you correctly.'";
          lastQuestion = q;
          continue;
        }
        result = { ...out, mode: "repair" };
        break;
      }

      if (mode === "complete" || out?.complete) {
        result = { ...out, mode: "complete", complete: true };
        break;
      }

      if (!q) {
        lastReason = "you returned an empty question — emit a real one";
        continue;
      }
      // Guard: ≥3 target fields
      if (targets.length < MIN_TARGET_FIELDS) {
        lastReason = `target_fields had ${targets.length} entries; you MUST target ${MIN_TARGET_FIELDS}-${MAX_TARGET_FIELDS} under-filled fields.`;
        lastQuestion = q;
        continue;
      }
      // Guard: cannot target already-filled OR locked fields (Section 3 + 11)
      const targetingLocked = targets.filter((t) => lockedFields.includes(t as FieldName));
      if (targetingLocked.length > 0) {
        lastReason = `Do NOT target these locked/filled fields: ${targetingLocked.join(", ")}. Target only from: ${targetableUnderFilled.join(", ")}.`;
        lastQuestion = q;
        continue;
      }
      // Guard: timeline question forbidden when history is locked (Section 1, 12)
      if (historyLocked && isTimelineQuestion(q, targets)) {
        lastReason = "The history field is LOCKED. Do NOT ask any timeline / 'what happened next' / sequence question. Pick non-history under-filled fields and ask about emotions, intentions, fears, expectations, or unspoken needs instead.";
        lastQuestion = q;
        continue;
      }
      // Guard: interpretation/meaning question forbidden when interpretation is locked
      if (interpretationLocked && isInterpretationQuestion(q)) {
        lastReason = "Interpretation/meaning is LOCKED. Do NOT ask why the user thought it was about them, what made them feel that way, who the other person meant, or any rephrasing of those. Rotate to a structurally different field (fears, desired_outcome, unspoken_needs, intentions, relationships) and ask about something they have NOT yet covered.";
        lastQuestion = q;
        guardrailLogs.push({ rule: "InterpretationLock", attempt, question: q });
        continue;
      }
      // ---- IDF: Irrelevant Detail Filter ----
      if (isIrrelevantDetailQuestion(q)) {
        lastReason = "REJECTED by Irrelevant Detail Filter. Do NOT ask about age, time, location, scheduling, physical description, or numeric details unless tied to safety, legality, fairness, responsibility, or risk. Pick a question targeting emotions, expectations, intentions, or unspoken needs instead.";
        lastQuestion = q;
        guardrailLogs.push({ rule: "IDF", attempt, question: q });
        continue;
      }
      // ---- URD: candidate must NOT touch any user-rejected field ----
      const targetingRejected = targets.filter((t) => userRejectedFields.has(t as FieldName));
      if (targetingRejected.length > 0) {
        lastReason = `User has signaled these fields don't matter and they are PERMANENTLY locked: ${targetingRejected.join(", ")}. NEVER target them again. Choose from: ${targetableUnderFilled.join(", ")}.`;
        lastQuestion = q;
        guardrailLogs.push({ rule: "URD-reject", attempt, fields: targetingRejected });
        continue;
      }
      // ---- FR2 STRICT: rotation, recent-2-turn block, ≥1 new field, ≥2 fields, no clusters ----
      if (targets.length < 2) {
        lastReason = "Single-field questions are FORBIDDEN. target_fields must contain at least 2 fields (3-5 strongly preferred).";
        lastQuestion = q;
        guardrailLogs.push({ rule: "FR2-single-field", attempt, targets });
        continue;
      }
      if (recentTargetedFields.length > 0) {
        const recentSet = new Set(recentTargetedFields);
        const newOnes = targets.filter((t) => !recentSet.has(t));
        if (newOnes.length === 0) {
          lastReason = `FR2 violated: every target_field (${JSON.stringify(targets)}) was already targeted in the last 2 turns (${JSON.stringify(recentTargetedFields)}). You MUST add ≥1 NEW field. Choose from: ${targetableUnderFilled.filter((f) => !recentSet.has(f)).join(", ") || targetableUnderFilled.join(", ")}.`;
          lastQuestion = q;
          guardrailLogs.push({ rule: "FR2-no-new-field", attempt, targets, recent: recentTargetedFields });
          continue;
        }
      }
      if (lastTargetedFields.length > 0 && targets.length > 0) {
        const prevSet = new Set(lastTargetedFields);
        const isExactRepeat = targets.length === lastTargetedFields.length && targets.every((t) => prevSet.has(t));
        if (isExactRepeat) {
          lastReason = `FR2 violated: target_fields exactly repeats the previous question's set ${JSON.stringify(lastTargetedFields)}. Rotate to a different field combination.`;
          lastQuestion = q;
          guardrailLogs.push({ rule: "FR2-exact-repeat", attempt, targets });
          continue;
        }
      }
      if (clusteredField && targets.includes(clusteredField)) {
        lastReason = `FR2 cluster detected: "${clusteredField}" appeared in the last 3 questions. Do NOT include it again. Pick a different field from: ${targetableUnderFilled.filter((f) => f !== clusteredField).join(", ")}.`;
        lastQuestion = q;
        guardrailLogs.push({ rule: "FR2-cluster", attempt, field: clusteredField });
        continue;
      }
      // ---- DEL: Depth Escalation Logic ----
      if (escalateDepth) {
        const hasDeep = targets.some((t) => (DEEPER_FIELDS as readonly string[]).includes(t));
        if (!hasDeep) {
          lastReason = `DEL: surface fields are filled. After turn 3 your question MUST include at least one deeper field (${DEEPER_FIELDS.join(", ")}). Use a multi-field scaffold pairing a deep field with a supporting field.`;
          lastQuestion = q;
          guardrailLogs.push({ rule: "DEL", attempt, targets });
          continue;
        }
      }
      // Guard: subset of any prior question's field set
      if (isSubsetOfAny(targets, allHistFieldSets)) {
        lastReason = `Your target_fields ${JSON.stringify(targets)} is a subset of a previously-asked question's targets. Pick a different combination of under-filled fields.`;
        lastQuestion = q;
        continue;
      }
      // Guard: Jaccard ≥0.35 against last 6
      if (isRepeat(q, recentHistTexts)) {
        lastReason = "Your question is too similar to one already asked. Use different language and target a different combination of under-filled fields.";
        lastQuestion = q;
        continue;
      }
      // Guard: banned elaboration phrases (minimal mode)
      if (minimalMode && containsBanned(q, BANNED_ELABORATION_PHRASES)) {
        lastReason = "Minimal-user mode: do not use elaboration-demanding phrases. Ask a broader question instead.";
        lastQuestion = q;
        continue;
      }
      // Guard: banned clinical/coachy terms
      if (containsBanned(q, BANNED_CLINICAL_TERMS)) {
        lastReason = "Avoid clinical/coachy words (dynamic, framework, lens, narrative, journey, etc.).";
        lastQuestion = q;
        continue;
      }
      // ---- Section 8: AlreadyProvidedGuardrail (LLM equivalence) — strengthened ----
      if (priorAnswers.length >= 1) {
        const guard = await checkAlreadyProvided(q, targets, priorAnswers);
        if (guard.alreadyAnswered) {
          lastReason = `AlreadyProvided: the user has already answered this. Covered fields: ${guard.coveredFields.join(", ") || "(unspecified)"}. Mark those fields FILLED in updated_context, escalate to a DEEPER field (${DEEPER_FIELDS.join(", ")}), and target a DIFFERENT combination of under-filled fields. Do not re-ask, even rephrased.`;
          lastQuestion = q;
          guardrailLogs.push({ rule: "AlreadyProvided", attempt, covered: guard.coveredFields });
          continue;
        }
      }
      // ---- EPB scoring (informational; not a hard reject unless score is terrible) ----
      const score = epbScore(targets);
      guardrailLogs.push({ rule: "EPB-score", attempt, targets, score });
      result = out;
      break;
    }
    if (guardrailLogs.length > 0) console.info("[engine-v2] guardrail_logs", JSON.stringify(guardrailLogs));

    // ---- Fix 3: sanity-check + FALLBACK_QUESTIONS ----
    // Ensure whatever we return passes structural sanity. If the LLM produced
    // nothing usable, fall back to a safe canned question instead of erroring.
    const ensureSane = (q: string, t: string[]) => {
      const sc = sanityCheckQuestion(q, t, allHistTexts);
      return sc.valid;
    };
    if (result && result.mode !== "repair" && result.mode !== "complete") {
      const candidateQ = String(result?.question ?? "").trim();
      const candidateT: string[] = Array.isArray(result?.target_fields)
        ? result.target_fields.filter((f: any) => (ALL_FIELDS as readonly string[]).includes(f))
        : [];
      if (!ensureSane(candidateQ, candidateT)) {
        const sc = sanityCheckQuestion(candidateQ, candidateT, allHistTexts);
        logEvent("sanity_failed_using_fallback", { reason: sc.reason, candidate: candidateQ.slice(0, 200) });
        // Pick a fallback whose targets aren't all locked.
        const usable = FALLBACK_QUESTIONS.find((fq) =>
          fq.target_fields.some((f) => !lockedFields.includes(f))
        ) ?? FALLBACK_QUESTIONS[0];
        const safeTargets = usable.target_fields.filter((f) => !lockedFields.includes(f));
        result = {
          ...(result ?? {}),
          mode: "question",
          question: usable.question,
          target_fields: safeTargets.length >= 2 ? safeTargets : usable.target_fields,
          depth: 2,
          rationale: "fallback_after_sanity_failure",
        };
      }
    }

    if (!result) {
      // Last-ditch: emit a canned safe question with ui_fallback so the UI
      // always has a renderable state instead of a hard error.
      const fb = FALLBACK_QUESTIONS[0];
      logEvent("no_result_using_fallback", { sessionId });
      return new Response(JSON.stringify({
        done: false,
        mode: "question",
        question: fb.question,
        target_fields: fb.target_fields,
        depth: 2,
        rationale: "no_result_fallback",
        slot,
        hard_cap: cap,
        coverage_map: preCov.map,
        saturation_score: preCov.score,
        critical_empty: underFilledFields(preCov.map),
        minimal_mode: minimalMode,
        state_repaired: stateRepaired,
        next_action: "retry",
        ui_fallback: makeUiFallback("Couldn't generate a tailored question. Here's a general one — answer freely."),
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Validate + persist updated ContextModel
    const u = result.updated_context ?? {};
    const merged: ContextModel = {
      situation: typeof u.situation === "string" ? u.situation : currentModel.situation,
      emotions: Array.isArray(u.emotions) ? u.emotions.map(String) : currentModel.emotions,
      intentions: Array.isArray(u.intentions) ? u.intentions.map(String) : currentModel.intentions,
      triggers: Array.isArray(u.triggers) ? u.triggers.map(String) : currentModel.triggers,
      expectations: Array.isArray(u.expectations) ? u.expectations.map(String) : currentModel.expectations,
      fears: Array.isArray(u.fears) ? u.fears.map(String) : currentModel.fears,
      desired_outcome: typeof u.desired_outcome === "string" ? u.desired_outcome : currentModel.desired_outcome,
      relationships: Array.isArray(u.relationships) ? u.relationships.map(String) : currentModel.relationships,
      history: Array.isArray(u.history) ? u.history.map(String) : currentModel.history,
      unspoken_needs: Array.isArray(u.unspoken_needs) ? u.unspoken_needs.map(String) : currentModel.unspoken_needs,
    };
    const postCov = computeCoverage(merged);

    await supabase.from("session_context_models").upsert({
      session_id: sessionId,
      ...merged,
      coverage_map: postCov.map,
      saturation_score: postCov.score,
    }, { onConflict: "session_id" });

    // Coverage delta check (server-side, source of truth)
    const noDelta = postCov.score <= prevCovScore;
    const lowSignal = result.confidence !== undefined && Number(result.confidence) < 0.5;
    const lastAnswerTokens = priorAnswers.length > 0 ? tokenCount(priorAnswers[priorAnswers.length - 1].answer) : 999;
    const lastQTargetCount = (histRows && histRows.length > 0) ? ((histRows[histRows.length - 1] as any).target_fields?.length ?? 0) : 0;

    // Server-side repair triggers (in addition to LLM's mode==="repair"):
    // 1) <4 tokens after a multi-field (≥3) question
    // 2) confidence <0.5 from extraction
    // 3) contradiction_detected flag
    // 4) two consecutive no-delta turns
    const serverRepairTrigger =
      result.mode !== "repair" &&
      askedSoFar > 0 && (
        (lastAnswerTokens < 4 && lastQTargetCount >= 3) ||
        lowSignal ||
        result.contradiction_detected === true ||
        (noDelta && noDeltaTurns >= 1)
      );

    const isRepair = result.mode === "repair" || serverRepairTrigger;

    // If repair: do NOT advance question_index, return repair message
    if (isRepair) {
      const repairMsg = (result.mode === "repair" && typeof result.question === "string")
        ? result.question
        : `I want to make sure I'm understanding you correctly. Here's what I think you're saying: ${currentModel.situation || "this is about a difficult moment between you and someone close to you"}. Can you confirm or correct this: what part of what's happening matters most to you right now?`;
      return new Response(JSON.stringify({
        done: false,
        mode: "repair",
        question: repairMsg,
        target_fields: [],
        depth: 1,
        rationale: "repair_triggered",
        slot,
        hard_cap: cap,
        coverage_map: postCov.map,
        saturation_score: postCov.score,
        critical_empty: underFilledFields(postCov.map),
        minimal_mode: minimalMode,
        state_repaired: stateRepaired,
        next_action: "retry",
        ui_fallback: makeUiFallback("Want to clarify your last answer in your own words?"),
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Server-side complete decision
    const llmDone = !!result.complete || result.mode === "complete";
    const saturated = postCov.score >= satExit && askedSoFar >= 3;
    const lowUnderFilled = underFilledFields(postCov.map).length < MIN_TARGET_FIELDS && askedSoFar >= 2;
    const noDeltaExit = noDelta && noDeltaTurns >= 1 && askedSoFar >= 3;
    const done = saturated || lowUnderFilled || noDeltaExit || (llmDone && askedSoFar >= 3);

    if (done) {
      return new Response(JSON.stringify({
        done: true,
        mode: "complete",
        coverage_map: postCov.map,
        saturation_score: postCov.score,
        updated_context: merged,
        reason: saturated ? "saturated" : lowUnderFilled ? "insufficient_underfilled" : noDeltaExit ? "no_delta" : "llm_complete",
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const question = String(result.question ?? "").trim();
    const targetFields: FieldName[] = Array.isArray(result.target_fields)
      ? (result.target_fields as string[]).filter((f): f is FieldName => (ALL_FIELDS as readonly string[]).includes(f))
      : [];
    const depth = result.depth === 1 || result.depth === 2 || result.depth === 3 ? result.depth : 2;
    const rationale = String(result.rationale ?? "");

    await supabase.from("question_history").insert({
      session_id: sessionId,
      question_index: slot,
      question_text: question,
      target_fields: targetFields,
      depth,
      rationale,
    });

    return new Response(JSON.stringify({
      done: false,
      mode: "question",
      question,
      target_fields: targetFields,
      depth,
      rationale,
      slot,
      hard_cap: cap,
      coverage_map: postCov.map,
      saturation_score: postCov.score,
      critical_empty: underFilledFields(postCov.map),
      minimal_mode: minimalMode,
      no_delta_turns: noDelta ? noDeltaTurns + 1 : 0,
      state_repaired: stateRepaired,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e: any) {
    const msg = e?.message || "Unknown error";
    if (msg === "RATE_LIMITED") return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly.", next_action: "retry", ui_fallback: makeUiFallback("Rate limited. Try again in a moment.") }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    if (msg === "PAYMENT_REQUIRED") return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits to continue.", next_action: "retry", ui_fallback: makeUiFallback("AI credits exhausted. Add credits to continue.") }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    console.error("generate-next-question-v2 error:", e);
    logEvent("handler_error", { message: msg });
    return new Response(JSON.stringify({ error: msg, next_action: "retry", ui_fallback: makeUiFallback("Something went wrong generating the next question. Try again.") }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
