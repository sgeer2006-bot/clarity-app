// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const DISCLAIMER =
  "This tool does not give advice. It generates general perspectives based solely on the information you provide. You are responsible for your own decisions.";

function buildQuestionPrompt(snapshot: any, originalAnswers: any[], corrections: any[]) {
  return `You are helping someone correct their situation snapshot. They said something is wrong or missing.

Current snapshot:
Summary: ${snapshot.summary}
Things to consider: ${(snapshot.observations || []).join("; ")}
Possible paths: ${(snapshot.possible_paths || []).join("; ")}

Original answers:
${originalAnswers.map((a: any, i: number) => `Q${i + 1}: ${a.question_text}\nA: ${a.answer_text}`).join("\n\n")}

${corrections.length > 0 ? `Corrections so far:\n${corrections.map((c: any) => `${c.role}: ${c.content}`).join("\n")}` : ""}

Ask ONE simple, concrete question about what feels inaccurate, what is missing, or what was misunderstood. Reference specific parts of the snapshot. Use plain language. No advice. No jargon.

Output: Single question sentence only.`;
}

function buildRegeneratePrompt(snapshot: any, originalAnswers: any[], corrections: any[]) {
  return `You are regenerating a corrected snapshot based on original answers and user corrections.

Original answers:
${originalAnswers.map((a: any, i: number) => `Q${i + 1}: ${a.question_text}\nA: ${a.answer_text}`).join("\n\n")}

Previous snapshot:
Summary: ${snapshot.summary}
Things to consider: ${(snapshot.observations || []).join("; ")}
Possible paths: ${(snapshot.possible_paths || []).join("; ")}
Recommended next steps: ${(snapshot.recommended_next_steps || []).join("; ")}
Common misunderstandings: ${(snapshot.common_misunderstandings || []).join("; ")}
How to communicate: ${(snapshot.how_to_communicate || []).join("; ")}

User corrections:
${corrections.map((c: any) => `${c.role}: ${c.content}`).join("\n")}

Produce an updated snapshot incorporating the corrections. Return strict JSON:
{
  "summary": string,
  "observations": string[3 to 5],
  "possible_paths": string[3 to 5],
  "recommended_next_steps": string[3 to 5],
  "common_misunderstandings": string[3 to 5],
  "how_to_communicate": string[3 to 5]
}

Section guidance:
- "recommended_next_steps": gentle, specific things the user could consider doing. Frame as "you could consider…", "one option is…", "some people choose to…". Never directive. Concrete to what the user actually said.
- "common_misunderstandings": what the OTHER person might be misreading or interpreting differently. Frame neutrally — never blame either side. Use "they might be reading this as…".
- "how_to_communicate": phrasing ideas — each item is one example "I" sentence in quotes plus a short note on when it might fit. Never accusations.

Rules:
- Plain language, 6th-grade level.
- Never give advice. Never use "you should", "I recommend", etc.
- Frame everything as perspective or possibility.
- JSON only, no prose.`;
}

const FORBIDDEN = [
  "you should", "you need to", "you must", "i recommend",
  "the best thing", "the best option", "the right choice", "try doing",
];

function containsForbidden(strs: string[]): boolean {
  const joined = strs.join(" ").toLowerCase();
  return FORBIDDEN.some((p) => joined.includes(p));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userToken = authHeader.replace("Bearer ", "");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userErr } = await supabase.auth.getUser(userToken);
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { sessionId, mode, corrections } = await req.json();
    // mode: "question" | "regenerate"
    if (!sessionId || !mode || !["question", "regenerate"].includes(mode)) {
      return new Response(JSON.stringify({ error: "Invalid input" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: session } = await supabase
      .from("reflection_sessions")
      .select("id, user_id, snapshot_json")
      .eq("id", sessionId)
      .maybeSingle();

    if (!session || session.user_id !== userData.user.id) {
      return new Response(JSON.stringify({ error: "Session not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: answers } = await supabase
      .from("reflection_answers")
      .select("question_text, answer_text")
      .eq("session_id", sessionId)
      .order("question_index", { ascending: true });

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");

    const correctionList = Array.isArray(corrections) ? corrections : [];

    if (mode === "question") {
      const prompt = buildQuestionPrompt(session.snapshot_json || {}, answers || [], correctionList);
      const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "google/gemini-2.5-pro", temperature: 0.4,
          messages: [{ role: "system", content: prompt }, { role: "user", content: "Ask the next correction question." }],
        }),
      });

      if (!resp.ok) {
        const text = await resp.text();
        const s = resp.status === 429 ? 429 : resp.status === 402 ? 402 : 500;
        return new Response(JSON.stringify({ error: s === 429 ? "Rate limited" : text }), {
          status: s, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const data = await resp.json();
      const question = (data?.choices?.[0]?.message?.content ?? "").trim().replace(/^["']|["']$/g, "");
      if (!question || containsForbidden([question])) {
        return new Response(JSON.stringify({ error: "Could not generate a valid question" }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      return new Response(JSON.stringify({ question }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // mode === "regenerate"
    const prompt = buildRegeneratePrompt(session.snapshot_json || {}, answers || [], correctionList);
    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-pro", temperature: 0.3,
        response_format: { type: "json_object" },
        messages: [{ role: "system", content: prompt }, { role: "user", content: "Regenerate the snapshot now." }],
      }),
    });

    if (!resp.ok) {
      const text = await resp.text();
      return new Response(JSON.stringify({ error: `AI error: ${text}` }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await resp.json();
    const content = data?.choices?.[0]?.message?.content ?? "";
    let parsed: any;
    try { parsed = JSON.parse(content); } catch { parsed = null; }

    const okArr = (v: any) =>
      Array.isArray(v) && v.length >= 3 && v.length <= 5 &&
      v.every((s: any) => typeof s === "string" && s.trim().length > 0);

    if (
      !parsed?.summary ||
      !okArr(parsed?.observations) ||
      !okArr(parsed?.possible_paths) ||
      !okArr(parsed?.recommended_next_steps) ||
      !okArr(parsed?.common_misunderstandings) ||
      !okArr(parsed?.how_to_communicate)
    ) {
      return new Response(JSON.stringify({ error: "Invalid snapshot format from AI" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (
      containsForbidden([
        parsed.summary,
        ...parsed.observations,
        ...parsed.possible_paths,
        ...parsed.recommended_next_steps,
        ...parsed.common_misunderstandings,
        ...parsed.how_to_communicate,
      ])
    ) {
      return new Response(JSON.stringify({ error: "Generated content violated safety rules" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get next version number
    const { data: versions } = await supabase
      .from("snapshot_versions")
      .select("version_number")
      .eq("session_id", sessionId)
      .order("version_number", { ascending: false })
      .limit(1);

    const nextVersion = (versions && versions.length > 0 ? versions[0].version_number : 0) + 1;

    // Save version
    await supabase.from("snapshot_versions").insert({
      session_id: sessionId,
      version_number: nextVersion,
      summary: parsed.summary,
      observations: parsed.observations,
      possible_paths: parsed.possible_paths,
      recommended_next_steps: parsed.recommended_next_steps,
      common_misunderstandings: parsed.common_misunderstandings,
      how_to_communicate: parsed.how_to_communicate,
      disclaimer: DISCLAIMER,
    });

    // Update session with latest snapshot
    const newJson = {
      summary: parsed.summary,
      observations: parsed.observations,
      possible_paths: parsed.possible_paths,
      recommended_next_steps: parsed.recommended_next_steps,
      common_misunderstandings: parsed.common_misunderstandings,
      how_to_communicate: parsed.how_to_communicate,
      disclaimer: DISCLAIMER,
    };
    await supabase.from("reflection_sessions").update({
      snapshot_json: newJson,
      snapshot: `${parsed.summary}\n\n${parsed.observations.join("\n")}\n\n${parsed.possible_paths.join("\n")}\n\n${DISCLAIMER}`,
    }).eq("id", sessionId);

    return new Response(JSON.stringify({ snapshot: newJson, version: nextVersion }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    console.error("generate-correction error:", e);
    return new Response(JSON.stringify({ error: e.message ?? "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
