// pe-update-timeline
// Appends a calm timeline entry summarizing the patterns detected for an answer.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

async function guardrail(text: string): Promise<string> {
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/pe-guardrail-rewrite`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE_KEY}`, apikey: SERVICE_KEY },
      body: JSON.stringify({ text }),
    });
    const json = await res.json();
    return json?.text ?? text;
  } catch {
    return text;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  try {
    const { answerId, userId } = await req.json().catch(() => ({}));
    if (!answerId || !userId) {
      return new Response(JSON.stringify({ ok: false }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Wait briefly so detect-macro-patterns has a chance to land
    await new Promise((r) => setTimeout(r, 1500));

    const { data: patterns } = await admin
      .from("pe_macro_patterns")
      .select("id, pattern_type, pattern_label")
      .contains("source_answer_ids", [answerId])
      .eq("user_id", userId);

    if (!patterns || patterns.length === 0) {
      return new Response(JSON.stringify({ ok: true, skipped: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
    }

    const top = patterns.slice(0, 3).map((p) => p.pattern_label).join(", ");
    const shortLabel = patterns[0].pattern_label;
    const summary = await guardrail(`A reflection touched on ${top}.`);

    await admin.from("pe_timeline_events").insert({
      user_id: userId,
      event_type: "reflection_patterns",
      short_label: shortLabel,
      summary,
      detail: { patterns: patterns.map((p) => ({ type: p.pattern_type, label: p.pattern_label })) },
      linked_pattern_ids: patterns.map((p) => p.id),
    });

    await admin.from("pe_job_runs").insert({
      user_id: userId, job_name: "pe_update_timeline", status: "success",
      triggered_by: "on_answer_saved", source_answer_id: answerId,
      completed_at: new Date().toISOString(),
    });

    return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: String(e) }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  }
});
