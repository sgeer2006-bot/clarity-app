// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SYSTEM_PROMPT = `You sort short personal-situation snapshots into folders.

You will receive:
- A short summary of a situation a person is thinking through.
- A list of folder names that already exist for this person.

Your job:
1) If one of the existing folders clearly fits, return that exact folder name.
2) Otherwise, propose ONE new folder name (1-2 simple words, Title Case, plain English). Examples: Work, Family, Money, Friends, Health, Roommates, Romance, School.

Rules:
- Use plain, everyday language. No jargon.
- Never use words like: reflection, dynamic, framework, pattern, lens, narrative, journey.
- Never invent a folder that's basically the same as an existing one — match the existing one instead.
- If the situation is too vague to categorize, return "General".

Return ONLY JSON in this exact shape:
{"folder_name": "<name>", "is_new": <true|false>}`;

function tryParseJson(s: string): any | null {
  if (!s) return null;
  const cleaned = s.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try { return JSON.parse(cleaned); } catch { /* try slice */ }
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start >= 0 && end > start) {
    try { return JSON.parse(cleaned.slice(start, end + 1)); } catch { return null; }
  }
  return null;
}

async function callLLM(summary: string, existingFolders: string[]): Promise<any | null> {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");

  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash-lite",
      temperature: 0.2,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        {
          role: "user",
          content: JSON.stringify({
            summary,
            existing_folders: existingFolders,
          }),
        },
      ],
    }),
  });

  if (!resp.ok) {
    const text = await resp.text();
    if (resp.status === 429) throw new Error("RATE_LIMITED");
    if (resp.status === 402) throw new Error("PAYMENT_REQUIRED");
    throw new Error(`LLM error ${resp.status}: ${text}`);
  }

  const data = await resp.json();
  const content: string = (data?.choices?.[0]?.message?.content ?? "").trim();
  return tryParseJson(content);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userToken = authHeader.replace("Bearer ", "");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userErr } = await supabase.auth.getUser(userToken);
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = userData.user.id;

    const { sessionId } = await req.json();
    if (!sessionId || typeof sessionId !== "string") {
      return new Response(JSON.stringify({ error: "Missing sessionId" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Load the snapshot summary (RLS confines to owner)
    const { data: session } = await supabase
      .from("reflection_sessions")
      .select("id, user_id, snapshot_json, title, folder_id")
      .eq("id", sessionId)
      .maybeSingle();

    if (!session || session.user_id !== userId) {
      return new Response(JSON.stringify({ error: "Session not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const summary: string =
      (session.snapshot_json as any)?.summary ?? session.title ?? "";

    if (!summary) {
      return new Response(JSON.stringify({ error: "No summary to categorize." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Load this user's existing folders.
    const { data: foldersRows } = await supabase
      .from("folders")
      .select("id, name")
      .eq("user_id", userId);
    const folders = (foldersRows ?? []) as { id: string; name: string }[];
    const folderNames = folders.map((f) => f.name);

    let llmResult: any = null;
    try {
      llmResult = await callLLM(summary, folderNames);
    } catch (e: any) {
      const status =
        e.message === "RATE_LIMITED" ? 429 : e.message === "PAYMENT_REQUIRED" ? 402 : 500;
      return new Response(JSON.stringify({ error: e.message || "LLM failed" }), {
        status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let chosen: string =
      typeof llmResult?.folder_name === "string" && llmResult.folder_name.trim().length > 0
        ? llmResult.folder_name.trim().slice(0, 40)
        : "General";

    // Try to match an existing folder case-insensitively first.
    const matchExisting = folders.find(
      (f) => f.name.toLowerCase() === chosen.toLowerCase(),
    );

    let folderId: string;
    let folderName: string;
    let createdNew = false;

    if (matchExisting) {
      folderId = matchExisting.id;
      folderName = matchExisting.name;
    } else {
      // Create a new folder. The unique index on (user_id, lower(name))
      // protects us from races; if it conflicts, re-fetch.
      const { data: created, error: createErr } = await supabase
        .from("folders")
        .insert({ user_id: userId, name: chosen })
        .select("id, name")
        .maybeSingle();

      if (createErr || !created) {
        // Race? Try to find it.
        const { data: refetch } = await supabase
          .from("folders")
          .select("id, name")
          .eq("user_id", userId)
          .ilike("name", chosen)
          .maybeSingle();
        if (!refetch) {
          return new Response(
            JSON.stringify({ error: createErr?.message || "Could not create folder" }),
            { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
          );
        }
        folderId = refetch.id;
        folderName = refetch.name;
      } else {
        folderId = created.id;
        folderName = created.name;
        createdNew = true;
      }
    }

    // Only auto-assign if the snapshot doesn't already have a folder
    // (we never overwrite a user's manual choice).
    if (!session.folder_id) {
      await supabase
        .from("reflection_sessions")
        .update({ folder_id: folderId })
        .eq("id", sessionId);
    }

    return new Response(
      JSON.stringify({
        folder_id: folderId,
        folder_name: folderName,
        created_new: createdNew,
        already_assigned: !!session.folder_id,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e: any) {
    console.error("suggest-folder error:", e);
    return new Response(JSON.stringify({ error: e.message ?? "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
