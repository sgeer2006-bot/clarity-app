// pe-update-identity
// Incrementally updates the user's psychological identity profile. Snapshots the
// prior version into pe_identity_profile_history before writing.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

async function guardrail(text: string | null): Promise<string | null> {
  if (!text) return text;
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/pe-guardrail-rewrite`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE_KEY}`, apikey: SERVICE_KEY },
      body: JSON.stringify({ text }),
    });
    const json = await res.json();
    return json?.text ?? text;
  } catch {
    return text;
  }
}

function topByType(rows: Array<{ pattern_type: string; pattern_label: string; weighted_score: number }>, type: string, n = 3) {
  return rows
    .filter((r) => r.pattern_type === type)
    .sort((a, b) => Number(b.weighted_score) - Number(a.weighted_score))
    .slice(0, n)
    .map((r) => ({ label: r.pattern_label, score: Number(r.weighted_score) }));
}

function buildNarrative(top: any) {
  const lines: string[] = [];
  if (top.communication.length) {
    lines.push(`In your reflections, a recurring communication shape has been ${top.communication.map((t: any) => t.label.toLowerCase()).join(", ")}.`);
  }
  if (top.conflict.length) {
    lines.push(`In moments of friction, you've often described moving as a ${top.conflict[0].label.toLowerCase()}.`);
  }
  if (top.themes.length) {
    lines.push(`Themes that keep returning: ${top.themes.map((t: any) => t.label.toLowerCase()).join(", ")}.`);
  }
  return lines.join(" ");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);
  let userId: string | null = null;

  try {
    const body = await req.json().catch(() => ({}));
    userId = body?.userId ?? null;
    if (!userId) {
      return new Response(JSON.stringify({ ok: false }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: freq } = await admin
      .from("pe_macro_frequency")
      .select("pattern_type, pattern_label, weighted_score")
      .eq("user_id", userId);

    const rows = freq ?? [];
    const top = {
      emotional: topByType(rows, "emotional_loop"),
      communication: topByType(rows, "communication_style"),
      conflict: topByType(rows, "conflict_role"),
      themes: topByType(rows, "recurring_theme"),
      distortions: topByType(rows, "cognitive_distortion"),
    };

    const newProfile = {
      emotional_baseline: { top: top.emotional },
      communication_baseline: { top: top.communication },
      conflict_role_baseline: { top: top.conflict },
      attachment_signals: {},
      blind_spots: top.distortions.map((t) => t.label),
      strengths: [],
      vulnerabilities: top.themes.map((t) => t.label),
      recurring_triggers: top.themes.map((t) => t.label),
    };

    const narrative = await guardrail(buildNarrative(top));

    // Snapshot previous version (if any), then upsert
    const { data: prev } = await admin
      .from("pe_identity_profile")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();

    if (prev) {
      await admin.from("pe_identity_profile_history").insert({
        user_id: userId,
        version: prev.version,
        snapshot: prev,
        narrative_md: prev.narrative_md,
      });
      await admin
        .from("pe_identity_profile")
        .update({
          ...newProfile,
          narrative_md: narrative,
          version: (prev.version ?? 1) + 1,
          last_updated_at: new Date().toISOString(),
        })
        .eq("user_id", userId);
    } else {
      await admin.from("pe_identity_profile").insert({
        user_id: userId,
        ...newProfile,
        narrative_md: narrative,
        version: 1,
      });
    }

    await admin.from("pe_job_runs").insert({
      user_id: userId,
      job_name: "pe_update_identity",
      status: "success",
      triggered_by: "on_answer_saved",
      completed_at: new Date().toISOString(),
    });

    return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: String(e) }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  }
});
