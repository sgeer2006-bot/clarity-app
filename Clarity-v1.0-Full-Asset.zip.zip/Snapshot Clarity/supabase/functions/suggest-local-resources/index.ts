// Suggest categories of local resources relevant to a user's situation.
// We deliberately do NOT return URLs or fabricated phone numbers — instead we
// return search-ready resource categories the user can look up locally
// (e.g. "Low-cost couples therapy", "Tenant rights legal aid").

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const SYSTEM_PROMPT = `You suggest categories of LOCAL, real-world resources a person might look up based on a situation they described.

STRICT RULES:
- Suggest 3 to 6 resource categories, ranked by relevance.
- Each suggestion must be a TYPE of resource people search for in their own area, not a specific organization, brand, website, or phone number.
- NEVER invent organization names, URLs, hotline numbers, or addresses. The app shows real hotlines separately.
- Do NOT give advice, do NOT take sides, do NOT diagnose. Just name the type of help that exists.
- Use plain, non-clinical language a regular person would type into a search engine.
- Each "search_query" is a short string the user could paste into Google + their city. Do not include city names or "near me" — the UI adds that.
- Tone: calm, practical, non-alarming.

Output ONLY valid JSON via the provided tool. No prose.`;

const TOOL = {
  type: "function",
  function: {
    name: "suggest_resource_categories",
    description: "Return 3-6 categories of local resources relevant to the situation.",
    parameters: {
      type: "object",
      properties: {
        suggestions: {
          type: "array",
          minItems: 3,
          maxItems: 6,
          items: {
            type: "object",
            properties: {
              title: {
                type: "string",
                description:
                  "Short label, max 6 words, e.g. 'Low-cost couples therapy'.",
              },
              why: {
                type: "string",
                description:
                  "One short sentence (≤ 20 words) on why this could help, neutral tone.",
              },
              search_query: {
                type: "string",
                description:
                  "Plain search query the user can paste into a search engine (no city, no quotes).",
              },
              category: {
                type: "string",
                enum: [
                  "mental_health",
                  "relationships",
                  "legal",
                  "financial",
                  "housing",
                  "medical",
                  "parenting_family",
                  "substance_use",
                  "spiritual_community",
                  "support_group",
                  "other",
                ],
              },
            },
            required: ["title", "why", "search_query", "category"],
            additionalProperties: false,
          },
        },
      },
      required: ["suggestions"],
      additionalProperties: false,
    },
  },
} as const;

const FORBIDDEN = [
  "you should",
  "i recommend",
  "i suggest",
  "the best thing",
  "you must",
  "call 1-",
  "call 1 ",
  "http://",
  "https://",
  ".com",
  ".org",
  ".net",
];

function looksLikeURLOrPhone(s: string) {
  const lower = s.toLowerCase();
  if (FORBIDDEN.some((f) => lower.includes(f))) return true;
  // crude phone heuristic
  if (/\d{3}[\s\-.]?\d{3}[\s\-.]?\d{4}/.test(s)) return true;
  return false;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const auth = req.headers.get("Authorization") ?? "";
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );
    const { data: userRes } = await supabase.auth.getUser();
    if (!userRes.user) {
      return new Response(JSON.stringify({ error: "unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { sessionId } = await req.json();
    if (!sessionId || typeof sessionId !== "string") {
      return new Response(JSON.stringify({ error: "sessionId required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: session, error: sErr } = await supabase
      .from("reflection_sessions")
      .select("id, user_id, snapshot_json, title")
      .eq("id", sessionId)
      .maybeSingle();

    if (sErr || !session || session.user_id !== userRes.user.id) {
      return new Response(JSON.stringify({ error: "not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: answers } = await supabase
      .from("reflection_answers")
      .select("question_text, answer_text, question_type")
      .eq("session_id", sessionId)
      .order("question_index", { ascending: true });

    const snapshotText = session.snapshot_json
      ? `SUMMARY: ${(session.snapshot_json as any).summary ?? ""}\nOBSERVATIONS: ${
          ((session.snapshot_json as any).observations ?? []).join(" | ")
        }`
      : "";

    const answersText = (answers ?? [])
      .map((a: any) => `Q: ${a.question_text}\nA: ${a.answer_text}`)
      .join("\n\n");

    const userPayload = `Title: ${session.title}\n\n${snapshotText}\n\n${answersText}`;

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "LOVABLE_API_KEY missing" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPayload },
        ],
        tools: [TOOL],
        tool_choice: { type: "function", function: { name: "suggest_resource_categories" } },
      }),
    });

    if (aiResp.status === 429) {
      return new Response(
        JSON.stringify({ error: "Rate limited, please try again in a moment." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (aiResp.status === 402) {
      return new Response(
        JSON.stringify({ error: "AI credits exhausted. Please add credits in Settings → Workspace → Usage." }),
        { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    if (!aiResp.ok) {
      const t = await aiResp.text();
      console.error("AI gateway error:", aiResp.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await aiResp.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    const argsStr = toolCall?.function?.arguments;
    if (!argsStr) {
      return new Response(JSON.stringify({ error: "AI returned no suggestions" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let parsed: any;
    try {
      parsed = JSON.parse(argsStr);
    } catch {
      return new Response(JSON.stringify({ error: "AI returned invalid JSON" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const raw = Array.isArray(parsed?.suggestions) ? parsed.suggestions : [];
    const suggestions = raw
      .filter((s: any) =>
        s &&
        typeof s.title === "string" &&
        typeof s.why === "string" &&
        typeof s.search_query === "string" &&
        typeof s.category === "string" &&
        !looksLikeURLOrPhone(s.title) &&
        !looksLikeURLOrPhone(s.why) &&
        !looksLikeURLOrPhone(s.search_query)
      )
      .slice(0, 6);

    if (suggestions.length === 0) {
      return new Response(JSON.stringify({ error: "No clean suggestions returned" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ suggestions }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("suggest-local-resources error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
