// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const MAX_QUESTIONS = 10;
const SOFT_FLOOR = 4; // QIL may end any time after this slot if no priority gap remains.

// Priority categories the QIL scans for, in order of importance.
const PRIORITY_CATEGORIES = [
  "contradiction",
  "missing_detail",
  "timeline_gap",
  "emotional_trigger",
  "motivation",
  "consequence",
  "relationship_dynamic",
] as const;
type PriorityCategory = typeof PRIORITY_CATEGORIES[number];

// ---------- Prompts ----------

const ANALYZER_PROMPT = `You are the analyzer for a reflective conversation tool. Read the user's prior answers and identify the SINGLE most important missing piece of context to ask about next.

Priority categories (in order of importance — pick the highest-priority gap that actually exists):
1. contradiction — something the user said conflicts with something else they said
2. missing_detail — a basic fact (who/what/when/where) is missing and blocks understanding
3. timeline_gap — the order or timing of events is unclear
4. emotional_trigger — what specifically set off their feelings is unclear
5. motivation — why someone (user or other) acted the way they did is unclear
6. consequence — what happened next or what's at stake is unclear
7. relationship_dynamic — the nature of the relationship is unclear in a way that matters

Also decide whether the best way to fill this gap is an OPEN question (needs a sentence) or a YES/NO question (a quick clarifier).

If you have enough context for a meaningful snapshot AND no priority gap remains, set "complete" to true.

Return ONLY valid JSON:
{"category": "<one of the categories above>", "gap_description": "<short description of what's missing>", "best_type": "open" | "yesno", "complete": false, "sufficiency_score": <0-100>}

If complete:
{"category": "none", "gap_description": "", "best_type": "open", "complete": true, "sufficiency_score": <0-100>}

No preamble, no markdown.`;

const QUESTION_PROMPT_OPEN = (gap: { category: string; gap_description: string }) =>
  `You help someone think through a tricky situation by asking ONE simple follow-up question at a time.

Your job RIGHT NOW: ask one question that fills this specific gap.
- Category: ${gap.category}
- Gap: ${gap.gap_description}

Style rules (very important):
- Plain, everyday language, ~6th-grade reading level.
- Short and concrete. One sentence.
- Reference specifics the user already mentioned when helpful.
- Do not repeat or reword a question already answered.
- Do not invent filler. The question must directly target the gap above.

Forbidden words: reflection, reflective, dynamic, framework, pattern, lens, construct, narrative, journey, therapeutic.

Hard rules (legal safety):
- Never give advice. Never recommend actions.
- Never use phrases like "you should", "you need to", "I recommend", "the best thing", "try doing".
- Do not assume fault, blame, or judge anyone.
- Do not diagnose or label anyone's behavior.

Return ONLY valid JSON:
{"question": "<single sentence question>", "min_chars": <integer 10-80>, "sufficiency_score": <integer 0-100>}

min_chars guidance: short clarifier 10-20; core description 40-80.
No preamble, no markdown.`;

const QUESTION_PROMPT_YESNO = (gap: { category: string; gap_description: string }) =>
  `You help someone think through a tricky situation. Ask ONE short Yes/No question that fills this specific gap.
- Category: ${gap.category}
- Gap: ${gap.gap_description}

Rules:
- Plain, 6th-grade language.
- Must be answerable strictly with Yes or No.
- Personalize from the user's words.
- Do not repeat a question already answered.
- No advice, no "you should", no recommendations.
- Forbidden words: reflection, dynamic, framework, pattern, lens, construct, narrative, journey, therapeutic.

Return ONLY valid JSON:
{"question": "<single yes/no question>", "sufficiency_score": <integer 0-100>}`;

const VALIDATOR_PROMPT = `You are a strict reviewer of follow-up questions in a reflective conversation tool.

Given the prior answers, the priority gap that should be filled, and a candidate question, decide if the question is:
- relevant: ties to what the user actually said
- connected: logically continues the thread
- necessary: fills a real gap, doesn't repeat what's known
- specific: not vague, not generic, not random

Reject if it violates ANY of those, repeats info already given, uses forbidden phrasing ("you should", "you need to", "I recommend"), or is filler.

Return ONLY valid JSON:
{"valid": true | false, "reason": "<short reason if invalid, empty string otherwise>"}`;

const NUDGE_PROMPT = `The user's answer is too brief to be useful. Write ONE short, kind nudge that asks them for the SPECIFIC kind of detail this question needs (a fact, a feeling, who was involved, what was said, etc.).

Tone: gentle, conversational, never frustrated. Never use the words "too short", "error", or "invalid".

Return ONLY valid JSON:
{"nudge": "<one short sentence ending with a question or soft prompt>"}`;

// ---------- Forbidden phrase guard ----------

const FORBIDDEN_STARTS = [
  "you should",
  "you need to",
  "you must",
  "i recommend",
  "the best thing",
  "the best option",
  "the right choice",
  "try doing",
];

function containsForbidden(s: string): boolean {
  const l = s.toLowerCase().trim();
  return FORBIDDEN_STARTS.some((p) => l.startsWith(p));
}

function tryParseJson(s: string): any | null {
  if (!s) return null;
  const cleaned = s.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try { return JSON.parse(cleaned); } catch { /* try slice */ }
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start >= 0 && end > start) {
    try { return JSON.parse(cleaned.slice(start, end + 1)); } catch { return null; }
  }
  return null;
}

// ---------- LLM helper ----------

async function callLLM(
  systemPrompt: string,
  userContent: string,
  temperature = 0.4,
): Promise<string | null> {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");

  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      temperature,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userContent },
      ],
    }),
  });

  if (!resp.ok) {
    const text = await resp.text();
    if (resp.status === 429) throw new Error("RATE_LIMITED");
    if (resp.status === 402) throw new Error("PAYMENT_REQUIRED");
    throw new Error(`LLM error ${resp.status}: ${text}`);
  }

  const data = await resp.json();
  const content: string = (data?.choices?.[0]?.message?.content ?? "").trim();
  return content || null;
}

function clampInt(n: any, lo: number, hi: number, fallback: number): number {
  const v = typeof n === "number" ? n : parseInt(n, 10);
  if (!Number.isFinite(v)) return fallback;
  return Math.max(lo, Math.min(hi, Math.round(v)));
}

// ---------- QIL pipeline steps ----------

interface PriorityGap {
  category: PriorityCategory | "none";
  gap_description: string;
  best_type: "open" | "yesno";
  complete: boolean;
  sufficiency_score: number;
}

async function analyzeContext(
  priorAnswers: { question: string; answer: string; type?: string }[],
): Promise<PriorityGap> {
  const out = await callLLM(
    ANALYZER_PROMPT,
    JSON.stringify({ prior_answers: priorAnswers }),
    0.2,
  );
  const parsed = tryParseJson(out || "");
  const cat = (parsed?.category ?? "missing_detail").toString();
  const valid = (PRIORITY_CATEGORIES as readonly string[]).includes(cat) || cat === "none";
  return {
    category: (valid ? cat : "missing_detail") as PriorityCategory | "none",
    gap_description: (parsed?.gap_description ?? "").toString(),
    best_type: parsed?.best_type === "yesno" ? "yesno" : "open",
    complete: !!parsed?.complete,
    sufficiency_score: clampInt(parsed?.sufficiency_score, 0, 100, 50),
  };
}

interface CandidateQuestion {
  question: string;
  min_chars: number;
  sufficiency_score: number;
}

async function generateQuestion(
  gap: PriorityGap,
  priorAnswers: { question: string; answer: string; type?: string }[],
  isYesNo: boolean,
): Promise<CandidateQuestion | null> {
  const sys = isYesNo
    ? QUESTION_PROMPT_YESNO({ category: gap.category, gap_description: gap.gap_description })
    : QUESTION_PROMPT_OPEN({ category: gap.category, gap_description: gap.gap_description });
  const out = await callLLM(sys, JSON.stringify({ prior_answers: priorAnswers }), 0.5);
  const parsed = tryParseJson(out || "");
  const q: string | undefined = parsed?.question?.toString?.().trim().replace(/^["']|["']$/g, "").trim();
  if (!q) return null;
  if (containsForbidden(q)) return null;
  return {
    question: q,
    min_chars: isYesNo ? 0 : clampInt(parsed?.min_chars, 10, 80, 30),
    sufficiency_score: clampInt(parsed?.sufficiency_score, 0, 100, 50),
  };
}

async function validateQuestion(
  question: string,
  gap: PriorityGap,
  priorAnswers: { question: string; answer: string; type?: string }[],
): Promise<{ valid: boolean; reason: string }> {
  const out = await callLLM(
    VALIDATOR_PROMPT,
    JSON.stringify({
      prior_answers: priorAnswers,
      priority_gap: { category: gap.category, gap_description: gap.gap_description },
      candidate_question: question,
    }),
    0.1,
  );
  const parsed = tryParseJson(out || "");
  return {
    valid: parsed?.valid === true,
    reason: (parsed?.reason ?? "").toString(),
  };
}

const SAFE_FALLBACK_OPEN: Record<string, string> = {
  contradiction: "Earlier it sounded like two things might be in tension — can you say more about which feels more true right now?",
  missing_detail: "Can you walk me through what actually happened, step by step?",
  timeline_gap: "When did this start, and what happened first?",
  emotional_trigger: "What part of this hit you hardest?",
  motivation: "What were you hoping would happen?",
  consequence: "What's at stake for you if this doesn't get better?",
  relationship_dynamic: "How would you describe your relationship with the person involved?",
  none: "What part of this feels most important to you right now?",
};

const SAFE_FALLBACK_YESNO: Record<string, string> = {
  contradiction: "Are you feeling pulled in two different directions about this?",
  missing_detail: "Did this happen recently?",
  timeline_gap: "Is this still happening now?",
  emotional_trigger: "Are you feeling pretty stirred up about this?",
  motivation: "Were you hoping for a specific outcome?",
  consequence: "Does this feel urgent to figure out?",
  relationship_dynamic: "Is this person someone close to you?",
  none: "Is this something you want to handle soon?",
};

async function runPipeline(
  priorAnswers: { question: string; answer: string; type?: string }[],
  forceRegenerate: boolean,
): Promise<{
  question: string;
  question_type: "open" | "yesno";
  min_chars: number;
  sufficiency_score: number;
  done: boolean;
  category: string;
}> {
  // Step 1: analyze context for the priority gap.
  const gap = await analyzeContext(priorAnswers);

  // Step 2: completion check (only after the soft floor).
  if (gap.complete && priorAnswers.length >= SOFT_FLOOR) {
    return {
      question: "",
      question_type: "open",
      min_chars: 0,
      sufficiency_score: gap.sufficiency_score,
      done: true,
      category: "none",
    };
  }

  // If the model said complete but we're below the floor, force a question
  // by treating it as a missing_detail gap.
  const effectiveGap: PriorityGap = gap.complete
    ? { ...gap, complete: false, category: "missing_detail", gap_description: "Need more context to build a useful snapshot.", best_type: "open" }
    : gap;

  const isYesNo = effectiveGap.best_type === "yesno";

  // Step 3 + 4: generate, validate, retry up to 3 times.
  const tempBoost = forceRegenerate ? 0.2 : 0;
  let lastCandidate: CandidateQuestion | null = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    const candidate = await generateQuestion(effectiveGap, priorAnswers, isYesNo);
    if (!candidate) {
      console.warn(`QIL attempt ${attempt + 1}: empty/forbidden generation`);
      continue;
    }
    lastCandidate = candidate;
    const review = await validateQuestion(candidate.question, effectiveGap, priorAnswers);
    if (review.valid) {
      return {
        question: candidate.question,
        question_type: isYesNo ? "yesno" : "open",
        min_chars: candidate.min_chars,
        sufficiency_score: candidate.sufficiency_score,
        done: false,
        category: effectiveGap.category,
      };
    }
    console.warn(`QIL attempt ${attempt + 1} rejected: ${review.reason}`);
  }

  // Step 5: fallback to a safe, category-appropriate default.
  const fallback = (isYesNo ? SAFE_FALLBACK_YESNO : SAFE_FALLBACK_OPEN)[effectiveGap.category]
    || SAFE_FALLBACK_OPEN.none;
  return {
    question: lastCandidate?.question && !containsForbidden(lastCandidate.question)
      ? lastCandidate.question
      : fallback,
    question_type: isYesNo ? "yesno" : "open",
    min_chars: isYesNo ? 0 : 30,
    sufficiency_score: 40,
    done: false,
    category: effectiveGap.category,
  };
}

async function generateNudge(
  currentQuestion: string,
  shortAnswer: string,
): Promise<string> {
  try {
    const out = await callLLM(
      NUDGE_PROMPT,
      JSON.stringify({ question: currentQuestion, answer: shortAnswer }),
      0.5,
    );
    const parsed = tryParseJson(out || "");
    const nudge = parsed?.nudge?.toString?.().trim();
    if (nudge) return nudge;
  } catch (e) {
    console.warn("Nudge generation failed:", e);
  }
  return "This is a little too brief for me to understand clearly. Could you add one detail about what happened or how you felt?";
}

// ---------- HTTP handler ----------

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userToken = authHeader.replace("Bearer ", "");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userErr } = await supabase.auth.getUser(userToken);
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = userData.user.id;

    const body = await req.json();
    const sessionId: string = body?.sessionId;
    const priorAnswers: { question: string; answer: string; type?: string }[] = Array.isArray(body?.priorAnswers)
      ? body.priorAnswers
      : [];
    const forceRegenerate: boolean = !!body?.forceRegenerate;

    // Nudge mode: return a contextual hint for a too-short answer.
    const mode: string | undefined = body?.mode;
    if (mode === "nudge") {
      const currentQuestion: string = body?.currentQuestion ?? "";
      const shortAnswer: string = body?.answer ?? "";
      const nudge = await generateNudge(currentQuestion, shortAnswer);
      return new Response(JSON.stringify({ nudge }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!sessionId || typeof sessionId !== "string") {
      return new Response(JSON.stringify({ error: "Missing sessionId" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: session } = await supabase
      .from("reflection_sessions")
      .select("id, user_id, status")
      .eq("id", sessionId)
      .maybeSingle();

    if (!session || session.user_id !== userId) {
      return new Response(JSON.stringify({ error: "Session not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const slot = priorAnswers.length + 1;

    // Hard cap.
    if (slot > MAX_QUESTIONS) {
      return new Response(
        JSON.stringify({
          done: true,
          target: SOFT_FLOOR,
          max: MAX_QUESTIONS,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    let result;
    try {
      result = await runPipeline(priorAnswers, forceRegenerate);
    } catch (e: any) {
      const msg = e?.message || "";
      if (msg === "RATE_LIMITED") {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (msg === "PAYMENT_REQUIRED") {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits to your workspace." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw e;
    }

    return new Response(
      JSON.stringify({
        question: result.question,
        question_type: result.question_type,
        min_chars: result.min_chars,
        sufficiency_score: result.sufficiency_score,
        done: result.done,
        category: result.category,
        target: SOFT_FLOOR,
        max: MAX_QUESTIONS,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e: any) {
    console.error("generate-next-question error:", e);
    return new Response(JSON.stringify({ error: e.message ?? "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
