// pe-detect-macro-patterns
// Lightweight per-answer macro pattern extraction. Combines a deterministic
// lexicon sweep with an LLM pass via Lovable AI Gateway. Writes results to
// pe_macro_patterns and updates pe_macro_frequency.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;

type PatternHit = {
  pattern_type: string;
  pattern_label: string;
  confidence: number;
};

const LEXICON: Array<{ re: RegExp; type: string; label: string; conf: number }> = [
  // emotional loops
  { re: /\b(again|same thing|always end up|keep doing|over and over)\b/i, type: "emotional_loop", label: "Recurring cycle awareness", conf: 0.5 },
  { re: /\b(panic|spiral|overwhelm|shutting down|shut down)\b/i, type: "emotional_loop", label: "Overwhelm spiral", conf: 0.55 },
  // communication styles
  { re: /\b(i didn't say|i kept quiet|i held back|i bit my tongue)\b/i, type: "communication_style", label: "Withheld communication", conf: 0.55 },
  { re: /\b(i snapped|i lashed out|i exploded|i yelled)\b/i, type: "communication_style", label: "Reactive communication", conf: 0.6 },
  { re: /\b(i explained|i tried to explain|i clarified|i justified)\b/i, type: "communication_style", label: "Over-explaining", conf: 0.5 },
  // conflict roles
  { re: /\b(i wanted them to|i needed them to respond|i kept reaching out)\b/i, type: "conflict_role", label: "Pursuer", conf: 0.55 },
  { re: /\b(i pulled away|i needed space|i shut down|i went quiet)\b/i, type: "conflict_role", label: "Distancer", conf: 0.55 },
  { re: /\b(i tried to fix|i wanted to make it better|i smoothed it over)\b/i, type: "conflict_role", label: "Fixer", conf: 0.5 },
  { re: /\b(it's their fault|they made me|because of them)\b/i, type: "conflict_role", label: "Blamer", conf: 0.5 },
  // cognitive distortions
  { re: /\b(always|never|everyone|no one|nothing ever)\b/i, type: "cognitive_distortion", label: "All-or-nothing thinking", conf: 0.45 },
  { re: /\b(worst case|disaster|ruined|catastroph)/i, type: "cognitive_distortion", label: "Catastrophizing", conf: 0.55 },
  { re: /\b(they think|they probably feel|i know what they|they must)\b/i, type: "cognitive_distortion", label: "Mind-reading", conf: 0.5 },
  { re: /\b(should have|shouldn't have|i should|they should)\b/i, type: "cognitive_distortion", label: "Should-ing", conf: 0.5 },
  // recurring themes
  { re: /\b(in control|out of control|losing control|lose control)\b/i, type: "recurring_theme", label: "Control", conf: 0.55 },
  { re: /\b(left me|abandoned|ghosted|walked away)\b/i, type: "recurring_theme", label: "Abandonment", conf: 0.6 },
  { re: /\b(seen|recognized|appreciated|noticed|valued)\b/i, type: "recurring_theme", label: "Recognition", conf: 0.45 },
  { re: /\b(unfair|not fair|deserved|owed|injustice)\b/i, type: "recurring_theme", label: "Fairness", conf: 0.5 },
  { re: /\b(my own|by myself|on my own|independence|space)\b/i, type: "recurring_theme", label: "Autonomy", conf: 0.45 },
];

function lexiconSweep(text: string): PatternHit[] {
  const hits: PatternHit[] = [];
  for (const entry of LEXICON) {
    if (entry.re.test(text)) {
      hits.push({ pattern_type: entry.type, pattern_label: entry.label, confidence: entry.conf });
    }
  }
  return hits;
}

async function llmExtract(text: string): Promise<PatternHit[]> {
  if (!LOVABLE_API_KEY || text.length < 60) return [];
  try {
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content:
              "Extract up to 4 macro psychological patterns from the journal text. Return ONLY JSON: {\"patterns\":[{\"pattern_type\":\"emotional_loop|communication_style|conflict_role|cognitive_distortion|recurring_theme\",\"pattern_label\":\"short label\",\"confidence\":0..1}]}. No prose. Be conservative; omit if not clearly present.",
          },
          { role: "user", content: text.slice(0, 4000) },
        ],
        response_format: { type: "json_object" },
      }),
    });
    if (!res.ok) return [];
    const json = await res.json();
    const content = json?.choices?.[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(content);
    const arr = Array.isArray(parsed?.patterns) ? parsed.patterns : [];
    return arr
      .filter((p: any) => p?.pattern_type && p?.pattern_label)
      .map((p: any) => ({
        pattern_type: String(p.pattern_type),
        pattern_label: String(p.pattern_label).slice(0, 80),
        confidence: Math.max(0, Math.min(1, Number(p.confidence) || 0.5)),
      }));
  } catch {
    return [];
  }
}

function dedupe(hits: PatternHit[]): PatternHit[] {
  const map = new Map<string, PatternHit>();
  for (const h of hits) {
    const key = `${h.pattern_type}::${h.pattern_label.toLowerCase()}`;
    const existing = map.get(key);
    if (!existing || h.confidence > existing.confidence) map.set(key, h);
  }
  return Array.from(map.values());
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const admin = createClient(SUPABASE_URL, SERVICE_KEY);
  let userId: string | null = null;
  let answerId: string | null = null;

  try {
    const body = await req.json().catch(() => ({}));
    answerId = body?.answerId ?? null;
    userId = body?.userId ?? null;
    if (!answerId || !userId) {
      return new Response(JSON.stringify({ ok: false, error: "missing answerId/userId" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: ans } = await admin
      .from("reflection_answers")
      .select("id, session_id, answer_text")
      .eq("id", answerId)
      .maybeSingle();

    if (!ans?.answer_text) {
      return new Response(JSON.stringify({ ok: true, skipped: "no answer text" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    const text = ans.answer_text;
    const lex = lexiconSweep(text);
    const llm = await llmExtract(text);
    const hits = dedupe([...lex, ...llm]);

    if (hits.length === 0) {
      return new Response(JSON.stringify({ ok: true, count: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    // Insert macro patterns
    const inserts = hits.map((h) => ({
      user_id: userId,
      pattern_type: h.pattern_type,
      pattern_label: h.pattern_label,
      confidence: h.confidence,
      source_answer_ids: [answerId],
      payload: { extractor: "lexicon+llm" },
    }));
    await admin.from("pe_macro_patterns").insert(inserts);

    // Upsert frequency rows (simple recency-weighted: weighted += confidence)
    for (const h of hits) {
      const { data: existing } = await admin
        .from("pe_macro_frequency")
        .select("id, raw_count, weighted_score")
        .eq("user_id", userId)
        .eq("pattern_type", h.pattern_type)
        .eq("pattern_label", h.pattern_label)
        .maybeSingle();

      if (existing) {
        await admin
          .from("pe_macro_frequency")
          .update({
            raw_count: (existing.raw_count ?? 0) + 1,
            weighted_score: Number(existing.weighted_score ?? 0) + h.confidence,
            last_seen_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
          .eq("id", existing.id);
      } else {
        await admin.from("pe_macro_frequency").insert({
          user_id: userId,
          pattern_type: h.pattern_type,
          pattern_label: h.pattern_label,
          raw_count: 1,
          weighted_score: h.confidence,
          last_seen_at: new Date().toISOString(),
        });
      }
    }

    await admin.from("pe_job_runs").insert({
      user_id: userId,
      job_name: "pe_detect_macro_patterns",
      status: "success",
      triggered_by: "on_answer_saved",
      source_answer_id: answerId,
      details: { count: hits.length },
      completed_at: new Date().toISOString(),
    });

    return new Response(JSON.stringify({ ok: true, count: hits.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (e) {
    if (userId) {
      await admin.from("pe_job_runs").insert({
        user_id: userId,
        job_name: "pe_detect_macro_patterns",
        status: "error",
        triggered_by: "on_answer_saved",
        source_answer_id: answerId,
        error_message: String(e),
        completed_at: new Date().toISOString(),
      }).then(() => {}, () => {});
    }
    return new Response(JSON.stringify({ ok: false, error: String(e) }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  }
});
