// Stripe webhook handler for Clarity+ subscriptions.
// Pre-registered by Lovable Payments; receives ?env=sandbox or ?env=live.
// Verifies the signature using the raw request body before any processing.

import { createClient } from "npm:@supabase/supabase-js@2";
import Stripe from "https://esm.sh/stripe@17.7.0?target=denonext";
import {
  type StripeEnv,
  createStripeClient,
  getWebhookSecret,
} from "../_shared/stripe.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type, stripe-signature",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

function envFromUrl(url: string): StripeEnv {
  try {
    const env = new URL(url).searchParams.get("env");
    return env === "live" ? "live" : "sandbox";
  } catch {
    return "sandbox";
  }
}

async function upsertFromSubscription(
  sub: any,
  environment: StripeEnv,
  fallbackUserId?: string,
) {
  const userId =
    (sub?.metadata?.userId as string | undefined) ?? fallbackUserId;
  if (!userId) {
    console.warn("[clarity-plus-webhook] no userId on subscription", sub?.id);
    return;
  }
  const item = sub?.items?.data?.[0];
  const stripePriceId = item?.price?.id as string | undefined;
  const productId = (item?.price?.product as string | undefined) ?? null;

  // Resolve the human-readable lookup_key (e.g. "clarity_plus_monthly")
  // so feature gating stays stable across sandbox and live.
  let priceLookup: string | null = null;
  try {
    if (stripePriceId) {
      const stripe = createStripeClient(environment);
      const priceObj = await stripe.prices.retrieve(stripePriceId);
      priceLookup = (priceObj.lookup_key as string | null) ?? null;
    }
  } catch (e) {
    console.warn("[clarity-plus-webhook] price lookup failed", e);
  }

  const periodEnd = sub?.current_period_end
    ? new Date(sub.current_period_end * 1000).toISOString()
    : null;

  await supabase
    .from("subscriptions")
    .upsert(
      {
        user_id: userId,
        environment,
        status: sub.status,
        price_id: priceLookup ?? stripePriceId ?? null,
        product_id: productId,
        stripe_customer_id: (sub.customer as string) ?? null,
        stripe_subscription_id: sub.id as string,
        current_period_end: periodEnd,
        cancel_at_period_end: !!sub.cancel_at_period_end,
      },
      { onConflict: "stripe_subscription_id" },
    );
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const environment = envFromUrl(req.url);
  const signature = req.headers.get("stripe-signature");
  if (!signature) return new Response("Missing signature", { status: 400 });

  // CRITICAL: read raw body before any JSON parsing.
  const rawBody = await req.text();

  const stripe = createStripeClient(environment);
  let event;
  try {
    event = await stripe.webhooks.constructEventAsync(
      rawBody,
      signature,
      getWebhookSecret(environment),
      undefined,
      Stripe.createSubtleCryptoProvider(),
    );
  } catch (err) {
    console.error("[clarity-plus-webhook] signature verification failed:", err);
    return new Response("Invalid signature", { status: 400 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session: any = event.data.object;
        if (session.mode === "subscription" && session.subscription) {
          const fullSub = await stripe.subscriptions.retrieve(
            session.subscription as string,
          );
          const fallbackUserId =
            (session.client_reference_id as string | undefined) ??
            (session.metadata?.userId as string | undefined);
          await upsertFromSubscription(fullSub, environment, fallbackUserId);
        }
        break;
      }
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "subscription.created":
      case "subscription.updated": {
        await upsertFromSubscription(event.data.object as any, environment);
        break;
      }
      case "customer.subscription.deleted":
      case "subscription.canceled": {
        const sub: any = event.data.object;
        await supabase
          .from("subscriptions")
          .update({ status: "canceled", cancel_at_period_end: true })
          .eq("stripe_subscription_id", sub.id)
          .eq("environment", environment);
        break;
      }
      default:
        // Acknowledge other event types without action.
        break;
    }
  } catch (err) {
    console.error("[clarity-plus-webhook] handler error:", err);
    // Acknowledge with 200 so Stripe doesn't retry indefinitely on logic errors.
  }

  return new Response(JSON.stringify({ received: true }), {
    status: 200,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});

