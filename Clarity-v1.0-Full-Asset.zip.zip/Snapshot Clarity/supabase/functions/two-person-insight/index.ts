// Generate a combined insight + per-side suggested rewrite for a Two-Person session.
// Owner-only. Uses Lovable AI Gateway (no API key required).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;

interface ReqBody {
  session_id: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const auth = req.headers.get("Authorization");
    if (!auth) {
      return json({ error: "Missing authorization" }, 401);
    }
    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: auth } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) {
      return json({ error: "Unauthorized" }, 401);
    }
    const userId = userData.user.id;

    let body: ReqBody;
    try {
      body = await req.json();
    } catch {
      return json({ error: "Invalid JSON" }, 400);
    }
    if (!body?.session_id || typeof body.session_id !== "string") {
      return json({ error: "session_id is required" }, 400);
    }

    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Verify ownership and load both perspectives
    const { data: session, error: sErr } = await admin
      .from("two_person_sessions")
      .select("id, owner_id, topic, status")
      .eq("id", body.session_id)
      .is("deleted_at", null)
      .maybeSingle();

    if (sErr || !session) return json({ error: "Session not found" }, 404);
    if (session.owner_id !== userId) return json({ error: "Forbidden" }, 403);

    const { data: perspectives, error: pErr } = await admin
      .from("two_person_perspectives")
      .select("side, display_name, perspective_text")
      .eq("session_id", session.id);

    if (pErr) return json({ error: "Failed to load perspectives" }, 500);

    const owner = perspectives?.find((p) => p.side === "owner");
    const invitee = perspectives?.find((p) => p.side === "invitee");
    if (!owner || !invitee) {
      return json({ error: "Both perspectives are required" }, 400);
    }

    const ownerName = owner.display_name?.trim() || "Person A";
    const inviteeName = invitee.display_name?.trim() || "Person B";

    const systemPrompt = `You are Clarity, a calm, neutral communication coach. Two people have shared their own perspectives on the same situation. Generate a balanced, grounded combined insight that respects both sides. Never take sides. Never give advice or diagnose. Use plain, warm language. No clichés.`;

    const userPrompt = `Topic: ${session.topic}

${ownerName}'s perspective:
"""
${owner.perspective_text}
"""

${inviteeName}'s perspective:
"""
${invitee.perspective_text}
"""

Produce, via the tool call, a structured response with:
- combined_summary: 2–3 sentences naming what they actually seem to share underneath the friction.
- shared_themes: 2–4 short phrases describing emotional themes both perspectives carry (e.g. "feeling unseen", "wanting reassurance"). No moralizing.
- misread_points: 2–4 plain-language items in the form "[Person A] may be reading [Person B] as X, when [Person B] describes feeling Y." Use the actual names provided.
- rewrite_for_owner: a single message ${ownerName} could send to ${inviteeName}, in their voice, that opens the conversation with care. 1–3 sentences. No demands.
- rewrite_for_invitee: a single message ${inviteeName} could send to ${ownerName}, in their voice. 1–3 sentences. No demands.

Be specific to what they wrote. No filler.`;

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tool_choice: { type: "function", function: { name: "emit_combined_insight" } },
        tools: [
          {
            type: "function",
            function: {
              name: "emit_combined_insight",
              description: "Emit the combined insight and per-side rewrites.",
              parameters: {
                type: "object",
                additionalProperties: false,
                required: [
                  "combined_summary",
                  "shared_themes",
                  "misread_points",
                  "rewrite_for_owner",
                  "rewrite_for_invitee",
                ],
                properties: {
                  combined_summary: { type: "string" },
                  shared_themes: {
                    type: "array",
                    items: { type: "string" },
                    minItems: 1,
                    maxItems: 6,
                  },
                  misread_points: {
                    type: "array",
                    items: { type: "string" },
                    minItems: 1,
                    maxItems: 6,
                  },
                  rewrite_for_owner: { type: "string" },
                  rewrite_for_invitee: { type: "string" },
                },
              },
            },
          },
        ],
      }),
    });

    if (aiRes.status === 429) return json({ error: "Rate limit exceeded, please try again." }, 429);
    if (aiRes.status === 402) return json({ error: "AI credits exhausted." }, 402);
    if (!aiRes.ok) {
      const txt = await aiRes.text();
      console.error("AI gateway error", aiRes.status, txt);
      return json({ error: "AI request failed" }, 500);
    }

    const ai = await aiRes.json();
    const call = ai?.choices?.[0]?.message?.tool_calls?.[0];
    if (!call?.function?.arguments) {
      return json({ error: "AI did not return structured output" }, 500);
    }

    let parsed: {
      combined_summary: string;
      shared_themes: string[];
      misread_points: string[];
      rewrite_for_owner: string;
      rewrite_for_invitee: string;
    };
    try {
      parsed = JSON.parse(call.function.arguments);
    } catch (e) {
      console.error("AI args parse failed", e);
      return json({ error: "Invalid AI output" }, 500);
    }

    // Persist combined insight on session
    const { error: updErr } = await admin
      .from("two_person_sessions")
      .update({
        combined_summary: parsed.combined_summary,
        shared_themes: parsed.shared_themes,
        misread_points: parsed.misread_points,
        status: "complete",
        completed_at: new Date().toISOString(),
      })
      .eq("id", session.id);
    if (updErr) {
      console.error("Update session failed", updErr);
      return json({ error: "Failed to save insight" }, 500);
    }

    // Persist per-side suggested rewrites
    await admin
      .from("two_person_perspectives")
      .update({ suggested_rewrite: parsed.rewrite_for_owner })
      .eq("session_id", session.id)
      .eq("side", "owner");
    await admin
      .from("two_person_perspectives")
      .update({ suggested_rewrite: parsed.rewrite_for_invitee })
      .eq("session_id", session.id)
      .eq("side", "invitee");

    return json({ ok: true, ...parsed });
  } catch (e) {
    console.error("two-person-insight error", e);
    return json({ error: "Unexpected error" }, 500);
  }
});

function json(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
    status,
  });
}
