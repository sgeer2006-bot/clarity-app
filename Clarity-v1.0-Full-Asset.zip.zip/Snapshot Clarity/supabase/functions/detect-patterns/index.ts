// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SYSTEM_PROMPT = `You are a careful classifier of communication patterns.
You will be given (1) a catalog of patterns with slugs + short descriptions
and (2) a snapshot of a real situation a user shared.

Pick AT MOST 3 patterns from the catalog that genuinely match the situation.
- Only include a pattern if there is real evidence in the snapshot for it.
- If nothing fits well, return an empty list.
- Confidence must reflect how strong the evidence is (0-100).
- Reasons must be one short sentence each, grounded in what the user shared.
- Never invent patterns that are not in the catalog.
- Do not give advice or judgement.
Return your answer ONLY by calling the tool.`;

const TOOL = {
  type: "function",
  function: {
    name: "classify_patterns",
    description: "Return up to 3 catalog patterns that match the snapshot.",
    parameters: {
      type: "object",
      properties: {
        matches: {
          type: "array",
          maxItems: 3,
          items: {
            type: "object",
            properties: {
              slug: { type: "string" },
              confidence: { type: "integer", minimum: 0, maximum: 100 },
              reason: { type: "string", maxLength: 240 },
            },
            required: ["slug", "confidence", "reason"],
            additionalProperties: false,
          },
        },
      },
      required: ["matches"],
      additionalProperties: false,
    },
  },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userToken = authHeader.replace("Bearer ", "");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userErr } = await supabase.auth.getUser(userToken);
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = userData.user.id;

    const { sessionId } = await req.json();
    if (!sessionId || typeof sessionId !== "string") {
      return new Response(JSON.stringify({ error: "Missing sessionId" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Confirm ownership and fetch the snapshot
    const { data: session } = await supabase
      .from("reflection_sessions")
      .select("id, user_id, title, snapshot_json")
      .eq("id", sessionId)
      .maybeSingle();
    if (!session || session.user_id !== userId) {
      return new Response(JSON.stringify({ error: "Session not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const snap = session.snapshot_json as any;
    if (!snap) {
      return new Response(JSON.stringify({ matches: [] }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Catalog
    const { data: patterns } = await supabase
      .from("patterns")
      .select("id, slug, name, short_description");
    if (!patterns || patterns.length === 0) {
      return new Response(JSON.stringify({ matches: [] }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");

    const userPayload = JSON.stringify({
      catalog: patterns.map((p: any) => ({
        slug: p.slug,
        name: p.name,
        description: p.short_description,
      })),
      snapshot: {
        title: session.title,
        summary: snap.summary,
        observations: snap.observations,
        possible_paths: snap.possible_paths,
      },
    });

    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        temperature: 0.2,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPayload },
        ],
        tools: [TOOL],
        tool_choice: { type: "function", function: { name: "classify_patterns" } },
      }),
    });

    if (!resp.ok) {
      const text = await resp.text();
      console.error("detect-patterns LLM error", resp.status, text);
      if (resp.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited" }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (resp.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted" }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      return new Response(JSON.stringify({ matches: [] }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await resp.json();
    const call = data?.choices?.[0]?.message?.tool_calls?.[0];
    let parsedMatches: { slug: string; confidence: number; reason: string }[] = [];
    if (call?.function?.arguments) {
      try {
        const args = JSON.parse(call.function.arguments);
        if (Array.isArray(args.matches)) {
          parsedMatches = args.matches.filter(
            (m: any) =>
              typeof m?.slug === "string" &&
              typeof m?.confidence === "number" &&
              typeof m?.reason === "string",
          );
        }
      } catch (e) {
        console.error("detect-patterns: bad tool args", e);
      }
    }

    // Map slug -> id and filter to known patterns
    const bySlug = new Map(patterns.map((p: any) => [p.slug, p.id]));
    const valid = parsedMatches
      .filter((m) => bySlug.has(m.slug))
      .slice(0, 3)
      .map((m) => ({
        session_id: sessionId,
        pattern_id: bySlug.get(m.slug)!,
        confidence: Math.max(0, Math.min(100, Math.round(m.confidence))),
        reason: m.reason.slice(0, 240),
      }));

    // Replace any prior matches for this session, then insert the new ones.
    await supabase.from("session_patterns").delete().eq("session_id", sessionId);
    if (valid.length > 0) {
      const { error: insErr } = await supabase.from("session_patterns").insert(valid);
      if (insErr) {
        console.error("detect-patterns: insert error", insErr);
      }
    }

    return new Response(
      JSON.stringify({ matches: valid.map((v) => ({ pattern_id: v.pattern_id, confidence: v.confidence, reason: v.reason })) }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e: any) {
    console.error("detect-patterns error:", e);
    return new Response(JSON.stringify({ error: e.message ?? "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
