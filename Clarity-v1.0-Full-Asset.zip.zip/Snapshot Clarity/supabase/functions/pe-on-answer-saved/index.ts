// pe-on-answer-saved
// Fire-and-forget entry point invoked by the client after a reflection answer is saved.
// Logs a job run, then dispatches the per-answer pipeline asynchronously and returns immediately.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

async function dispatch(fn: string, body: Record<string, unknown>) {
  try {
    await fetch(`${SUPABASE_URL}/functions/v1/${fn}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${SERVICE_KEY}`,
        apikey: SERVICE_KEY,
      },
      body: JSON.stringify(body),
    });
  } catch {
    // swallow: never block
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  let answerId: string | null = null;
  let userId: string | null = null;

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ ok: false, error: "unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claims } = await supabase.auth.getClaims(token);
    userId = claims?.claims?.sub ?? null;

    const body = await req.json().catch(() => ({}));
    answerId = typeof body?.answerId === "string" ? body.answerId : null;

    if (userId && answerId) {
      const admin = createClient(SUPABASE_URL, SERVICE_KEY);
      await admin.from("pe_job_runs").insert({
        user_id: userId,
        job_name: "pe_on_answer_saved",
        status: "started",
        triggered_by: "on_answer_saved",
        source_answer_id: answerId,
      });

      // fire-and-forget the pipeline (do not await)
      dispatch("pe-detect-macro-patterns", { answerId, userId });
      dispatch("pe-update-identity", { answerId, userId });
      dispatch("pe-update-timeline", { answerId, userId });
      dispatch("pe-update-heatmap", { answerId, userId });
      dispatch("pe-cluster-patterns", { answerId, userId });
    }

    return new Response(JSON.stringify({ ok: true, queued: !!(userId && answerId) }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (e) {
    return new Response(JSON.stringify({ ok: true, error: String(e) }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200, // never block client
    });
  }
});
