// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function jsonOk(b: any) {
  return new Response(JSON.stringify(b), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
function jsonErr(s: number, e: string) {
  return new Response(JSON.stringify({ error: e }), {
    status: s,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) return jsonErr(401, "Unauthorized");
    const userToken = authHeader.replace("Bearer ", "");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: userData, error: userErr } = await supabase.auth.getUser(userToken);
    if (userErr || !userData?.user) return jsonErr(401, "Unauthorized");

    const { sessionId } = await req.json();
    if (!sessionId) return jsonErr(400, "Missing sessionId");

    const { data: sess } = await supabase
      .from("reflection_sessions")
      .select("id, user_id, snapshot_json, pattern_identity_id")
      .eq("id", sessionId)
      .maybeSingle();
    if (!sess || sess.user_id !== userData.user.id) return jsonErr(404, "Session not found");

    // Idempotent: if already assigned, return current
    if (sess.pattern_identity_id) {
      const { data: cur } = await supabase
        .from("pattern_identities")
        .select("*")
        .eq("id", sess.pattern_identity_id)
        .maybeSingle();
      if (cur) return jsonOk({ identity: cur, alreadyAssigned: true });
    }

    if (!sess.snapshot_json) return jsonErr(400, "No snapshot to classify");

    // Load context model for richer classification signal
    const { data: ctx } = await supabase
      .from("session_context_models")
      .select("*")
      .eq("session_id", sessionId)
      .maybeSingle();

    const { data: catalog } = await supabase
      .from("pattern_identities")
      .select("id, slug, name, short_description, communication_tendency, emotional_signature");

    if (!catalog || catalog.length === 0) return jsonErr(500, "Identity catalog is empty");

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) return jsonErr(500, "AI not configured");

    const catalogBlock = catalog
      .map((c: any) => `- ${c.slug} | ${c.name}: ${c.short_description}\n  signature: ${c.emotional_signature}\n  tendency: ${c.communication_tendency}`)
      .join("\n");

    const snap = sess.snapshot_json as any;
    const ctxBlock = ctx
      ? JSON.stringify({
          emotions: ctx.emotions,
          intentions: ctx.intentions,
          fears: ctx.fears,
          unspoken_needs: ctx.unspoken_needs,
          desired_outcome: ctx.desired_outcome,
        })
      : "{}";

    const system = `You are classifying a person's communication pattern from one situation snapshot.

Pick the SINGLE best match from this catalog. You must pick one — even if it's only an 80% fit, pick the closest.

CATALOG:
${catalogBlock}

SNAPSHOT:
summary: ${snap.summary || ""}
observations:
${(snap.observations || []).map((o: string) => `- ${o}`).join("\n")}
how_to_communicate:
${(snap.how_to_communicate || []).map((o: string) => `- ${o}`).join("\n")}

CONTEXT MODEL (signals about the user):
${ctxBlock}

Hard rules:
- Match the USER's communication pattern, not the other person's.
- Choose by emotional_signature + communication_tendency, not just by topic.

Return STRICT JSON only:
{ "slug": "one-of-the-catalog-slugs", "confidence": 0-100, "reason": "1 short sentence" }`;

    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        temperature: 0.2,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: system },
          { role: "user", content: "Classify and return JSON." },
        ],
      }),
    });

    if (!resp.ok) {
      const text = await resp.text();
      const status = resp.status === 429 ? 429 : resp.status === 402 ? 402 : 500;
      return jsonErr(status, `AI error: ${text}`);
    }

    const data = await resp.json();
    const raw = data?.choices?.[0]?.message?.content ?? "{}";
    let parsed: any = {};
    try { parsed = JSON.parse(raw); } catch { /* ignore */ }

    const slug = String(parsed.slug || "").trim();
    const match = catalog.find((c: any) => c.slug === slug);
    if (!match) return jsonErr(500, "Could not match a pattern identity");

    await supabase
      .from("reflection_sessions")
      .update({ pattern_identity_id: match.id })
      .eq("id", sessionId);

    return jsonOk({
      identity: match,
      alreadyAssigned: false,
      confidence: typeof parsed.confidence === "number" ? parsed.confidence : null,
      reason: parsed.reason || "",
    });
  } catch (e: any) {
    console.error("assign-pattern-identity error:", e);
    return jsonErr(500, e.message ?? "Unknown error");
  }
});
