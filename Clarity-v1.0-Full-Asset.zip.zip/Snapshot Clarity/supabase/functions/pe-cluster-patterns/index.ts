// pe-cluster-patterns
// Groups frequent patterns into themed clusters using a simple type-based grouping.
// Idempotent: replaces user's clusters on each run once enough frequency rows exist.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const CLUSTER_TEMPLATES: Record<string, { label: string; summary: string }> = {
  emotional_loop: { label: "Recurring emotional cycles", summary: "Sequences of feeling that have appeared more than once in your reflections." },
  communication_style: { label: "Communication shapes", summary: "Ways your voice has tended to land in moments you've described." },
  conflict_role: { label: "Roles in friction", summary: "Stances you've described taking when something gets hard." },
  cognitive_distortion: { label: "Thinking shortcuts", summary: "Framings your mind has reached for under pressure." },
  recurring_theme: { label: "Themes that keep returning", summary: "Subjects that have surfaced across different reflections." },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  try {
    const { userId } = await req.json().catch(() => ({}));
    if (!userId) {
      return new Response(JSON.stringify({ ok: false }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: freq } = await admin
      .from("pe_macro_frequency")
      .select("pattern_type, pattern_label, raw_count, weighted_score")
      .eq("user_id", userId);

    const rows = freq ?? [];
    if (rows.length < 3) {
      return new Response(JSON.stringify({ ok: true, skipped: "not enough patterns" }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
    }

    // Need pattern UUIDs to attach as members
    const { data: patterns } = await admin
      .from("pe_macro_patterns")
      .select("id, pattern_type, pattern_label")
      .eq("user_id", userId);

    const grouped: Record<string, { labels: Set<string>; ids: string[]; score: number }> = {};
    for (const r of rows) {
      const g = (grouped[r.pattern_type] ??= { labels: new Set(), ids: [], score: 0 });
      g.labels.add(r.pattern_label);
      g.score += Number(r.weighted_score ?? 0);
    }
    for (const p of patterns ?? []) {
      const g = grouped[p.pattern_type];
      if (g) g.ids.push(p.id);
    }

    // Replace clusters (idempotent)
    await admin.from("pe_pattern_clusters").delete().eq("user_id", userId);

    const inserts = Object.entries(grouped)
      .filter(([_, g]) => g.labels.size >= 2)
      .map(([type, g]) => {
        const tpl = CLUSTER_TEMPLATES[type] ?? { label: type, summary: "" };
        const labels = Array.from(g.labels).slice(0, 6).join(", ");
        return {
          user_id: userId,
          cluster_label: tpl.label,
          cluster_summary: `${tpl.summary} Includes: ${labels}.`,
          member_pattern_ids: g.ids.slice(0, 50),
          cohesion_score: Math.min(1, g.score / 10),
          last_updated_at: new Date().toISOString(),
        };
      });

    if (inserts.length) await admin.from("pe_pattern_clusters").insert(inserts);

    return new Response(JSON.stringify({ ok: true, clusters: inserts.length }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: String(e) }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  }
});
