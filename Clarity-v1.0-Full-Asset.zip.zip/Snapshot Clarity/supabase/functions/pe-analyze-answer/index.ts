// deno-lint-ignore-file no-explicit-any
// Pattern Engine v1 — analyze a single reflection_answer end-to-end.
// Returns the persisted SnapshotAnalysis. Parallel to the existing snapshot system.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ---------- Lexicons (mirrored from src/pattern-engine/config/lexicons.ts) ----------
const LINGUISTIC_LEX: Record<string, { p: RegExp; w: number }[]> = {
  certainty: [
    { p: /\balways\b/gi, w: 0.7 }, { p: /\bnever\b/gi, w: 0.7 },
    { p: /\bdefinitely\b/gi, w: 0.6 }, { p: /\bobviously\b/gi, w: 0.6 },
    { p: /\bcompletely\b/gi, w: 0.5 },
  ],
  uncertainty: [
    { p: /\bmaybe\b/gi, w: 0.5 }, { p: /\bkind of\b/gi, w: 0.5 },
    { p: /\bI guess\b/gi, w: 0.6 }, { p: /\bsort of\b/gi, w: 0.5 },
    { p: /\bnot sure\b/gi, w: 0.6 },
  ],
  avoidance: [
    { p: /\bwhatever\b/gi, w: 0.6 }, { p: /\bit'?s fine\b/gi, w: 0.7 },
    { p: /\bdoesn'?t matter\b/gi, w: 0.7 }, { p: /\bI'?m over it\b/gi, w: 0.7 },
  ],
  blame_outward: [
    { p: /\b(he|she|they) (always|never)\b/gi, w: 0.7 },
    { p: /\bnever listens?\b/gi, w: 0.7 }, { p: /\bmakes me\b/gi, w: 0.6 },
  ],
  blame_inward: [
    { p: /\bmy fault\b/gi, w: 0.8 }, { p: /\bbecause of me\b/gi, w: 0.7 },
    { p: /\bI ruined\b/gi, w: 0.7 },
  ],
  minimizing: [
    { p: /\bit'?s not a big deal\b/gi, w: 0.7 },
    { p: /\bI shouldn'?t even\b/gi, w: 0.6 }, { p: /\bit'?s nothing\b/gi, w: 0.6 },
  ],
};

const EMOTION_LEX: Record<string, { p: RegExp; w: number }[]> = {
  sadness: [{ p: /\b(sad|hurt|crying|grief|miss|lonely)\b/gi, w: 0.6 }],
  anger: [{ p: /\b(angry|furious|pissed|mad|rage|resent)\b/gi, w: 0.7 }],
  fear: [{ p: /\b(scared|afraid|terrified|nervous|worried)\b/gi, w: 0.6 }],
  shame: [{ p: /\b(ashamed|embarrass|humiliat|stupid|worthless)\b/gi, w: 0.7 }],
  joy: [{ p: /\b(happy|joy|grateful|delighted|excited)\b/gi, w: 0.5 }],
  love: [{ p: /\b(love|adore|cherish|connected)\b/gi, w: 0.5 }],
  numbness: [{ p: /\b(numb|empty|nothing|don'?t feel)\b/gi, w: 0.6 }],
  anxiety: [{ p: /\b(anxious|panic|spiral|overwhelm)\b/gi, w: 0.7 }],
};

// ---------- Taxonomy labels (subset for narrative grounding) ----------
const TAX_LABELS: Record<string, string> = {
  "loop.anxious_reassurance": "Anxious Reassurance Loop",
  "loop.shame_withdraw": "Shame → Withdraw Loop",
  "loop.anger_guilt_repair": "Anger → Guilt → Repair Loop",
  "loop.control_collapse": "Control → Collapse Loop",
  "loop.abandonment_test": "Abandonment Test Loop",
  "role.pursuer": "Pursuer", "role.withdrawer": "Withdrawer",
  "role.fixer": "Fixer", "role.victim": "Powerless Stance",
  "role.peacemaker": "Peacemaker",
  "comm.over_explaining": "Over-explaining", "comm.minimizing": "Minimizing",
  "comm.stonewalling": "Stonewalling", "comm.deflecting": "Deflecting",
  "comm.placating": "Placating",
  "conflict.criticism_defensiveness": "Criticism → Defensiveness",
  "conflict.demand_withdraw": "Demand → Withdraw",
  "conflict.contempt_withdrawal": "Contempt → Withdrawal",
  "identity.inner_critic_dominant": "Inner Critic Dominant",
  "identity.perfectionist_self": "Perfectionist Self",
  "identity.caretaker_self": "Caretaker Self",
  "identity.fragile_self_worth": "Fragile Self-worth",
  "attach.anxious": "Anxious-leaning Attachment",
  "attach.avoidant": "Avoidant-leaning Attachment",
  "attach.disorganized": "Disorganized-leaning Attachment",
  "attach.secure_leaning": "Secure-leaning Attachment",
  "distortion.all_or_nothing": "All-or-nothing Thinking",
  "distortion.catastrophizing": "Catastrophizing",
  "distortion.mind_reading": "Mind-reading",
  "distortion.personalization": "Personalization",
  "distortion.shoulding": "Should-ing", "distortion.labeling": "Labeling",
  "distortion.overgeneralization": "Overgeneralization",
  "need.validation": "Need: Validation", "need.safety": "Need: Safety",
  "need.autonomy": "Need: Autonomy", "need.belonging": "Need: Belonging",
  "need.being_seen": "Need: Being Seen",
  "observation.too_brief_for_pattern": "Brief Reflection",
  "observation.insufficient_signal": "Quiet Signal",
};
const VALID_TAG_KEYS = new Set(Object.keys(TAX_LABELS));

// ---------- Utility ----------
function clamp01(n: number) { return Math.max(0, Math.min(1, n)); }

interface LexHit { subtype: string; intensity: number; evidence: { quote: string; offset: number }[] }

function sweepLex(text: string, lex: Record<string, { p: RegExp; w: number }[]>): LexHit[] {
  const out: LexHit[] = [];
  for (const [subtype, hits] of Object.entries(lex)) {
    let score = 0;
    const ev: { quote: string; offset: number }[] = [];
    for (const { p, w } of hits) {
      p.lastIndex = 0;
      let m: RegExpExecArray | null;
      while ((m = p.exec(text)) !== null) {
        score += w;
        if (ev.length < 4) {
          const start = Math.max(0, m.index - 24);
          const end = Math.min(text.length, m.index + m[0].length + 24);
          ev.push({ quote: text.slice(start, end).trim(), offset: m.index });
        }
      }
    }
    if (score > 0) out.push({ subtype, intensity: clamp01(score / 2.5), evidence: ev });
  }
  return out;
}

// ---------- LLM orchestration ----------
async function callAI(messages: any[], opts: { model?: string; temperature?: number; tools?: any[]; tool_choice?: any } = {}) {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY missing");
  const body: any = {
    model: opts.model ?? "google/gemini-3-flash-preview",
    temperature: opts.temperature ?? 0.4,
    messages,
  };
  if (opts.tools) body.tools = opts.tools;
  if (opts.tool_choice) body.tool_choice = opts.tool_choice;

  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (resp.status === 429) throw new Error("RATE_LIMITED");
  if (resp.status === 402) throw new Error("PAYMENT_REQUIRED");
  if (!resp.ok) throw new Error(`AI ${resp.status}: ${await resp.text()}`);
  return await resp.json();
}

// One combined LLM pass: extract markers, distill patterns, compose narrative sections.
// Uses tool-calling for guaranteed structured output.
async function llmAnalyze(answerText: string, questionText: string): Promise<any | null> {
  const validIds = Object.keys(TAX_LABELS).join(", ");

  const tool = {
    type: "function",
    function: {
      name: "emit_analysis",
      description: "Emit a complete pattern analysis for a single reflection answer.",
      parameters: {
        type: "object",
        properties: {
          markers: {
            type: "array",
            items: {
              type: "object",
              properties: {
                kind: { type: "string", enum: ["linguistic", "emotional", "communication", "behavioral", "identity"] },
                subtype: { type: "string" },
                intensity: { type: "number" },
                valence: { type: "number" },
                certainty: { type: "number" },
                evidence_quote: { type: "string", description: "An EXACT substring of the user's answer." },
              },
              required: ["kind", "subtype", "intensity", "evidence_quote"],
              additionalProperties: false,
            },
          },
          primary_pattern_id: { type: "string", description: `One of: ${validIds}` },
          secondary_pattern_ids: { type: "array", items: { type: "string" }, maxItems: 3 },
          loop: {
            type: "object",
            properties: {
              id: { type: "string" },
              label: { type: "string" },
              stages: { type: "array", items: { type: "object", properties: { emotion: { type: "string" }, trigger: { type: "string" } }, required: ["emotion"], additionalProperties: false } },
            },
            required: ["id", "label", "stages"],
            additionalProperties: false,
          },
          communication_style: { type: "object", properties: { label: { type: "string" }, notes: { type: "string" } }, required: ["label", "notes"], additionalProperties: false },
          behavioral_tendencies: { type: "array", items: { type: "object", properties: { label: { type: "string" }, notes: { type: "string" } }, required: ["label", "notes"], additionalProperties: false } },
          primary_summary: { type: "string", description: "1-2 sentence read-back of the primary pattern, observational, no advice." },
          secondary_summaries: { type: "array", items: { type: "string" } },
          meaning: { type: "string", description: "What this pattern usually means. Observational, warm, second-person. No diagnosis." },
          why: { type: "string", description: "Why this pattern might be showing up here. Possibility framing." },
          how_it_shows_up: { type: "string", description: "How this shows up in their life. Grounded in evidence." },
          what_ai_notices: { type: "array", items: { type: "string" }, description: "2-4 short consistent observations." },
          paths_forward: { type: "array", items: { type: "string" }, description: "3 soft openings, framed as questions or experiments. Never prescriptions." },
        },
        required: ["markers", "primary_pattern_id", "secondary_pattern_ids", "communication_style", "behavioral_tendencies", "primary_summary", "secondary_summaries", "meaning", "why", "how_it_shows_up", "what_ai_notices", "paths_forward"],
        additionalProperties: false,
      },
    },
  };

  const sys = `You analyze a single reflection answer for psychological patterns.

VOICE RULES (hard):
- Observational, warm, second-person ("There's a pull toward…", "What surfaces is…")
- NEVER use: "you should", "you need to", "you must", "I recommend", "the right thing"
- No diagnostic labels ("you have anxiety"). Possibilities only.
- Every prose section must be grounded in what the user actually wrote.

PATTERN IDS: only emit ids from this allowed set:
${validIds}

If the answer is too brief or signal is weak, set primary_pattern_id to "observation.too_brief_for_pattern" or "observation.insufficient_signal" and keep prose gentle.

EVIDENCE: every marker's evidence_quote MUST be an exact substring of the answer.`;

  const user = `Question asked: ${questionText}\n\nUser's answer:\n"""\n${answerText}\n"""\n\nProduce the full analysis via the emit_analysis tool.`;

  let lastErr: any = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const data = await callAI(
        [{ role: "system", content: sys }, { role: "user", content: user }],
        {
          model: attempt === 0 ? "google/gemini-3-flash-preview" : "google/gemini-2.5-pro",
          temperature: 0.45,
          tools: [tool],
          tool_choice: { type: "function", function: { name: "emit_analysis" } },
        },
      );
      const call = data?.choices?.[0]?.message?.tool_calls?.[0];
      if (!call) { lastErr = "no_tool_call"; continue; }
      const parsed = JSON.parse(call.function.arguments);
      // Validate primary id
      if (!VALID_TAG_KEYS.has(parsed.primary_pattern_id)) {
        parsed.primary_pattern_id = "observation.insufficient_signal";
      }
      parsed.secondary_pattern_ids = (parsed.secondary_pattern_ids || []).filter((id: string) => VALID_TAG_KEYS.has(id));
      return parsed;
    } catch (e: any) {
      lastErr = e?.message ?? String(e);
      if (lastErr === "RATE_LIMITED" || lastErr === "PAYMENT_REQUIRED") throw e;
    }
  }
  console.warn("llmAnalyze failed:", lastErr);
  return null;
}

// ---------- Forbidden phrase softener ----------
const SOFT: Array<[RegExp, string]> = [
  [/\byou should\b/gi, "you could"],
  [/\byou need to\b/gi, "you might want to"],
  [/\byou must\b/gi, "you might"],
  [/\bI recommend\b/gi, "one possibility is"],
  [/\bthe right thing\b/gi, "one option"],
];
function soften(s: string): string {
  let o = s;
  for (const [re, rep] of SOFT) o = o.replace(re, rep);
  return o;
}
function softenSections(sec: any) {
  return {
    ...sec,
    primaryPattern: { ...sec.primaryPattern, summary: soften(sec.primaryPattern.summary) },
    secondaryPatterns: sec.secondaryPatterns.map((p: any) => ({ ...p, summary: soften(p.summary) })),
    communicationStyle: { ...sec.communicationStyle, notes: soften(sec.communicationStyle.notes) },
    behavioralTendencies: sec.behavioralTendencies.map((b: any) => ({ ...b, notes: soften(b.notes) })),
    meaning: soften(sec.meaning), why: soften(sec.why), howItShowsUp: soften(sec.howItShowsUp),
    whatAINotices: sec.whatAINotices.map(soften),
    pathsForward: sec.pathsForward.map(soften),
  };
}

// ---------- Snapshot composition fallback ----------
function buildFallbackSections(primaryId: string): any {
  const label = TAX_LABELS[primaryId] ?? "Quiet Signal";
  return {
    primaryPattern: { id: primaryId, label, summary: "What you wrote stays close to the surface — there's not enough yet to read a clear pattern." },
    secondaryPatterns: [],
    communicationStyle: { label: "Reserved", notes: "Your words are brief; the texture of the pattern is still forming." },
    behavioralTendencies: [],
    meaning: "Patterns become more visible as you keep writing. This early read is gentle on purpose.",
    why: "It might be early in the situation, or you might be holding more than you've put on the page yet.",
    howItShowsUp: "It's hard to say from this single answer alone.",
    whatAINotices: ["You showed up to write something — that itself is a signal."],
    pathsForward: [
      "What if you wrote one more line about what felt hardest?",
      "Is there a feeling underneath the words you used that wants more space?",
      "What would you say if no one would read this?",
    ],
  };
}

// ---------- Handler ----------
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization") || "";
    if (!auth.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );
    const { data: claims, error: claimsErr } = await supabase.auth.getClaims(auth.replace("Bearer ", ""));
    if (claimsErr || !claims?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userId = claims.claims.sub as string;

    const body = await req.json().catch(() => ({}));
    const answerId = body?.answerId;
    if (!answerId || typeof answerId !== "string") {
      return new Response(JSON.stringify({ error: "Missing answerId" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Idempotency: return existing snapshot if present and not forced.
    if (!body?.force) {
      const { data: existing } = await supabase
        .from("pe_snapshots")
        .select("*")
        .eq("answer_id", answerId)
        .eq("user_id", userId)
        .maybeSingle();
      if (existing) {
        return new Response(JSON.stringify({ snapshot: existing }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
    }

    // Load answer + verify ownership via session
    const { data: answer } = await supabase
      .from("reflection_answers")
      .select("id, session_id, question_text, answer_text")
      .eq("id", answerId)
      .maybeSingle();
    if (!answer) {
      return new Response(JSON.stringify({ error: "Answer not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { data: session } = await supabase
      .from("reflection_sessions")
      .select("id, user_id")
      .eq("id", answer.session_id)
      .maybeSingle();
    if (!session || session.user_id !== userId) {
      return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const text = String(answer.answer_text ?? "").trim();
    const wordCount = text.split(/\s+/).filter(Boolean).length;

    // Lexicon sweep (always)
    const linguistic = sweepLex(text, LINGUISTIC_LEX);
    const emotional = sweepLex(text, EMOTION_LEX);

    // Decide whether to call LLM
    let llm: any = null;
    if (wordCount >= 6 && text.length >= 30) {
      try { llm = await llmAnalyze(text, String(answer.question_text ?? "")); } catch (e: any) {
        if (e.message === "RATE_LIMITED") {
          return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        if (e.message === "PAYMENT_REQUIRED") {
          return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits to your workspace." }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        console.error("llm error:", e);
      }
    }

    // Determine primary pattern id and status
    const tooBrief = wordCount < 6;
    const status: "complete" | "markers_only" | "too_brief" = tooBrief
      ? "too_brief"
      : llm ? "complete" : "markers_only";

    const primaryPatternId = tooBrief
      ? "observation.too_brief_for_pattern"
      : llm?.primary_pattern_id ?? "observation.insufficient_signal";

    // Build sections
    const sections = llm
      ? softenSections({
          primaryPattern: { id: primaryPatternId, label: TAX_LABELS[primaryPatternId] ?? "Pattern", summary: llm.primary_summary },
          secondaryPatterns: (llm.secondary_pattern_ids || []).map((id: string, i: number) => ({
            id, label: TAX_LABELS[id] ?? id, summary: llm.secondary_summaries?.[i] ?? "",
          })),
          emotionalLoop: llm.loop ?? undefined,
          communicationStyle: llm.communication_style,
          behavioralTendencies: llm.behavioral_tendencies ?? [],
          meaning: llm.meaning,
          why: llm.why,
          howItShowsUp: llm.how_it_shows_up,
          whatAINotices: llm.what_ai_notices ?? [],
          pathsForward: llm.paths_forward ?? [],
        })
      : buildFallbackSections(primaryPatternId);

    // Persist markers (lexicon hits + LLM markers)
    const markerRows: any[] = [];
    for (const h of linguistic) {
      markerRows.push({
        user_id: userId, answer_id: answerId, session_id: answer.session_id,
        kind: "linguistic", subtype: h.subtype, intensity: h.intensity,
        payload: { evidence: h.evidence, source: "lexicon" },
      });
    }
    for (const h of emotional) {
      markerRows.push({
        user_id: userId, answer_id: answerId, session_id: answer.session_id,
        kind: "emotional", subtype: h.subtype, intensity: h.intensity, valence: -0.3,
        payload: { evidence: h.evidence, source: "lexicon" },
      });
    }
    if (llm?.markers) {
      for (const m of llm.markers.slice(0, 25)) {
        markerRows.push({
          user_id: userId, answer_id: answerId, session_id: answer.session_id,
          kind: m.kind, subtype: m.subtype,
          intensity: clamp01(Number(m.intensity) || 0),
          valence: typeof m.valence === "number" ? m.valence : null,
          certainty: typeof m.certainty === "number" ? m.certainty : null,
          payload: { evidence: [{ quote: String(m.evidence_quote || "").slice(0, 240), offset: text.indexOf(String(m.evidence_quote || "")) }], source: "llm" },
        });
      }
    }
    if (markerRows.length) {
      const { error } = await supabase.from("pe_markers").insert(markerRows);
      if (error) console.error("markers insert error:", error);
    }

    // Persist tags (primary + secondaries)
    const tagRows: any[] = [];
    const allTagIds = [primaryPatternId, ...(llm?.secondary_pattern_ids || [])];
    for (const id of allTagIds) {
      if (!VALID_TAG_KEYS.has(id)) continue;
      tagRows.push({
        user_id: userId, answer_id: answerId, session_id: answer.session_id,
        tag_key: id, tag_label: TAX_LABELS[id], category: id.split(".")[0],
        intensity: id === primaryPatternId ? 0.8 : 0.5,
        confidence: llm ? 0.7 : 0.4,
        evidence_snippets: (llm?.markers || []).slice(0, 3).map((m: any) => ({ quote: m.evidence_quote, offset: 0 })),
      });
    }
    if (tagRows.length) {
      const { error } = await supabase.from("pe_pattern_tags").insert(tagRows);
      if (error) console.error("tags insert error:", error);
    }

    // Persist snapshot
    const snapshotRow = {
      user_id: userId,
      answer_id: answerId,
      session_id: answer.session_id,
      primary_pattern_id: primaryPatternId,
      secondary_pattern_ids: (llm?.secondary_pattern_ids || []).filter((id: string) => VALID_TAG_KEYS.has(id)),
      loop_id: llm?.loop?.id ?? null,
      communication_style: llm?.communication_style?.label ?? null,
      behavioral_tendencies: (llm?.behavioral_tendencies || []).map((b: any) => b.label).filter(Boolean),
      sections,
      narrative_md: null,
      status,
      model: llm ? "google/gemini-3-flash-preview" : null,
    };

    // Upsert (force=true overwrites)
    const { data: saved, error: snapErr } = await supabase
      .from("pe_snapshots")
      .upsert(snapshotRow, { onConflict: "answer_id" })
      .select("*")
      .single();
    if (snapErr) {
      console.error("snapshot upsert error:", snapErr);
      return new Response(JSON.stringify({ error: "Failed to save snapshot" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Mark answer analyzed
    await supabase.from("reflection_answers").update({ pe_analyzed_at: new Date().toISOString(), pe_analysis_version: 1 }).eq("id", answerId);

    return new Response(JSON.stringify({ snapshot: saved }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e: any) {
    console.error("pe-analyze-answer error:", e);
    return new Response(JSON.stringify({ error: e?.message ?? "Unknown error" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
