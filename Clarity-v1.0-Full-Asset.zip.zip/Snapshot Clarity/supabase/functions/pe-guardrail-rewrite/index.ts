// pe-guardrail-rewrite
// Rewrites interpretive text into observational, tentative, user-owned language.
// Strips diagnoses, judgment, and prescriptive advice. Pure-function fallback so
// callers can use it synchronously without LLM latency.
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const DIAGNOSTIC_PHRASES: Array<[RegExp, string]> = [
  [/\byou have (a |an )?(disorder|condition|syndrome|trauma|depression|anxiety disorder|adhd|ocd|ptsd|bpd)\b/gi, "you've described experiences with"],
  [/\byou are (a |an )?(narcissist|codependent|avoidant|toxic|manipulative|abuser|victim)\b/gi, "you've described moments that look like"],
  [/\byou suffer from\b/gi, "you've described struggling with"],
  [/\byou clearly (are|have|show)\b/gi, "what you've shared suggests"],
  [/\bobviously\b/gi, ""],
  [/\bdefinitely\b/gi, "often"],
  [/\balways\b/gi, "frequently"],
  [/\bnever\b/gi, "rarely"],
];

const PRESCRIPTIVE_PHRASES: Array<[RegExp, string]> = [
  [/\byou should\b/gi, "you could"],
  [/\byou must\b/gi, "you might"],
  [/\byou need to\b/gi, "one option is to"],
  [/\byou have to\b/gi, "one option is to"],
  [/\byou ought to\b/gi, "you might"],
  [/\bdo this\b/gi, "consider this"],
  [/\bdon't\s+(\w+)/gi, "you might pause before $1"],
];

const JUDGMENTAL_PHRASES: Array<[RegExp, string]> = [
  [/\bthat's wrong\b/gi, "that's worth noticing"],
  [/\bthat's bad\b/gi, "that's worth sitting with"],
  [/\byou're failing\b/gi, "you've described feeling stuck"],
  [/\byou messed up\b/gi, "something didn't land the way you hoped"],
];

function softenText(input: string): string {
  if (!input) return "";
  let out = input;
  for (const [re, sub] of [...DIAGNOSTIC_PHRASES, ...PRESCRIPTIVE_PHRASES, ...JUDGMENTAL_PHRASES]) {
    out = out.replace(re, sub);
  }
  // Collapse whitespace
  out = out.replace(/[ \t]+/g, " ").replace(/\s+\./g, ".").trim();
  return out;
}

function softenAny(value: unknown): unknown {
  if (typeof value === "string") return softenText(value);
  if (Array.isArray(value)) return value.map(softenAny);
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) out[k] = softenAny(v);
    return out;
  }
  return value;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await req.json().catch(() => ({}));
    const { text, payload } = body ?? {};
    const result = {
      text: typeof text === "string" ? softenText(text) : null,
      payload: payload !== undefined ? softenAny(payload) : null,
    };
    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (e) {
    return new Response(JSON.stringify({ text: null, payload: null, error: String(e) }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200, // never block callers
    });
  }
});
