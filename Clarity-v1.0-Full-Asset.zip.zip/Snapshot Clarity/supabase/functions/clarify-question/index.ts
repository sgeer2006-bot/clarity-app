// deno-lint-ignore-file no-explicit-any
// Misunderstanding-repair flow.
// Two modes:
//   - mode="explain": given the current question and ContextModel, return a
//     warm, plain-language explanation of what the engine is confused about,
//     a soft hypothesis, and 3 candidate interpretations the user can pick from.
//   - mode="patch": given the user's clarification, return a structured
//     ContextModel patch which we apply server-side, and mark the repair resolved.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const ALL_FIELDS = [
  "situation",
  "emotions",
  "intentions",
  "triggers",
  "expectations",
  "fears",
  "desired_outcome",
  "relationships",
  "history",
  "unspoken_needs",
] as const;

const EXPLAIN_TOOL = {
  type: "function",
  function: {
    name: "emit_explanation",
    description: "Return what the engine is confused about and 3 interpretations.",
    parameters: {
      type: "object",
      properties: {
        confused_about: {
          type: "string",
          description:
            "Plain-language description of the ambiguity, written warmly in second person ('I'm not sure if…').",
        },
        hypothesis: {
          type: "string",
          description: "A soft best-guess of what the user might mean ('It sounds like you might mean…').",
        },
        interpretations: {
          type: "array",
          minItems: 3,
          maxItems: 3,
          items: { type: "string" },
          description: "3 short, distinct interpretations the user could pick from.",
        },
      },
      required: ["confused_about", "hypothesis", "interpretations"],
      additionalProperties: false,
    },
  },
};

const PATCH_TOOL = {
  type: "function",
  function: {
    name: "emit_patch",
    description: "Return a structured patch to the ContextModel based on the user's clarification.",
    parameters: {
      type: "object",
      properties: {
        patch: {
          type: "object",
          description: "Only include fields that should be set or replaced. Omit fields you don't want to change.",
          properties: {
            situation: { type: "string" },
            emotions: { type: "array", items: { type: "string" } },
            intentions: { type: "array", items: { type: "string" } },
            triggers: { type: "array", items: { type: "string" } },
            expectations: { type: "array", items: { type: "string" } },
            fears: { type: "array", items: { type: "string" } },
            desired_outcome: { type: "string" },
            relationships: { type: "array", items: { type: "string" } },
            history: { type: "array", items: { type: "string" } },
            unspoken_needs: { type: "array", items: { type: "string" } },
          },
          additionalProperties: false,
        },
        ack: {
          type: "string",
          description: "One-sentence warm acknowledgement of the clarification (no advice).",
        },
      },
      required: ["patch", "ack"],
      additionalProperties: false,
    },
  },
};

async function callEngine(systemPrompt: string, payload: unknown, tool: any) {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");
  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      temperature: 0.4,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: JSON.stringify(payload) },
      ],
      tools: [tool],
      tool_choice: { type: "function", function: { name: tool.function.name } },
    }),
  });
  if (resp.status === 429) throw new Error("RATE_LIMITED");
  if (resp.status === 402) throw new Error("PAYMENT_REQUIRED");
  if (!resp.ok) throw new Error(`LLM error ${resp.status}: ${await resp.text()}`);
  const data = await resp.json();
  const call = data?.choices?.[0]?.message?.tool_calls?.[0];
  if (!call?.function?.arguments) throw new Error("No tool call in response");
  return JSON.parse(call.function.arguments);
}

const EXPLAIN_PROMPT = `You are a warm, therapy-style conversational engine. The user has flagged a question as confusing.

Your "confused_about" field MUST begin with the exact phrase:
"I want to make sure I'm understanding you correctly. Here's what I think you're saying: " followed by your interpretation, then " Can you confirm or correct this: " followed by the specific thing you need clarified.

The "hypothesis" field is your best soft guess of what they meant.
The "interpretations" field is 3 short, distinct candidate readings the user can pick from.

Tone: validating, never defensive, never clinical. Never use words like "framework", "pattern", "dynamic", "narrative", "lens", "journey".`;

const PATCH_PROMPT = `You are updating a ContextModel based on a user's clarification.
Return only the fields that should change. For string fields, replace. For array fields, replace with the corrected list (don't append unless the user explicitly added).
Do not invent. Do not give advice.`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization") || "";
    if (!auth.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const token = auth.replace("Bearer ", "");
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: auth } } },
    );
    const { data: userData } = await supabase.auth.getUser(token);
    const userId = userData?.user?.id;
    if (!userId) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const sessionId: string = body?.sessionId;
    const mode: "explain" | "patch" = body?.mode === "patch" ? "patch" : "explain";
    const questionIndex: number = Number(body?.questionIndex ?? 0);
    const questionText: string = String(body?.questionText ?? "");

    if (!sessionId) {
      return new Response(JSON.stringify({ error: "Missing sessionId" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: session } = await supabase
      .from("reflection_sessions").select("id, user_id").eq("id", sessionId).maybeSingle();
    if (!session || session.user_id !== userId) {
      return new Response(JSON.stringify({ error: "Session not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: ctxRow } = await supabase
      .from("session_context_models").select("*").eq("session_id", sessionId).maybeSingle();
    const { data: priorRows } = await supabase
      .from("reflection_answers")
      .select("question_index, question_text, answer_text")
      .eq("session_id", sessionId)
      .order("question_index", { ascending: true });
    const priorAnswers = (priorRows ?? []).map((r: any) => ({
      question: r.question_text, answer: r.answer_text,
    }));

    if (mode === "explain") {
      const out = await callEngine(EXPLAIN_PROMPT, {
        question: questionText,
        prior_answers: priorAnswers,
        current_context: ctxRow ?? {},
      }, EXPLAIN_TOOL);

      const interpretations: string[] = Array.isArray(out?.interpretations)
        ? out.interpretations.slice(0, 3).map(String)
        : [];

      // Log the repair as opened (unresolved).
      const { data: inserted } = await supabase
        .from("misunderstanding_repairs").insert({
          session_id: sessionId,
          question_index: questionIndex,
          question_text: questionText,
          hypothesis: String(out?.hypothesis ?? ""),
          interpretations,
        }).select("id").maybeSingle();

      return new Response(JSON.stringify({
        repair_id: inserted?.id ?? null,
        confused_about: String(out?.confused_about ?? ""),
        hypothesis: String(out?.hypothesis ?? ""),
        interpretations,
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // mode === "patch"
    const clarification: string = String(body?.clarification ?? "").trim();
    const repairId: string | undefined = body?.repairId;
    if (!clarification) {
      return new Response(JSON.stringify({ error: "Missing clarification" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const out = await callEngine(PATCH_PROMPT, {
      question: questionText,
      clarification,
      current_context: ctxRow ?? {},
    }, PATCH_TOOL);

    const patch = out?.patch && typeof out.patch === "object" ? out.patch : {};
    const merged: Record<string, any> = { ...(ctxRow ?? {}) };
    for (const f of ALL_FIELDS) {
      if (patch[f] === undefined) continue;
      merged[f] = patch[f];
    }
    // Recompute coverage server-side.
    const map: Record<string, "empty" | "partial" | "filled"> = {};
    let score = 0;
    for (const f of ALL_FIELDS) {
      const v = merged[f];
      if (v == null || (typeof v === "string" && !v.trim()) || (Array.isArray(v) && v.length === 0)) map[f] = "empty";
      else if (typeof v === "string" && v.trim().length < 25) map[f] = "partial";
      else if (Array.isArray(v) && v.length === 1) map[f] = "partial";
      else map[f] = "filled";
      score += map[f] === "filled" ? 10 : map[f] === "partial" ? 5 : 0;
    }

    await supabase.from("session_context_models").upsert({
      session_id: sessionId,
      situation: merged.situation ?? "",
      emotions: merged.emotions ?? [],
      intentions: merged.intentions ?? [],
      triggers: merged.triggers ?? [],
      expectations: merged.expectations ?? [],
      fears: merged.fears ?? [],
      desired_outcome: merged.desired_outcome ?? "",
      relationships: merged.relationships ?? [],
      history: merged.history ?? [],
      unspoken_needs: merged.unspoken_needs ?? [],
      coverage_map: map,
      saturation_score: score,
    }, { onConflict: "session_id" });

    if (repairId) {
      await supabase.from("misunderstanding_repairs").update({
        clarification, context_patch: patch, resolved: true,
      }).eq("id", repairId);
    }

    // Invalidate the just-asked question so the next call regenerates it.
    await supabase.from("question_history")
      .delete().eq("session_id", sessionId).eq("question_index", questionIndex);

    return new Response(JSON.stringify({
      ack: String(out?.ack ?? "Got it — thanks for clearing that up."),
      patch,
      coverage_map: map,
      saturation_score: score,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e: any) {
    const msg = e?.message || "Unknown error";
    if (msg === "RATE_LIMITED") {
      return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }), {
        status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (msg === "PAYMENT_REQUIRED") {
      return new Response(JSON.stringify({ error: "AI credits exhausted." }), {
        status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    console.error("clarify-question error:", e);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
