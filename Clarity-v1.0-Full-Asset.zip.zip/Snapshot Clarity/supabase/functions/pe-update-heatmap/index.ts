// pe-update-heatmap
// Recomputes today's heatmap cell for the user based on detected patterns.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  try {
    const { userId } = await req.json().catch(() => ({}));
    if (!userId) {
      return new Response(JSON.stringify({ ok: false }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    await new Promise((r) => setTimeout(r, 1500));

    const today = new Date().toISOString().slice(0, 10);
    const startOfDay = `${today}T00:00:00.000Z`;

    const { data: rows } = await admin
      .from("pe_macro_patterns")
      .select("pattern_type, confidence")
      .eq("user_id", userId)
      .gte("created_at", startOfDay);

    const list = rows ?? [];
    const count = list.length;
    const intensity = list.reduce((s, r) => s + Number(r.confidence ?? 0), 0);

    // dominant type
    const counts: Record<string, number> = {};
    for (const r of list) counts[r.pattern_type] = (counts[r.pattern_type] ?? 0) + 1;
    const dominant = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;

    const { data: existing } = await admin
      .from("pe_heatmap_cells")
      .select("id")
      .eq("user_id", userId)
      .eq("cell_date", today)
      .maybeSingle();

    if (existing) {
      await admin.from("pe_heatmap_cells").update({
        pattern_count: count,
        dominant_pattern_type: dominant,
        intensity_score: intensity,
        updated_at: new Date().toISOString(),
      }).eq("id", existing.id);
    } else {
      await admin.from("pe_heatmap_cells").insert({
        user_id: userId, cell_date: today,
        pattern_count: count, dominant_pattern_type: dominant, intensity_score: intensity,
      });
    }

    return new Response(JSON.stringify({ ok: true, count }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: String(e) }), { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 });
  }
});
