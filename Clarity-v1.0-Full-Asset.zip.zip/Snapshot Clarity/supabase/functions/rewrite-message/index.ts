// Generate a single, ready-to-send message based on a snapshot's
// "how_to_communicate" guidance and the user's situation. Returns one
// short, warm, first-person message the user can copy/paste.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";
import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;

interface ReqBody {
  sessionId: string;
  tone?: "warm" | "direct" | "soft";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization");
    if (!auth) return json({ error: "Unauthorized" }, 401);

    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: auth } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user) return json({ error: "Unauthorized" }, 401);

    let body: ReqBody;
    try { body = await req.json(); } catch { return json({ error: "Invalid JSON" }, 400); }
    if (!body?.sessionId) return json({ error: "sessionId required" }, 400);
    const tone = body.tone ?? "warm";

    const { data: session } = await userClient
      .from("reflection_sessions")
      .select("id, title, snapshot_json")
      .eq("id", body.sessionId)
      .maybeSingle();
    if (!session?.snapshot_json) return json({ error: "Snapshot not found" }, 404);

    const snap = session.snapshot_json as {
      summary: string;
      how_to_communicate?: string[];
      common_misunderstandings?: string[];
    };

    const systemPrompt = `You write a single short message someone can send to the OTHER person in their situation. Use first-person ("I"), name a feeling and a need, never accuse, never demand, never give advice. Plain everyday language. 2–4 sentences. No greetings like "Hey [name]", just the body.`;

    const userPrompt = `Situation summary: ${snap.summary}

Phrasing guidance from the snapshot:
${(snap.how_to_communicate ?? []).map((s) => `- ${s}`).join("\n") || "(none)"}

Things the other person may be misreading:
${(snap.common_misunderstandings ?? []).map((s) => `- ${s}`).join("\n") || "(none)"}

Tone: ${tone}.

Return ONLY a JSON object: { "message": string }. No prose.`;

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        temperature: 0.5,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (aiRes.status === 429) return json({ error: "Rate limited" }, 429);
    if (aiRes.status === 402) return json({ error: "AI credits exhausted" }, 402);
    if (!aiRes.ok) return json({ error: "AI failed" }, 500);

    const data = await aiRes.json();
    const content = data?.choices?.[0]?.message?.content ?? "";
    let parsed: { message?: string } = {};
    try { parsed = JSON.parse(content); } catch { /* ignore */ }
    if (!parsed.message || typeof parsed.message !== "string") {
      return json({ error: "Invalid AI output" }, 500);
    }

    return json({ message: parsed.message.trim() });
  } catch (e) {
    console.error("rewrite-message error", e);
    return json({ error: "Unexpected error" }, 500);
  }
});

function json(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
    status,
  });
}
