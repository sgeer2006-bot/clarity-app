// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const MAX_QUESTIONS = 5;

const MODE_LABELS: Record<string, string> = {
  explore: "Explore Deeper",
  angle: "Try Another Angle",
  context: "Add New Context",
};

const MODE_GUIDANCE: Record<string, string> = {
  explore:
    "Drill into the most emotionally charged unresolved thread the user has surfaced. Ask one open, attuned question that goes a layer deeper into that specific thread. Never branch into new topics.",
  angle:
    "Help the user imagine what the other party in the situation might plausibly be feeling, intending, or fearing. Ask one open question that invites a perspective shift toward the other person — without putting words in their mouth.",
  context:
    "Invite the user to add new factual context (events, history, words spoken, missing details) that they haven't shared yet. Ask one specific, concrete question about a piece of context that seems missing.",
};

const FORBIDDEN = [
  "you should", "you need to", "you must", "i recommend",
  "the best thing", "the best option", "the right choice", "try doing",
];

const BANNED_ELABORATION = [
  "can you tell me more", "could you elaborate",
  "please share more detail", "i need more information",
];

function containsForbidden(s: string): boolean {
  const l = s.toLowerCase();
  return FORBIDDEN.some((p) => l.includes(p)) || BANNED_ELABORATION.some((p) => l.includes(p));
}

function isSubsetOfAny(candidate: string[], priorSets: string[][]): boolean {
  if (candidate.length === 0) return false;
  const cs = new Set(candidate);
  return priorSets.some((p) => {
    if (p.length === 0) return false;
    const ps = new Set(p);
    for (const c of cs) if (!ps.has(c)) return false;
    return true;
  });
}

function tokenize(s: string): Set<string> {
  return new Set(
    s
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((w) => w.length > 3),
  );
}

function jaccard(a: string, b: string): number {
  const sa = tokenize(a);
  const sb = tokenize(b);
  if (sa.size === 0 || sb.size === 0) return 0;
  let inter = 0;
  for (const w of sa) if (sb.has(w)) inter++;
  return inter / (sa.size + sb.size - inter);
}

function tokenCount(s: string): number {
  return s.trim().split(/\s+/).filter(Boolean).length;
}

const TIMELINE_KEYWORDS = [
  "what happened", "what happened next", "what happened after", "what happened because",
  "how did it end", "how did this end", "how it ended", "what came next",
  "after that", "before that", "what came before", "led up to",
  "the sequence", "timeline", "first, then", "what occurred",
];
function isTimelineQuestion(q: string, targets: string[]): boolean {
  if (targets.includes("history")) return true;
  const l = q.toLowerCase();
  return TIMELINE_KEYWORDS.some((k) => l.includes(k));
}

// Interpretation/meaning loop breaker — pattern-based.
const INTERPRETATION_KEYWORDS = [
  "why did you think", "why do you think",
  "what made you think", "what made you feel", "what made you believe",
  "why did it seem like", "why did it feel like",
  "what did they say that made you", "what did she say that made you", "what did he say that made you",
  "what made you feel she", "what made you feel he", "what made you feel they",
  "who do you think they meant", "who did they mean",
  "how did you know it was about you",
  "how did you know she meant", "how did you know he meant", "how did you know they meant",
  "what made it feel personal", "what convinced you",
];
function isInterpretationQuestion(q: string): boolean {
  const l = q.toLowerCase();
  return INTERPRETATION_KEYWORDS.some((k) => l.includes(k));
}
const INTERPRETATION_ANSWER_CUES = [
  "meant me", "meant us", "she meant", "he meant", "they meant",
  "about me", "about us", "directed at me", "aimed at me", "talking about me", "talking to me",
  "looking right at me", "looking at me", "stared at me", "glanced at me",
  "everyone knew", "obvious", "obviously", "clearly", "no doubt",
  "the way she said", "the way he said", "the way they said",
  "tone of voice", "her tone", "his tone", "their tone",
  "made it personal", "felt personal", "took it personally",
  "i felt targeted", "i felt singled out",
];
function answerHasInterpretationContent(answer: string): boolean {
  const l = (answer || "").toLowerCase();
  if (l.trim().length < 4) return false;
  return INTERPRETATION_ANSWER_CUES.some((k) => l.includes(k));
}

// ---- IDF: Irrelevant Detail Filter ----
const IRRELEVANT_DETAIL_PATTERNS = [
  "how old is", "how old are", "how old was", "what age",
  "what time", "what day", "what date", "what month", "what year",
  "where were you", "where was", "where did this happen", "what location",
  "what color", "what colour", "what were they wearing", "how tall", "how big",
  "how many", "how much", "what number", "how often per day", "how often per week",
  "what's the schedule", "what time of day", "what street",
];
const SAFETY_RISK_FAIRNESS_TIE = [
  "safe", "safety", "danger", "harm", "hurt", "violence", "abuse", "threat",
  "legal", "law", "police", "court", "custody", "lawyer",
  "fair", "unfair", "responsib", "blame", "fault", "risk", "consequence",
];
function isIrrelevantDetailQuestion(q: string): boolean {
  const l = q.toLowerCase();
  if (!IRRELEVANT_DETAIL_PATTERNS.some((p) => l.includes(p))) return false;
  return !SAFETY_RISK_FAIRNESS_TIE.some((p) => l.includes(p));
}

// ---- URD: User Rejection Detector ----
const REJECTION_PHRASES = [
  "it doesn't matter", "it does not matter", "doesnt matter", "doesn't matter",
  "that's not important", "thats not important", "not important",
  "that's irrelevant", "thats irrelevant", "irrelevant",
  "that's not the point", "thats not the point", "not the point",
  "stop asking that", "stop asking about", "quit asking",
  "i don't care about that", "i dont care about that",
  "why does that matter", "who cares", "move on", "let it go",
];
function detectUserRejection(answer: string): string | null {
  const l = (answer || "").toLowerCase();
  for (const p of REJECTION_PHRASES) if (l.includes(p)) return p;
  return null;
}
const REDUNDANCY_PHRASES = [
  "i already told you", "i already said", "i already answered",
  "i answered that", "i told you that", "i said that already",
  "that's the same question", "thats the same question",
  "you already asked", "asked that already",
];
function detectRedundancySignal(answer: string): boolean {
  const l = (answer || "").toLowerCase();
  return REDUNDANCY_PHRASES.some((p) => l.includes(p));
}

// ---- DEL / EPB priority ----
const DEEPER_FIELDS_C = ["emotions", "expectations", "intentions", "unspoken_needs", "fears", "desired_outcome"];
const SURFACE_FIELDS_C = ["situation", "history", "triggers", "relationships"];
function shouldEscalateDepthC(coverageMap: Record<string, string>, askedSoFar: number): boolean {
  if (askedSoFar < 1) return false;
  const surfaceFilled = SURFACE_FIELDS_C.filter((f) => coverageMap[f] === "filled").length;
  return surfaceFilled >= 2;
}

// Section 8 (continuation parity): AlreadyProvidedGuardrail via LLM equivalence
async function checkAlreadyProvided(
  candidateQuestion: string,
  candidateTargets: string[],
  recentAnswers: { question: string; answer: string }[],
): Promise<boolean> {
  if (recentAnswers.length === 0 || !candidateQuestion.trim()) return false;
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) return false;
  const lastThree = recentAnswers.slice(-3);
  const prompt = `Does the candidate question ask about something the user has ALREADY substantively explained?
Candidate: ${JSON.stringify(candidateQuestion)}
Targets: ${JSON.stringify(candidateTargets)}
Recent answers:
${lastThree.map((a, i) => `${i + 1}. Q: ${a.question}\n   A: ${a.answer}`).join("\n")}
Return JSON: { "already_answered": true|false }`;
  try {
    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-lite",
        temperature: 0.1,
        response_format: { type: "json_object" },
        messages: [{ role: "user", content: prompt }],
      }),
    });
    if (!resp.ok) return false;
    const data = await resp.json();
    const txt = data?.choices?.[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(txt);
    return parsed?.already_answered === true;
  } catch (_) {
    return false;
  }
}

function jsonOk(body: any) {
  return new Response(JSON.stringify(body), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
function jsonErr(status: number, error: string) {
  return new Response(JSON.stringify({ error }), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function callAI(messages: any[], opts: { json?: boolean; temperature?: number } = {}) {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");
  const body: any = {
    model: "google/gemini-2.5-flash",
    temperature: opts.temperature ?? 0.5,
    messages,
  };
  if (opts.json) body.response_format = { type: "json_object" };
  const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!resp.ok) {
    const text = await resp.text();
    const err: any = new Error(`AI error ${resp.status}: ${text}`);
    err.status = resp.status;
    throw err;
  }
  const data = await resp.json();
  return (data?.choices?.[0]?.message?.content ?? "").trim();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    if (!authHeader.startsWith("Bearer ")) return jsonErr(401, "Unauthorized");
    const userToken = authHeader.replace("Bearer ", "");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: userData, error: userErr } = await supabase.auth.getUser(userToken);
    if (userErr || !userData?.user) return jsonErr(401, "Unauthorized");

    const body = await req.json();
    const action = body.action as "start" | "next" | "finalize";
    if (!["start", "next", "finalize"].includes(action)) return jsonErr(400, "Invalid action");

    // Helper: load reflection session + snapshot + context model + answers
    const loadSessionContext = async (sessionId: string) => {
      const { data: sess } = await supabase
        .from("reflection_sessions")
        .select("id, user_id, snapshot_json, title")
        .eq("id", sessionId)
        .maybeSingle();
      if (!sess || sess.user_id !== userData.user.id) return null;

      const [{ data: ctx }, { data: answers }, { data: qhist }] = await Promise.all([
        supabase
          .from("session_context_models")
          .select("*")
          .eq("session_id", sessionId)
          .maybeSingle(),
        supabase
          .from("reflection_answers")
          .select("question_text, answer_text, question_index")
          .eq("session_id", sessionId)
          .order("question_index", { ascending: true }),
        supabase
          .from("question_history")
          .select("question_text")
          .eq("session_id", sessionId),
      ]);

      return { sess, ctx, answers: answers || [], qhist: qhist || [] };
    };

    // ---------------- START ----------------
    if (action === "start") {
      const sessionId = body.sessionId as string;
      const mode = body.mode as "explore" | "angle" | "context";
      if (!sessionId || !["explore", "angle", "context"].includes(mode)) {
        return jsonErr(400, "Missing sessionId or invalid mode");
      }
      const loaded = await loadSessionContext(sessionId);
      if (!loaded) return jsonErr(404, "Session not found");

      const { data: cs, error: csErr } = await supabase
        .from("continuation_sessions")
        .insert({ session_id: sessionId, mode, status: "active" })
        .select("id")
        .single();
      if (csErr) return jsonErr(500, csErr.message);

      // Hydrate saturation from prior ContextModel — if already ≥70, skip to wrap-up turn.
      const hydratedSat = Number(loaded.ctx?.saturation_score ?? 0);
      if (hydratedSat >= 70) {
        const wrap = "Looking at everything you've already shared, what's the one piece of this you'd most want the other person to truly hear?";
        await supabase.from("continuation_messages").insert({
          continuation_id: cs.id, role: "ai", content: wrap, target_fields: ["unspoken_needs", "intentions", "desired_outcome"],
        });
        await supabase.from("continuation_sessions")
          .update({ questions_asked: 1, fields_touched: ["unspoken_needs", "intentions", "desired_outcome"] })
          .eq("id", cs.id);
        return jsonOk({
          continuationId: cs.id, question: wrap, questionsAsked: 1, max: MAX_QUESTIONS, done: false, wrapUp: true,
        });
      }

      // Generate first question
      const question = await generateContinuationQuestion(
        mode,
        loaded.sess.snapshot_json,
        loaded.ctx,
        loaded.answers,
        loaded.qhist.map((q: any) => q.question_text).slice(-6),
        [],
        loaded.ctx,
      );

      await supabase.from("continuation_messages").insert({
        continuation_id: cs.id,
        role: "ai",
        content: question.text,
        target_fields: question.targetFields,
      });

      await supabase
        .from("continuation_sessions")
        .update({ questions_asked: 1, fields_touched: question.targetFields })
        .eq("id", cs.id);

      return jsonOk({
        continuationId: cs.id,
        question: question.text,
        questionsAsked: 1,
        max: MAX_QUESTIONS,
        done: false,
      });
    }

    // ---------------- NEXT ----------------
    if (action === "next") {
      const continuationId = body.continuationId as string;
      const userAnswer = (body.userAnswer as string) || "";
      if (!continuationId || !userAnswer.trim()) return jsonErr(400, "Missing inputs");

      const { data: cs } = await supabase
        .from("continuation_sessions")
        .select("*")
        .eq("id", continuationId)
        .maybeSingle();
      if (!cs) return jsonErr(404, "Continuation not found");

      const loaded = await loadSessionContext(cs.session_id);
      if (!loaded) return jsonErr(404, "Session not found");

      // Persist user answer
      await supabase.from("continuation_messages").insert({
        continuation_id: continuationId,
        role: "user",
        content: userAnswer.trim(),
      });

      const { data: msgs } = await supabase
        .from("continuation_messages")
        .select("role, content, target_fields")
        .eq("continuation_id", continuationId)
        .order("created_at", { ascending: true });

      // Guard: hit max questions
      if (cs.questions_asked >= MAX_QUESTIONS) {
        await supabase
          .from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "max_questions_reached" })
          .eq("id", continuationId);
        return jsonOk({ done: true, exitReason: "max_questions_reached", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }

      // Generate next question
      const allPriorQuestions = [
        ...loaded.qhist.map((q: any) => q.question_text),
        ...(msgs || []).filter((m) => m.role === "ai").map((m) => m.content),
      ];
      const recentPriorQuestions = allPriorQuestions.slice(-6);
      const allPriorFieldSets = [
        ...loaded.qhist.map((q: any) => (q.target_fields as string[]) ?? []),
        ...(msgs || []).filter((m) => m.role === "ai").map((m: any) => (m.target_fields as string[]) ?? []),
      ];
      const convo = (msgs || []).map((m) => ({ role: m.role, content: m.content }));

      const question = await generateContinuationQuestion(
        cs.mode,
        loaded.sess.snapshot_json,
        loaded.ctx,
        loaded.answers,
        recentPriorQuestions,
        convo,
        loaded.ctx,
      );

      // Guard: ≥3 target fields
      if (question.targetFields.length < 3) {
        await supabase.from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "shallow_question" })
          .eq("id", continuationId);
        return jsonOk({ done: true, exitReason: "shallow_question", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }

      // Guard: semantic similarity check (Jaccard ≥0.35 over last 6)
      const maxSim = Math.max(0, ...recentPriorQuestions.map((q) => jaccard(q, question.text)));
      if (maxSim >= 0.35) {
        await supabase.from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "no_new_ground" })
          .eq("id", continuationId);
        return jsonOk({ done: true, exitReason: "no_new_ground", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }

      // Guard: target_fields subset of any prior question's set
      if (isSubsetOfAny(question.targetFields, allPriorFieldSets)) {
        await supabase.from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "fields_subset" })
          .eq("id", continuationId);
        return jsonOk({ done: true, exitReason: "fields_subset", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }

      // Guard: targets only fields already touched in this continuation
      const newFields = question.targetFields.filter((f) => !cs.fields_touched.includes(f));
      if (newFields.length === 0 && cs.questions_asked >= 2) {
        await supabase.from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "fields_saturated" })
          .eq("id", continuationId);
        return jsonOk({ done: true, exitReason: "fields_saturated", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }

      // Section 1/11/12 (continuation parity): timeline lock check.
      // history is locked when coverage_map.history === "filled" OR original session
      // already has substantive history entries.
      const ctxAny = loaded.ctx as any;
      const coverageMap = (ctxAny?.coverage_map as Record<string, string>) ?? {};
      const historyLocked =
        coverageMap.history === "filled" ||
        (Array.isArray(ctxAny?.history) && ctxAny.history.length >= 1);
      if (historyLocked && (question.targetFields.includes("history") || isTimelineQuestion(question.text, question.targetFields))) {
        await supabase.from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "timeline_locked" })
          .eq("id", continuationId);
        return jsonOk({ done: true, exitReason: "timeline_locked", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }

      // Interpretation/meaning lock (continuation parity).
      // Inherits from parent: if any prior answer in the parent session OR in this
      // continuation already volunteered interpretation content, OR if a prior AI
      // question in this continuation was already an interpretation question, the
      // field is locked.
      const parentInterpretationVolunteered = (loaded.answers || []).some((a: any) =>
        answerHasInterpretationContent(String(a.answer_text ?? ""))
      );
      const continuationUserAnswers = (msgs || []).filter((m) => m.role === "user").map((m) => String(m.content ?? ""));
      const continuationInterpretationVolunteered = continuationUserAnswers.some(answerHasInterpretationContent);
      const priorInterpretationQuestionCount = (msgs || [])
        .filter((m) => m.role === "ai" && isInterpretationQuestion(String(m.content ?? "")))
        .length;
      const interpretationLocked =
        parentInterpretationVolunteered ||
        continuationInterpretationVolunteered ||
        priorInterpretationQuestionCount >= 2;
      if (interpretationLocked && isInterpretationQuestion(question.text)) {
        await supabase.from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "interpretation_locked" })
          .eq("id", continuationId);
        return jsonOk({ done: true, exitReason: "interpretation_locked", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }

      // ---- IDF: irrelevant detail filter (continuation parity) ----
      if (isIrrelevantDetailQuestion(question.text)) {
        await supabase.from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "irrelevant_detail" })
          .eq("id", continuationId);
        console.info("[continuation] IDF reject", { q: question.text });
        return jsonOk({ done: true, exitReason: "irrelevant_detail", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }

      // ---- URD: inherit from parent + this continuation ----
      // Locked fields = parent fields the user already rejected, plus those rejected
      // in continuation answers.
      const parentRejectedFields = new Set<string>();
      for (let i = 0; i < (loaded.answers || []).length; i++) {
        const ans = String((loaded.answers as any[])[i]?.answer_text ?? "");
        if (detectUserRejection(ans) || detectRedundancySignal(ans)) {
          // We don't have direct field mapping here; conservatively lock based on
          // parent question history target_fields (best-effort).
          const qhRow = (loaded.qhist as any[])[i];
          const fields = (qhRow?.target_fields as string[]) ?? [];
          fields.forEach((f) => parentRejectedFields.add(f));
        }
      }
      const continuationRejectedFields = new Set<string>();
      const aiMsgs = (msgs || []).filter((m) => m.role === "ai");
      const userMsgs = (msgs || []).filter((m) => m.role === "user");
      for (let i = 0; i < userMsgs.length; i++) {
        const ans = String(userMsgs[i]?.content ?? "");
        if (detectUserRejection(ans) || detectRedundancySignal(ans)) {
          const aiBefore = aiMsgs[i];
          const fields = ((aiBefore as any)?.target_fields as string[]) ?? [];
          fields.forEach((f) => continuationRejectedFields.add(f));
        }
      }
      const allRejected = new Set([...parentRejectedFields, ...continuationRejectedFields]);
      const rejectedHits = question.targetFields.filter((f) => allRejected.has(f));
      if (rejectedHits.length > 0) {
        await supabase.from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "user_rejected_field" })
          .eq("id", continuationId);
        console.info("[continuation] URD reject", { fields: rejectedHits });
        return jsonOk({ done: true, exitReason: "user_rejected_field", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }

      // ---- FR2 strict: ≥2 fields, no recent-2-turn re-targeting ----
      if (question.targetFields.length < 2) {
        await supabase.from("continuation_sessions")
          .update({ status: "exited_by_guard", exit_reason: "single_field_question" })
          .eq("id", continuationId);
        return jsonOk({ done: true, exitReason: "single_field_question", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
      }
      const recentTwoTurnFields = new Set<string>();
      aiMsgs.slice(-2).forEach((m: any) => {
        ((m?.target_fields as string[]) ?? []).forEach((f) => recentTwoTurnFields.add(f));
      });
      if (recentTwoTurnFields.size > 0) {
        const newOnes = question.targetFields.filter((f) => !recentTwoTurnFields.has(f));
        if (newOnes.length === 0) {
          await supabase.from("continuation_sessions")
            .update({ status: "exited_by_guard", exit_reason: "no_new_field" })
            .eq("id", continuationId);
          return jsonOk({ done: true, exitReason: "no_new_field", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
        }
      }

      // ---- DEL: depth escalation after surface fields filled ----
      const ctxAny2 = loaded.ctx as any;
      const covMap = (ctxAny2?.coverage_map as Record<string, string>) ?? {};
      if (shouldEscalateDepthC(covMap, cs.questions_asked)) {
        const hasDeep = question.targetFields.some((f) => DEEPER_FIELDS_C.includes(f));
        if (!hasDeep) {
          await supabase.from("continuation_sessions")
            .update({ status: "exited_by_guard", exit_reason: "depth_not_escalated" })
            .eq("id", continuationId);
          return jsonOk({ done: true, exitReason: "depth_not_escalated", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
        }
      }

      // Section 8 (continuation parity): AlreadyProvidedGuardrail — every turn.
      const priorAnswerPairs = (loaded.answers || []).map((a: any) => ({
        question: String(a.question_text ?? ""),
        answer: String(a.answer_text ?? ""),
      }));
      // Also include continuation user answers so guardrail covers them.
      const continuationPairs = userMsgs.map((m: any, i: number) => ({
        question: String((aiMsgs[i] as any)?.content ?? ""),
        answer: String(m?.content ?? ""),
      }));
      const allPairs = [...priorAnswerPairs, ...continuationPairs];
      if (allPairs.length >= 1) {
        const alreadyAnswered = await checkAlreadyProvided(question.text, question.targetFields, allPairs);
        if (alreadyAnswered) {
          await supabase.from("continuation_sessions")
            .update({ status: "exited_by_guard", exit_reason: "already_answered" })
            .eq("id", continuationId);
          return jsonOk({ done: true, exitReason: "already_answered", questionsAsked: cs.questions_asked, max: MAX_QUESTIONS });
        }
      }

      const newQuestionsAsked = cs.questions_asked + 1;
      const mergedFields = Array.from(new Set([...cs.fields_touched, ...question.targetFields]));

      await supabase.from("continuation_messages").insert({
        continuation_id: continuationId,
        role: "ai",
        content: question.text,
        target_fields: question.targetFields,
      });

      await supabase
        .from("continuation_sessions")
        .update({ questions_asked: newQuestionsAsked, fields_touched: mergedFields })
        .eq("id", continuationId);

      return jsonOk({
        question: question.text,
        questionsAsked: newQuestionsAsked,
        max: MAX_QUESTIONS,
        done: newQuestionsAsked >= MAX_QUESTIONS,
      });
    }

    // ---------------- FINALIZE ----------------
    if (action === "finalize") {
      const continuationId = body.continuationId as string;
      if (!continuationId) return jsonErr(400, "Missing continuationId");

      const { data: cs } = await supabase
        .from("continuation_sessions")
        .select("*")
        .eq("id", continuationId)
        .maybeSingle();
      if (!cs) return jsonErr(404, "Continuation not found");

      const loaded = await loadSessionContext(cs.session_id);
      if (!loaded) return jsonErr(404, "Session not found");

      const { data: msgs } = await supabase
        .from("continuation_messages")
        .select("role, content")
        .eq("continuation_id", continuationId)
        .order("created_at", { ascending: true });

      const mini = await generateMiniSnapshot(
        cs.mode,
        loaded.sess.snapshot_json,
        msgs || [],
      );

      await supabase.from("mini_snapshots").insert({
        continuation_id: continuationId,
        session_id: cs.session_id,
        mode: cs.mode,
        title: mini.title,
        summary: mini.summary,
        insights: mini.insights,
        changed_sections: mini.changed_sections,
      });

      // For "context" mode: patch the snapshot in place (diff-based)
      let updatedSnapshot = loaded.sess.snapshot_json;
      if (cs.mode === "context" && updatedSnapshot && mini.changed_sections) {
        const patched = { ...updatedSnapshot, ...mini.changed_sections };
        await supabase
          .from("reflection_sessions")
          .update({ snapshot_json: patched })
          .eq("id", cs.session_id);
        updatedSnapshot = patched;
      }

      await supabase
        .from("continuation_sessions")
        .update({
          status: cs.status === "exited_by_guard" ? "exited_by_guard" : "completed",
          completed_at: new Date().toISOString(),
        })
        .eq("id", continuationId);

      return jsonOk({
        miniSnapshot: mini,
        snapshotPatched: cs.mode === "context",
        updatedSnapshot,
      });
    }

    return jsonErr(400, "Unknown action");
  } catch (e: any) {
    console.error("continuation-engine error:", e);
    const status = e.status === 429 ? 429 : e.status === 402 ? 402 : 500;
    return jsonErr(status, e.message ?? "Unknown error");
  }
});

// ---------------- Question Generation ----------------
const ALL_FIELDS = [
  "situation", "emotions", "intentions", "triggers", "expectations",
  "fears", "desired_outcome", "relationships", "history", "unspoken_needs",
];

async function generateContinuationQuestion(
  mode: string,
  snapshot: any,
  ctx: any,
  answers: any[],
  priorQuestions: string[],
  convo: { role: string; content: string }[],
  hydratedCtx?: any,
): Promise<{ text: string; targetFields: string[] }> {
  const guidance = MODE_GUIDANCE[mode];
  const snapSummary = snapshot?.summary ? `Snapshot summary: ${snapshot.summary}` : "";
  const useCtx = hydratedCtx ?? ctx;
  const ctxJson = useCtx
    ? JSON.stringify({
        situation: useCtx.situation,
        emotions: useCtx.emotions,
        intentions: useCtx.intentions,
        triggers: useCtx.triggers,
        expectations: useCtx.expectations,
        fears: useCtx.fears,
        desired_outcome: useCtx.desired_outcome,
        relationships: useCtx.relationships,
        history: useCtx.history,
        unspoken_needs: useCtx.unspoken_needs,
      })
    : "{}";
  const coverageMap = useCtx?.coverage_map ?? {};
  const filledFields = ALL_FIELDS.filter((f) => coverageMap[f] === "filled");
  const underFilled = ALL_FIELDS.filter((f) => coverageMap[f] !== "filled");

  const priorList = priorQuestions.length
    ? priorQuestions.map((q, i) => `${i + 1}. ${q}`).join("\n")
    : "(none yet)";

  const convoBlock = convo.length
    ? convo.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join("\n")
    : "(no exchange yet)";

  const system = `You are a warm, attuned conversation partner helping someone continue thinking about a situation they've already explored.

MODE: ${MODE_LABELS[mode]}
MODE GUIDANCE: ${guidance}

${snapSummary}

Existing context model (what we know):
${ctxJson}

Coverage: filled fields (DO NOT target): ${filledFields.join(", ") || "(none)"}
Under-filled fields (target 3-5 of these): ${underFilled.join(", ") || "(none)"}

Original answers (for grounding only — do NOT re-ask any of these):
${answers.slice(0, 8).map((a, i) => `Q${i + 1}: ${a.question_text}\nA: ${a.answer_text}`).join("\n\n")}

Questions ALREADY asked (last 6) — NEVER repeat or rephrase any of these:
${priorList}

Current continuation exchange so far:
${convoBlock}

Hard rules:
- Ask ONE single open-ended therapy-style question that layers 3-5 under-filled ContextModel fields at once.
- Forbidden phrases: "you should", "you need to", "you must", "I recommend", "the best thing", "try doing", "can you tell me more", "could you elaborate", "please share more detail", "I need more information".
- Forbidden words: reflection, reflective, dynamic, framework, lens, construct, narrative, journey, therapeutic.
- Must NOT semantically repeat any prior question.
- DO NOT ask interpretation/meaning questions ("why did you think they meant you", "what made you feel that way", "what made you think that", "who do you think they meant", "how did you know it was about you", or any rephrasing). The parent session has already covered interpretation; rotate to a structurally different field.
- DO NOT target the same field set as the previous question — include at least one field NOT covered by the previous question.
- target_fields MUST contain 3-5 entries chosen ONLY from the under-filled list above. Single-field questions are FORBIDDEN.
- IRRELEVANT DETAIL RULE: Do NOT ask about age, time, location, scheduling, physical description, or numeric details unless tied to safety, legality, fairness, responsibility, or risk. Banned starts: "How old is...", "What time...", "Where were you...", "What color...", "How many...", "What day...".
- USER REJECTION RULE: If the user has signaled (in parent or this continuation) that a topic doesn't matter ("it doesn't matter", "that's not important", "stop asking that", or any paraphrase), the corresponding fields are PERMANENTLY locked. Never target them.
- EMOTIONAL PRIORITY: Prioritize emotional relevance over factual detail. Order: emotions, expectations, intentions, fairness/resentment, unspoken_needs, relationships, responsibility, consequences. Logistics only when tied to safety/legal.
- DEPTH ESCALATION: After turn 3 or once surface fields (situation, history, triggers, relationships) are filled, your target_fields MUST include at least one of: emotions, expectations, intentions, unspoken_needs, fears, desired_outcome.
- FIELD ROTATION (STRICT): Do not target the same field twice in a row. Do not target any field already targeted in the LAST 2 turns. Always add ≥1 NEW field. Avoid clusters: if a field appeared in the last 3 turns, do not include it again.

Return STRICT JSON only:
{
  "question": "string (the single question)",
  "target_fields": ["field1", "field2"]
}`;

  const raw = await callAI(
    [{ role: "system", content: system }, { role: "user", content: "Generate the next question." }],
    { json: true, temperature: 0.5 },
  );

  let parsed: any = {};
  try {
    parsed = JSON.parse(raw);
  } catch {
    // Best-effort fallback
    parsed = { question: raw.replace(/^["']|["']$/g, ""), target_fields: [] };
  }
  const text = String(parsed.question || "").trim().replace(/^["']|["']$/g, "");
  if (!text || containsForbidden(text)) {
    throw new Error("Could not generate a valid question");
  }
  const targetFields = Array.isArray(parsed.target_fields)
    ? parsed.target_fields.filter((f: any) => typeof f === "string" && ALL_FIELDS.includes(f))
    : [];
  return { text, targetFields };
}

// ---------------- Mini-Snapshot Generation ----------------
async function generateMiniSnapshot(
  mode: string,
  snapshot: any,
  msgs: { role: string; content: string }[],
): Promise<{
  title: string;
  summary: string;
  insights: string[];
  changed_sections: Record<string, any>;
}> {
  const convo = msgs.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join("\n");
  const snapJson = snapshot ? JSON.stringify(snapshot) : "{}";

  const titleByMode: Record<string, string> = {
    explore: "What we explored deeper",
    angle: "From their side",
    context: "Updated with new context",
  };

  const modeInstruction =
    mode === "context"
      ? `Identify which snapshot sections (summary, observations, possible_paths, recommended_next_steps, common_misunderstandings, how_to_communicate) need to change based on the new context. Return ONLY the sections that should change in "changed_sections". Each section must be a string (for summary) or string[] (for the others). Do NOT include sections that don't change.`
      : `Do NOT modify the original snapshot. Leave "changed_sections" as an empty object {}.`;

  const system = `You are summarizing a short follow-up conversation that built on an existing situation snapshot.

MODE: ${MODE_LABELS[mode]}

Original snapshot (JSON):
${snapJson}

Follow-up conversation:
${convo}

${modeInstruction}

Hard rules:
- Warm, validating, non-directive tone.
- 2-4 distinct insights that came out of THIS specific exchange (not generic).
- Forbidden phrases: "you should", "you need to", "I recommend", "the best thing".

Return STRICT JSON only:
{
  "title": "string",
  "summary": "1-2 sentences capturing what shifted or surfaced",
  "insights": ["short insight 1", "short insight 2"],
  "changed_sections": { /* only for context mode, otherwise {} */ }
}`;

  const raw = await callAI(
    [{ role: "system", content: system }, { role: "user", content: "Build the mini-snapshot." }],
    { json: true, temperature: 0.4 },
  );

  let parsed: any = {};
  try { parsed = JSON.parse(raw); } catch { /* ignore */ }

  return {
    title: String(parsed.title || titleByMode[mode] || "What surfaced").trim(),
    summary: String(parsed.summary || "").trim(),
    insights: Array.isArray(parsed.insights)
      ? parsed.insights.map((s: any) => String(s).trim()).filter(Boolean).slice(0, 6)
      : [],
    changed_sections:
      mode === "context" && parsed.changed_sections && typeof parsed.changed_sections === "object"
        ? parsed.changed_sections
        : {},
  };
}
