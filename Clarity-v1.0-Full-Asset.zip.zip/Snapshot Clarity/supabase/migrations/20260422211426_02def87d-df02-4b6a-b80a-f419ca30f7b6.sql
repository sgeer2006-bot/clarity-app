
CREATE TABLE public.continuation_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id UUID NOT NULL,
  mode TEXT NOT NULL CHECK (mode IN ('explore','angle','context')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','completed','exited_by_guard')),
  questions_asked INT NOT NULL DEFAULT 0,
  fields_touched TEXT[] NOT NULL DEFAULT '{}',
  exit_reason TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);

CREATE TABLE public.continuation_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  continuation_id UUID NOT NULL REFERENCES public.continuation_sessions(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user','ai')),
  content TEXT NOT NULL,
  target_fields TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.mini_snapshots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  continuation_id UUID NOT NULL REFERENCES public.continuation_sessions(id) ON DELETE CASCADE,
  session_id UUID NOT NULL,
  mode TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  insights JSONB NOT NULL DEFAULT '[]',
  changed_sections JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_cs_session ON public.continuation_sessions(session_id);
CREATE INDEX idx_cm_continuation ON public.continuation_messages(continuation_id);
CREATE INDEX idx_ms_session ON public.mini_snapshots(session_id);

ALTER TABLE public.continuation_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.continuation_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mini_snapshots ENABLE ROW LEVEL SECURITY;

CREATE POLICY cs_select_own ON public.continuation_sessions FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.reflection_sessions s WHERE s.id = continuation_sessions.session_id AND s.user_id = auth.uid())
);
CREATE POLICY cs_insert_own ON public.continuation_sessions FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.reflection_sessions s WHERE s.id = continuation_sessions.session_id AND s.user_id = auth.uid())
);
CREATE POLICY cs_update_own ON public.continuation_sessions FOR UPDATE USING (
  EXISTS (SELECT 1 FROM public.reflection_sessions s WHERE s.id = continuation_sessions.session_id AND s.user_id = auth.uid())
);
CREATE POLICY cs_delete_own ON public.continuation_sessions FOR DELETE USING (
  EXISTS (SELECT 1 FROM public.reflection_sessions s WHERE s.id = continuation_sessions.session_id AND s.user_id = auth.uid())
);

CREATE POLICY cm_select_own ON public.continuation_messages FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.continuation_sessions cs
    JOIN public.reflection_sessions s ON s.id = cs.session_id
    WHERE cs.id = continuation_messages.continuation_id AND s.user_id = auth.uid()
  )
);
CREATE POLICY cm_insert_own ON public.continuation_messages FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.continuation_sessions cs
    JOIN public.reflection_sessions s ON s.id = cs.session_id
    WHERE cs.id = continuation_messages.continuation_id AND s.user_id = auth.uid()
  )
);

CREATE POLICY ms_select_own ON public.mini_snapshots FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.reflection_sessions s WHERE s.id = mini_snapshots.session_id AND s.user_id = auth.uid())
);
CREATE POLICY ms_insert_own ON public.mini_snapshots FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.reflection_sessions s WHERE s.id = mini_snapshots.session_id AND s.user_id = auth.uid())
);
CREATE POLICY ms_delete_own ON public.mini_snapshots FOR DELETE USING (
  EXISTS (SELECT 1 FROM public.reflection_sessions s WHERE s.id = mini_snapshots.session_id AND s.user_id = auth.uid())
);
