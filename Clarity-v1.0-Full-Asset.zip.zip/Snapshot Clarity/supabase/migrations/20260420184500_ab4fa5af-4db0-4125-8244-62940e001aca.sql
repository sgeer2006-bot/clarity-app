
-- Follow-up messages table
CREATE TABLE public.follow_up_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.reflection_sessions(id) ON DELETE CASCADE,
  section text NOT NULL CHECK (section IN ('summary', 'consider', 'paths')),
  role text NOT NULL CHECK (role IN ('user', 'ai')),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.follow_up_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "fu_select_own" ON public.follow_up_messages FOR SELECT
  USING (EXISTS (SELECT 1 FROM reflection_sessions s WHERE s.id = follow_up_messages.session_id AND s.user_id = auth.uid()));

CREATE POLICY "fu_insert_own" ON public.follow_up_messages FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM reflection_sessions s WHERE s.id = follow_up_messages.session_id AND s.user_id = auth.uid()));

CREATE POLICY "fu_delete_own" ON public.follow_up_messages FOR DELETE
  USING (EXISTS (SELECT 1 FROM reflection_sessions s WHERE s.id = follow_up_messages.session_id AND s.user_id = auth.uid()));

-- Snapshot versions table
CREATE TABLE public.snapshot_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.reflection_sessions(id) ON DELETE CASCADE,
  version_number integer NOT NULL DEFAULT 1,
  summary text NOT NULL,
  observations jsonb NOT NULL DEFAULT '[]'::jsonb,
  possible_paths jsonb NOT NULL DEFAULT '[]'::jsonb,
  disclaimer text NOT NULL DEFAULT 'This tool does not give advice. It generates general perspectives based solely on the information you provide. You are responsible for your own decisions.',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (session_id, version_number)
);

ALTER TABLE public.snapshot_versions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "sv_select_own" ON public.snapshot_versions FOR SELECT
  USING (EXISTS (SELECT 1 FROM reflection_sessions s WHERE s.id = snapshot_versions.session_id AND s.user_id = auth.uid()));

CREATE POLICY "sv_insert_own" ON public.snapshot_versions FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM reflection_sessions s WHERE s.id = snapshot_versions.session_id AND s.user_id = auth.uid()));

CREATE POLICY "sv_delete_own" ON public.snapshot_versions FOR DELETE
  USING (EXISTS (SELECT 1 FROM reflection_sessions s WHERE s.id = snapshot_versions.session_id AND s.user_id = auth.uid()));

CREATE INDEX idx_follow_up_session ON public.follow_up_messages(session_id, created_at);
CREATE INDEX idx_snapshot_versions_session ON public.snapshot_versions(session_id, version_number);
