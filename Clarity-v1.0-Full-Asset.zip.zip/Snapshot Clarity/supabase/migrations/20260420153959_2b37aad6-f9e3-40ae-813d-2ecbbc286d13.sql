-- Drop old tables
DROP TABLE IF EXISTS public.question_responses CASCADE;
DROP TABLE IF EXISTS public.snapshots CASCADE;
DROP TABLE IF EXISTS public.sessions CASCADE;

-- reflection_sessions
CREATE TABLE public.reflection_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  title text NOT NULL DEFAULT 'Reflection',
  status text NOT NULL DEFAULT 'in_progress',
  snapshot text,
  snapshot_json jsonb,
  share_token text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  deleted_at timestamptz
);

CREATE INDEX idx_reflection_sessions_user ON public.reflection_sessions(user_id);
CREATE INDEX idx_reflection_sessions_share_token ON public.reflection_sessions(share_token) WHERE share_token IS NOT NULL;

ALTER TABLE public.reflection_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY rs_select_own ON public.reflection_sessions
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY rs_insert_own ON public.reflection_sessions
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY rs_update_own ON public.reflection_sessions
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY rs_delete_own ON public.reflection_sessions
  FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY rs_select_share ON public.reflection_sessions
  FOR SELECT USING (share_token IS NOT NULL AND deleted_at IS NULL AND status = 'complete');

-- reflection_answers
CREATE TABLE public.reflection_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.reflection_sessions(id) ON DELETE CASCADE,
  question_index int NOT NULL CHECK (question_index BETWEEN 1 AND 5),
  question_text text NOT NULL,
  answer_text text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (session_id, question_index)
);

CREATE INDEX idx_reflection_answers_session ON public.reflection_answers(session_id);

ALTER TABLE public.reflection_answers ENABLE ROW LEVEL SECURITY;

CREATE POLICY ra_select_own ON public.reflection_answers
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.reflection_sessions s
    WHERE s.id = reflection_answers.session_id AND s.user_id = auth.uid()
  ));
CREATE POLICY ra_insert_own ON public.reflection_answers
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.reflection_sessions s
    WHERE s.id = reflection_answers.session_id AND s.user_id = auth.uid()
  ));
CREATE POLICY ra_update_own ON public.reflection_answers
  FOR UPDATE USING (EXISTS (
    SELECT 1 FROM public.reflection_sessions s
    WHERE s.id = reflection_answers.session_id AND s.user_id = auth.uid()
  ));
CREATE POLICY ra_delete_own ON public.reflection_answers
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.reflection_sessions s
    WHERE s.id = reflection_answers.session_id AND s.user_id = auth.uid()
  ));