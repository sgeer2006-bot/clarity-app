-- Sessions
CREATE TABLE public.sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 80),
  status text NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress','completed','failed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);
ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sessions_select_own" ON public.sessions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "sessions_insert_own" ON public.sessions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "sessions_update_own" ON public.sessions FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "sessions_delete_own" ON public.sessions FOR DELETE USING (auth.uid() = user_id);

-- Question responses
CREATE TABLE public.question_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,
  question_number int NOT NULL CHECK (question_number BETWEEN 1 AND 5),
  question_text text NOT NULL,
  response_text text NOT NULL CHECK (char_length(response_text) BETWEEN 5 AND 500),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(session_id, question_number)
);
ALTER TABLE public.question_responses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "qr_select_own" ON public.question_responses FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.sessions s WHERE s.id = session_id AND s.user_id = auth.uid())
);
CREATE POLICY "qr_insert_own" ON public.question_responses FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM public.sessions s WHERE s.id = session_id AND s.user_id = auth.uid())
);
CREATE POLICY "qr_update_own" ON public.question_responses FOR UPDATE USING (
  EXISTS (SELECT 1 FROM public.sessions s WHERE s.id = session_id AND s.user_id = auth.uid())
);
CREATE POLICY "qr_delete_own" ON public.question_responses FOR DELETE USING (
  EXISTS (SELECT 1 FROM public.sessions s WHERE s.id = session_id AND s.user_id = auth.uid())
);

-- Snapshots
CREATE TABLE public.snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL UNIQUE REFERENCES public.sessions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  summary text NOT NULL,
  insights jsonb NOT NULL,
  options jsonb NOT NULL,
  share_token text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
ALTER TABLE public.snapshots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "snap_select_own" ON public.snapshots FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "snap_insert_own" ON public.snapshots FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "snap_update_own" ON public.snapshots FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "snap_delete_own" ON public.snapshots FOR DELETE USING (auth.uid() = user_id);
-- Public read by share_token
CREATE POLICY "snap_select_share" ON public.snapshots FOR SELECT USING (share_token IS NOT NULL AND deleted_at IS NULL);

CREATE INDEX idx_snapshots_user_created ON public.snapshots(user_id, created_at DESC);
CREATE INDEX idx_qr_session ON public.question_responses(session_id);