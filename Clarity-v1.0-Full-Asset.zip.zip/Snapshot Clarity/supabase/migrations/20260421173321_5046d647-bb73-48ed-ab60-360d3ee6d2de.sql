CREATE OR REPLACE FUNCTION public.validate_reflection_answer_index()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_count INTEGER;
  expected_index INTEGER;
BEGIN
  -- On UPDATE: only allow if the index isn't changing, or if it stays sequential.
  IF TG_OP = 'UPDATE' THEN
    IF NEW.question_index = OLD.question_index THEN
      RETURN NEW;
    END IF;
  END IF;

  -- Count existing answers for this session (excluding the row being updated).
  SELECT COUNT(*) INTO existing_count
  FROM public.reflection_answers
  WHERE session_id = NEW.session_id
    AND (TG_OP = 'INSERT' OR id <> NEW.id);

  -- Allowed indices: 1..existing_count (overwrite existing) or existing_count+1 (next).
  expected_index := existing_count + 1;

  IF NEW.question_index < 1 OR NEW.question_index > expected_index THEN
    RAISE EXCEPTION 'Invalid question_index %: expected between 1 and % for session %',
      NEW.question_index, expected_index, NEW.session_id
      USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS validate_reflection_answer_index_trigger ON public.reflection_answers;

CREATE TRIGGER validate_reflection_answer_index_trigger
  BEFORE INSERT OR UPDATE ON public.reflection_answers
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_reflection_answer_index();