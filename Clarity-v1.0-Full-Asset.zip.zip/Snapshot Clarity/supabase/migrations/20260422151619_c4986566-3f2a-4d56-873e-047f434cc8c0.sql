-- Per-user pattern counts (joined with pattern metadata)
CREATE OR REPLACE FUNCTION public.get_user_pattern_counts(_user_id uuid)
RETURNS TABLE(
  pattern_id uuid,
  slug text,
  name text,
  short_description text,
  match_count bigint,
  last_matched_at timestamptz
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    p.id AS pattern_id,
    p.slug,
    p.name,
    p.short_description,
    COUNT(sp.id) AS match_count,
    MAX(sp.created_at) AS last_matched_at
  FROM public.session_patterns sp
  JOIN public.reflection_sessions s ON s.id = sp.session_id
  JOIN public.patterns p ON p.id = sp.pattern_id
  WHERE s.user_id = _user_id
    AND s.deleted_at IS NULL
  GROUP BY p.id, p.slug, p.name, p.short_description
  ORDER BY match_count DESC, last_matched_at DESC;
$$;

-- Daily completed-reflection counts for the user over the last N days
CREATE OR REPLACE FUNCTION public.get_user_activity_timeline(_user_id uuid, _days integer DEFAULT 30)
RETURNS TABLE(day date, session_count bigint)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  WITH days AS (
    SELECT generate_series(
      (now() AT TIME ZONE 'UTC')::date - (_days - 1),
      (now() AT TIME ZONE 'UTC')::date,
      INTERVAL '1 day'
    )::date AS day
  )
  SELECT
    d.day,
    COUNT(s.id) AS session_count
  FROM days d
  LEFT JOIN public.reflection_sessions s
    ON s.user_id = _user_id
    AND s.deleted_at IS NULL
    AND s.status = 'complete'
    AND (s.completed_at AT TIME ZONE 'UTC')::date = d.day
  GROUP BY d.day
  ORDER BY d.day ASC;
$$;

-- Top-level totals for the dashboard
CREATE OR REPLACE FUNCTION public.get_user_summary_stats(_user_id uuid)
RETURNS TABLE(
  total_sessions bigint,
  completed_sessions bigint,
  total_shared bigint,
  total_patterns_matched bigint,
  unique_patterns bigint,
  current_streak_days integer
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  streak integer := 0;
  d date := (now() AT TIME ZONE 'UTC')::date;
  has_activity boolean;
BEGIN
  -- Compute current streak: consecutive days (ending today or yesterday) with at least one completed session
  LOOP
    SELECT EXISTS (
      SELECT 1 FROM public.reflection_sessions s
      WHERE s.user_id = _user_id
        AND s.deleted_at IS NULL
        AND s.status = 'complete'
        AND (s.completed_at AT TIME ZONE 'UTC')::date = d
    ) INTO has_activity;

    IF has_activity THEN
      streak := streak + 1;
      d := d - 1;
    ELSE
      -- Allow streak to start from yesterday if today has no activity yet
      IF streak = 0 AND d = (now() AT TIME ZONE 'UTC')::date THEN
        d := d - 1;
        CONTINUE;
      END IF;
      EXIT;
    END IF;
  END LOOP;

  RETURN QUERY
  SELECT
    (SELECT COUNT(*) FROM public.reflection_sessions
       WHERE user_id = _user_id AND deleted_at IS NULL),
    (SELECT COUNT(*) FROM public.reflection_sessions
       WHERE user_id = _user_id AND deleted_at IS NULL AND status = 'complete'),
    (SELECT COUNT(*) FROM public.shared_snapshots
       WHERE user_id = _user_id),
    (SELECT COUNT(*) FROM public.session_patterns sp
       JOIN public.reflection_sessions s ON s.id = sp.session_id
       WHERE s.user_id = _user_id AND s.deleted_at IS NULL),
    (SELECT COUNT(DISTINCT sp.pattern_id) FROM public.session_patterns sp
       JOIN public.reflection_sessions s ON s.id = sp.session_id
       WHERE s.user_id = _user_id AND s.deleted_at IS NULL),
    streak;
END;
$$;