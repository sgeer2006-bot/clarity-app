-- ============================================================
-- Phase 2 Pattern Engine: additive tables (all prefixed pe_*)
-- ============================================================

-- 1. Macro pattern instances
CREATE TABLE public.pe_macro_patterns (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  pattern_type TEXT NOT NULL,       -- 'emotional_loop' | 'communication_style' | 'conflict_role' | 'cognitive_distortion' | 'recurring_theme'
  pattern_label TEXT NOT NULL,
  confidence NUMERIC NOT NULL DEFAULT 0,
  source_answer_ids UUID[] NOT NULL DEFAULT '{}',
  payload JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX idx_pe_macro_patterns_user ON public.pe_macro_patterns(user_id, created_at DESC);
CREATE INDEX idx_pe_macro_patterns_type ON public.pe_macro_patterns(user_id, pattern_type);

ALTER TABLE public.pe_macro_patterns ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_macro_patterns_select_own" ON public.pe_macro_patterns FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_macro_patterns_insert_own" ON public.pe_macro_patterns FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_macro_patterns_update_own" ON public.pe_macro_patterns FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "pe_macro_patterns_delete_own" ON public.pe_macro_patterns FOR DELETE USING (auth.uid() = user_id);

-- 2. Macro frequency rollup
CREATE TABLE public.pe_macro_frequency (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  pattern_type TEXT NOT NULL,
  pattern_label TEXT NOT NULL,
  raw_count INTEGER NOT NULL DEFAULT 0,
  weighted_score NUMERIC NOT NULL DEFAULT 0,
  last_seen_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, pattern_type, pattern_label)
);
CREATE INDEX idx_pe_macro_frequency_user ON public.pe_macro_frequency(user_id, weighted_score DESC);

ALTER TABLE public.pe_macro_frequency ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_macro_frequency_select_own" ON public.pe_macro_frequency FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_macro_frequency_insert_own" ON public.pe_macro_frequency FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_macro_frequency_update_own" ON public.pe_macro_frequency FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "pe_macro_frequency_delete_own" ON public.pe_macro_frequency FOR DELETE USING (auth.uid() = user_id);

-- 3. Psychological identity profile (one row per user)
CREATE TABLE public.pe_identity_profile (
  user_id UUID NOT NULL PRIMARY KEY,
  emotional_baseline JSONB NOT NULL DEFAULT '{}',
  communication_baseline JSONB NOT NULL DEFAULT '{}',
  conflict_role_baseline JSONB NOT NULL DEFAULT '{}',
  attachment_signals JSONB NOT NULL DEFAULT '{}',
  blind_spots JSONB NOT NULL DEFAULT '[]',
  strengths JSONB NOT NULL DEFAULT '[]',
  vulnerabilities JSONB NOT NULL DEFAULT '[]',
  recurring_triggers JSONB NOT NULL DEFAULT '[]',
  narrative_md TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  last_updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.pe_identity_profile ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_identity_profile_select_own" ON public.pe_identity_profile FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_identity_profile_insert_own" ON public.pe_identity_profile FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_identity_profile_update_own" ON public.pe_identity_profile FOR UPDATE USING (auth.uid() = user_id);

-- 4. Identity profile history snapshots
CREATE TABLE public.pe_identity_profile_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  version INTEGER NOT NULL,
  snapshot JSONB NOT NULL DEFAULT '{}',
  narrative_md TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX idx_pe_identity_history_user ON public.pe_identity_profile_history(user_id, version DESC);

ALTER TABLE public.pe_identity_profile_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_identity_history_select_own" ON public.pe_identity_profile_history FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_identity_history_insert_own" ON public.pe_identity_profile_history FOR INSERT WITH CHECK (auth.uid() = user_id);

-- 5. Timeline events
CREATE TABLE public.pe_timeline_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  event_date DATE NOT NULL DEFAULT (now() AT TIME ZONE 'UTC')::date,
  event_type TEXT NOT NULL,
  short_label TEXT NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  detail JSONB NOT NULL DEFAULT '{}',
  linked_pattern_ids UUID[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX idx_pe_timeline_user_date ON public.pe_timeline_events(user_id, event_date DESC);

ALTER TABLE public.pe_timeline_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_timeline_select_own" ON public.pe_timeline_events FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_timeline_insert_own" ON public.pe_timeline_events FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_timeline_update_own" ON public.pe_timeline_events FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "pe_timeline_delete_own" ON public.pe_timeline_events FOR DELETE USING (auth.uid() = user_id);

-- 6. Heatmap cells
CREATE TABLE public.pe_heatmap_cells (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  cell_date DATE NOT NULL,
  pattern_count INTEGER NOT NULL DEFAULT 0,
  dominant_pattern_type TEXT,
  intensity_score NUMERIC NOT NULL DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, cell_date)
);
CREATE INDEX idx_pe_heatmap_user_date ON public.pe_heatmap_cells(user_id, cell_date DESC);

ALTER TABLE public.pe_heatmap_cells ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_heatmap_select_own" ON public.pe_heatmap_cells FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_heatmap_insert_own" ON public.pe_heatmap_cells FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_heatmap_update_own" ON public.pe_heatmap_cells FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "pe_heatmap_delete_own" ON public.pe_heatmap_cells FOR DELETE USING (auth.uid() = user_id);

-- 7. Pattern clusters
CREATE TABLE public.pe_pattern_clusters (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  cluster_label TEXT NOT NULL,
  cluster_summary TEXT NOT NULL DEFAULT '',
  member_pattern_ids UUID[] NOT NULL DEFAULT '{}',
  cohesion_score NUMERIC NOT NULL DEFAULT 0,
  last_updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX idx_pe_clusters_user ON public.pe_pattern_clusters(user_id, last_updated_at DESC);

ALTER TABLE public.pe_pattern_clusters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_clusters_select_own" ON public.pe_pattern_clusters FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_clusters_insert_own" ON public.pe_pattern_clusters FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_clusters_update_own" ON public.pe_pattern_clusters FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "pe_clusters_delete_own" ON public.pe_pattern_clusters FOR DELETE USING (auth.uid() = user_id);

-- 8. Background job observability
CREATE TABLE public.pe_job_runs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  job_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'started',  -- 'started' | 'success' | 'error' | 'partial'
  triggered_by TEXT NOT NULL DEFAULT 'unknown', -- 'on_answer_saved' | 'scheduled' | 'manual'
  source_answer_id UUID,
  error_message TEXT,
  details JSONB NOT NULL DEFAULT '{}',
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE
);
CREATE INDEX idx_pe_job_runs_user ON public.pe_job_runs(user_id, started_at DESC);
CREATE INDEX idx_pe_job_runs_job ON public.pe_job_runs(job_name, started_at DESC);

ALTER TABLE public.pe_job_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_job_runs_select_own" ON public.pe_job_runs FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_job_runs_insert_own" ON public.pe_job_runs FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);