
-- FTUE / onboarding profile (Phase 1 of clarity_global_pass_v1)
CREATE TABLE public.user_profiles (
  user_id UUID NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  ftue_a_completed BOOLEAN NOT NULL DEFAULT false,
  ftue_a_completed_at TIMESTAMPTZ,
  ftue_b_last_shown_at TIMESTAMPTZ,
  ftue_enabled BOOLEAN NOT NULL DEFAULT true,
  tour_completed BOOLEAN NOT NULL DEFAULT false,
  tour_completed_at TIMESTAMPTZ,
  identity_seed TEXT,
  identity_seed_at TIMESTAMPTZ,
  clarity_plus_intro_dismissed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "up_select_own" ON public.user_profiles
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "up_insert_own" ON public.user_profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "up_update_own" ON public.user_profiles
  FOR UPDATE USING (auth.uid() = user_id);

-- Touch updated_at
CREATE OR REPLACE FUNCTION public.touch_user_profiles_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_user_profiles_touch
  BEFORE UPDATE ON public.user_profiles
  FOR EACH ROW EXECUTE FUNCTION public.touch_user_profiles_updated_at();

-- Auto-create a profile row on new auth user
CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.user_profiles (user_id) VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_profile();
