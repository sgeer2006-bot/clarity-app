-- Sessions: one per shared situation
CREATE TABLE public.two_person_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_id UUID NOT NULL,
  topic TEXT NOT NULL,
  invite_token TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'awaiting_invitee'
    CHECK (status IN ('awaiting_owner', 'awaiting_invitee', 'awaiting_other', 'ready', 'complete')),
  combined_summary TEXT,
  shared_themes JSONB NOT NULL DEFAULT '[]'::jsonb,
  misread_points JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  deleted_at TIMESTAMPTZ
);

CREATE INDEX two_person_sessions_owner_idx ON public.two_person_sessions(owner_id);
CREATE INDEX two_person_sessions_token_idx ON public.two_person_sessions(invite_token);

-- Perspectives: one per side ('owner' or 'invitee')
CREATE TABLE public.two_person_perspectives (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id UUID NOT NULL REFERENCES public.two_person_sessions(id) ON DELETE CASCADE,
  side TEXT NOT NULL CHECK (side IN ('owner', 'invitee')),
  display_name TEXT,
  perspective_text TEXT NOT NULL,
  suggested_rewrite TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (session_id, side)
);

CREATE INDEX two_person_perspectives_session_idx ON public.two_person_perspectives(session_id);

-- RLS
ALTER TABLE public.two_person_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.two_person_perspectives ENABLE ROW LEVEL SECURITY;

-- Owner-side policies on sessions
CREATE POLICY tps_select_own ON public.two_person_sessions
  FOR SELECT USING (auth.uid() = owner_id);

CREATE POLICY tps_insert_own ON public.two_person_sessions
  FOR INSERT WITH CHECK (auth.uid() = owner_id);

CREATE POLICY tps_update_own ON public.two_person_sessions
  FOR UPDATE USING (auth.uid() = owner_id);

CREATE POLICY tps_delete_own ON public.two_person_sessions
  FOR DELETE USING (auth.uid() = owner_id);

-- Owner can manage their perspectives
CREATE POLICY tpp_select_owner ON public.two_person_perspectives
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.two_person_sessions s
      WHERE s.id = two_person_perspectives.session_id
        AND s.owner_id = auth.uid()
    )
  );

CREATE POLICY tpp_insert_owner ON public.two_person_perspectives
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.two_person_sessions s
      WHERE s.id = two_person_perspectives.session_id
        AND s.owner_id = auth.uid()
    )
  );

CREATE POLICY tpp_update_owner ON public.two_person_perspectives
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.two_person_sessions s
      WHERE s.id = two_person_perspectives.session_id
        AND s.owner_id = auth.uid()
    )
  );

-- Touch updated_at on perspectives
CREATE OR REPLACE FUNCTION public.touch_two_person_perspective_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_two_person_perspective_touch
BEFORE UPDATE ON public.two_person_perspectives
FOR EACH ROW
EXECUTE FUNCTION public.touch_two_person_perspective_updated_at();

-- SECURITY DEFINER helpers for token-based (no-auth) access by the invitee.
-- Returns minimal session info needed to show the invite landing page.
CREATE OR REPLACE FUNCTION public.get_two_person_session_by_token(_token TEXT)
RETURNS TABLE(
  id UUID,
  topic TEXT,
  status TEXT,
  has_owner_perspective BOOLEAN,
  has_invitee_perspective BOOLEAN,
  created_at TIMESTAMPTZ
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    s.id,
    s.topic,
    s.status,
    EXISTS (SELECT 1 FROM public.two_person_perspectives p WHERE p.session_id = s.id AND p.side = 'owner') AS has_owner_perspective,
    EXISTS (SELECT 1 FROM public.two_person_perspectives p WHERE p.session_id = s.id AND p.side = 'invitee') AS has_invitee_perspective,
    s.created_at
  FROM public.two_person_sessions s
  WHERE s.invite_token = _token
    AND s.deleted_at IS NULL
  LIMIT 1;
$$;

-- Allow the invitee (no auth) to upsert their perspective via token.
CREATE OR REPLACE FUNCTION public.submit_invitee_perspective(
  _token TEXT,
  _display_name TEXT,
  _perspective_text TEXT
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_session_id UUID;
BEGIN
  IF _perspective_text IS NULL OR length(trim(_perspective_text)) < 20 THEN
    RAISE EXCEPTION 'Perspective is too short' USING ERRCODE = 'check_violation';
  END IF;

  SELECT id INTO v_session_id
  FROM public.two_person_sessions
  WHERE invite_token = _token
    AND deleted_at IS NULL
  LIMIT 1;

  IF v_session_id IS NULL THEN
    RAISE EXCEPTION 'Invite not found' USING ERRCODE = 'no_data_found';
  END IF;

  INSERT INTO public.two_person_perspectives (session_id, side, display_name, perspective_text)
  VALUES (v_session_id, 'invitee', NULLIF(trim(_display_name), ''), trim(_perspective_text))
  ON CONFLICT (session_id, side)
  DO UPDATE SET
    display_name = EXCLUDED.display_name,
    perspective_text = EXCLUDED.perspective_text,
    updated_at = now();

  -- Move status forward if owner already submitted
  UPDATE public.two_person_sessions
  SET status = CASE
    WHEN EXISTS (SELECT 1 FROM public.two_person_perspectives p
                 WHERE p.session_id = v_session_id AND p.side = 'owner')
      THEN 'ready'
    ELSE 'awaiting_owner'
  END
  WHERE id = v_session_id;

  RETURN v_session_id;
END;
$$;