-- Safety events log: records when crisis indicators are detected
CREATE TABLE public.safety_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  session_id UUID REFERENCES public.reflection_sessions(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'medium',
  matched_terms TEXT[] NOT NULL DEFAULT '{}',
  source TEXT NOT NULL DEFAULT 'answer',
  source_text TEXT,
  shown BOOLEAN NOT NULL DEFAULT true,
  acknowledged BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.safety_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "se_select_own"
  ON public.safety_events FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "se_insert_own"
  ON public.safety_events FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "se_update_own"
  ON public.safety_events FOR UPDATE
  USING (auth.uid() = user_id);

CREATE INDEX idx_safety_events_user ON public.safety_events(user_id, created_at DESC);
CREATE INDEX idx_safety_events_session ON public.safety_events(session_id);