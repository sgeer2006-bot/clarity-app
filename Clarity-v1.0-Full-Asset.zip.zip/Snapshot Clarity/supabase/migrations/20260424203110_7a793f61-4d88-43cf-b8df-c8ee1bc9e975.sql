-- Pattern Engine v1 — parallel system, per-answer analysis unit
-- All tables are user-scoped via RLS. The "entry" unit is reflection_answers.id.

-- 1) markers: polymorphic per-answer extracted markers
CREATE TABLE public.pe_markers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  answer_id UUID NOT NULL,
  session_id UUID NOT NULL,
  kind TEXT NOT NULL,
  subtype TEXT NOT NULL,
  valence NUMERIC,
  intensity NUMERIC NOT NULL DEFAULT 0,
  certainty NUMERIC,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX pe_markers_user_kind_idx ON public.pe_markers(user_id, kind, subtype);
CREATE INDEX pe_markers_answer_idx ON public.pe_markers(answer_id);
CREATE INDEX pe_markers_user_recent_idx ON public.pe_markers(user_id, created_at DESC);
ALTER TABLE public.pe_markers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_markers_select_own" ON public.pe_markers FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_markers_insert_own" ON public.pe_markers FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_markers_delete_own" ON public.pe_markers FOR DELETE USING (auth.uid() = user_id);

-- 2) pattern_tags: normalized tags per answer
CREATE TABLE public.pe_pattern_tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  answer_id UUID NOT NULL,
  session_id UUID NOT NULL,
  tag_key TEXT NOT NULL,
  tag_label TEXT NOT NULL,
  category TEXT NOT NULL,
  intensity NUMERIC NOT NULL DEFAULT 0,
  confidence NUMERIC NOT NULL DEFAULT 0,
  cluster_id TEXT,
  evidence_snippets JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX pe_tags_user_key_idx ON public.pe_pattern_tags(user_id, tag_key);
CREATE INDEX pe_tags_user_recent_idx ON public.pe_pattern_tags(user_id, created_at DESC);
CREATE INDEX pe_tags_answer_idx ON public.pe_pattern_tags(answer_id);
ALTER TABLE public.pe_pattern_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_tags_select_own" ON public.pe_pattern_tags FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_tags_insert_own" ON public.pe_pattern_tags FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_tags_delete_own" ON public.pe_pattern_tags FOR DELETE USING (auth.uid() = user_id);

-- 3) snapshots: one per analyzed answer
CREATE TABLE public.pe_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  answer_id UUID NOT NULL UNIQUE,
  session_id UUID NOT NULL,
  primary_pattern_id TEXT NOT NULL,
  secondary_pattern_ids TEXT[] NOT NULL DEFAULT '{}',
  loop_id TEXT,
  communication_style TEXT,
  behavioral_tendencies TEXT[] NOT NULL DEFAULT '{}',
  sections JSONB NOT NULL DEFAULT '{}'::jsonb,
  narrative_md TEXT,
  status TEXT NOT NULL DEFAULT 'complete',
  model TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX pe_snapshots_user_recent_idx ON public.pe_snapshots(user_id, created_at DESC);
CREATE INDEX pe_snapshots_session_idx ON public.pe_snapshots(session_id);
ALTER TABLE public.pe_snapshots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_snapshots_select_own" ON public.pe_snapshots FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_snapshots_insert_own" ON public.pe_snapshots FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_snapshots_update_own" ON public.pe_snapshots FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "pe_snapshots_delete_own" ON public.pe_snapshots FOR DELETE USING (auth.uid() = user_id);

-- 4) frequency rollup
CREATE TABLE public.pe_pattern_frequency (
  user_id UUID NOT NULL,
  tag_key TEXT NOT NULL,
  window_start DATE NOT NULL,
  window_end DATE NOT NULL,
  count INT NOT NULL DEFAULT 0,
  weighted_score NUMERIC NOT NULL DEFAULT 0,
  trend TEXT NOT NULL DEFAULT 'new',
  PRIMARY KEY (user_id, tag_key, window_start)
);
ALTER TABLE public.pe_pattern_frequency ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_freq_select_own" ON public.pe_pattern_frequency FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_freq_insert_own" ON public.pe_pattern_frequency FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_freq_update_own" ON public.pe_pattern_frequency FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "pe_freq_delete_own" ON public.pe_pattern_frequency FOR DELETE USING (auth.uid() = user_id);

-- 5) living psychological profile, one row per user
CREATE TABLE public.pe_psych_profile (
  user_id UUID PRIMARY KEY,
  self_perception JSONB NOT NULL DEFAULT '{}'::jsonb,
  recurring_loops JSONB NOT NULL DEFAULT '[]'::jsonb,
  recurring_conflicts JSONB NOT NULL DEFAULT '[]'::jsonb,
  recurring_roles JSONB NOT NULL DEFAULT '[]'::jsonb,
  unmet_needs JSONB NOT NULL DEFAULT '[]'::jsonb,
  strengths JSONB NOT NULL DEFAULT '[]'::jsonb,
  vulnerabilities JSONB NOT NULL DEFAULT '[]'::jsonb,
  blind_spots JSONB NOT NULL DEFAULT '[]'::jsonb,
  what_ai_notices JSONB NOT NULL DEFAULT '[]'::jsonb,
  profile_version INT NOT NULL DEFAULT 1,
  last_updated TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pe_psych_profile ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pe_profile_select_own" ON public.pe_psych_profile FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pe_profile_insert_own" ON public.pe_psych_profile FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pe_profile_update_own" ON public.pe_psych_profile FOR UPDATE USING (auth.uid() = user_id);

-- 6) extend reflection_answers with analysis tracking
ALTER TABLE public.reflection_answers
  ADD COLUMN IF NOT EXISTS pe_analyzed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS pe_analysis_version INT DEFAULT 1;