
-- Catalog of named pattern identities
CREATE TABLE public.pattern_identities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  short_description TEXT NOT NULL,
  long_description TEXT NOT NULL DEFAULT '',
  emotional_signature TEXT NOT NULL DEFAULT '',
  communication_tendency TEXT NOT NULL DEFAULT '',
  growth_edge TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.pattern_identities ENABLE ROW LEVEL SECURITY;

CREATE POLICY pi_select_public ON public.pattern_identities FOR SELECT USING (true);

-- Tag reflection sessions with one identity
ALTER TABLE public.reflection_sessions
  ADD COLUMN pattern_identity_id UUID REFERENCES public.pattern_identities(id) ON DELETE SET NULL;

CREATE INDEX idx_rs_pattern_identity ON public.reflection_sessions(pattern_identity_id);

-- Stats function for social-proof badges
CREATE OR REPLACE FUNCTION public.get_pattern_identity_stats(_identity_id UUID)
RETURNS TABLE(identity_count BIGINT, total_count BIGINT)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT
    (SELECT COUNT(*) FROM public.reflection_sessions
       WHERE pattern_identity_id = _identity_id
         AND deleted_at IS NULL
         AND status = 'complete') AS identity_count,
    (SELECT COUNT(*) FROM public.reflection_sessions
       WHERE pattern_identity_id IS NOT NULL
         AND deleted_at IS NULL
         AND status = 'complete') AS total_count;
$$;
