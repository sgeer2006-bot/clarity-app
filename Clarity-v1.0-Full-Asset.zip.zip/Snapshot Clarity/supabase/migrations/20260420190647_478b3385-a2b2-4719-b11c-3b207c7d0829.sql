-- Folders table
CREATE TABLE IF NOT EXISTS public.folders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS folders_user_id_idx ON public.folders(user_id);
-- Case-insensitive unique folder name per user
CREATE UNIQUE INDEX IF NOT EXISTS folders_user_name_unique
  ON public.folders(user_id, lower(name));

ALTER TABLE public.folders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS folders_select_own ON public.folders;
DROP POLICY IF EXISTS folders_insert_own ON public.folders;
DROP POLICY IF EXISTS folders_update_own ON public.folders;
DROP POLICY IF EXISTS folders_delete_own ON public.folders;

CREATE POLICY folders_select_own ON public.folders
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY folders_insert_own ON public.folders
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY folders_update_own ON public.folders
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY folders_delete_own ON public.folders
  FOR DELETE USING (auth.uid() = user_id);

-- Add folder_id to reflection_sessions (nullable = Uncategorized).
-- Use ON DELETE SET NULL so deleting a folder leaves snapshots intact.
ALTER TABLE public.reflection_sessions
  ADD COLUMN IF NOT EXISTS folder_id uuid REFERENCES public.folders(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS reflection_sessions_folder_id_idx
  ON public.reflection_sessions(folder_id);