ALTER TABLE public.snapshot_versions
  ADD COLUMN IF NOT EXISTS recommended_next_steps jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS common_misunderstandings jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS how_to_communicate jsonb NOT NULL DEFAULT '[]'::jsonb;