-- Storage bucket for shared snapshot PNG exports (publicly readable for OG images)
INSERT INTO storage.buckets (id, name, public)
VALUES ('snapshot-shares', 'snapshot-shares', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: anyone can read; authenticated users can upload to their own folder
CREATE POLICY "Snapshot share images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'snapshot-shares');

CREATE POLICY "Users can upload their own snapshot share images"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'snapshot-shares'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can update their own snapshot share images"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'snapshot-shares'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own snapshot share images"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'snapshot-shares'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Shared snapshots: each row is a public, link-shareable card derived from a session
CREATE TABLE public.shared_snapshots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  session_id UUID NOT NULL REFERENCES public.reflection_sessions(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE,
  variant TEXT NOT NULL DEFAULT 'square' CHECK (variant IN ('square', 'vertical')),
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  observations JSONB NOT NULL DEFAULT '[]'::jsonb,
  possible_paths JSONB NOT NULL DEFAULT '[]'::jsonb,
  image_path TEXT,
  view_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_shared_snapshots_user ON public.shared_snapshots(user_id, created_at DESC);
CREATE INDEX idx_shared_snapshots_session ON public.shared_snapshots(session_id);
CREATE INDEX idx_shared_snapshots_token ON public.shared_snapshots(token);

ALTER TABLE public.shared_snapshots ENABLE ROW LEVEL SECURITY;

-- Owner can manage their shares
CREATE POLICY "ss_select_own"
ON public.shared_snapshots FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "ss_insert_own"
ON public.shared_snapshots FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "ss_update_own"
ON public.shared_snapshots FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "ss_delete_own"
ON public.shared_snapshots FOR DELETE
USING (auth.uid() = user_id);

-- Public read by token (anyone with the link can view)
CREATE POLICY "ss_select_public_by_token"
ON public.shared_snapshots FOR SELECT
USING (token IS NOT NULL);