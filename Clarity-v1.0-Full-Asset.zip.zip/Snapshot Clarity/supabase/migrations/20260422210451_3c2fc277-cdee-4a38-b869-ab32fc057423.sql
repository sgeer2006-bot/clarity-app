-- 1. Add engine_version to reflection_sessions for the v2 feature flag pin
ALTER TABLE public.reflection_sessions
  ADD COLUMN IF NOT EXISTS engine_version text NOT NULL DEFAULT 'v1';

-- 2. Extend reflection_answers with v2 metadata
ALTER TABLE public.reflection_answers
  ADD COLUMN IF NOT EXISTS targeted_fields text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS depth integer NOT NULL DEFAULT 1;

-- 3. session_context_models: one ContextModel per session
CREATE TABLE IF NOT EXISTS public.session_context_models (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL UNIQUE,
  situation text NOT NULL DEFAULT '',
  emotions jsonb NOT NULL DEFAULT '[]'::jsonb,
  intentions jsonb NOT NULL DEFAULT '[]'::jsonb,
  triggers jsonb NOT NULL DEFAULT '[]'::jsonb,
  expectations jsonb NOT NULL DEFAULT '[]'::jsonb,
  fears jsonb NOT NULL DEFAULT '[]'::jsonb,
  desired_outcome text NOT NULL DEFAULT '',
  relationships jsonb NOT NULL DEFAULT '[]'::jsonb,
  history jsonb NOT NULL DEFAULT '[]'::jsonb,
  unspoken_needs jsonb NOT NULL DEFAULT '[]'::jsonb,
  coverage_map jsonb NOT NULL DEFAULT '{}'::jsonb,
  saturation_score integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.session_context_models ENABLE ROW LEVEL SECURITY;

CREATE POLICY scm_select_own ON public.session_context_models
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = session_context_models.session_id
              AND s.user_id = auth.uid())
  );

CREATE POLICY scm_insert_own ON public.session_context_models
  FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = session_context_models.session_id
              AND s.user_id = auth.uid())
  );

CREATE POLICY scm_update_own ON public.session_context_models
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = session_context_models.session_id
              AND s.user_id = auth.uid())
  );

CREATE POLICY scm_delete_own ON public.session_context_models
  FOR DELETE USING (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = session_context_models.session_id
              AND s.user_id = auth.uid())
  );

CREATE TRIGGER scm_touch_updated_at
  BEFORE UPDATE ON public.session_context_models
  FOR EACH ROW EXECUTE FUNCTION public.touch_two_person_perspective_updated_at();

-- 4. question_history: every question emitted for a session
CREATE TABLE IF NOT EXISTS public.question_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL,
  question_index integer NOT NULL,
  question_text text NOT NULL,
  target_fields text[] NOT NULL DEFAULT '{}',
  depth integer NOT NULL DEFAULT 1,
  rationale text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS question_history_session_idx
  ON public.question_history(session_id, question_index);

ALTER TABLE public.question_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY qh_select_own ON public.question_history
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = question_history.session_id
              AND s.user_id = auth.uid())
  );

CREATE POLICY qh_insert_own ON public.question_history
  FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = question_history.session_id
              AND s.user_id = auth.uid())
  );

CREATE POLICY qh_delete_own ON public.question_history
  FOR DELETE USING (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = question_history.session_id
              AND s.user_id = auth.uid())
  );

-- 5. misunderstanding_repairs: log of repair flow events
CREATE TABLE IF NOT EXISTS public.misunderstanding_repairs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL,
  question_index integer NOT NULL,
  question_text text NOT NULL,
  hypothesis text NOT NULL DEFAULT '',
  interpretations jsonb NOT NULL DEFAULT '[]'::jsonb,
  clarification text NOT NULL DEFAULT '',
  context_patch jsonb NOT NULL DEFAULT '{}'::jsonb,
  resolved boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS misunderstanding_repairs_session_idx
  ON public.misunderstanding_repairs(session_id, created_at DESC);

ALTER TABLE public.misunderstanding_repairs ENABLE ROW LEVEL SECURITY;

CREATE POLICY mr_select_own ON public.misunderstanding_repairs
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = misunderstanding_repairs.session_id
              AND s.user_id = auth.uid())
  );

CREATE POLICY mr_insert_own ON public.misunderstanding_repairs
  FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = misunderstanding_repairs.session_id
              AND s.user_id = auth.uid())
  );

CREATE POLICY mr_update_own ON public.misunderstanding_repairs
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.reflection_sessions s
            WHERE s.id = misunderstanding_repairs.session_id
              AND s.user_id = auth.uid())
  );