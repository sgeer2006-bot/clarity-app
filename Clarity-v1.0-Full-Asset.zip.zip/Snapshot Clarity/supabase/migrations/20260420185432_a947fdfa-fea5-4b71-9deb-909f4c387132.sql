-- Add per-question metadata to reflection_answers to support yes/no questions,
-- per-question minimum character counts, and dynamic context-sufficiency scoring.

ALTER TABLE public.reflection_answers
  ADD COLUMN IF NOT EXISTS question_type text NOT NULL DEFAULT 'open',
  ADD COLUMN IF NOT EXISTS min_chars integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS sufficiency_score integer;

-- Constrain to known types: open | yesno
ALTER TABLE public.reflection_answers
  DROP CONSTRAINT IF EXISTS reflection_answers_question_type_check;
ALTER TABLE public.reflection_answers
  ADD CONSTRAINT reflection_answers_question_type_check
  CHECK (question_type IN ('open', 'yesno'));