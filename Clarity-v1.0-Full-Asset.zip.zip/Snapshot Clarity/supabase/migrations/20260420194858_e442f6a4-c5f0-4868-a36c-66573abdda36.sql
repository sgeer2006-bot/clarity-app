-- Privacy hardening for safety_events:
-- The triggering user text must NOT be stored. We drop the source_text column
-- entirely so it cannot be persisted, even accidentally. matched_terms still
-- captures the (already-known) phrase so analytics work without storing the
-- user's surrounding sentence.
ALTER TABLE public.safety_events DROP COLUMN IF EXISTS source_text;