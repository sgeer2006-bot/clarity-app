-- Catalog of communication patterns. Public read; only service role can write.
CREATE TABLE public.patterns (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  short_description TEXT NOT NULL,
  emotional_meaning TEXT NOT NULL,
  other_person_tip TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.patterns ENABLE ROW LEVEL SECURITY;

-- Anyone can read the catalog
CREATE POLICY "patterns_select_public"
ON public.patterns FOR SELECT
USING (true);

-- Per-session pattern matches
CREATE TABLE public.session_patterns (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id UUID NOT NULL REFERENCES public.reflection_sessions(id) ON DELETE CASCADE,
  pattern_id UUID NOT NULL REFERENCES public.patterns(id) ON DELETE CASCADE,
  confidence INTEGER NOT NULL DEFAULT 50 CHECK (confidence BETWEEN 0 AND 100),
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (session_id, pattern_id)
);

CREATE INDEX idx_session_patterns_session ON public.session_patterns(session_id);
CREATE INDEX idx_session_patterns_pattern ON public.session_patterns(pattern_id, created_at DESC);

ALTER TABLE public.session_patterns ENABLE ROW LEVEL SECURITY;

-- Only the session owner can read/manage their pattern links
CREATE POLICY "sp_select_own"
ON public.session_patterns FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.reflection_sessions s
    WHERE s.id = session_patterns.session_id AND s.user_id = auth.uid()
  )
);

CREATE POLICY "sp_insert_own"
ON public.session_patterns FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.reflection_sessions s
    WHERE s.id = session_patterns.session_id AND s.user_id = auth.uid()
  )
);

CREATE POLICY "sp_delete_own"
ON public.session_patterns FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM public.reflection_sessions s
    WHERE s.id = session_patterns.session_id AND s.user_id = auth.uid()
  )
);

-- Aggregate stats function: returns counts only, no row contents.
-- SECURITY DEFINER so anonymous users can call it for the public pattern page.
CREATE OR REPLACE FUNCTION public.get_pattern_stats(_pattern_id UUID, _days INTEGER DEFAULT 30)
RETURNS TABLE (
  pattern_count BIGINT,
  total_count BIGINT
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    (SELECT COUNT(*) FROM public.session_patterns sp
       WHERE sp.pattern_id = _pattern_id
         AND sp.created_at >= now() - make_interval(days => _days)) AS pattern_count,
    (SELECT COUNT(*) FROM public.session_patterns
       WHERE created_at >= now() - make_interval(days => _days)) AS total_count;
$$;

GRANT EXECUTE ON FUNCTION public.get_pattern_stats(UUID, INTEGER) TO anon, authenticated;

-- Seed starter patterns
INSERT INTO public.patterns (slug, name, short_description, emotional_meaning, other_person_tip) VALUES
  ('silent-standoff',
   'The Silent Standoff',
   'Both sides go quiet, each waiting for the other to make the first move.',
   'Often a sign that someone feels hurt or unheard, and is protecting themselves by withdrawing rather than escalating.',
   'A small, low-stakes opening — like a check-in question — can break the loop without requiring either side to "lose".'),
  ('mismatched-expectations',
   'Mismatched Expectations',
   'Two people expected different things and discovered it after the fact.',
   'There is usually no bad actor here — just two valid mental models that never got compared out loud.',
   'Naming the assumption you each had makes it easier to talk about the gap rather than blame the result.'),
  ('emotional-flooding',
   'Emotional Flooding',
   'One or both sides feel overwhelmed and stop being able to think clearly.',
   'Underneath the intensity is usually a need that feels unmet — safety, respect, being heard.',
   'Pausing before responding gives both nervous systems room to settle. The conversation rarely moves while flooded.'),
  ('intent-vs-impact',
   'Intent vs. Impact',
   'Someone meant one thing and the other person experienced something different.',
   'Both feelings can be real at the same time. The gap itself is the thing to talk about.',
   'Acknowledging the impact does not require admitting the intent was bad. They are separate truths.'),
  ('script-mismatch',
   'Script Mismatch',
   'Each person is using a different rulebook for what the conversation should look like.',
   'Familiar scripts feel like "the obvious way" — until they collide with someone else''s obvious way.',
   'Asking "what would feel right to you here?" surfaces the script without making it a fight.'),
  ('repair-avoided',
   'Repair Avoided',
   'A small rupture happened, and no one circled back to mend it.',
   'Avoidance is often less about the original moment and more about not knowing how to start the repair.',
   'A short, specific acknowledgement ("the way I said that landed badly") often unlocks more than a long explanation.'),
  ('boundary-blurred',
   'Boundary Blurred',
   'A line that mattered to one person was crossed without it being clear it was a line.',
   'The hurt is rarely just about the action — it''s about the line itself feeling invisible.',
   'Naming the line as a line, not as a complaint, makes it easier to honor next time.'),
  ('ask-vs-tell',
   'Ask vs. Tell',
   'One person prefers being told directly; the other prefers being asked.',
   'Neither style is wrong, but they can feel inconsiderate to each other when they collide.',
   'Calling out the preference itself ("I do better with a heads-up") removes the guesswork.');