# Phase 2 — Cleanup Checklist (deferred)

- Move legacy components out of `CalmPrimitives.tsx` into `src/components/calm/legacy.tsx` (deferred)
- Remove unused imports and files flagged during Phase 2 (none discovered in Commit K audit of `OnboardingPage.tsx`)
- Run visual QA across Insights and Analytics pages
- Add unit tests for Calm primitives exports (deferred)
- Schedule a small follow-up commit to consolidate calm exports (deferred)
