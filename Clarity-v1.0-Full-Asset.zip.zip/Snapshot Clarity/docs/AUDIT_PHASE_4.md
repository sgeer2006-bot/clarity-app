# Clarity — Phase 4 Global Content & Structure Audit

## 1. Scope and ground rules

This document is **audit-only**. No source code, route, page, component,
engine, layer, configuration, schema, or asset has been modified to produce
it. No identifiers, files, or folders have been renamed or moved. No
features were added or removed. No wording was rewritten anywhere outside
this report.

The approved naming system is the reference for label observations:
**Today, Questions, Moments, Insights, You** (primary nav);
**Calm, Quick Prompts, Folders, History** (Tools tab);
**Your Story, Trends, Timeline, Streaks, Share**;
**Clarity+, Welcome, Credits**;
**Who You Are, Your Emotions, Your Situations**.
Tone reference: grounded, warm, reflective, premium, non-clinical,
non-prescriptive, concise, modern.

The following modules are **off-limits** for any recommendation in this
report (they may be referenced as context only):
Module #1 (heat map removal), Module #2 (back button + nav labels),
Modules #3/#4 (Tools tab contents), Module #5 (templates + transition
wrapper), Module #6 (capability detection), Module #7 (fallback wrapper),
Module #8 (stop-digging wrapper), Module #9 (psychological profile engine),
Module #10 (`ProfileInsightsEngine.ts`), Module #11
(`ProfileAwareFraming.ts`), Module #12 (`ClarityPlusGating.ts`),
Module #13 (Premium Insights Page), Module #14 (`SubscriptionEngine.ts`),
Module #15 (polish results), Module #16 (Home/Menu wording).

The deliverable is this single Markdown file.

---

## 2. Complete list of all pages and routes

Source: `src/App.tsx`. Root tabs per `src/components/nav/BottomNav.tsx`
(global pass: `Today /home`, `Questions /thoughts`, `Moments /patterns`,
`Insights /tools`, `You /you`). Back button rule per
`src/components/nav/BackButton.tsx`: hidden on `/`, `/home`, `/thoughts`,
`/patterns`, `/tools`, `/you`; visible everywhere else.

| Route | Component file | Root tab? | Back button? | Reachable from |
|---|---|---|---|---|
| `/` | redirect → `/home` | n/a | n/a | direct |
| `/home` | `src/pages/Home.tsx` | yes (Today) | no | BottomNav, TopBar logo |
| `/thoughts` | `src/pages/NewSession.tsx` (alias) | yes (Questions) | no | BottomNav |
| `/reflect` | `src/pages/NewSession.tsx` (alias) | no | yes | TopBar Menu, Home CTA |
| `/new` | `src/pages/NewSession.tsx` | no | yes | direct |
| `/new/:sessionId/:step` | `src/pages/QuestionFlow.tsx` | no | yes | flow |
| `/loading/:sessionId` | `src/pages/Loading.tsx` | no | yes | flow |
| `/snapshot/:snapshotId` | `src/pages/SnapshotPage.tsx` | no | yes | History, flow |
| `/follow-up/:sessionId` | `src/pages/FollowUpFlow.tsx` | no | yes | flow |
| `/correct/:sessionId` | `src/pages/CorrectionFlow.tsx` | no | yes | flow |
| `/patterns` | `src/pages/insights/PremiumInsightsPage.tsx` (alias) | yes (Moments) | no | BottomNav |
| `/insights` | `src/pages/insights/PremiumInsightsPage.tsx` | no | yes | TopBar Menu, Home CTA |
| `/insights/flow` | `src/pages/insights/Insights.flow.tsx` | no | yes | TopBar Menu (deep links), legacy redirects |
| `/patterns/dashboard` | redirect → `/#patterns` | n/a | n/a | legacy |
| `/patterns/timeline` | redirect → `/#story` | n/a | n/a | legacy |
| `/patterns/heatmap` | redirect → `/#patterns` | n/a | n/a | legacy |
| `/patterns/clusters` | redirect → `/#patterns` | n/a | n/a | legacy |
| `/patterns/profile` | redirect → `/#story` | n/a | n/a | legacy |
| `/dashboard` | `src/pages/Analytics.tsx` | no | yes | TopBar Menu (Trends) |
| `/history` | `src/pages/History.tsx` | no | yes | Tools tab, TopBar Menu |
| `/share/:token` | `src/pages/SharePage.tsx` | no | yes | external link |
| `/s/:token` | `src/pages/SharedSnapshotPage.tsx` | no | yes | external link |
| `/p/:slug` | `src/pages/PatternPage.tsx` | no | yes | deep link |
| `/pattern/answer/:answerId` | `src/pages/PatternSnapshotPage.tsx` | no | yes | deep link |
| `/two-person` | `src/pages/TwoPersonHub.tsx` | no | yes | TopBar Menu, Tools tab (hidden) |
| `/two-person/:sessionId` | `src/pages/TwoPersonSession.tsx` | no | yes | flow |
| `/two-person/invite/:token` | `src/pages/TwoPersonInvite.tsx` | no | yes | external link |
| `/two-person-room` | `src/pages/TwoPersonRoomPage.tsx` | no | yes | direct |
| `/safety/resources` | `src/pages/SafetyResourcesPage.tsx` | no | yes | TopBar Menu (Calm), Tools tab |
| `/tools` | `src/pages/ToolsPage.tsx` | yes (Insights label) | no | BottomNav |
| `/fast-clarity` | `src/pages/FastClarity.tsx` | no | yes | TopBar Menu, Home CTA, Tools tab (hidden) |
| `/folders` | `src/pages/FoldersPage.tsx` | no | yes | Tools tab |
| `/folders/:id` | `src/pages/FolderDetailPage.tsx` | no | yes | Folders |
| `/compose` | `src/pages/ComposerPage.tsx` | no | yes | Tools tab (hidden) |
| `/you` | `src/pages/SettingsIndexPage.tsx` (alias) | yes (You) | no | BottomNav |
| `/settings` | `src/pages/SettingsIndexPage.tsx` | no | yes | TopBar Menu |
| `/settings/visual` | `src/pages/SettingsVisualPage.tsx` | no | yes | TopBar Menu, /settings |
| `/settings/billing` | `src/pages/SettingsBillingPage.tsx` | no | yes | TopBar Menu, /settings |
| `/onboarding` | `src/pages/OnboardingPage.tsx` | no | yes | OnboardingGate |
| `/onboarding/light` | `src/pages/onboarding/OnboardingLight.tsx` | no | yes | onboarding |
| `/onboarding/deep` | `src/pages/onboarding/OnboardingDeep.tsx` | no | yes | onboarding |
| `/onboarding/deep/intro` | `src/pages/onboarding/OnboardingDeepIntro.tsx` | no | yes | onboarding |
| `/auth` | `src/pages/Auth.tsx` | no | yes | TopBar Login/Create |
| `/clarity-plus` | `src/premium/clarityPlus/ClarityPlusPage.tsx` | no | yes | TopBar Menu, Insights upsell |
| `/clarity-plus/pricing` | `src/premium/clarityPlus/PricingPage.tsx` | no | yes | TopBar Menu, /clarity-plus |
| `/clarity-plus/success` | `src/pages/clarityPlus/ClarityPlusSuccess.tsx` | no | yes | checkout return |
| `/clarity-plus/cancel` | `src/pages/clarityPlus/ClarityPlusCancel.tsx` | no | yes | checkout return |
| `/premium` | redirect → `/clarity-plus` | n/a | n/a | legacy |
| `/demo/premium` | redirect → `/clarity-plus` | n/a | n/a | legacy |
| `/analytics/premium` | redirect → `/dashboard` | n/a | n/a | legacy |
| `/dev/features` | redirect → `/settings` | n/a | n/a | legacy |
| `/about` | `src/pages/AboutPage.tsx` | no | yes | TopBar Menu, footer-style links |
| `/help` | `src/pages/HelpPage.tsx` | no | yes | TopBar Menu |
| `*` | `src/pages/NotFound.tsx` | no | yes | fallthrough |

Files **on disk but unrouted**: `src/pages/InsightsPage.tsx` (legacy
Insights surface — superseded by `pages/insights/PremiumInsightsPage.tsx`);
`src/pages/Index.tsx` (intentionally retained per Phase 1, Commit 7 note).

---

## 3. Sections per page (render order, with component references)

**`/home` — `src/pages/Home.tsx`**
1. `TopBar` (header, Menu trigger)
2. `CreditMeterBanner` (`@/premium/TierGate`)
3. Section A "Today" — heading + `IdentityChips` + continuation step (`getNextStep`)
4. Section B "What keeps quietly coming up" — `PatternTile` x3 from `useFrequency`
5. Section C "Your story, right now" — `useIdentity().narrative_md`
6. Section D — three CTA buttons: Reflect / Insights / Fast Clarity
7. `BottomNav` (global)

**`/thoughts` and `/reflect` and `/new` — `src/pages/NewSession.tsx`**
- Reflection entry surface (Reflection Engine, off-limits to modify).

**`/patterns` and `/insights` — `src/pages/insights/PremiumInsightsPage.tsx`** (Module #13, off-limits)
1. Optional framing line (`getProfileAwareFraming`)
2. `TopInsightCard`
3. `IdentityInsightsSection`
4. `SituationInsightsSection`
5. `TrendInsightsSection`
6. `UpgradePromptCard`

**`/insights/flow` — `src/pages/insights/Insights.flow.tsx`**
1. `MindTodaySection`
2. `PatternsSection`
3. `StorySection`
4. `ToolsSection`
5. `PremiumPreviewSection`

**`/tools` — `src/pages/ToolsPage.tsx`** (Modules #3/#4, off-limits)
- Header "Helpful things, when you need them."
- Visible cards: `Folders`, `Your history`, `Grounding & support`, `Quick Prompts`.
- Hidden cards (`hidden: true` filtered out): `Fast Clarity`, `Shared Clarity`, `Compose a message`.

**`/dashboard` — `src/pages/Analytics.tsx`**
- `StatCard`s, `ActivityChart`, `PatternBreakdown`, `SnapshotsGallery`, `WeeklySummaryCard`.

**`/history` — `src/pages/History.tsx`** — `HistoryList` and snapshot list.

**`/folders` — `src/pages/FoldersPage.tsx`** — folder index using `useFolders`.
**`/folders/:id` — `src/pages/FolderDetailPage.tsx`** — folder detail.
**`/compose` — `src/pages/ComposerPage.tsx`** — message composer.

**`/safety/resources` — `src/pages/SafetyResourcesPage.tsx`** — `SafetyCard`, `LocalResourcesCard`.
**`/fast-clarity` — `src/pages/FastClarity.tsx`** — fast-path reflection.

**`/two-person` — `src/pages/TwoPersonHub.tsx`** — Shared Clarity hub.
**`/two-person-room` — `src/pages/TwoPersonRoomPage.tsx`** — alternate room entry.

**`/you` and `/settings` — `src/pages/SettingsIndexPage.tsx`**
- Account, Appearance, Billing entries; sign-out; Clarity+ link.

**`/settings/visual` — `src/pages/SettingsVisualPage.tsx`**
- `TopBar`; `PageHeader` "Visual atmosphere"; Switch (motion); Slider (intensity); `PremiumCalmLayer` toggle.

**`/settings/billing` — `src/pages/SettingsBillingPage.tsx`** — subscription state, portal link.

**`/clarity-plus` — `ClarityPlusPage.tsx`** — `ClarityPlusUpsell`, paywall trigger.
**`/clarity-plus/pricing` — `PricingPage.tsx`** — pricing tiers (Module #14 metadata is the source of truth, but this page predates the wiring).

**`/about` — `src/pages/AboutPage.tsx`** — sections at anchors `#how`, `#privacy`.
**`/help` — `src/pages/HelpPage.tsx`** — FAQ.

**TopBar Menu (`src/components/TopBar.tsx`)** sections, in render order:
Today → Questions (Questions, Fast Clarity) → Insights (Your Insights, Your Patterns, Your Story, Trends) → Helpful Tools (Fast Clarity, Quick Prompts, Calm) → Shared Clarity (Shared Clarity, Share Your Clarity) → Clarity+ (What you unlock, Plans & pricing) → Settings (Account, Appearance, Billing) → About & Help (About Clarity, How it works, Your privacy, FAQ & Help) → Sign out.

**BottomNav** (`src/components/nav/BottomNav.tsx`): Today, Questions, Moments, Insights, You. Note: the `Insights` label points at `/tools`; the `Moments` label points at `/patterns`.

---

## 4. Complete list of all features (cross-referenced)

| Feature | Surfaces |
|---|---|
| Reflection / Questions entry | `/thoughts`, `/reflect`, `/new`, TopBar Menu "Questions", Home CTA "Start a reflection" |
| Fast Clarity | `/fast-clarity`, TopBar Menu (Questions section + Helpful Tools section), Home CTA "Get grounded fast", Tools page (hidden card) |
| Quick Prompts | TopBar Menu "Helpful Tools", Tools page card, both routing to `/reflect` |
| Insights (Module #13) | `/insights`, `/patterns` (alias), TopBar Menu "Your Insights", Home CTA "See your Insights" |
| Insights (legacy flow) | `/insights/flow`, TopBar Menu "Your Patterns" (`#patterns`), "Your Story" (`#story`) |
| Patterns / Moments | `/patterns` (alias of Module #13), legacy redirect routes `/patterns/*` |
| Trends | `/dashboard`, TopBar Menu "Trends" |
| History | `/history`, TopBar Menu "Share Your Clarity" (under Shared Clarity), Tools page card |
| Folders | `/folders`, Tools page card |
| Calm / Grounding | `/safety/resources`, TopBar Menu "Calm" (Helpful Tools section), Tools page card "Grounding & support" |
| Shared Clarity | `/two-person`, TopBar Menu "Shared Clarity" section, Tools page (hidden card) |
| Compose | `/compose`, Tools page (hidden card) |
| Clarity+ paywall / pricing | `/clarity-plus`, `/clarity-plus/pricing`, TopBar Menu "Clarity+" section, Insights upsell, Settings/Billing |
| Credits | `CreditMeterBanner` on Home; gated insights in Module #13 |
| Settings — Account / Appearance / Billing | `/settings`, `/settings/visual`, `/settings/billing`, TopBar Menu "Settings" section, BottomNav "You" |
| About / Help | `/about`, `/help`, TopBar Menu "About & Help" section |

---

## 5. Duplicates list (Module 4)

| Concept | Locations | Observation |
|---|---|---|
| Fast Clarity | TopBar Menu "Questions" section; TopBar Menu "Helpful Tools" section; Home Section D CTA; `ToolsPage` (hidden); standalone route `/fast-clarity` | Listed twice in the same Menu surface. |
| Quick Prompts | TopBar Menu "Helpful Tools"; `ToolsPage` card | Both targets resolve to `/reflect`, the same surface as "Questions". |
| Reflect surface | `/thoughts`, `/reflect`, `/new` all render `NewSession` | Three URLs, one component. |
| Insights surface | `/insights`, `/patterns` both render Module #13's `PremiumInsightsPage` | Single surface exposed under two primary URLs. |
| Calm | TopBar Menu "Helpful Tools" → "Calm"; `ToolsPage` card "Grounding & support"; route `/safety/resources` | Same destination, two visible labels. |
| History | TopBar Menu "Shared Clarity" → "Share Your Clarity" (`/history`); `ToolsPage` card "Your history"; standalone route | The label "Share Your Clarity" routes to History, conflating sharing and history. |
| Helpful Tools concept | TopBar Menu section "Helpful Tools"; `ToolsPage` heading "Helpful things, when you need them." | Two parallel groupings of the same idea. |
| Patterns | TopBar Menu "Your Patterns" → `/insights/flow#patterns`; BottomNav "Moments" → `/patterns` (Module #13 alias); Home Section B "What keeps quietly coming up" | Three surfaces, three different framings. |
| Story | TopBar Menu "Your Story" → `/insights/flow#story`; Home Section C "Your story, right now"; `StorySection` inside `/insights/flow` | Parallel narrative readouts. |
| Pricing | `/clarity-plus/pricing` (`PricingPage.tsx`); `src/premium/Pricing.tsx` (3-tier component) | Two pricing renderers in the codebase. |
| Two-Person | `/two-person` (Hub); `/two-person-room` (Room page); `/two-person/:sessionId` (Session) | Two non-flow entry points. |
| Settings index | `/you` (alias) and `/settings` both render `SettingsIndexPage` | Single page, two URLs. |
| Insights legacy file | `src/pages/InsightsPage.tsx` and `src/pages/insights/PremiumInsightsPage.tsx` | Two Insights page files exist; only the latter is routed. |

---

## 6. Obsolete / prototype pages list (Module 5)

| Page / file | Reason |
|---|---|
| `src/pages/InsightsPage.tsx` | Predates Module #13; not routed by `App.tsx`; superseded by `PremiumInsightsPage`. |
| `src/premium/Pricing.tsx` | Standalone 3-tier pricing component predating Module #14 locked-in pricing; coexists with `PricingPage`. |
| `src/pages/insights/Insights.flow.tsx` | Phase 1 unified flow page; partly superseded by Module #13 at `/insights` and `/patterns` while still routed at `/insights/flow` and linked from Menu. |
| `src/pages/insights/sections/PremiumPreviewSection.tsx` | Premium preview block predating the Module #13 `UpgradePromptCard`. |
| `src/pages/insights/sections/PatternsSection.tsx` | Patterns view preserved for the unified-flow page; effectively a legacy reading surface alongside Module #13. |
| `src/pages/Index.tsx` | Explicitly retained-but-not-routed per Phase 1, Commit 7. |
| Hidden Tools cards (`Fast Clarity`, `Shared Clarity`, `Compose a message`) in `ToolsPage.tsx` | Cards declared but render-suppressed (`hidden: true` → `false && item`); prototype leftovers per Module #3/#4 cleanup. |
| `src/pages/SettingsVisualPage.tsx` "Visual atmosphere" sliders | Source notes in code reference the Phase 7 keep-decision; the surface still exposes raw sliders that appear prototype-grade relative to current tone. |
| Legacy `/patterns/*` redirects (`dashboard`, `timeline`, `heatmap`, `clusters`, `profile`) | Five redirect routes preserved for backward compatibility; no longer reachable from current UI. |
| Legacy `/premium`, `/demo/premium`, `/analytics/premium`, `/dev/features` redirects | Backward-compatibility redirects to current canonical routes. |
| `src/pages/TwoPersonRoomPage.tsx` | Unreferenced from primary nav; alternate Two-Person room surface. |

---

## 7. Misplaced features list (Module 6)

| Feature | Current location | Suggested logical home (per approved naming) |
|---|---|---|
| Calm | TopBar Menu "Helpful Tools"; `ToolsPage` (with label "Grounding & support") | The Tools tab (Calm) — already a Tools-tab item per approved naming. |
| Quick Prompts | TopBar Menu "Helpful Tools"; routes to `/reflect` | Questions tab (Quick Prompts is a Questions surface, not a Helpful-Tools surface). |
| Fast Clarity | Listed under both Questions and Helpful Tools in Menu; also a Home CTA | Questions tab. |
| Shared Clarity | TopBar Menu "Shared Clarity" section; hidden card on `ToolsPage` | A dedicated surface or under Questions/Insights — not under Tools. |
| Your Story | TopBar Menu "Insights" → "Your Story" routes to `/insights/flow#story` | Moments tab or Insights tab in line with approved Your Story / Timeline grouping. |
| Your Patterns | Menu link → `/insights/flow#patterns` (legacy flow) | Moments tab (Module #13 surface). |
| Trends | TopBar Menu "Insights" section but routes to `/dashboard` (Analytics) | Insights or Moments tab depending on the approved Trends home. |
| History | Surfaced inside "Shared Clarity" section as "Share Your Clarity" | Tools tab (History is a Tools-tab item per approved naming). |
| Helpful Tools (as a Menu section) | TopBar Menu | Redundant with the Tools tab. |
| Compose | Hidden Tools card | Questions or a Messaging surface; not currently in approved naming. |

---

## 8. Missing or weak logic list (Module 7)

| Surface | File | Observation |
|---|---|---|
| `/insights` (Module #13) — profile + recent snapshots wiring | `src/pages/insights/PremiumInsightsPage.tsx` | `profile` and `recentSnapshots` are hard-coded to empty literals (`useMemo(() => ({}), [])` / `useMemo(() => [], [])`). Engines tolerate this and yield empty insights, so all four sections render empty until upstream wiring lands. |
| `/insights/flow` Story section | `src/pages/insights/sections/StorySection.tsx` | Reads `useTimeline` / `useIdentity`; renders empty/placeholder state when timeline and identity narrative are not yet present. |
| Home Section C "Your story, right now" | `src/pages/Home.tsx` line 117 | Falls back to placeholder text "Your story is still gathering shape…" when `narrative_md` is empty — placeholder ships as primary content. |
| Home Section A continuation step | `src/pages/Home.tsx` line 41 | `getNextStep({ lastActionType: "insight_viewed" })` is called with a constant input; not actually personalized to the user's last action. |
| `/insights` framing | Module #13 `getProfileAwareFraming` runs against an empty profile, so framing line is rarely shown. |
| `/insights/flow#patterns` vs `/patterns` | `Insights.flow.tsx` + `PremiumInsightsPage.tsx` | Two distinct logic stacks for what the Menu treats as the same concept. |
| Module #14 (`SubscriptionEngine.ts`) | `src/lib/premium/SubscriptionEngine.ts` | Pure-logic and exported; not currently consumed by `PricingPage`, `ClarityPlusPaywall`, or `SettingsBillingPage` (per Module #14 spec, wiring is a later module). |
| Module #11 (`ProfileAwareFraming`) | `src/lib/insights/ProfileAwareFraming.ts` | Consumed only by `/insights`; not consumed by `Insights.flow`, Home, or Tools. |
| Module #12 gating | `src/lib/premium/ClarityPlusGating.ts` | Consumed only by `/insights`; legacy `InsightsPage.tsx` and `Insights.flow` still rely on `usePremium()` and feature-flag helpers. |
| `/dashboard` (Trends) | `src/pages/Analytics.tsx` | Surface named "Trends" in Menu but page is titled / structured as Analytics. Trend-Engine alignment is partial. |
| `/settings/visual` | `src/pages/SettingsVisualPage.tsx` | Sliders persist on-device only (per code comment); user is not informed that values are not synced. |
| `/help` | `src/pages/HelpPage.tsx` | Static FAQ; no dynamic links to current Module #14 pricing or Module #13 insight behavior. |
| `/about` | `src/pages/AboutPage.tsx` | Static; predates current naming model in places. |
| Hidden `ToolsPage` cards | `src/pages/ToolsPage.tsx` | Items declared in `TOOLS` then unconditionally suppressed via `false && item` — dead branches. |
| Home → Insights CTA | `src/pages/Home.tsx` line 134 | Routes to `/insights` (Module #13) but "What keeps quietly coming up" tiles above are computed from a different source (`useFrequency`), so the two reads can disagree. |

---

## 9. Wording issues list, grouped by page (Module 8)

Categories used: `developer-style label`, `confusing explanation`,
`abstract concept`, `outdated tone`, `inconsistent capitalization`,
`inconsistent naming`, `overly complex description`, `unclear section header`,
`stale tier name`, `stale feature name`.

**`/home` (`src/pages/Home.tsx`)**
- "Where you've been showing up" — `abstract concept`.
- "What keeps quietly coming up" — `abstract concept`.
- "Your story, right now" — `unclear section header`.
- "Your story is still gathering shape. Every reflection adds another quiet line." — `outdated tone`.
- "See your Insights" — `inconsistent capitalization` (mid-sentence "Insights" is a proper-noun choice that reads inconsistently across the app).
- "Get grounded fast" — `inconsistent naming` (this CTA opens Fast Clarity; label does not match the approved feature name).

**TopBar Menu (`src/components/TopBar.tsx`)**
- "Helpful Tools" section — `inconsistent naming` (duplicates the Tools tab idea).
- "Share Your Clarity" routing to `/history` — `confusing explanation` and `inconsistent naming`.
- "What you unlock" / "Plans & pricing" under Clarity+ — `inconsistent naming` vs Module #14 vocabulary.
- "Your Insights" vs "Insights" tab label — `inconsistent capitalization`/`inconsistent naming`.
- "How it works" / "Your privacy" under About & Help — `unclear section header` (in-page anchors not labelled as such).

**`/tools` (`src/pages/ToolsPage.tsx`)**
- Header "Helpful things, when you need them." — `unclear section header` vs approved tab name "Insights".
- Subhead "Open any of these whenever you'd like. Nothing here demands your attention — they wait until you reach for them." — `outdated tone` / `overly complex description`.
- Card label "Grounding & support" for Calm — `inconsistent naming` (approved label is "Calm").
- Card label "Your history" — `inconsistent capitalization`.

**`/insights` (`src/pages/insights/PremiumInsightsPage.tsx`)** — Module #13, off-limits for rewrite. No wording flagged.

**`/insights/flow` and `src/pages/InsightsPage.tsx` (legacy)**
- "What we've been quietly noticing" — `abstract concept`.
- "Patterns we've been noticing" with "Three plain-language lenses…" — `overly complex description`.
- Group descriptions ("What tends to show up inside you, again and again." / "How your language shifts across people and topics.") — `overly complex description`.
- "Things you might gently sit with" / "Soft questions, not instructions." — `outdated tone`.
- "loops", "emotional_loop" used as user-visible groupings — `abstract concept` / `developer-style label`.
- "A longer read on lately" — `unclear section header`.
- Free-tier upsell paragraph "A deeper read of you, when you want it" / "Your deeper clarity starts here." — `outdated tone`.
- "Unlock Clarity+" CTA — `stale feature name` relative to Module #14 upgrade-prompt copy.

**`/dashboard` (`src/pages/Analytics.tsx`)**
- Page is reached as "Trends" from Menu but presents as "Analytics" — `inconsistent naming` / `stale feature name`.
- Component class names visible to the user as headers (e.g. "Pattern Breakdown", "Activity Chart") — `developer-style label`.

**`/history`, `/folders`, `/folders/:id`**
- Section titles read like nouns from the code (e.g. "Your folders", "Folder detail") — `developer-style label` / `unclear section header` (in places).

**`/safety/resources`**
- Page mixes the labels "Calm" (Menu), "Grounding & support" (Tools card), and "Safety resources" (page) — `inconsistent naming`.

**`/clarity-plus` and `/clarity-plus/pricing`**
- "Clarity Free" label in `Pricing.tsx` (line 23) — `stale tier name` (approved short label is "Free").
- "Always yours. No card needed." — `outdated tone`.
- "Weekly clarity credits" — `inconsistent capitalization` (Credits is a proper noun in approved naming).
- Mixed use of "Clarity+" and "Clarity Plus" across `Pricing.tsx`, `PricingPage`, `ClarityPlusPaywall`, and Menu — `inconsistent naming`.

**`/settings`, `/settings/visual`, `/settings/billing`**
- "Visual atmosphere" / "Tune the ambient layer behind your reflections." — `overly complex description`.
- Slider with no numeric explanation labelled "Drift intensity" / "Theme intensity" — `developer-style label`.
- Settings index uses the literal "Account / Appearance / Billing" — adequate, but "Appearance" inconsistent with the "Visual" route — `inconsistent naming`.
- Billing page mixes "subscription", "plan", "Clarity+" — `inconsistent naming`.

**`/about`, `/help`**
- Anchored sections "How it works" and "Your privacy" — `unclear section header` (no visible anchors in nav apart from Menu rows).
- Help FAQ uses "premium" interchangeably with "Clarity+" — `inconsistent naming`.

**`/auth`**
- Toggle between "Log in" / "Create account" / "Sign in" / "Sign up" across surfaces — `inconsistent naming`.

**Onboarding (`/onboarding`, `/onboarding/light`, `/onboarding/deep`, `/onboarding/deep/intro`)**
- Intro copy refers to "your mind" repeatedly — `outdated tone` in places.
- "Meet Your Mind" component title (`src/components/ftue/MeetYourMind.tsx`) — `outdated tone` against the current grounded/reflective tone reference.

**Cross-cutting**
- "Reflection" vs "Question" used interchangeably across Menu, Home CTA, and pages — `inconsistent naming`.
- "Patterns" vs "Moments" used interchangeably between BottomNav (Moments) and Menu/Home (Patterns) — `inconsistent naming`.
- "Insights" ambiguously used for Module #13 page, BottomNav Tools label, and Menu section — `inconsistent naming`.

---

## 10. Structural issues list (Module 9)

Categories used: `duplicated menu item`, `duplicated category`,
`inconsistent grouping`, `feature in the wrong place`,
`candidate for merge`, `candidate for separation`, `candidate for rename`.

| Location | Observation | Category |
|---|---|---|
| TopBar Menu — "Fast Clarity" appears in both Questions and Helpful Tools | — | `duplicated menu item` |
| TopBar Menu — "Helpful Tools" section vs `/tools` tab | — | `duplicated category` |
| TopBar Menu — "Insights" section contains both Module #13 ("Your Insights") and the legacy flow ("Your Patterns", "Your Story") | — | `inconsistent grouping` |
| TopBar Menu — "Trends" listed under Insights but routes to `/dashboard` (Analytics) | — | `feature in the wrong place` |
| TopBar Menu — "Share Your Clarity" routes to `/history` under "Shared Clarity" | — | `feature in the wrong place` |
| TopBar Menu — "Calm" listed under "Helpful Tools" but is a Tools-tab item | — | `feature in the wrong place` |
| BottomNav — "Insights" label points to `/tools`, while `/insights` is Module #13 (Moments tab) | — | `inconsistent grouping` |
| `/patterns` and `/insights` rendering the same component | — | `candidate for merge` |
| `/insights/flow` and `/insights` (Module #13) | — | `candidate for merge` (or `candidate for separation` if the flow is meant to be a different surface) |
| `src/pages/InsightsPage.tsx` (unrouted) and `src/pages/insights/PremiumInsightsPage.tsx` | — | `candidate for merge` |
| `src/premium/Pricing.tsx` and `src/premium/clarityPlus/PricingPage.tsx` | — | `candidate for merge` |
| `/two-person` and `/two-person-room` | — | `candidate for merge` |
| `/settings` and `/you` rendering the same component | — | `candidate for merge` |
| `/thoughts`, `/reflect`, `/new` rendering `NewSession` | — | `candidate for merge` |
| `ToolsPage.tsx` hidden cards (`Fast Clarity`, `Shared Clarity`, `Compose`) | — | `candidate for separation` (if intended for elsewhere) or removal candidates |
| `/dashboard` titled differently from its Menu label "Trends" | — | `candidate for rename` |
| `/safety/resources` page reached via three different labels ("Calm", "Grounding & support", "Safety resources") | — | `candidate for rename` |
| Tools card label "Grounding & support" vs approved "Calm" | — | `candidate for rename` |
| Tools card label "Your history" vs approved "History" | — | `candidate for rename` |
| `MeetYourMind` onboarding component name vs current tone reference | — | `candidate for rename` (label only, not file) |
| TopBar Menu sub-items "What you unlock" / "Plans & pricing" | — | `candidate for rename` |
| Menu category labels "Today" / "Questions" / "Insights" duplicate root tab labels and could read as redundant grouping | — | `inconsistent grouping` |

---

## 11. Recommended merges (Module 10)

Recommendations only; no action taken.

- **Insights surfaces.** Merge `/insights/flow`, the legacy
  `src/pages/InsightsPage.tsx` (unrouted), and the various
  `pages/insights/sections/*` reads into the Module #13 surface at
  `/insights` (and its `/patterns` alias). Cross-refs: §5 (Insights surface,
  Insights legacy file), §6 (`InsightsPage.tsx`, `Insights.flow.tsx`,
  `PremiumPreviewSection`, `PatternsSection`), §7 (Your Story, Your
  Patterns, Trends), §10 (`candidate for merge`).
- **Pricing surfaces.** Merge `src/premium/Pricing.tsx` into
  `src/premium/clarityPlus/PricingPage.tsx`, sourced from Module #14's
  `getSubscriptionMetadata`. Cross-refs: §5 (Pricing), §6
  (`Pricing.tsx`), §8 (Clarity Free / Clarity Plus / Clarity+), §10
  (`candidate for merge`).
- **Two-Person surfaces.** Merge `/two-person-room` into `/two-person`
  unless there is a flow reason to keep the room as a separate URL.
  Cross-refs: §5 (Two-Person), §10 (`candidate for merge`).
- **Reflect surface URLs.** Treat `/thoughts`, `/reflect`, `/new` as a
  single canonical surface (the BottomNav alias plus the Menu link plus
  the legacy URL). Cross-refs: §5 (Reflect surface), §10
  (`candidate for merge`).
- **Settings surface URLs.** Treat `/you` and `/settings` as one canonical
  surface. Cross-refs: §5 (Settings index), §10 (`candidate for merge`).
- **Helpful Tools concept.** Collapse the TopBar Menu "Helpful Tools"
  section into the Tools tab so a single grouping owns Calm, Quick Prompts,
  Folders, History. Cross-refs: §5 (Helpful Tools concept), §7 (Calm,
  Quick Prompts), §10 (`duplicated category`).

## 12. Recommended deletions (Module 10)

Recommendations only; nothing has been deleted.

- **`src/pages/InsightsPage.tsx`** — unrouted legacy page superseded by
  Module #13. Cross-refs: §6, §11 (Insights merge).
- **`src/premium/Pricing.tsx`** — superseded by `PricingPage.tsx` once the
  pricing merge above lands. Cross-refs: §6, §11.
- **Legacy redirect routes** `/patterns/dashboard`, `/patterns/timeline`,
  `/patterns/heatmap`, `/patterns/clusters`, `/patterns/profile`,
  `/premium`, `/demo/premium`, `/analytics/premium`, `/dev/features` —
  candidates for removal once external links no longer rely on them.
  Cross-refs: §2, §6.
- **Hidden `ToolsPage` cards** (`Fast Clarity`, `Shared Clarity`,
  `Compose`) — currently dead branches via `false && item`. Cross-refs:
  §6, §8, §10 (`candidate for separation`).
- **`src/pages/Index.tsx`** — explicitly retained-but-not-routed; deletable
  once Phase 1 references are reconciled. Cross-refs: §2.

## 13. Recommended renames (Module 10)

Visible labels only.

- TopBar Menu category "Helpful Tools" → align with Tools-tab vocabulary
  (or remove per §11). Cross-refs: §5, §10 (`duplicated category`).
- TopBar Menu item "Share Your Clarity" (→ `/history`) → align with
  History naming. Cross-refs: §7, §8, §10 (`feature in the wrong place`).
- TopBar Menu item "What you unlock" / "Plans & pricing" → align with
  Module #14 vocabulary. Cross-refs: §8.
- Tools card "Grounding & support" → "Calm". Cross-refs: §7, §8.
- Tools card "Your history" → "History". Cross-refs: §8, §10.
- `/dashboard` page title "Analytics" → "Trends" (label only).
  Cross-refs: §7, §8, §10 (`candidate for rename`).
- `Pricing.tsx` "Clarity Free" → "Free"; mixed "Clarity Plus" → "Clarity+".
  Cross-refs: §8 (`stale tier name`, `inconsistent naming`).
- BottomNav fourth-tab label "Insights" pointing at `/tools` reads against
  the Insights tab in approved naming; the labelling vs target needs
  reconciliation at the labelling level. Cross-refs: §10
  (`inconsistent grouping`). Note: the tab label text itself is governed
  by Module #2 and is therefore flagged here as observation only.
- "MeetYourMind" onboarding visible header, where it shows as user-facing
  copy. Cross-refs: §8.

## 14. Pages requiring full rewrites (Module 10)

Surfaces where wording, structure, and logic all need substantial work.

- **`/insights/flow` (`src/pages/insights/Insights.flow.tsx`)** — abstract
  language, parallel logic to Module #13, redundant sections, mixed
  vocabulary. Cross-refs: §3, §6, §7, §8, §10, §11.
- **`src/pages/InsightsPage.tsx` (unrouted legacy)** — heavy use of
  abstract concepts ("loops"), outdated tone, stale tier naming, and
  partial wiring. Cross-refs: §6, §8, §11.
- **`/dashboard` (`src/pages/Analytics.tsx`)** — naming mismatch with
  Trends, developer-style component headers, structure is analytics-page
  rather than Trends-engine-aligned. Cross-refs: §7, §8, §9.
- **`/clarity-plus/pricing` (`PricingPage.tsx`) + `src/premium/Pricing.tsx`**
  — duplicated rendering, mixed brand strings, stale tier copy.
  Cross-refs: §5, §6, §8, §11.
- **`/about` and `/help`** — static content predating current naming and
  Module #14 metadata. Cross-refs: §8.
- **`/onboarding`, `/onboarding/light`, `/onboarding/deep`,
  `/onboarding/deep/intro`** — tone mismatches and "Meet Your Mind"
  framing. Cross-refs: §8 (Onboarding).

## 15. Pages requiring minor alignment (Module 10)

Surfaces where small label/wording swaps would suffice.

- **`/home` (`src/pages/Home.tsx`)** — tightening of three section
  headings and the two CTA labels; minor capitalization sweep. Cross-refs:
  §8 (Home).
- **`/tools` (`src/pages/ToolsPage.tsx`)** — header sentence and two card
  labels. Cross-refs: §8 (Tools).
- **`/safety/resources`** — single-label alignment to "Calm".
  Cross-refs: §7, §8.
- **`/folders` and `/folders/:id`** — section-header polish.
  Cross-refs: §8.
- **`/history`** — header tone polish. Cross-refs: §8.
- **`/settings`, `/settings/billing`** — minor brand-naming consistency
  pass (Clarity+ vs Clarity Plus vs premium). Cross-refs: §8.
- **`/auth`** — unify "Log in / Sign in" and "Create account / Sign up".
  Cross-refs: §8.
- **TopBar Menu (`src/components/TopBar.tsx`)** — section-label and
  sub-item polish; redundancy resolution would be the bigger move
  (covered in §11).

---

## 16. Open questions

- Is `/insights/flow` intended to remain as a separate surface or is it slated to be folded into the Module #13 Insights page?
- Is the `/patterns` route intended to remain a permanent alias of `/insights`, or is it the canonical Moments surface that should diverge over time?
- Is the BottomNav fourth-tab label ("Insights" pointing at `/tools`) intentionally inverted relative to `/insights`, or is the labelling a Module #2 decision that this audit should not question?
- Should `src/premium/Pricing.tsx` be retired now that Module #14 owns pricing metadata, or is it still a legitimate alternate renderer?
- Is the legacy `src/pages/InsightsPage.tsx` intentionally retained on disk (parallel to `src/pages/Index.tsx`) or is its presence simply a leftover?
- Are the hidden `ToolsPage` cards (`Fast Clarity`, `Shared Clarity`, `Compose`) waiting on a future module that will re-enable them?
- Is "Trends" intended to mean `/dashboard` (Analytics) or is a separate Trend-Engine-aligned surface planned?
- Should "Helpful Tools" remain as a Menu category alongside the Tools tab, or be merged?
- Is "Share Your Clarity" intended to point at `/history` permanently, or is a dedicated sharing surface planned?
- Is the `/two-person-room` route intentionally separate from `/two-person`?
- Are the sliders in `/settings/visual` intended to remain as raw controls, or is a tone pass planned?
- Is "MeetYourMind" intended to remain as visible onboarding wording, or is it a working title?
- Are the legacy `/patterns/*`, `/premium`, `/demo/premium`, `/analytics/premium`, `/dev/features` redirects still needed for external links?
- Is the placeholder copy in Home Section C ("Your story is still gathering shape…") intended to ship as the empty state long-term?
- Is the empty-input wiring in Module #13 (`profile = {}`, `recentSnapshots = []`) the intended interim, with real wiring owned by a later module?
