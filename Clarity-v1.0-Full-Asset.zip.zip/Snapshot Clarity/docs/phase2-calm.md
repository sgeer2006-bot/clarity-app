# Phase 2 — Calm Design System

## Overview
Phase 2 introduced the Calm design system: a token-driven foundation (`--calm-*` CSS variables), composable primitives, calm typography, motion utilities, a layout shell integration, a premium-only visual layer, and a guided FTUE ("Meet Your Mind"). The work is visual and structural; it does not alter routes, business logic, analytics, auth, or feature gates.

## Folder map
- `src/components/calm/` — tokens (`tokens.css`), primitives (`CalmPrimitives`, `CalmText`, `CalmSectionHeader`), motion (`CalmMotion`, `motion.css`), `PremiumCalmLayer`, `ShellPrimaryNav`
- `src/components/ftue/` — `MeetYourMind` guided onboarding component
- `src/components/layout/AppShell.tsx` — shell integration (premium layer wrap)
- `src/pages/insights/sections/` — Insights surfaces adopting Calm primitives
- `src/pages/Analytics.tsx` — analytics overview adoption

## How to use

Import a primitive:
```ts
import { CalmSection, CalmText, CalmStack } from "@/components/calm";
```

Wrap premium content in the calm layer (gated):
```tsx
import { PremiumCalmLayer } from "@/components/calm";
import { canUse } from "@/lib/featureGate";

{canUse("premium_calm_layer") ? (
  <PremiumCalmLayer>{children}</PremiumCalmLayer>
) : children}
```

Use motion primitives:
```ts
import { FadeIn, HoverScale } from "@/components/calm";
```

## Acceptance checklist
- `tsc --noEmit` passes
- No route changes
- No analytics, auth, or feature-gate changes
- FTUE state is local only (no persistence beyond existing `clarity.onboarding.done`)

## Cleanup notes (deferred)
- Move legacy components from `CalmPrimitives.tsx` into `src/components/calm/legacy.tsx`
- Remove unused files surfaced during Phase 2 audits
- Consolidate calm exports for ergonomic imports
- Add unit tests for Calm primitive exports
